﻿namespace SF.ConstandDataModel
{
    using Newtonsoft.Json;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;

    public class NIDList
    {
        private static string DirectoryPath => Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        public List<NIDFormat> Prop { get; set; }

        public static NIDList Load()
        {
            return JsonConvert.DeserializeObject<NIDList>(File.ReadAllText($@"{DirectoryPath}\Data\json_data\nationalid.json"));
        }
    }

    public class NIDFormat
    {
        public string Country_Code { get; set; }
        public string Country { get; set; }
        public string National_ID_Type { get; set; }
        public string National_ID_Desc { get; set; }
        public string Display_Format { get; set; }
        public string Regular_Expression { get; set; }
    }

}
