﻿/// <summary>
/// Runtime Data Store
/// </summary>
namespace SF.FieldGlassBO
{
    using SF.Parameter;
    using System;
    public class JobRequisitionData
    {
        [ColumnHeader(0, "Generate")]
        public bool Generate { set; get; } = false;
        [ColumnHeader(1, "Job Requisition ID")]
        public string JobId { get; set; } = string.Empty;
        [ColumnHeader(2, "Job Requisition Name")]
        public string JobName { get; set; } = string.Empty;
        [ColumnHeader(3, "Country")]
        public string JobCountry { get; set; } = string.Empty;
        [ColumnHeader(4, "Department ID")]
        public string Department { get; set; } = string.Empty;
        [ColumnHeader(5, "Job Classification ID")]
        public string JobCode { get; set; } = string.Empty;
        [ColumnHeader(6, "Rank")]
        public string Rank { get; set; } = string.Empty;
        [ColumnHeader(7, "Location")]
        public string JobLocation { get; set; } = string.Empty;
        [ColumnHeader(8, "Minmum Rate")]
        public double MinimumRate { get; set; } = 0;
        [ColumnHeader(9, "Maximum Rate")]
        public double MaximumRate { get; set; } = 0;
        [ColumnHeader(10, "Engagement Name")]
        public string EngagementName { get; set; } = string.Empty;
        public JobSeeker Job_Seeker { get; set; } = new JobSeeker();
        public WorkerOrder Worker_Order { get; set; } = new WorkerOrder();
        public int NumberOfPosition { get; set; } = 0;
    }

    public class JobSeeker
    {
        public string Id { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string SecurityId { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string EmailId { get; set; } = string.Empty;
        public DateTime AvailableFrom { get; set; } = DateTime.MinValue;
    }

    public class WorkerOrder
    {
        public string WorkerOrderId { get; set; } = string.Empty;
        public string WorkerOrderState { get; set; } = string.Empty;
        public DateTime StartDate { get; set; } = DateTime.MinValue;
        public DateTime EndDate { get; set; } = DateTime.MinValue;
    }

}
