﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{
    public class Constants
    {
        /// <summary>
        /// This will be used for the no of months
        /// </summary>
        public static int MonthsCount = 12;

        /// <summary>
        /// This will print - 10 times
        /// </summary>
        public static string _Char10 = new string('-', 10);

        public static readonly string AVPass = "API Validation Passed!";
        public static readonly string AVFail = "API Validation Failed!";
        public static readonly string TVPass = "TDDH Validation Passed!";
        public static readonly string TVFail = "TDDH Validation Failed!";
        public static readonly string CoreHR = "CoreHR";
        public static readonly string Foundation = "Foundation";
        public static readonly string NoRun = "No Run";
        public static readonly string ACPass = "Data Upsert Success!";
        public static readonly string ACFail = "Data Upsert Failed!";
        public static readonly string TST1 = "TST1";
        public static readonly string ITSDEV1 = "ITSDEV1";
    }
}