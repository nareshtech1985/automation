﻿using System;

namespace SF.Parameter
{
    public class BaseParameter
    {
        [ColumnHeader(999, "Run # / Date")]
        public int rowKey { get; set; }

        public static int TotalRecords { get; set; }
        public string ClassName { get; set; }
        public string file { get; set; }

        [ColumnHeader(1, "GUI")]
        public string personIdExternal { get; set; } = string.Empty;

        [ColumnHeader(2, "USERID")]
        public string userId { get; set; } = string.Empty;

        [ColumnHeader(3, "EFFECTIVE START DATE")]
        public DateTime startDate { get; set; }

        public DateTime endDate { get; set; }

        public string ParameterShort
        {
            get
            {
                if (userId.Equals(personIdExternal))
                { return $"{personIdExternal}-{startDate:yyyy-MM-dd}"; }
                else if (userId.Equals(string.Empty) && personIdExternal.Equals(string.Empty))
                { return $"Invalid Data"; }
                else if (userId.Equals(string.Empty) && !personIdExternal.Equals(string.Empty))
                { return $"{personIdExternal}-{startDate:yyyy-MM-dd}"; }
                else if (!userId.Equals(string.Empty) && personIdExternal.Equals(string.Empty))
                { return $"{userId}-{startDate:yyyy-MM-dd}"; }
                else
                { return $"startDate-{startDate:yyyy-MM-dd}"; }
            }
        }

        [ColumnHeader(95, "API CALL STATUS")]
        public string api_c_status { get; set; } = "No Run";

        [ColumnHeader(96, "API VALIDATION STATUS")]
        public string api_v_status { get; set; } = "No Run";

        [ColumnHeader(97, "TDDH DB STATUS")]
        public string db_v_status { get; set; } = "No Run";
    }
}