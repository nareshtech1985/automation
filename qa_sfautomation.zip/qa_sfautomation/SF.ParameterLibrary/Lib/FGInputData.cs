﻿/// <summary>
/// Business Objects for the input and output data 
/// </summary>
namespace SF.FieldGlassBO
{
    using SF.Parameter;

    public class FGInputData 
    {
        [ColumnHeader(0,"Request Type")]
        public string RequestType { get; set; }
        [ColumnHeader(1, "Country")]
        public string CountryValue { get; set; }
        [ColumnHeader(2, "Rank")]
        public string RankValue { get; set; }
        [ColumnHeader(3,"Department")]
        public string DepartmentValue { get; set; }    
        [ColumnHeader(4,"Job Code")]
        public string JobCodeValue { get; set; }
        [ColumnHeader(5,"Location")]
        public string LocationValue { get; set; }
        [ColumnHeader(6, "Generate Data")]
        public bool IsGenerate { get; set; }
        public string JobPosting { get; set; }
    }


}
