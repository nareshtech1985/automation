﻿namespace SF.Parameter
{
    public class GlobalAssignmentParameter : BaseParameter
    {
        [ColumnHeader(4, "Host Location")]
        public string hostLocation { get; set; }
        public string newuserid { get; set; }
        [ColumnHeader(5, "Employee Class")]
        public string employeeClass { get; set; }
        [ColumnHeader(6, "Holiday Calender")]
        public string holidayCalendarCode { get; set; }
        // Management Region
        [ColumnHeader(7, "Management Region")]
        public string businessUnit { get; set; }
        [ColumnHeader(8, "Work Schedule")]
        public string workscheduleCode { get; set; }
        [ColumnHeader(9, "Employment Type")]
        public string employmentType { get; set; }
        // geographic area
        [ColumnHeader(10, "Geographic Area")]
        public string customString5 { get; set; }
        [ColumnHeader(11, "Job Code")]
        public string jobCode { get; set; }
        // Geographic Region
        [ColumnHeader(12, "Geographic Region")]
        public string customString4 { get; set; }
        // Sub Service Line
        [ColumnHeader(13, "Sub Service Line")]
        public string customString3 { get; set; }
        // rank
        [ColumnHeader(14, "Rank")]
        public string customString11 { get; set; }
        // service line
        [ColumnHeader(15, "Service line")]
        public string customString2 { get; set; }
        [ColumnHeader(16, "Event Reason")]
        public string eventReason { get; set; }
        // speciality
        [ColumnHeader(17, "Speciality")]
        public string division { get; set; }
        public string timeTypeProfileCode { get; set; }
        // Benefit Program
        [ColumnHeader(18, "Benefit Program Code")]
        public string customString146 { get; set; }
        [ColumnHeader(19, "Legal Entity")]
        public string company { get; set; }
        public string location { get; set; }
        public bool isFulltimeEmployee { get; set; } = true;
        public string managerId { get; set; } = "NO_MANAGER";
        public string fte { get; set; } = "1";
        public string standardHours { get; set; } = "40";
        public string customDouble20 { get; set; } = "40";
        [ColumnHeader(20, "GPN")]
        public string GPN { get; set; } = "";
        [ColumnHeader(21, "LPN")]
        public string LPN { get; set; } = "";
        [ColumnHeader(22, "Department ID")] public string department { get; set; }
    }
}
