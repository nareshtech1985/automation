﻿using System;

namespace SF.Parameter
{
    public class DataChangeParameter : BaseParameter
    {
        [ColumnHeader(4, "GPN")]
        public string gpn { get; set; } = null;
        [ColumnHeader(5, "LPN")]
        public string lpn { get; set; } = null;
        public DateTime terminatedDate { get; set; }
        public string changetype { get; set; }
        [ColumnHeader(6, "Department ID")]
        public string departmentid { get; set; }
        public string EmplStatus { get; set; }
        [ColumnHeader(7, "Event Reason")]
        public string eventReason { get; set; }
        [ColumnHeader(8, "FTE ")]
        public string fte { get; set; }
        [ColumnHeader(9, "FTE Hours")]
        public string ftehours { get; set; }
        [ColumnHeader(10, "Hire Date")]
        public DateTime hireDate { get; set; }
        [ColumnHeader(11, "Job Code")]
        public string jobcode { get; set; }
        [ColumnHeader(12, "Location")]
        public string location { get; set; }
        [ColumnHeader(13, "Location Desc")]
        public string locationDesc { get; set; }
        [ColumnHeader(14, "Counselor")]
        public string managerId { get; set; } = "NO_MANAGER";
        [ColumnHeader(15, "Original Start Date")]
        public DateTime originalStartDate { get; set; }
        [ColumnHeader(16, "Standard Hours")]
        public string standardHours { get; set; }
        [ColumnHeader(17, "Legal Entity/Company")]
        public string company { get; set; }
        [ColumnHeader(18, "Management Region Id")]
        public string managementregionid { get; set; }
        [ColumnHeader(19, "Speciality")]
        public string speciality { get; set; }
        [ColumnHeader(20, "Management Country Id")]
        public string managementcountryid { get; set; }
        [ColumnHeader(21, "Sub Service Line")]
        public string subservicelineid { get; set; }
        [ColumnHeader(22, "Country")]
        public string country { get; set; }
        [ColumnHeader(23, "Service Line ID")]
        public string serviceLineId { get; set; }
        [ColumnHeader(24, "Employee Class")]
        public string employeeClass { get; set; }
        public string employeeClassCode { get; set; }
        [ColumnHeader(25, "Employment Type")]
        public string employmentType { get; set; }
        public string employmentTypeCode { get; set; }
        /// <summary>
        /// Rank
        /// </summary>
        [ColumnHeader(26, "Rank ID")]
        public string customString11 { get; set; }
        public string IsSameMR { get; set; }
    }
}