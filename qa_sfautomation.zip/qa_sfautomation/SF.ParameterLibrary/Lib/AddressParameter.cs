﻿namespace SF.Parameter
{
    public class AddressParameter : BaseParameter
    {
        [ColumnHeader(4, "ADDRESS TYPE")]
        public string addressType { get; set; } = null;
        [ColumnHeader(5, "ADDRESS LINE 1")]
        public string address1 { get; set; } = null;
        [ColumnHeader(6, "ADDRESS LINE 2")]
        public string address2 { get; set; } = null;
        [ColumnHeader(7, "ADDRESS LINE 3")]
        public string address3 { get; set; } = null;
        [ColumnHeader(8, "ADDRESS LINE 4")]
        public string address4 { get; set; } = null;
        [ColumnHeader(9, "ADDRESS LINE 5")]
        public string address5 { get; set; } = null;
        [ColumnHeader(10, "CITY")]
        public string city { get; set; } = null;
        [ColumnHeader(11, "COUNTY")]
        public string county { get; set; } = null;
        [ColumnHeader(12, "PROVINCE")]
        public string province { get; set; } = null;
        [ColumnHeader(13, "STATE")]
        public string state { get; set; } = null;
        [ColumnHeader(14, "ZIP CODE")]
        public string zipCode { get; set; } = null;
        [ColumnHeader(15, "COUNTRY")]
        public string country { get; set; } = null;

    }
}