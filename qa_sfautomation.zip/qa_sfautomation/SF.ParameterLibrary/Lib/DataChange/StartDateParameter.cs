﻿namespace SF.Parameter
{
    using System;
    public class StartDateParameter : DataChangeParameter
    {
        [ColumnHeader(4, "New Start Date")]
        public DateTime newstartdate { get; set; }
    }
}