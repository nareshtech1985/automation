﻿namespace SF.Parameter
{
    public class ClassChangeParameter : BaseParameter
    {
        [ColumnHeader(7, "Employee Class")]
        public string employeeClass { get; set; }
        public string eventReason { get; set; }
        [ColumnHeader(8, "Employement Type")]
        public string employmentType { get; set; }
        public string emplStatus { get; set; }

        public string OutputString => $"User ID : {userId} \nGUI : {personIdExternal} \nEmployee Class : {employeeClass} \nEmployee Type : {employmentType}";
    }
}
