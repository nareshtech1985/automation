﻿namespace cryptic
{
    using System;
    using System.IO;
    using System.Security.Cryptography;
    using System.Text;

    public class Cred
    {

        public string Publickey { get; set; }
        private readonly string PrivateKey = "automate";

        public string Decrypt(string CypherText)
        {
            try
            {
                var toreturn = "";
                byte[] privatekeyByte = { };
                privatekeyByte = Encoding.UTF8.GetBytes(PrivateKey);
                byte[] publickeybyte = { };
                publickeybyte = Encoding.UTF8.GetBytes(Publickey);
                MemoryStream ms = null;
                CryptoStream cs = null;
                byte[] inputbyteArray = new byte[CypherText.Replace(" ", "+").Length];
                inputbyteArray = Convert.FromBase64String(CypherText.Replace(" ", "+"));
                using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
                {
                    ms = new MemoryStream();
                    cs = new CryptoStream(ms, des.CreateDecryptor(publickeybyte, privatekeyByte), CryptoStreamMode.Write);
                    cs.Write(inputbyteArray, 0, inputbyteArray.Length);
                    cs.FlushFinalBlock();
                    Encoding encoding = Encoding.UTF8;
                    toreturn = encoding.GetString(ms.ToArray());
                }
                return toreturn;
            }
            catch (Exception ae)
            {
                throw new Exception(ae.Message, ae.InnerException);
            }
        }
        public string Encrypt(string TextToCypher)
        {
            try
            {
                var ToReturn = "";
                byte[] secretkeyByte = { };
                secretkeyByte = Encoding.UTF8.GetBytes(PrivateKey);
                byte[] publickeybyte = { };
                publickeybyte = Encoding.UTF8.GetBytes(Publickey);
                MemoryStream ms = null;
                CryptoStream cs = null;
                byte[] inputbyteArray = System.Text.Encoding.UTF8.GetBytes(TextToCypher);
                using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
                {
                    ms = new MemoryStream();
                    cs = new CryptoStream(ms, des.CreateEncryptor(publickeybyte, secretkeyByte), CryptoStreamMode.Write);
                    cs.Write(inputbyteArray, 0, inputbyteArray.Length);
                    cs.FlushFinalBlock();
                    ToReturn = Convert.ToBase64String(ms.ToArray());
                }
                return ToReturn;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex.InnerException);
            }
        }
    }


}
