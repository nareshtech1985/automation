﻿namespace SF.Parameter
{
    using System;
    using System.Collections.Generic;

    public class ColumnHeader : Attribute
    {
        private string _columnName = "";
        private int _index = -1;

        public ColumnHeader()
        {

        }
        public ColumnHeader(int index, string columnName)
        {
            _index = index;
            _columnName = columnName;
        }
        public string ColumnName { get => _columnName; }

        public static Dictionary<int, string> OrderHeaderList<T>(T t)
        {
            Dictionary<int, string> excelColumns = new Dictionary<int, string>();
            var props = t.GetType().GetProperties();
            int _Index = 11;
            foreach (var p in props)
            {
                try
                {
                    if (p.GetCustomAttributes(false).Length != 0)
                    {
                        for (int i = 0; i < p.GetCustomAttributes(false).Length; i++)
                        {
                            var prp = p.GetCustomAttributes(false).GetValue(i);
                            if (prp.GetType().Name.Equals(nameof(ColumnHeader)))
                            {
                                ColumnHeader o = (ColumnHeader)prp;
                                if (o != null)
                                {
                                    if (!excelColumns.ContainsKey(o._index))
                                    {
                                        excelColumns.Add(o._index, o.ColumnName);
                                    }
                                    else
                                    {
                                        excelColumns.Add(_Index++, o.ColumnName);
                                    }

                                }
                            }
                        }
                    }
                }
                catch (Exception e) { Console.WriteLine($"{e.Message}"); }
            }
            return excelColumns;
        }

        public static Dictionary<int, string> OrderFieldist<T>(T t)
        {
            Dictionary<int, string> excelColumns = new Dictionary<int, string>();
            var props = t.GetType().GetProperties();
            int _Index = 11;
            foreach (var p in props)
            {
                try
                {
                    for (int i = 0; i < p.GetCustomAttributes(false).Length; i++)
                    {
                        var prp = p.GetCustomAttributes(false).GetValue(i);
                        if (prp.GetType().Name.Equals(nameof(ColumnHeader)))
                        {
                            ColumnHeader o = (ColumnHeader)prp;
                            if (o != null)
                            {
                                if (!excelColumns.ContainsKey(o._index))
                                {
                                    excelColumns.Add(o._index, p.Name);
                                }
                                else
                                {
                                    excelColumns.Add(_Index++, p.Name);
                                }

                            }
                        }
                    }
                }
                catch (Exception e) { Console.WriteLine($"{e.Message}"); }
            }
            return excelColumns;
        }
    }
}