﻿namespace SF.HelperLibrary.Mapping.Helper
{
    using Microsoft.Extensions.Configuration;
    using SF.Helper;
    using System.IO;
    public class PackageInfoLoader
    {
        private const string DefaultSettingsFile = "./Data/json_data/PackageMapping.json";

        /// <summary>
        /// Loads the configuration for the given environment and tenant.
        /// If no environment or tenant is provided, then the default local config is loaded.
        /// </summary>
        /// <param name="environment">The environment to point to.</param>
        /// <param name="tenant">The country to target.</param>
        /// <returns>The relevant configuration for .</returns>
        public static PackageMap Load(string environment = "")
        {
            string targetJsonFile = DefaultSettingsFile;

            if (!string.IsNullOrWhiteSpace(environment))
            {
                targetJsonFile = $"./Data/json_data/PackageMapping.{environment}.json";
            }

            // Loads the default config, then overrides matching keys 
            // with the environment specific version
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile(DefaultSettingsFile)
                .AddJsonFile(targetJsonFile)
                .Build();

            var _configuration = new PackageMap();

            // Deserialises the config into the HostsConfiguration object
            configuration.GetSection("PackageMap").Bind(_configuration);

            return _configuration;
        }
    }
}
