﻿namespace SF.Helper
{
    using System.Collections.Generic;

    public class PackageMap
    {
        public List<JobPackage> Packs { get; set; }
    }

    public class JobPackage
    {

        public int Order { get; set; }
        public bool IsCPI { get; set; }
        public bool IsSFIC { get; set; }
        public string Group { get; set; }
        public string Table_Name { get; set; }
        public string Name { get; set; }
        public string Class_Name { get; set; }
        public string Package_Name { get; set; }
        public string Entity_Name { get; set; }
        public string Create_TC_Name { get; set; }
        public string Validate_TC_Name { get; set; }
        public string CS_File_Name { get; set; }
    }
}
