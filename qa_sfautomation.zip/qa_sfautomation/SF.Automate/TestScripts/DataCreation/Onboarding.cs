﻿namespace SF.Automate.TestScripts.DataCreation
{
    using EY_Test.PageObjects;
    using EY_Test.PageObjects.SuccessFactors;
    using EY_Test.PageObjects.SuccessFactors.Onboarding;
    using EY_Test.PageObjects.SuccessFactors.SF_Pages.MPH;
    using EY_Test.TestScripts.InputObjects;
    using Fare;
    using NUnit.Framework;
    using Pom;
    using Pom.PageObjects;
    using SF.ConstandDataModel;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;

    [TestFixture]
    public class Onboarding : TestRunner
    {
        #region variables
        private List<InputTestData> datas = new List<InputTestData>();
        private OnboardingDashboard dashboard;
        private LoginPage login;
        private Home sfhome;
        #endregion

        #region Onboarding Data Creations Scripts
        [Test]
        [Category("Onboarding-Global-WorkFlow")]
        [TestCaseSource(nameof(NonUSData))]
        public void Onboarding_GlobalWorkflow(InputTestData data)
        {
            try
            {
                login = new LoginPage(Driver);
                sfhome = login.Login();
                dashboard = (OnboardingDashboard)sfhome.NavigateTo(HomePageMenu.Onboarding);
                var workflow = dashboard.InitiateNonUSWorkflow(data);
                var names = workflow.AddPersonalInformation();
                data.firstname = names.FirstName;
                data.lastname = names.LastName;
                workflow.AddStartDate();
                workflow.AddPersonalEmail();
                workflow.AddHireInformation();
                workflow.Submit();//
                dashboard.SelectProcess("Global Workflow", names.FirstName);
                workflow.AddEmployeeClassandType();
                workflow.Next();
                //workflow.AddPersonalInformation();
                workflow.Next();
                workflow.AddNationalID();
                workflow.Next();
                workflow.AddOrgInformation();
                workflow.Next();
                workflow.AddStandardHours();
                workflow.Next();
                workflow.AddOtherJobInformations();
                workflow.Next(); workflow.Next();
                var idtvalue = workflow.PerformIDTSearchAndUpdateInfo();
                data.GUI = idtvalue.gui;
                data.GPN = idtvalue.gpn;
                data.LPN = idtvalue.lpn;
                workflow.PerformPreverification();
                workflow.Submit();
                var e = false;
                do
                {
                    dashboard.SelectProcess("Global Workflow", names.FirstName);
                    e = workflow.VerifyTDDHExportStatus();
                    if (!e)
                    {
                        workflow.Cancel();
                    }
                    else
                    {
                        workflow.Submit();
                    }
                } while (!e);
                dashboard.Exit();

                //var mph = (ManagePendingHireList)sfhome.NavigateToManagePendingHires("Manage Pending Hires");
                //mph.ChoosePage();//default onboarding
                //mph.ApplyFilter(names.FirstName, names.LastName);
                //var addnewemp = mph.SelectFirstRecord();
                //addnewemp.ClickContinue(Section.IDENTITY);
                //addnewemp.UpdateAddress();
                //addnewemp.UpdateEmailAddress();
                //addnewemp.ClickContinue(Section.PERSONAL);
                //addnewemp.UpdateJobinformationData();
                //addnewemp.UpdateTimeProfile();
                //addnewemp.ClickContinue(Section.JOB);
                //addnewemp.ClickContinue(Section.COMPENSATION);
                //addnewemp.Submit();

            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
            }
            finally
            {
                ExcelWorkBook.CreateOnboardingReport(data);
            }

        }

        [Test]
        [Category("Onboarding-US-WorkFlow")]
        public void Onboarding_USWorkflow()
        {
            try
            {
                login = new LoginPage(Driver);
                sfhome = login.Login();
                dashboard = (OnboardingDashboard)sfhome.NavigateTo(HomePageMenu.Onboarding);
                var workflow = dashboard.InitiateUSWorkflow();

                workflow.AddNewJoinerInfo();
                workflow.Next();
                var names = workflow.AddNameInformation();
                workflow.UpdateJobClassification();
                workflow.Next();
                workflow.AddEmploymentDetails();
                workflow.AddTime();
                workflow.AddCompensation();
                workflow.Next();
                workflow.AddNationalID();
                workflow.Next();
                workflow.PerformIDTSearchAndUpdateInfo();
                workflow.PerformPreverification();
                workflow.Submit();

                var e = false;
                for (int i = 0; i < 2; i++)
                {
                    do
                    {
                        Thread.Sleep(1000);
                        dashboard.SelectProcess("US Workflow", names.FirstName);
                        e = workflow.VerifySystemValidationStatus();
                        if (!e)
                        {
                            workflow.Cancel();
                        }
                        else
                        {
                            workflow.Submit();
                        }
                    } while (!e);
                }

                //dashboard.SelectProcess("US Workflow", names.FirstName);
                //workflow.Submit();

                dashboard.Exit();

                //var mph = (ManagePendingHireList)sfhome.NavigateToManagePendingHires("Manage Pending Hires");
                //mph.ChoosePage();//default onboarding
                //mph.ApplyFilter(names.FirstName, names.LastName);
                //var addnewemp = mph.SelectFirstRecord();

                //addnewemp.ClickContinue(Section.IDENTITY);
                //addnewemp.UpdateAddress();
                //addnewemp.UpdateEmailAddress($"{names.FirstName}.{names.LastName}@gmail.com");
                //addnewemp.ClickContinue(Section.PERSONAL);
                //addnewemp.UpdateCounselor();
                //addnewemp.UpdateTimeProfile();
                //addnewemp.ClickContinue(Section.JOB);
                //addnewemp.ClickContinue(Section.COMPENSATION);
                //addnewemp.Submit();
            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
            }
        }

        [Test]
        [Category("Submit Pending MPH Requests")]
        [TestCaseSource(nameof(MPHData))]
        public void Process_Recods_From_MPH(InputTestData temp)
        {
            login = new LoginPage(Driver);
            sfhome = login.Login();
            var mph = (ManagePendingHireList)sfhome.NavigateToManagePendingHires("Manage Pending Hires");
            mph.ChoosePage();//default onboarding
            mph.ApplyFilter(temp.firstname, temp.lastname);
            var addnewemp = mph.SelectFirstRecord();
            if (addnewemp != null)
            {
                addnewemp.ClickContinue(Section.IDENTITY);
                addnewemp.UpdateAddress();
                addnewemp.UpdateEmailAddress($"{temp.firstname}.{temp.lastname}@gmail.com");
                addnewemp.ClickContinue(Section.PERSONAL);
                addnewemp.UpdateJobinformationData();
                addnewemp.UpdateTimeProfile();
                addnewemp.ClickContinue(Section.JOB);
                addnewemp.ClickContinue(Section.COMPENSATION);
                addnewemp.Submit();
            }

        }

        [Test, Category("Generate NID")]
        [TestCaseSource(nameof(NonUSData))]
        public void GenerateNationalID(InputTestData data)
        {
            TestLog.Info($"Country : {data.country}\tRank : {data.rank}");

            NIDFormat iDFormat = new NIDFormat();
            var random = new Random();
            var nidlist = NIDList.Load().Prop.FindAll(x => x.Country.ToLower().Equals(data.country.ToLower()));
            if (nidlist.Count > 1)
            {
                iDFormat = nidlist[random.Next(nidlist.Count)];
            }
            else if (nidlist.Count == 1)
            {
                iDFormat = nidlist[0];
            }
            else
            {
                iDFormat = new NIDFormat() { Country = "India", National_ID_Type = "Aadhaar Card No", Regular_Expression = @"[\d]{4}-[\d]{4}-[\d]{4}" };
            }

            iDFormat.Regular_Expression = iDFormat.Regular_Expression.Replace("\\d", "0-9");
            iDFormat.Regular_Expression = iDFormat.Regular_Expression.Replace("\\s", " ");
            iDFormat.Regular_Expression = iDFormat.Regular_Expression.Replace(".", @"\.");


            Xeger xeger = new Xeger(iDFormat.Regular_Expression, new Random());
            string nidvalue = xeger.Generate();
            TestLog.Info($"National ID Type : {iDFormat.National_ID_Desc} | National ID Value : {nidvalue}");
        }
        #endregion

        #region Runtime Data Mappers
        private static IEnumerable<InputTestData> MPHData
        {
            get
            {
                yield return new InputTestData() { firstname = "Dhyana", lastname = "Nabhi", GUI = "3223741", GPN = "CA014016167", LPN = "4016167", EmployeeClass = "3", EmploymentType = "U6", legalEntityId = "000065" };
                yield return new InputTestData() { firstname = "Dhani", lastname = "Kushi", GUI = "3223740", GPN = "CA014016166", LPN = "4016166", EmployeeClass = "1", EmploymentType = "US", legalEntityId = "000065" };
                yield return new InputTestData() { firstname = "Aparaajitha", lastname = "Shiny", GUI = "3223739", GPN = "CA014016165", LPN = "4016165", EmployeeClass = "3", EmploymentType = "U6", legalEntityId = "000065" };
                yield return new InputTestData() { firstname = "Dulal", lastname = "Dillon", GUI = "3223738", GPN = "CA014016164", LPN = "4016164", EmployeeClass = "1", EmploymentType = "US", legalEntityId = "000065" };
                yield return new InputTestData() { firstname = "Asmi", lastname = "Sami", GUI = "3223737", GPN = "CA014016163", LPN = "4016163", EmployeeClass = "3", EmploymentType = "U6", legalEntityId = "000065" };
                yield return new InputTestData() { firstname = "Ramaa", lastname = "Dildar", GUI = "3223736", GPN = "CA014016162", LPN = "4016162", EmployeeClass = "3", EmploymentType = "U6", legalEntityId = "000065" };
                yield return new InputTestData() { firstname = "Simi", lastname = "Salu", GUI = "3223735", GPN = "CA014016161", LPN = "4016161", EmployeeClass = "1", EmploymentType = "US", legalEntityId = "000065" };
                yield return new InputTestData() { firstname = "Ahi", lastname = "Naia", GUI = "3223734", GPN = "CA014016160", LPN = "4016160", EmployeeClass = "3", EmploymentType = "U6", legalEntityId = "000065" };
                yield return new InputTestData() { firstname = "Dodo", lastname = "Shey", GUI = "3223733", GPN = "CA014016159", LPN = "4016159", EmployeeClass = "1", EmploymentType = "US", legalEntityId = "000065" };
                yield return new InputTestData() { firstname = "Sija", lastname = "Rusham", GUI = "3223732", GPN = "CA014016158", LPN = "4016158", EmployeeClass = "3", EmploymentType = "U6", legalEntityId = "000065" };
            }
        }

        public static InputTestData[] NonUSData => ExcelWorkBook.ReadInputData<InputTestData>("GlobalWorkflow", "Onboarding").Select(x => (InputTestData)x).ToArray();
        #endregion
    }
}
