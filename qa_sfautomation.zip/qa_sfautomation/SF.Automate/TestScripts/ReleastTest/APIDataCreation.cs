﻿namespace EY_Test.TestScripts.Regression
{ using Pom; using NUnit.Framework;

    using Pom.PageObjects;
    using SF.API.UseCases;
    using SF.Parameter;
    using System.Collections.Generic;
    using System.Linq;
    using EY_Test.API.Framework;
    using EY_Test.API.Scenarios;
    using System;


    [TestFixture]
    [Category("Step 01")]
    public class APIDataCreation : TestRunner
    {
        private CoreHRScenario currentScenario;

        #region DataLoad for Creation
        private static IEnumerable<AddressParameter> AddressData() => OutputExcel.ReadTestData<AddressParameter>(CoreHRScenario.ADDRESS_CHANGE).Select(item => (AddressParameter)item);
        private static IEnumerable<BankChangeParameter> BankData() => OutputExcel.ReadTestData<BankChangeParameter>(CoreHRScenario.BANK_ACCOUNT_CHANGE).Select(item => (BankChangeParameter)item);
        private static IEnumerable<ClassChangeParameter> ClassChangeData() => OutputExcel.ReadTestData<ClassChangeParameter>(CoreHRScenario.CLASS_CHANGE).Select(item => (ClassChangeParameter)item);
        private static IEnumerable<DataChangeParameter> CounselorChangeData() => OutputExcel.ReadTestData<DataChangeParameter>(CoreHRScenario.CHANGE_COUNSELOR).Select(item => (DataChangeParameter)item);
        private static IEnumerable<DataChangeParameter> CreateConcurrentEmpData() => OutputExcel.ReadTestData<DataChangeParameter>(CoreHRScenario.CREATE_CONCURRENT_ASSIGNMENT).Select(item => (DataChangeParameter)item);
        private static IEnumerable<RankParameter> DemotionData() => OutputExcel.ReadTestData<RankParameter>(CoreHRScenario.RANK_CHANGE_DEMOTION).Select(item => (RankParameter)item);
        private static IEnumerable<DepartmentParameter> DepartmentData() => OutputExcel.ReadTestData<DepartmentParameter>(CoreHRScenario.DEPARTMENT_CHANGE).Select(item => (DepartmentParameter)item);
        private static IEnumerable<DataChangeParameter> DomesticTransferData() => OutputExcel.ReadTestData<DataChangeParameter>(CoreHRScenario.DOMESTIC_TRANSFER).Select(item => (DataChangeParameter)item);
        private static IEnumerable<DataChangeParameter> FTEHoursData() => OutputExcel.ReadTestData<DataChangeParameter>(CoreHRScenario.FTE_CHANGE).Select(item => (DataChangeParameter)item);
        private static IEnumerable<LEParameter> LegalEntityData() => OutputExcel.ReadTestData<LEParameter>(CoreHRScenario.LEGAL_ENTITY_CHANGE).Select(item => (LEParameter)item);
        private static IEnumerable<TimeOffParameter> LongTermDisabilityData() => OutputExcel.ReadTestData<TimeOffParameter>(CoreHRScenario.LONG_TERM_DISABILITY).Select(item => (TimeOffParameter)item);
        private static IEnumerable<MCParameter> ManagerialData() => OutputExcel.ReadTestData<MCParameter>(CoreHRScenario.MC_CHANGE).Select(item => (MCParameter)item);
        private static IEnumerable<TerminateParameter> NoShowData() => OutputExcel.ReadTestData<TerminateParameter>(CoreHRScenario.NO_SHOW).Select(item => (TerminateParameter)item);
        private static IEnumerable<TimeOffParameter> PaidLeaveData() => OutputExcel.ReadTestData<TimeOffParameter>(CoreHRScenario.PAID_LEAVE).Select(item => (TimeOffParameter)item);
        private static IEnumerable<RankParameter> PromotionData() => OutputExcel.ReadTestData<RankParameter>(CoreHRScenario.RANK_CHANGE_PROMOTION).Select(item => (RankParameter)item);
        private static IEnumerable<DataChangeParameter> ReturnFromGAData() => OutputExcel.ReadTestData<DataChangeParameter>(CoreHRScenario.RETURN_FROM_GLOBAL_ASSIGNMENT).Select(item => (DataChangeParameter)item);
        private static IEnumerable<TimeOffParameter> ReturnPaidLeaveData() => OutputExcel.ReadTestData<TimeOffParameter>(CoreHRScenario.RETURN_PAID_LEAVE).Select(item => (TimeOffParameter)item);
        private static IEnumerable<TimeOffParameter> ReturnUnpaidLeaveData() => OutputExcel.ReadTestData<TimeOffParameter>(CoreHRScenario.RETURN_UNPAID_LEAVE).Select(item => (TimeOffParameter)item);
        private static IEnumerable<DataChangeParameter> SendEmpGAData() => OutputExcel.ReadTestData<DataChangeParameter>(CoreHRScenario.EMP_GLOBAL_ASSIGNMENT).Select(item => (DataChangeParameter)item);
        private static IEnumerable<DataChangeParameter> StandardHoursData() => OutputExcel.ReadTestData<DataChangeParameter>(CoreHRScenario.STD_HRS_CHANGE).Select(item => (DataChangeParameter)item);
        private static IEnumerable<StartDateParameter> StartDateData() => OutputExcel.ReadTestData<StartDateParameter>(CoreHRScenario.START_DATE_CHANGE).Select(item => (StartDateParameter)item);
        private static IEnumerable<TerminateParameter> TerminateData() => OutputExcel.ReadTestData<TerminateParameter>(CoreHRScenario.TERMINATE_EMPLOYEE).Select(item => (TerminateParameter)item);
        private static IEnumerable<TimeOffParameter> UnpaidLeaveData() => OutputExcel.ReadTestData<TimeOffParameter>(CoreHRScenario.UNPAID_LEAVE).Select(item => (TimeOffParameter)item);

        #endregion DataLoad for Creation

        #region Setup and TearDown

        [TearDown]
        public void AfterTest()
        {
        }

        [SetUp]
        public void BeforeTest()
        {
            
        }

        #endregion Setup and TearDown

        #region API Data Creation

       

        [Test, TestCaseSource(nameof(AddressData))]
        public void TC001_Create_Address_ChangeData(AddressParameter parameter)
        {
            currentScenario = CoreHRScenario.ADDRESS_CHANGE;
            AddressChange.AddNewAddress(parameter);
        }

        [Test, TestCaseSource(nameof(BankData))]
        public void TC002_Create_Bank_Account_ChangeData(BankChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.BANK_ACCOUNT_CHANGE;
            BankChange.ChangeBankinfo(parameter);
        }

        [Test, TestCaseSource(nameof(CounselorChangeData))]
        public void TC003_Create_Change_CounselorData(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.CHANGE_COUNSELOR;
            CounselorChange.PerformCounselorChange(parameter);
        }

        [Test, TestCaseSource(nameof(ClassChangeData))]
        public void TC004_Create_Class_ChangeData(ClassChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.CLASS_CHANGE;
            ClassChange.PerformClassChange(parameter);
        }

        //

        //[Test, TestCaseSource(nameof(CreateConcurrentEmpData))]
        public void TC005_Create_Create_Concurrent_AssignmentData(DataChangeParameter parameter)
        {
            //currentScenario = CoreHRScenario.CHANGE_COUNSELOR;
            //CounselorChange.PerformCounselorChange(parameter);
        }

        [Test, TestCaseSource(nameof(DepartmentData))]
        public void TC006_Create_Department_ChangeData(DepartmentParameter parameter)
        {
            currentScenario = CoreHRScenario.DEPARTMENT_CHANGE;
            DepartmentChange.PerformDepartmentChange(parameter);
        }

        [Test, TestCaseSource(nameof(DomesticTransferData))]
        public void TC007_Create_Domestic_TransferData(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.DOMESTIC_TRANSFER;
            LocationChange.PerformLocationChange(parameter);
        }

        //

        //[Test, TestCaseSource(nameof(SendEmpGAData))]
        public void TC008_Create_Emp_Global_AssignmentData(DataChangeParameter parameter)
        {
        }

        [Test, TestCaseSource(nameof(FTEHoursData))]
        public void TC009_Create_Fte_ChangeData(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.FTE_CHANGE;
            FTEChange.PerformFTEHourChange(parameter);
        }

        [Test, TestCaseSource(nameof(LegalEntityData))]
        public void TC010_Create_Legal_Entity_ChangeData(LEParameter parameter)
        {
            currentScenario = CoreHRScenario.LEGAL_ENTITY_CHANGE;
            LegalEntityChange.PerformLegalEntityChange(parameter);
        }

        [Test, TestCaseSource(nameof(LongTermDisabilityData))]
        public void TC011_Create_Long_Term_DisabilityData(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.LONG_TERM_DISABILITY;
            TimeOff.ApplyLongDisability(parameter);
        }

        [Test, TestCaseSource(nameof(ManagerialData))]
        public void TC012_Create_Mc_ChangeData(MCParameter parameter)
        {
            currentScenario = CoreHRScenario.MC_CHANGE;
            ManagerialCountryChange.PerformManagerialCountryChange(parameter);
        }

        [Test, TestCaseSource(nameof(NoShowData))]
        public void TC013_Create_No_ShowData(TerminateParameter parameter)
        {
            currentScenario = CoreHRScenario.NO_SHOW;
            TerminateEmployee.PerformTermination(parameter, currentScenario);
        }

        [Test, TestCaseSource(nameof(PaidLeaveData))]
        public void TC014_Create_Paid_LeaveData(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.PAID_LEAVE;
            TimeOff.ApplyTimeOff(parameter);
        }

        [Test, TestCaseSource(nameof(DemotionData))]
        public void TC015_Create_Rank_Change_DemotionData(RankParameter parameter)
        {
            currentScenario = CoreHRScenario.RANK_CHANGE_DEMOTION;
            RankChange.PerformDemotion(parameter);
        }

        [Test, TestCaseSource(nameof(PromotionData))]
        public void TC016_Create_Rank_Change_PromotionData(RankParameter parameter)
        {
            currentScenario = CoreHRScenario.RANK_CHANGE_PROMOTION;
            RankChange.PerformPromotion(parameter);
        }

        //

        //[Test, TestCaseSource(nameof(ReturnFromGAData))]
        public void TC017_Create_Return_From_Global_AssignmentData(DataChangeParameter parameter)
        {
        }

        [Test, TestCaseSource(nameof(ReturnPaidLeaveData))]
        public void TC018_Create_Return_Paid_LeaveData(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.RETURN_PAID_LEAVE;
            TimeOff.ReturnFromLeave(parameter);
        }

        [Test, TestCaseSource(nameof(ReturnUnpaidLeaveData))]
        public void TC019_Create_Return_Unpaid_LeaveData(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.RETURN_UNPAID_LEAVE;
            TimeOff.ReturnFromLeave(parameter);
        }

        //

        //[Test, TestCaseSource(nameof(StartDateData))]
        public void TC020_Create_Start_Date_ChangeData(StartDateParameter parameter)
        {
        }

        [Test, TestCaseSource(nameof(StandardHoursData))]
        public void TC021_Create_Std_Hrs_ChangeData(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.STD_HRS_CHANGE;
            StandardHour.PerformStandardHourChange(parameter);
        }

        [Test, TestCaseSource(nameof(TerminateData))]
        public void TC022_Create_Terminate_EmployeeData(TerminateParameter parameter)
        {
            currentScenario = CoreHRScenario.TERMINATE_EMPLOYEE;
            TerminateEmployee.PerformTermination(parameter, currentScenario);
        }

        [Test, TestCaseSource(nameof(UnpaidLeaveData))]
        public void TC023_Create_Unpaid_LeaveData(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.UNPAID_LEAVE;
            TimeOff.ApplyTimeOff(parameter);
        }

        #endregion API Data Creation
    }

    public class TestInstanceParameter
    {
        public static string Category { get; set; } = "";
        public static int Count { get; set; } = 0;
        public static List<object> ParamList { get; set; } = new List<object>();
    }
}