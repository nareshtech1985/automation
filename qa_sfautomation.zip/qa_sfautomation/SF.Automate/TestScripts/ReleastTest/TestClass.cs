﻿namespace EY_Test.TestScripts.ReleastTest
{ using Pom; using NUnit.Framework;
    using NUnit.Framework.Internal;
    using Pom.PageObjects;
    using SF.Parameter;
    using SF.Parameter.Lib;
    using System;

    using System.Collections.Generic;
    using System.Linq;

    [TestFixture]
    public class TestClass
    {
        #region DataLoad for Creation

        public static IEnumerable<AddressParameter> AD() => OutputExcel.ReadTestData<AddressParameter>(CoreHRScenario.ADDRESS_CHANGE).Select(item => (AddressParameter)item);

        public static IEnumerable<AddressParameter> BD() => OutputExcel.ReadTestData<AddressParameter>(CoreHRScenario.ADDRESS_CHANGE).Select(item => (AddressParameter)item);

        public static IEnumerable<Param> CD() => OutputExcel.ReadTestData<Param>(CoreHRScenario.START_DATE_CHANGE).Select(item => (Param)item);

        #endregion

        [Test]
        [TestCaseSource(nameof(AD))]
        public void Test01(AddressParameter parameter)
        {

        }

        [Test]
        [TestCaseSource(nameof(BD))]
        public void Test02(AddressParameter parameter)
        {

        }

        [Test]
        [TestCaseSource(nameof(CD))]
        public void Test03(Param parameter)
        {

        }

        [Test]
        public void Testm()
        {
            Console.WriteLine($"Name of Method : {nameof(AD)} ");
            Console.WriteLine($"Name of Method : {nameof(CD)} ");
        }

    }
}
