﻿namespace EY_Test.TestScripts.Regression
{ using Pom; using DatabaseValidation;
    using NUnit.Framework;
    

    using SF.Parameter;
    using System;

    using System.Threading;
    using EY_Test.PageObjects;

    [TestFixture]
    [Category("Step 03")]
    public class TDDHExtraction : TestRunner
    {
        private static DateTime fileGenerateTime;       
        [Test]
        public void TC047_ZoneAToTDDH()
        {
            Driver.Manage().Window.Maximize();
            Driver.Url = "https://e2133-tmn.hci.eu1.hana.ondemand.com/itspaces/shell/design";
            Util.Updatelog("Initiate the IFlow", "Stating IFlow Jobs", Status.Done);
            fileGenerateTime = WorkFlow.Run(new WorkFlowParameter() { Driver = Driver, Type = WorkFlowType.All });

            /* Open file explorer to view the automation folder */
            int i = 0;
            Driver.Navigate().GoToUrl(Util.Settings.GetCustomKeyValue("APIAutomationFolder"));
            Util.Updatelog("Place file in batch folder", "file placed in batch folder", Status.Pass);
            do
            {
                Thread.Sleep(5000);
                Driver.Navigate().Refresh();
                i++;
            } while (i < 5);
            /* display the loader */
            Driver.Url = $@"{Util.DirectoryPath}\dataloading.html";
            if (fileGenerateTime != DateTime.MinValue)
            {
                TDDHQA.WaitForDataLoading(fileGenerateTime);
            }
            else
            {
                TDDHQA.WaitForDataLoading(DateTime.UtcNow.AddHours(3));
            }
            Thread.Sleep(TimeSpan.FromMinutes(1));
        }
    }

    [TestFixture]
    [Category("Step 04")]
    public class TDDHValidation : TestRunner
    {
        private CoreHRScenario currentScenario;

        #region TDDH Verification and Validation


        [Test, TestCaseSource(typeof(APIDataValidation),nameof(APIDataValidation.Saved_Address_Data))]
        public void TC048_Verify_Address_Change_Data_in_TDDH(AddressParameter parameter)
        {
            currentScenario = CoreHRScenario.ADDRESS_CHANGE;
            db.Validate_AddressData(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_Bank_Data))]
        public void TC049_Verify_Bank_Account_Change_Data_in_TDDH(BankChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.BANK_ACCOUNT_CHANGE;
            db.Validate_BankDetails(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_CounselorChange_Data))]
        public void TC050_Verify_Change_Counselor_Data_in_TDDH(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.CHANGE_COUNSELOR;
            db.Validate_CounselorChangeData(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_ClassChange_Data))]
        public void TC051_Verify_Class_Change_Data_in_TDDH(ClassChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.CLASS_CHANGE;
            db.Validate_ClassChange(parameter);
        }
        //
        
        //[Test, TestCaseSource(nameof(Saved_ConcurrentEmployee_Data))]
        public void TC052_Verify_Create_Concurrent_Assignment_Data_in_TDDH(DataChangeParameter parameter)
        {
            //currentScenario = CoreHRScenario.ADDRESS_CHANGE;
            //db.Validate_AddressData(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_Department_Data))]
        public void TC053_Verify_Department_Change_Data_in_TDDH(DepartmentParameter parameter)
        {
            currentScenario = CoreHRScenario.DEPARTMENT_CHANGE;
            db.Validate_Department_Change(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_DomesticTransfer_Data))]
        public void TC054_Verify_Domestic_Transfer_Data_in_TDDH(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.DOMESTIC_TRANSFER;
            db.Validate_DomesticTransferData(parameter);
        }
        //
        
        //[Test, TestCaseSource(nameof(Saved_EmpOnGA_Data))]
        public void TC055_Verify_Emp_Global_Assignment_Data_in_TDDH(DataChangeParameter parameter)
        {
            //currentScenario = CoreHRScenario.ADDRESS_CHANGE;
            //db.Validate_AddressData(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_FTEHours_Data))]
        public void TC056_Verify_Fte_Change_Data_in_TDDH(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.FTE_CHANGE;
            db.Validate_FTEChangeData(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_LegalEntiry_Data))]
        public void TC057_Verify_Legal_Entity_Change_Data_in_TDDH(LEParameter parameter)
        {
            currentScenario = CoreHRScenario.LEGAL_ENTITY_CHANGE;
            db.Validate_MCChangeRecords(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_LongTermDisability_Data))]
        public void TC058_Verify_Long_Term_Disability_Data_in_TDDH(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.LONG_TERM_DISABILITY;
            db.Validate_LongTermDisability(parameter);

        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_Managerial_Data))]
        public void TC059_Verify_Mc_Change_Data_in_TDDH(MCParameter parameter)
        {
            currentScenario = CoreHRScenario.MC_CHANGE;
            db.Validate_MCChangeRecords(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_NoShow_Data))]
        public void TC060_Verify_No_Show_Data_in_TDDH(TerminateParameter parameter)
        {
            currentScenario = CoreHRScenario.NO_SHOW    ;
            db.Validate_TerminatedRecords(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_PaidLeave_Data))]
        public void TC061_Verify_Paid_Leave_Data_in_TDDH(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.PAID_LEAVE;
            db.Vaidate_PaidLeaveData(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_Demotion_Data))]
        public void TC062_Verify_Rank_Change_Demotion_Data_in_TDDH(RankParameter parameter)
        {
            currentScenario = CoreHRScenario.RANK_CHANGE_DEMOTION;
            db.Validate_RankChange_Demotion(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_Promotion_Data))]
        public void TC063_Verify_Rank_Change_Promotion_Data_in_TDDH(RankParameter parameter)
        {
            currentScenario = CoreHRScenario.RANK_CHANGE_PROMOTION;
            db.Validate_RankChange_Promotion(parameter);
        }
        //
        
        //[Test, TestCaseSource(nameof(Saved_ReturnGA_Data))]
        public void TC064_Verify_Return_From_Global_Assignment_Data_in_TDDH(DataChangeParameter parameter)
        {
            //currentScenario = CoreHRScenario.ADDRESS_CHANGE;
            //db.Validate_AddressData(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_ReturnPaidLeave_Data))]
        public void TC065_Verify_Return_Paid_Leave_Data_in_TDDH(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.RETURN_PAID_LEAVE;
            db.Validate_ReturnFromPaidLeaveData(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_ReturnUnpaidLeave_Data))]
        public void TC066_Verify_Return_Unpaid_Leave_Data_in_TDDH(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.RETURN_UNPAID_LEAVE;
            db.Validate_ReturnFromUnPaidLeaveData(parameter);
        }
        //
        
        //[Test, TestCaseSource(nameof(Saved_StartDateDate_Data))]
        public void TC067_Verify_Start_Date_Change_Data_in_TDDH(StartDateParameter parameter)
        {
            currentScenario = CoreHRScenario.START_DATE_CHANGE;
            db.Validate_StartDateChange(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_StandardHours_Data))]
        public void TC068_Verify_Std_Hrs_Change_Data_in_TDDH(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.STD_HRS_CHANGE;
            db.Validate_StandardHourData(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_Terminate_Data))]
        public void TC069_Verify_Terminate_Employee_Data_in_TDDH(TerminateParameter parameter)
        {
            currentScenario = CoreHRScenario.TERMINATE_EMPLOYEE;
            db.Validate_TerminatedRecords(parameter);
        }
        
        
        [Test, TestCaseSource(nameof(APIDataValidation.Saved_UnpaidLeave_Data))]
        public void TC070_Verify_Unpaid_Leave_Data_in_TDDH(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.UNPAID_LEAVE;
            db.Validate_UnPaidLeaveData(parameter);

        }
        #endregion
    }
}