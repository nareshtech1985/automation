﻿namespace EY_Test.TestScripts.Regression
{ using Pom; using EY_Test.API.Scenarios;
    using EY_Test.Lib.DataHelpers;
    using NUnit.Framework;

    using SF.API.UseCases;
    using SF.Parameter;
    using System.Collections.Generic;
    using System.Linq;

    [TestFixture]
    [Category("Step 02")]
    public class APIDataValidation : TestRunner
    {
        private CoreHRScenario currentScenario;

        #region API Validation Methods


        [Test, TestCaseSource(nameof(Saved_Address_Data))]
        public void TC024_Verify_Address_Change_via_API(AddressParameter parameter)
        {
            currentScenario = CoreHRScenario.ADDRESS_CHANGE;
            TestInstanceParameter.Category = "api_validation";
            AddressChange.ValidateDataChange(parameter);
        }


        [Test, TestCaseSource(nameof(Saved_Bank_Data))]
        public void TC025_Verify_Bank_Account_Change_via_API(BankChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.BANK_ACCOUNT_CHANGE;
            TestInstanceParameter.Category = "api_validation";
            BankChange.ValidateDataChange(parameter);
        }


        [Test, TestCaseSource(nameof(Saved_CounselorChange_Data))]
        public void TC026_Verify_Change_Counselor_via_API(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.CHANGE_COUNSELOR;
            TestInstanceParameter.Category = "api_validation";
            CounselorChange.ValidateDataChange(parameter);
        }


        [Test, TestCaseSource(nameof(Saved_ClassChange_Data))]
        public void TC027_Verify_Class_Change_via_API(ClassChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.CLASS_CHANGE;
            TestInstanceParameter.Category = "api_validation";
            ClassChange.ValidateDataChange(parameter);
        }
        //

        //[Test, TestCaseSource(nameof(Saved_ConcurrentEmployee_Data))]
        public void TC028_Verify_Create_Concurrent_Assignment_via_API(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.CREATE_CONCURRENT_ASSIGNMENT;
            TestInstanceParameter.Category = "api_validation";
        }


        [Test, TestCaseSource(nameof(Saved_Department_Data))]
        public void TC029_Verify_Department_Change_via_API(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.DEPARTMENT_CHANGE;
            TestInstanceParameter.Category = "api_validation";
            DepartmentChange.ValidateDataChange(ref parameter);
        }


        [Test, TestCaseSource(nameof(Saved_DomesticTransfer_Data))]
        public void TC030_Verify_Domestic_Transfer_via_API(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.DOMESTIC_TRANSFER;
            TestInstanceParameter.Category = "api_validation";
            LocationChange.ValidateLocationChange(ref parameter);
        }
        //

        //[Test, TestCaseSource(nameof(Saved_EmpOnGA_Data))]
        public void TC031_Verify_Emp_Global_Assignment_via_API(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.EMP_GLOBAL_ASSIGNMENT;
            TestInstanceParameter.Category = "api_validation";
        }


        [Test, TestCaseSource(nameof(Saved_FTEHours_Data))]
        public void TC032_Verify_Fte_Change_via_API(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.FTE_CHANGE;
            TestInstanceParameter.Category = "api_validation";
            FTEChange.ValidateDataChange(parameter);
        }


        [Test, TestCaseSource(nameof(Saved_LegalEntiry_Data))]
        public void TC033_Verify_Legal_Entity_Change_via_API(LEParameter parameter)
        {
            currentScenario = CoreHRScenario.LEGAL_ENTITY_CHANGE;
            TestInstanceParameter.Category = "api_validation";
            LegalEntityChange.ValidateDataChange(parameter);
        }


        [Test, TestCaseSource(nameof(Saved_LongTermDisability_Data))]
        public void TC034_Verify_Long_Term_Disability_via_API(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.LONG_TERM_DISABILITY;
            TestInstanceParameter.Category = "api_validation";
            TimeOff.ValidateDataChange(parameter);
        }


        [Test, TestCaseSource(nameof(Saved_Managerial_Data))]
        public void TC035_Verify_Mc_Change_via_API(MCParameter parameter)
        {
            currentScenario = CoreHRScenario.MC_CHANGE;
            TestInstanceParameter.Category = "api_validation";
            ManagerialCountryChange.ValidateDataChange(parameter);
        }


        [Test, TestCaseSource(nameof(Saved_NoShow_Data))]
        public void TC036_Verify_No_Show_via_API(TerminateParameter parameter)
        {
            currentScenario = CoreHRScenario.NO_SHOW;
            TestInstanceParameter.Category = "api_validation";
            TerminateEmployee.ValidateDataChange(parameter, currentScenario);
        }


        [Test, TestCaseSource(nameof(Saved_PaidLeave_Data))]
        public void TC037_Verify_Paid_Leave_via_API(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.PAID_LEAVE;
            TestInstanceParameter.Category = "api_validation";
            TimeOff.ValidateDataChange(parameter);
        }


        [Test, TestCaseSource(nameof(Saved_Demotion_Data))]
        public void TC038_Verify_Rank_Change_Demotion_via_API(RankParameter parameter)
        {
            currentScenario = CoreHRScenario.RANK_CHANGE_DEMOTION;
            TestInstanceParameter.Category = "api_validation";
            RankChange.ValidateDemotionChange(parameter);
        }


        [Test, TestCaseSource(nameof(Saved_Promotion_Data))]
        public void TC039_Verify_Rank_Change_Promotion_via_API(RankParameter parameter)
        {
            currentScenario = CoreHRScenario.RANK_CHANGE_PROMOTION;
            TestInstanceParameter.Category = "api_validation";
            RankChange.ValidatePromotionChange(parameter);
        }
        //

        //[Test, TestCaseSource(nameof(Saved_ReturnGA_Data))]
        public void TC040_Verify_Return_From_Global_Assignment_via_API(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.RETURN_FROM_GLOBAL_ASSIGNMENT;
            TestInstanceParameter.Category = "api_validation";
        }


        [Test, TestCaseSource(nameof(Saved_ReturnPaidLeave_Data))]
        public void TC041_Verify_Return_Paid_Leave_via_API(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.RETURN_PAID_LEAVE;
            TestInstanceParameter.Category = "api_validation";
            TimeOff.ValidateDataChange(parameter);
        }


        [Test, TestCaseSource(nameof(Saved_ReturnUnpaidLeave_Data))]
        public void TC042_Verify_Return_Unpaid_Leave_via_API(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.RETURN_UNPAID_LEAVE;
            TestInstanceParameter.Category = "api_validation";
            TimeOff.ValidateDataChange(parameter);
        }
        //

        //[Test, TestCaseSource(nameof(Saved_StartDateDate_Data))]
        public void TC043_Verify_Start_Date_Change_via_API(StartDateParameter parameter)
        {
            currentScenario = CoreHRScenario.START_DATE_CHANGE;
            TestInstanceParameter.Category = "api_validation";
        }


        [Test, TestCaseSource(nameof(Saved_StandardHours_Data))]
        public void TC044_Verify_Std_Hrs_Change_via_API(DataChangeParameter parameter)
        {
            currentScenario = CoreHRScenario.STD_HRS_CHANGE;
            TestInstanceParameter.Category = "api_validation";
            StandardHour.ValidateDataChange(parameter);
        }


        [Test, TestCaseSource(nameof(Saved_Terminate_Data))]
        public void TC045_Verify_Terminate_Employee_via_API(TerminateParameter parameter)
        {
            currentScenario = CoreHRScenario.TERMINATE_EMPLOYEE;
            TestInstanceParameter.Category = "api_validation";
            TerminateEmployee.ValidateDataChange(parameter, currentScenario);
        }


        [Test, TestCaseSource(nameof(Saved_UnpaidLeave_Data))]
        public void TC046_Verify_Unpaid_Leave_via_API(TimeOffParameter parameter)
        {
            currentScenario = CoreHRScenario.UNPAID_LEAVE;
            TestInstanceParameter.Category = "api_validation";
            TimeOff.ValidateDataChange(parameter);
        }
        #endregion

        #region DataLoad for Validation
        public static AddressParameter[] Saved_Address_Data
        {
            get
            {
                //if (AddressChange.parameters != null && AddressChange.parameters.Count != 0) return AddressChange.parameters.ToArray();
                return RunTimeData<AddressParameter>.ReadOutputDataAsArray(CoreHRScenario.ADDRESS_CHANGE).ToArray();
            }
        }
        public static BankChangeParameter[] Saved_Bank_Data => RunTimeData<BankChangeParameter>.ReadOutputDataAsArray(CoreHRScenario.BANK_ACCOUNT_CHANGE).ToArray();
        public static ClassChangeParameter[] Saved_ClassChange_Data => RunTimeData<ClassChangeParameter>.ReadOutputDataAsArray(CoreHRScenario.CLASS_CHANGE).ToArray();
        public static DataChangeParameter[] Saved_ConcurrentEmployee_Data => RunTimeData<DataChangeParameter>.ReadOutputDataAsArray(CoreHRScenario.STD_HRS_CHANGE).ToArray();
        public static DataChangeParameter[] Saved_CounselorChange_Data => RunTimeData<DataChangeParameter>.ReadOutputDataAsArray(CoreHRScenario.CHANGE_COUNSELOR).ToArray();
        public static RankParameter[] Saved_Demotion_Data => RunTimeData<RankParameter>.ReadOutputDataAsArray(CoreHRScenario.RANK_CHANGE_DEMOTION).ToArray();
        public static DepartmentParameter[] Saved_Department_Data => RunTimeData<DepartmentParameter>.ReadOutputDataAsArray(CoreHRScenario.DEPARTMENT_CHANGE).ToArray();
        public static DataChangeParameter[] Saved_DomesticTransfer_Data => RunTimeData<DataChangeParameter>.ReadOutputDataAsArray(CoreHRScenario.DOMESTIC_TRANSFER).ToArray();
        public static DataChangeParameter[] Saved_EmpOnGA_Data => RunTimeData<DataChangeParameter>.ReadOutputDataAsArray(CoreHRScenario.STD_HRS_CHANGE).ToArray();
        public static DataChangeParameter[] Saved_FTEHours_Data => RunTimeData<DataChangeParameter>.ReadOutputDataAsArray(CoreHRScenario.FTE_CHANGE).ToArray();
        public static LEParameter[] Saved_LegalEntiry_Data => RunTimeData<LEParameter>.ReadOutputDataAsArray(CoreHRScenario.LEGAL_ENTITY_CHANGE).ToArray();
        public static TimeOffParameter[] Saved_LongTermDisability_Data => RunTimeData<TimeOffParameter>.ReadOutputDataAsArray(CoreHRScenario.LONG_TERM_DISABILITY).ToArray();
        public static MCParameter[] Saved_Managerial_Data => RunTimeData<MCParameter>.ReadOutputDataAsArray(CoreHRScenario.MC_CHANGE).ToArray();
        public static TerminateParameter[] Saved_NoShow_Data => RunTimeData<TerminateParameter>.ReadOutputDataAsArray(CoreHRScenario.NO_SHOW).ToArray();
        public static TimeOffParameter[] Saved_PaidLeave_Data => RunTimeData<TimeOffParameter>.ReadOutputDataAsArray(CoreHRScenario.PAID_LEAVE).ToArray();
        public static RankParameter[] Saved_Promotion_Data => RunTimeData<RankParameter>.ReadOutputDataAsArray(CoreHRScenario.RANK_CHANGE_PROMOTION).ToArray();
        public static DataChangeParameter[] Saved_ReturnGA_Data => RunTimeData<DataChangeParameter>.ReadOutputDataAsArray(CoreHRScenario.STD_HRS_CHANGE).ToArray();
        public static TimeOffParameter[] Saved_ReturnPaidLeave_Data => RunTimeData<TimeOffParameter>.ReadOutputDataAsArray(CoreHRScenario.RETURN_PAID_LEAVE).ToArray();
        public static TimeOffParameter[] Saved_ReturnUnpaidLeave_Data => RunTimeData<TimeOffParameter>.ReadOutputDataAsArray(CoreHRScenario.RETURN_UNPAID_LEAVE).ToArray();
        public static DataChangeParameter[] Saved_StandardHours_Data => RunTimeData<DataChangeParameter>.ReadOutputDataAsArray(CoreHRScenario.STD_HRS_CHANGE).ToArray();
        public static StartDateParameter[] Saved_StartDateDate_Data => RunTimeData<StartDateParameter>.ReadOutputDataAsArray(CoreHRScenario.START_DATE_CHANGE).ToArray();
        public static TerminateParameter[] Saved_Terminate_Data => RunTimeData<TerminateParameter>.ReadOutputDataAsArray(CoreHRScenario.TERMINATE_EMPLOYEE).ToArray();
        public static TimeOffParameter[] Saved_UnpaidLeave_Data => RunTimeData<TimeOffParameter>.ReadOutputDataAsArray(CoreHRScenario.UNPAID_LEAVE).ToArray();
        #endregion
    }
}