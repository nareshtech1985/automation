﻿/// <summary>
/// Page Object Class for the FG 'Profile Worker'
/// Created By: Samson Simon
/// Created On: 09-05-2022
/// </summary>
namespace SF.Automate.TestScripts.Regression
{
    using EY_Test.Lib.DataHelpers;
    using NUnit.Framework;
    using Pom;
    using Pom.DataHelpers;
    using Pom.PageObjects;
    using SF.Automate.PageObjects.FieldGlass;
    using SF.FieldGlassBO;
    using System;
    using System.Collections.Generic;

    [TestFixture]
    internal class FieldGlass : TestRunner
    {
        private FGLogin _fglogin;
        private FGHome _fghome;
        private FGCreateProfileWorker _fgcreateprofile;
        private FGWorkerMaster _fgworkermaster;

        private List<JobRequisitionData> jobRequisition = new List<JobRequisitionData>();

        [TearDown]
        public void SaveRunTimedata()
        {
            jobRequisition.RemoveAll(x => x.JobId.Equals(String.Empty));
            JsonHelper.SaveAsJson(jobRequisition, "JobRequisitionData");
        }

        #region Profile Worker

        /// <summary>
        /// Approve the profile worker after creating the record
        /// </summary>
        [Test]
        [Category("Profile Worker")]
        public void CreateProfileWorkerAndApprove()
        {
            if (jobRequisition.Count == 0)
            {
                jobRequisition = RunTimeData<JobRequisitionData>.ReadOutputData(nameof(JobRequisitionData));
            }

            /* Code below need to be remodified as per the progress */
            List<FGInputData> fginputs = new List<FGInputData>();
            try
            {
                fginputs = ExcelWorkBook.ReadFGInputData<FGInputData>().FindAll(x => x.IsGenerate);
            }
            catch (Exception)
            {
            }

            fginputs.ForEach(x =>
            {
                JobRequisitionData requisitionData = new JobRequisitionData()
                {
                    Department = x.DepartmentValue,
                    JobCode = x.JobCodeValue,
                    JobLocation = x.LocationValue,
                };

                try
                {
                    _fglogin = new FGLogin(Driver);
                    _fghome = _fglogin.Login();
                    _fgcreateprofile = _fghome.NavigateToCreateProfileWorker();
                    _fgcreateprofile.SelectSupplier();
                    _fgcreateprofile.SetFirstName();
                    _fgcreateprofile.SetLastName();
                    _fgcreateprofile.SetPhone();
                    _fgcreateprofile.SetEmail();
                    _fgcreateprofile.SetLegalEntity();
                    _fgcreateprofile.SetOffice(x.LocationValue);
                    _fgcreateprofile.SetHRDepartment(x.DepartmentValue);
                    _fgcreateprofile.SetPhoneAndEmailConfirmation();
                    _fgcreateprofile.SetDateofbirth();
                    _fgcreateprofile.SelectEmployeeType();
                    _fgcreateprofile.SelectCountryISO(x.CountryValue);
                    _fgcreateprofile.SelectRank(x.RankValue);
                    _fgcreateprofile.SelectJobClassification(x.JobCodeValue);
                    _fgcreateprofile.SelectActivityType();
                    _fgcreateprofile.SetStartDate();
                    _fgcreateprofile.SetEndDate();
                    _fgcreateprofile.SetSecurityID();
                    _fgcreateprofile.SetConfirmSecurityID();
                    _fgworkermaster = _fgcreateprofile.ContinueAndCreate();
                    _fgworkermaster.Approve();
                    Assert.AreEqual("Open", _fgworkermaster.GetWorkerStatus());
                }
                catch (Exception e)
                {
                    Console.WriteLine($"{e.Message}");
                    Console.WriteLine($"");
                }
                finally
                {
                    _fglogin = new FGLogin(Driver);
                }
            });
        }

        #endregion

        #region Contract Worker - USA

        /// <summary>
        /// Create a Job Requisition Record
        /// </summary>
        [Test]
        [Category("Contract Worker")]
        public void Step01_CreateJobRequisition()
        {
            List<FGInputData> fginputs = new List<FGInputData>();
            try
            {
                fginputs = ExcelWorkBook.ReadFGInputData<FGInputData>("JobRequisition").FindAll(x => x.IsGenerate);
            }
            catch (Exception)
            {
            }
            Console.WriteLine($"No of Test Data : {fginputs.Count}");
            foreach (var x in fginputs)
            {
                JobRequisitionData requisitionData = new JobRequisitionData()
                {
                    Generate = true,
                    JobCountry = x.CountryValue,
                    JobCode = x.JobCodeValue,
                    Department = x.DepartmentValue,
                    JobLocation = x.LocationValue
                };
                try
                {
                    _fglogin = new FGLogin(Driver);
                    _fghome = _fglogin.Login(AuthRole.FGHMUS);
                    var jobreq = _fghome.NavigateToCreateJobRequsistion();
                    var jrname = jobreq.GetFirstTemplateName();
                    jobreq.SelectTemplate();
                    jobreq.SetNumberOfPositions(); requisitionData.NumberOfPosition = jobreq.GetNumberOfPosition();
                    jobreq.SelectStartDate();
                    jobreq.SelectEndDate();
                    jobreq.SelectLegalEntityAs();
                    jobreq.SelectEYOfficeAs(x.LocationValue);
                    jobreq.SelectDepartmentAs(x.DepartmentValue);
                    jobreq.SelectEyBilling();
                    jobreq.AgreeWithStatements();
                    jobreq.SelectSecurityClearance();
                    jobreq.ChooseInternalTransferRequiredAs("No");
                    jobreq.ChooseCanThisBeRemoteAs("Yes");
                    jobreq.SelectBusinessReason();
                    jobreq.SetBusinessUnit();
                    jobreq.SetExperienceManager();
                    jobreq.SetNSR();
                    jobreq.SelectRelationTypeAs();
                    jobreq.SelectEngagementAs();
                    jobreq.Continue();
                    jobreq.SetMaximumRate(); requisitionData.MaximumRate = jobreq.GetMaximumRate();
                    jobreq.SetMinimumRate(); requisitionData.MinimumRate = jobreq.GetMinmumRate();
                    var jobrequ = jobreq.ContinueandCreate();
                    Assert.AreEqual("Submitted", jobrequ.GetStatus(), "Status for newly created Job requisition not matching");
                    var jr = jobrequ.GetJobRequistionNumber();
                    Util.Updatelog("Create Job Requisition ", $"Job Requisition Created {jr}", State.Pass);
                    requisitionData.JobId = jr;
                }
                catch (Exception e)
                {
                    Util.Updatelog("Create Job Requisition", $"Process Failed due to {e.Message}", State.Fail);
                    Console.WriteLine($"Error in Page {e.Message}");
                }
                finally
                {
                    jobRequisition.Add(requisitionData);
                }
            }
        }

        /// <summary>
        /// Submit a Job Seeker
        /// </summary>
        [Test]
        [Category("Contract Worker")]
        public void Step02_SubmitUSWorker()
        {
            if (jobRequisition.Count == 0)
            {
                jobRequisition = RunTimeData<JobRequisitionData>.ReadOutputData("JobRequisitionData");
            }

            if (jobRequisition.Count == 0)
            {
                //throw new FrameworkException("Input Data missing from the location or Job Requisition Test Case has failed!");
            }
            try
            {
                foreach (var x in jobRequisition)
                {
                    var jobseeker = new JobSeeker();
                    try
                    {
                        _fglogin = new FGLogin(Driver);
                        _fghome = _fglogin.Login(AuthRole.FGGIGNOW);
                        var _jbposting = _fghome.SearchJobPosting(x.JobId);
                        var _seeker = _jbposting.SubmitSeeker();
                        _seeker.SetFirstName(); jobseeker.FirstName = _seeker.GetFirstName();
                        _seeker.SetLastName(); jobseeker.LastName = _seeker.GetLastName();
                        _seeker.SetSecurityId(); jobseeker.SecurityId = _seeker.GetSecurityId();
                        _seeker.SetConfirmSecurityID();
                        _seeker.SetAvailableDate();
                        _seeker.AttachResume();
                        jobseeker.AvailableFrom = Convert.ToDateTime(_seeker.GetAvailableDate());
                        _seeker.SetIndependenceFlag();
                        _seeker.SetCandidateSourcedFromGignowAs();
                        _seeker.SetActualSupplierName();
                        _seeker.SetCommittedSpend();
                        _seeker.SetContractorEmail(); jobseeker.EmailId = _seeker.GetEmailId();
                        _seeker.SetContractorCity();
                        _seeker.SetContractorState();
                        _seeker.SelectContractorCountry();
                        _seeker.SetContractorPhone(); jobseeker.PhoneNumber = _seeker.GetPhoneNumber();
                        _seeker.HasCandidateWorkerForEYAs();
                        _seeker.IsCandidateAuthorisedtoWorkAs();
                        _seeker.SetSponsershipForEmployment();
                        _seeker.Continue(); _seeker.Continue();
                        _jbposting = _seeker.SubmitandCreate();
                        var _seekerview = _jbposting.GotoSubmittedJobSeeker();
                        jobseeker.Id = _seekerview.GetJobSeekerID();
                        Util.Updatelog("Submit a Job Seeker ", $"Job Seeker Submitted with seeker id {jobseeker.Id}", State.Pass);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine($"Submitted {e.Message}");
                        Util.Updatelog("Submit a Job Seeker ", "Job Seeker Not Submitted", State.Fail);
                    }
                    finally
                    {
                        x.Job_Seeker = jobseeker;
                        _fghome.Logout();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        /// <summary>
        /// Approve the Work Order
        /// </summary>
        [Test]
        [Category("Contract Worker")]
        public void Step03_Approve_WorkOrder_As_HiringManager()
        {
            try
            {
                if (jobRequisition.Count == 0)
                {
                    jobRequisition = RunTimeData<JobRequisitionData>.ReadOutputData("JobRequisitionData");
                }

                Console.WriteLine($"No of Test Data : {jobRequisition.Count}");
                jobRequisition.ForEach(x =>
                {
                    _fglogin = new FGLogin(Driver);
                    _fghome = _fglogin.Login(AuthRole.FGHMUS);
                    var _jobposting = _fghome.SearchJobPosting(x.JobId);
                    var _jbSeekers = _jobposting.GotoJobSeekersView();
                    var _createworkorder = _jbSeekers.Initiate_Worker_Hire(x.Job_Seeker.Id);
                    _createworkorder.Select_WorkerTypeAs();
                    _createworkorder.Select_CountryCodeAs(x.JobCountry);
                    _createworkorder.Select_RankAs(x.Rank);
                    _createworkorder.Select_JobClassificationAs(x.JobCode);
                    _createworkorder.Select_EyBillingLevelAs();
                    _createworkorder.Select_BridgeRequestTypeAs();
                    _createworkorder.Select_StandardIndependeceTermsAs("Yes");
                    _createworkorder.Set_CandidateSourceFromGignowAs("Yes");
                    _createworkorder.Set_CommittedSpendAs("10");
                    _createworkorder.Continue();
                    var _workorder = _createworkorder.SubmitAndCreate();
                    x.Worker_Order.WorkerOrderId = _workorder.GetWorkOrderId();
                    x.Worker_Order.WorkerOrderState = _workorder.GetStatus();
                });
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error in Page {e.Message}");
            }
        }

        [Test]
        [Category("Contract Worker")]
        public void Step03_Approve_WorkOrder_As_ProgramCordinator()
        {
            try
            {
                if (jobRequisition.Count == 0)
                {
                    jobRequisition = RunTimeData<JobRequisitionData>.ReadOutputData("JobRequisitionData");
                }

                Console.WriteLine($"No of Test Data : {jobRequisition.Count}");
                jobRequisition.ForEach(x =>
                {
                    _fglogin = new FGLogin(Driver);
                    _fghome = _fglogin.Login(AuthRole.FGEWO);
                    var _wkView = _fghome.SearchWorkOrder(x.Worker_Order.WorkerOrderId);
                    var _cWk = _wkView.EditWorkOrder();
                });
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error in Page {e.Message}");
            }

        }

        [Test]
        [Category("Contract Worker")]
        public void Step04_Approve_WorkOrder_As_ExperienceManger()
        {
        }

        [Test]
        [Category("Contract Worker")]
        public void Step05_Reassign_WorkOrder_As_GignowUser()
        {
        }

        [Test]
        [Category("Contract Worker")]
        public void Step06_Accept_WorkOrder_As_TestSupplier()
        {
        }

        [Test]
        [Category("Contract Worker")]
        public void Step07_Activate_WorkOrder_As_ProgramCordniator()
        {

        }
        #endregion
    }
}