﻿namespace EY_Test.TestScripts.Regression
{
    using NUnit.Framework;
    using Pom;
    using Pom.PageObjects;
    using SF.API.FO.Scenarios;
    using SF.Automate.API.FO.Scenarios;
    using SF.Automate.PageObjects.Modules;
    using SF.FO.Foundation;
    using SF.FOEntities;
    using System;
    using System.Collections.Generic;

    [TestFixture]
    public partial class SuccessFactor_Suite : TestRunner
    {
        
        

        #region Application Specific Setup and TearDown

        /// <summary>
        /// These functions are specific to the program only
        /// </summary>
        [SetUp]
        public void StartUp()
        {
            
        }

        [TearDown]
        public void StopTest()
        {
            
        }


        #endregion Application Specific Setup and TearDown

        #region Test Data Creation and Validation via API

        /// <summary>
        /// Test case for data creation and validation of FO_GeographicArea
        /// </summary>
        [Test]
        [Category("01_Foundation")]//[Category("SFIC")]
        public void TCC001_Create_FO_GeographicArea()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeographicAreaFO>(FOType.geographicarea);
            foreach (GeographicAreaFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (GeographicAreaFO fo_data in fo_test_datas) { GeographicArea.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_GeographicRegion
        /// </summary>
        [Test]
        [Category("01_Foundation")]//[Category("SFIC")]
        public void TCC002_Create_FO_GeographicRegion()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeographicRegionFO>(FOType.geographicregion);
            foreach (GeographicRegionFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (GeographicRegionFO fo_data in fo_test_datas) { GeographicRegion.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ManagerialCountry
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC003_Create_FO_ManagerialCountry()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagerialCountryFO>(FOType.managerialcountry);
            foreach (ManagerialCountryFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ManagerialCountryFO fo_data in fo_test_datas) { ManagementCountry.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ManagementArea
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC004_Create_FO_ManagementArea()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementAreaFO>(FOType.managementarea);
            foreach (ManagementAreaFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ManagementAreaFO fo_data in fo_test_datas) { ManagementArea.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_BusinessUnit_Finance
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC005_Create_FO_BusinessUnit_Finance()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BusinessUnit_FinanceFO>(FOType.businessunit_finance);
            foreach (BusinessUnit_FinanceFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (BusinessUnit_FinanceFO fo_data in fo_test_datas) { BusinessUnit_Finance.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ManagementRegion
        /// </summary>
        [Test]
        [Category("01_Foundation")]//[Category("CPIJob")]
        public void TCC006_Create_FO_ManagementRegion()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementRegionFO>(FOType.managementregion);
            foreach (ManagementRegionFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ManagementRegionFO fo_data in fo_test_datas) { ManagementRegion.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ManagementUnit
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC007_Create_FO_ManagementUnit()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementUnitFO>(FOType.managementunit);
            foreach (ManagementUnitFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ManagementUnitFO fo_data in fo_test_datas) { ManagementUnit.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_SubManagementUnit
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC008_Create_FO_SubManagementUnit()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SubManagementUnitFO>(FOType.submanagementunit);
            foreach (SubManagementUnitFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (SubManagementUnitFO fo_data in fo_test_datas) { SubManagementUnit.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_OperatingUnit
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC009_Create_FO_OperatingUnit()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<OperatingUnitFO>(FOType.operatingunit);
            foreach (OperatingUnitFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (OperatingUnitFO fo_data in fo_test_datas) { OperatingUnit.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_CostCenter
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC010_Create_FO_CostCenter()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CostCenterFO>(FOType.costcenter);
            foreach (CostCenterFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (CostCenterFO fo_data in fo_test_datas) { CostCenter.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_CodeBlock
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC011_Create_FO_CodeBlock()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CodeBlockFO>(FOType.codeblock);
            foreach (CodeBlockFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (CodeBlockFO fo_data in fo_test_datas) { CodeBlock.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Establishment
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC012_Create_FO_Establishment()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<EstablishmentFO>(FOType.establishment);
            foreach (EstablishmentFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (EstablishmentFO fo_data in fo_test_datas) { Establishment.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        //Category("01_Foundation")]
        //[Test]
        [Category("Step 01 FO Data Validation Only")]
        public void TCC013_Create_FO_CorporateAddress()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CorporateAddressFO>(FOType.corporateaddress);
            //foreach (CorporateAddressFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (CorporateAddressFO fo_data in fo_test_datas) { CorporateAddress.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_GeoZone
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC014_Create_FO_GeoZone()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeoZoneFO>(FOType.geozone);
            foreach (GeoZoneFO fo_data in fo_test_datas)
            {
                FoundationObject.Create(fo_data);
            }
            foreach (GeoZoneFO fo_data in fo_test_datas) { GeoZone.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Location
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC015_Create_FO_Location()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<LocationFO>(FOType.location);
            foreach (LocationFO fo_data in fo_test_datas) { Location.Create(fo_data); }
            foreach (LocationFO fo_data in fo_test_datas) { Location.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_LegalEntity
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC016_Create_FO_LegalEntity()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<LegalEntityFO>(FOType.legalentity);
            foreach (LegalEntityFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (LegalEntityFO fo_data in fo_test_datas) { LegalEntity.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_LegalEntityCS
        /// </summary>

        [Category("01_Foundation")]//[Category("SFIC")]//42
        public void TCC016_Create_FO_LegalEntityCS()
        {
            //var fo_test_datas = ExcelWorkBook.ReadFoundationData<LegalEntityCSFO>(FOType.legalentitycs);
            //foreach (LegalEntityCSFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            //foreach (LegalEntityCSFO fo_data in fo_test_datas) { LegalEntityCS.Validate(fo_data); } FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Speciality
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC017_Create_FO_Speciality()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SpecialityFO>(FOType.speciality);
            foreach (SpecialityFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (SpecialityFO fo_data in fo_test_datas) { Speciality.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ServiceLine
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC018_Create_FO_ServiceLine()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ServiceLineFO>(FOType.serviceline);
            foreach (ServiceLineFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ServiceLineFO fo_data in fo_test_datas) { ServiceLine.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_SubServiceLine
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC019_Create_FO_SubServiceLine()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SubServiceLineFO>(FOType.subserviceline);
            foreach (SubServiceLineFO fo_data in fo_test_datas) { SubServiceLine.Create(fo_data); }
            foreach (SubServiceLineFO fo_data in fo_test_datas) { SubServiceLine.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Department
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC020_Create_FO_Department()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<DepartmentFO>(FOType.department);
            foreach (DepartmentFO fo_data in fo_test_datas) { Department.Create(fo_data); }
            foreach (DepartmentFO fo_data in fo_test_datas) { Department.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobFamilyGroup
        /// </summary>
        //[Test]
        [Category("Entity Not Editable via API")]
        public void TCC021_Create_FO_JobFamilyGroup()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFamilyGroupFO>(FOType.jobfamilygroup);
            foreach (JobFamilyGroupFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (JobFamilyGroupFO fo_data in fo_test_datas) { JobFamilyGroup.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobFamily
        /// </summary>
        //[Test]
        [Category("Entity Not Editable via API")]
        public void TCC022_Create_FO_JobFamily()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFamilyFO>(FOType.jobfamily);
            foreach (JobFamilyFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (JobFamilyFO fo_data in fo_test_datas) { JobFamily.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_CareerLevel
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC023_Create_FO_CareerLevel()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CareerLevelFO>(FOType.careerlevel);
            foreach (CareerLevelFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (CareerLevelFO fo_data in fo_test_datas) { CareerLevel.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobRoleType
        /// </summary>
        //[Test]
        [Category("Entity Not Editable via API")]
        public void TCC024_Create_FO_JobRoleType()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobRoleTypeFO>(FOType.jobroletype);
            foreach (JobRoleTypeFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (JobRoleTypeFO fo_data in fo_test_datas) { JobRoleType.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobFunction
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC025_Create_FO_JobFunction()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFunctionFO>(FOType.jobfunction);
            foreach (JobFunctionFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (JobFunctionFO fo_data in fo_test_datas) { JobFunction.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_RewardsDiversifier
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC026_Create_FO_RewardsDiversifier()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<RewardsDiversifierFO>(FOType.rewardsdiversifier);
            foreach (RewardsDiversifierFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (RewardsDiversifierFO fo_data in fo_test_datas) { RewardsDiversifier.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Rank
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC027_Create_FO_Rank()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<RankFO>(FOType.rank);
            foreach (RankFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (RankFO fo_data in fo_test_datas) { Rank.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ServiceType
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC028_Create_FO_ServiceType()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ServiceTypeFO>(FOType.servicetype);
            foreach (ServiceTypeFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ServiceTypeFO fo_data in fo_test_datas) { ServiceType.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_PayGrade
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC029_Create_FO_PayGrade()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayGradeFO>(FOType.paygrade);
            foreach (PayGradeFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (PayGradeFO fo_data in fo_test_datas) { PayGrade.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ActivityType
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC030_Create_FO_ActivityType()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ActivityTypeFO>(FOType.activitytype);
            foreach (ActivityTypeFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ActivityTypeFO fo_data in fo_test_datas) { ActivityType.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobClassification
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC031_Create_FO_JobClassification()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobClassificationFO>(FOType.jobclassification);
            foreach (JobClassificationFO fo_data in fo_test_datas) { JobClassification.Create(fo_data); }
            foreach (JobClassificationFO fo_data in fo_test_datas) { JobClassification.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobClassificationCS
        /// </summary>
        //[Test]
        //[Category("01_Foundation")]
        //[Category("SFIC")]//41
        public void TCC031_Create_FO_JobClassificationCS()
        {
            var fo_test_datas = new List<object>
            {
                new FO_ObjectBase() { externalCode = "1",_startDate = DateTime.Now,name = "Hello",description = "There",api_c_status = "Pass",api_v_status ="Pass" },
                new FO_ObjectBase() { externalCode = "2",_startDate = DateTime.Now,name = "Hello",description = "There",api_c_status = "Pass",api_v_status ="Pass" },
                new FO_ObjectBase() { externalCode = "3",_startDate = DateTime.Now,name = "Hello",description = "There",api_c_status = "Pass",api_v_status ="Pass" },
                new FO_ObjectBase() { externalCode = "4",_startDate = DateTime.Now,name = "Hello",description = "There",api_c_status = "Pass",api_v_status ="Pass" },
                new FO_ObjectBase() { externalCode = "4",_startDate = DateTime.Now,name = "Hello",description = "There",api_c_status = "Pass",api_v_status ="Pass" }
            };

            //var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobClassificationCSFO>(FOType.jobclassificationcs);
            //foreach (JobClassificationCSFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            //foreach (JobClassificationCSFO fo_data in fo_test_datas) { JobClassificationCS.Validate(fo_data); } FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Frequency
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC032_Create_FO_Frequency()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<FrequencyFO>(FOType.frequency);
            foreach (FrequencyFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (FrequencyFO fo_data in fo_test_datas) { Frequency.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_PayRanges
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC033_Create_FO_PayRanges()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayRangesFO>(FOType.payranges);
            foreach (PayRangesFO fo_data in fo_test_datas) { PayRanges.Create(fo_data); }
            foreach (PayRangesFO fo_data in fo_test_datas) { PayRanges.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_PayGroup
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC034_Create_FO_PayGroup()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayGroupFO>(FOType.paygroup);
            foreach (PayGroupFO fo_data in fo_test_datas) { PayGroup.Create(fo_data); }
            foreach (PayGroupFO fo_data in fo_test_datas) { PayGroup.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_PayComponentGroup
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC035_Create_FO_PayComponentGroup()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayComponentGroupFO>(FOType.paycomponentgroup);
            foreach (PayComponentGroupFO fo_data in fo_test_datas) { PayComponentGroup.Create(fo_data); }
            foreach (PayComponentGroupFO fo_data in fo_test_datas) { PayComponentGroup.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_PayComponent
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC036_Create_FO_PayComponent()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayComponentFO>(FOType.paycomponent);
            foreach (PayComponentFO fo_data in fo_test_datas) { PayComponent.Create(fo_data); }
            foreach (PayComponentFO fo_data in fo_test_datas) { PayComponent.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Bank
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC037_Create_FO_Bank()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BankFO>(FOType.bank);
            foreach (BankFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (BankFO fo_data in fo_test_datas) { Bank.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_BelgiumWeeklyHours
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC038_Create_FO_BelgiumWeeklyHours()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BelgiumWeeklyHoursFO>(FOType.belgiumweeklyhours);
            foreach (BelgiumWeeklyHoursFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (BelgiumWeeklyHoursFO fo_data in fo_test_datas) { BelgiumWeeklyHours.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_BrazilCNPJ
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC039_Create_FO_BrazilCNPJ()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BrazilCNPJFO>(FOType.brazilcnpj);
            foreach (BrazilCNPJFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (BrazilCNPJFO fo_data in fo_test_datas) { BrazilCNPJ.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_CorporateAddress
        /// </summary>
        /// <summary>
        /// Test case for data creation and validation of FO_CurrencyExchangeRate
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC040_Create_FO_CurrencyExchangeRate()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CurrencyExchangeRateFO>(FOType.currencyexchangerate);
            foreach (CurrencyExchangeRateFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (CurrencyExchangeRateFO fo_data in fo_test_datas) { CurrencyExchangeRate.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_EventReason
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC041_Create_FO_EventReason()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<EventReasonFO>(FOType.eventreason);
            foreach (EventReasonFO fo_data in fo_test_datas) { EventReason.Create(fo_data); }
            foreach (EventReasonFO fo_data in fo_test_datas) { EventReason.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_NameFormat
        /// </summary>
        //[Test]
        [Category("Entity Not Editable via API")]
        public void TCC042_Create_FO_NameFormat()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<NameFormatFO>(FOType.nameformat);
            foreach (NameFormatFO fo_data in fo_test_datas) { NameFormat.Create(fo_data); }
            foreach (NameFormatFO fo_data in fo_test_datas) { NameFormat.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ProficiencyLevel
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC043_Create_FO_ProficiencyLevel()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ProficiencyLevelFO>(FOType.proficiencylevel);
            foreach (ProficiencyLevelFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ProficiencyLevelFO fo_data in fo_test_datas) { ProficiencyLevel.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        /// <summary>
        /// Test case for data creation and validation of FO_WorkSchedule
        /// </summary>
        [Test]
        [Category("01_Foundation")]
        public void TCC044_Create_FO_WorkSchedule()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<WorkScheduleFO>(FOType.workschedule);
            foreach (WorkScheduleFO fo_data in fo_test_datas) { WorkSchedule.Create(fo_data); }
            foreach (WorkScheduleFO fo_data in fo_test_datas) { WorkSchedule.Validate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        #endregion Test Data Creation and Validation via API

        #region Test Data validation in TDDH

        [Test, Category("03_Foundation")]
        public void TCV076_Validate_FO_ActivityType()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ActivityTypeFO>(FOType.activitytype);
            foreach (ActivityTypeFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ActivityType(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV083_Validate_FO_Bank()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BankFO>(FOType.bank);
            foreach (BankFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Bank(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV084_Validate_FO_BelgiumWeeklyHours()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BelgiumWeeklyHoursFO>(FOType.belgiumweeklyhours);
            foreach (BelgiumWeeklyHoursFO fo_data in fo_test_datas) { dataaccess.Validate_FO_BelgiumWeeklyHours(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV085_Validate_FO_BrazilCNPJ()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BrazilCNPJFO>(FOType.brazilcnpj);
            foreach (BrazilCNPJFO fo_data in fo_test_datas) { dataaccess.Validate_FO_BrazilCNPJ(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV069_Validate_FO_CareerLevel()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CareerLevelFO>(FOType.careerlevel);
            foreach (CareerLevelFO fo_data in fo_test_datas) { dataaccess.Validate_FO_CareerLevel(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV057_Validate_FO_CodeBlock()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CodeBlockFO>(FOType.codeblock);
            foreach (CodeBlockFO fo_data in fo_test_datas) { dataaccess.Validate_FO_CodeBlock(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        //[Test]
        [Category("Entity Not Editable via API")]
        public void TCV059_Validate_FO_CorporateAddress()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CorporateAddressFO>(FOType.corporateaddress);
            foreach (CorporateAddressFO fo_data in fo_test_datas) { dataaccess.Validate_FO_CorporateAddress(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV056_Validate_FO_CostCenter()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CostCenterFO>(FOType.costcenter);
            foreach (CostCenterFO fo_data in fo_test_datas) { dataaccess.Validate_FO_CostCenter(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV086_Validate_FO_CurrencyExchangeRate()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CurrencyExchangeRateFO>(FOType.currencyexchangerate);
            foreach (CurrencyExchangeRateFO fo_data in fo_test_datas) { dataaccess.Validate_FO_CurrencyExchangeRate(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV066_Validate_FO_Department()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<DepartmentFO>(FOType.department);
            foreach (DepartmentFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Department(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV058_Validate_FO_Establishment()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<EstablishmentFO>(FOType.establishment);
            foreach (EstablishmentFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Establishment(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV087_Validate_FO_EventReason()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<EventReasonFO>(FOType.eventreason);
            foreach (EventReasonFO fo_data in fo_test_datas) { dataaccess.Validate_FO_EventReason(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV078_Validate_FO_Frequency()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<FrequencyFO>(FOType.frequency);
            foreach (FrequencyFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Frequency(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV047_Validate_FO_GeographicArea()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeographicAreaFO>(FOType.geographicarea);
            foreach (GeographicAreaFO fo_data in fo_test_datas) { dataaccess.Validate_FO_GeographicArea(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV048_Validate_FO_GeographicRegion()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeographicRegionFO>(FOType.geographicregion);
            foreach (GeographicRegionFO fo_data in fo_test_datas) { dataaccess.Validate_FO_GeographicRegion(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV060_Validate_FO_GeoZone()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeoZoneFO>(FOType.geozone);
            foreach (GeoZoneFO fo_data in fo_test_datas) { dataaccess.Validate_FO_GeoZone(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV077_Validate_FO_JobClassification()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobClassificationFO>(FOType.jobclassification);
            foreach (JobClassificationFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobClassification(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        //[Test, Category("03_Foundation")]
        public void TCV091_Validate_FO_JobClassificationCS()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobClassificationCSFO>(FOType.jobclassificationcs);
            foreach (JobClassificationCSFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobClassificationCS(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        //[Test]
        [Category("Entity Not Editable via API")]
        public void TCV068_Validate_FO_JobFamily()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFamilyFO>(FOType.jobfamily);
            foreach (JobFamilyFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobFamily(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        //[Test]
        [Category("Entity Not Editable via API")]
        public void TCV067_Validate_FO_JobFamilyGroup()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFamilyGroupFO>(FOType.jobfamilygroup);
            foreach (JobFamilyGroupFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobFamilyGroup(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV071_Validate_FO_JobFunction()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFunctionFO>(FOType.jobfunction);
            foreach (JobFunctionFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobFunction(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        //[Test]
        [Category("Entity Not Editable via API")]
        public void TCV070_Validate_FO_JobRoleType()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobRoleTypeFO>(FOType.jobroletype);
            foreach (JobRoleTypeFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobRoleType(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV062_Validate_FO_LegalEntity()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<LegalEntityFO>(FOType.legalentity);
            foreach (LegalEntityFO fo_data in fo_test_datas) { dataaccess.Validate_FO_LegalEntity(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        //[Test, Category("03_Foundation")]
        public void TCV092_Validate_FO_LegalEntityCS()
        {
            //dataaccess = new FODataAccess(Driver);
            //var fo_test_datas = ExcelWorkBook.ReadFoundationData<LegalEntityCSFO>(FOType.legalentitycs);
            //foreach (LegalEntityCSFO fo_data in fo_test_datas) { dataaccess.Validate_FO_LegalEntityCS(fo_data); } FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV061_Validate_FO_Location()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<LocationFO>(FOType.location);
            foreach (LocationFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Location(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV050_Validate_FO_ManagementArea()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementAreaFO>(FOType.managementarea);
            foreach (ManagementAreaFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ManagementArea(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV052_Validate_FO_ManagementRegion()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementRegionFO>(FOType.managementregion);
            foreach (ManagementRegionFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ManagementRegion(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV053_Validate_FO_ManagementUnit()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementUnitFO>(FOType.managementunit);
            foreach (ManagementUnitFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ManagementUnit(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV049_Validate_FO_ManagerialCountry()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagerialCountryFO>(FOType.managerialcountry);
            foreach (ManagerialCountryFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ManagerialCountry(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        //[Test]
        [Category("Entity Not Editable via API")]
        public void TCV088_Validate_FO_NameFormat()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<NameFormatFO>(FOType.nameformat);
            foreach (NameFormatFO fo_data in fo_test_datas) { dataaccess.Validate_FO_NameFormat(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV055_Validate_FO_OperatingUnit()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<OperatingUnitFO>(FOType.operatingunit);
            foreach (OperatingUnitFO fo_data in fo_test_datas) { dataaccess.Validate_FO_OperatingUnit(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV082_Validate_FO_PayComponent()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayComponentFO>(FOType.paycomponent);
            foreach (PayComponentFO fo_data in fo_test_datas) { dataaccess.Validate_FO_PayComponent(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV081_Validate_FO_PayComponentGroup()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayComponentGroupFO>(FOType.paycomponentgroup);
            foreach (PayComponentGroupFO fo_data in fo_test_datas) { dataaccess.Validate_FO_PayComponentGroup(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV075_Validate_FO_PayGrade()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayGradeFO>(FOType.paygrade);
            foreach (PayGradeFO fo_data in fo_test_datas) { dataaccess.Validate_FO_PayGrade(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV080_Validate_FO_PayGroup()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayGroupFO>(FOType.paygroup);
            foreach (PayGroupFO fo_data in fo_test_datas) { dataaccess.Validate_FO_PayGroup(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV079_Validate_FO_PayRanges()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayRangesFO>(FOType.payranges);
            foreach (PayRangesFO fo_data in fo_test_datas) { dataaccess.Validate_FO_PayRanges(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV089_Validate_FO_ProficiencyLevel()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ProficiencyLevelFO>(FOType.proficiencylevel);
            foreach (ProficiencyLevelFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ProficiencyLevel(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV073_Validate_FO_Rank()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<RankFO>(FOType.rank);
            foreach (RankFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Rank(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV072_Validate_FO_RewardsDiversifier()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<RewardsDiversifierFO>(FOType.rewardsdiversifier);
            foreach (RewardsDiversifierFO fo_data in fo_test_datas) { dataaccess.Validate_FO_RewardsDiversifier(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV064_Validate_FO_ServiceLine()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ServiceLineFO>(FOType.serviceline);
            foreach (ServiceLineFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ServiceLine(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV074_Validate_FO_ServiceType()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ServiceTypeFO>(FOType.servicetype);
            foreach (ServiceTypeFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ServiceType(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV063_Validate_FO_Speciality()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SpecialityFO>(FOType.speciality);
            foreach (SpecialityFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Speciality(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV054_Validate_FO_SubManagementUnit()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SubManagementUnitFO>(FOType.submanagementunit);
            foreach (SubManagementUnitFO fo_data in fo_test_datas) { dataaccess.Validate_FO_SubManagementUnit(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV065_Validate_FO_SubServiceLine()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SubServiceLineFO>(FOType.subserviceline);
            foreach (SubServiceLineFO fo_data in fo_test_datas) { dataaccess.Validate_FO_SubServiceLine(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV090_Validate_FO_WorkSchedule()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<WorkScheduleFO>(FOType.workschedule);
            foreach (WorkScheduleFO fo_data in fo_test_datas) { dataaccess.Validate_FO_WorkSchedule(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        [Test, Category("03_Foundation")]
        public void TCV051_Validate_FO_BusinessUnit_Finance()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BusinessUnit_FinanceFO>(FOType.businessunit_finance);
            foreach (BusinessUnit_FinanceFO fo_data in fo_test_datas) { dataaccess.Validate_FO_BusinessUnit_Finance(fo_data); }
            FoundationExecution.AddStatus(fo_test_datas);
        }

        #endregion Test Data validation in TDDH
    }
}