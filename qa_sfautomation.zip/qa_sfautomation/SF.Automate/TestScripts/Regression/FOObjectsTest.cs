﻿namespace EY_Test.TestScripts.Regression
{
    using System.Collections.Generic;
    using System.Text.RegularExpressions;
    using DatabaseValidation;
    using EY_Test.API.Framework;
    using EY_Test.PageObjects;
    using NUnit.Framework;
    using Pom;
    using Pom.PageObjects;
    using SF.API.FO.Scenarios;
    using SF.Automate.API.FO.Scenarios;
    using SF.Automate.PageObjects.Modules;
    using SF.FO.Foundation;
    using SF.FOEntities;

    [TestFixture]
    public class FOObjectsTest : TestRunner
    {

        #region Application Specific Setup and TearDown

        /// <summary>
        /// These functions are specific to the program only
        /// </summary>
        [SetUp]
        public void StartUp()
        {
            var path = Util.DirectoryPath;
            currentCategory = (string)TestContext.CurrentContext.Test.Properties.Get("Category");
            switch (currentCategory)
            {
                case "Step 01 FO Data Creation":
                    Driver.Url = $@"{path}\apistatus.html";
                    HTMLReport.Driver = Driver;
                    //HTMLReport.CallHistory.Clear();
                    HTMLReport.TestName = TestContext.CurrentContext.Test.Name.Replace("_", " ");
                    HTMLReport.UpdateStatusView();
                    var n = CleanFOName(TestContext.CurrentContext.Test.Name);
                    workflowparam.FoObjectname.Add(n);
                    HTMLReport.UserDetails = n;
                    break;

                case "Step 02 FO Data Extraction": Driver.Url = $@"about:blank"; break;
                case "Step 03 FO TDDH Validation": Driver.Url = $@"{path}\TDDH_Result.html"; break;
            }
        }

        [TearDown]
        public void StopTest()
        {
            switch (currentCategory)
            {
                case "Step 01 FO Data Setup":
                    HTMLReport.SaveReport();

                    break;

                case "Step 02 FO Data Extraction":
                    break;

                case "Step 03 FO TDDH Validation":
                    break;
            }
        }

        private string CleanFOName(string name) => Regex.Match(name, @"Create_FO_[\w]+").Value.Replace("Create_FO_", string.Empty);
        #endregion Application Specific Setup and TearDown

        #region Test Data Creation and Validation via API

        /// <summary>
        /// Test case for data creation and validation of FO_GeographicArea
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]//[Category("SFIC")]
        public void TC001_Create_FO_GeographicArea()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeographicAreaFO>(FOType.geographicarea);
            foreach (GeographicAreaFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (GeographicAreaFO fo_data in fo_test_datas) { GeographicArea.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_GeographicRegion
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]//[Category("SFIC")]
        public void TC002_Create_FO_GeographicRegion()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeographicRegionFO>(FOType.geographicregion);
            foreach (GeographicRegionFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (GeographicRegionFO fo_data in fo_test_datas) { GeographicRegion.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ManagerialCountry
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC003_Create_FO_ManagerialCountry()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagerialCountryFO>(FOType.managerialcountry);
            foreach (ManagerialCountryFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ManagerialCountryFO fo_data in fo_test_datas) { ManagementCountry.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ManagementArea
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC004_Create_FO_ManagementArea()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementAreaFO>(FOType.managementarea);
            foreach (ManagementAreaFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ManagementAreaFO fo_data in fo_test_datas) { ManagementArea.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_BusinessUnit_Finance
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC005_Create_FO_BusinessUnit_Finance()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BusinessUnit_FinanceFO>(FOType.businessunit_finance);
            foreach (BusinessUnit_FinanceFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (BusinessUnit_FinanceFO fo_data in fo_test_datas) { BusinessUnit_Finance.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ManagementRegion
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]//[Category("CPIJob")]
        public void TC006_Create_FO_ManagementRegion()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementRegionFO>(FOType.managementregion);
            foreach (ManagementRegionFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ManagementRegionFO fo_data in fo_test_datas) { ManagementRegion.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ManagementUnit
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC007_Create_FO_ManagementUnit()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementUnitFO>(FOType.managementunit);
            foreach (ManagementUnitFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ManagementUnitFO fo_data in fo_test_datas) { ManagementUnit.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_SubManagementUnit
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC008_Create_FO_SubManagementUnit()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SubManagementUnitFO>(FOType.submanagementunit);
            foreach (SubManagementUnitFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (SubManagementUnitFO fo_data in fo_test_datas) { SubManagementUnit.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_OperatingUnit
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC009_Create_FO_OperatingUnit()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<OperatingUnitFO>(FOType.operatingunit);
            foreach (OperatingUnitFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (OperatingUnitFO fo_data in fo_test_datas) { OperatingUnit.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_CostCenter
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC010_Create_FO_CostCenter()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CostCenterFO>(FOType.costcenter);
            foreach (CostCenterFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (CostCenterFO fo_data in fo_test_datas) { CostCenter.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_CodeBlock
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("CPIJob")]
        public void TC011_Create_FO_CodeBlock()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CodeBlockFO>(FOType.codeblock);
            foreach (CodeBlockFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (CodeBlockFO fo_data in fo_test_datas) { CodeBlock.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Establishment
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC012_Create_FO_Establishment()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<EstablishmentFO>(FOType.establishment);
            foreach (EstablishmentFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (EstablishmentFO fo_data in fo_test_datas) { Establishment.Validate(fo_data); }
        }

        //Category("Step 01 FO Data Creation")]
        [Test]
        [Category("Step 01 FO Data Validation Only")]
        //[Category("CPIJob")]
        public void TC013_Create_FO_CorporateAddress()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CorporateAddressFO>(FOType.corporateaddress);
            //foreach (CorporateAddressFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (CorporateAddressFO fo_data in fo_test_datas) { CorporateAddress.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_GeoZone
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC014_Create_FO_GeoZone()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeoZoneFO>(FOType.geozone);
            foreach (GeoZoneFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (GeoZoneFO fo_data in fo_test_datas) { GeoZone.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Location
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("CPIJob")]
        public void TC015_Create_FO_Location()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<LocationFO>(FOType.location);
            foreach (LocationFO fo_data in fo_test_datas) { Location.Create(fo_data); }
            foreach (LocationFO fo_data in fo_test_datas) { Location.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_LegalEntity
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC016_Create_FO_LegalEntity()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<LegalEntityFO>(FOType.legalentity);
            foreach (LegalEntityFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (LegalEntityFO fo_data in fo_test_datas) { LegalEntity.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_LegalEntityCS
        /// </summary>
        
        [Category("Step 01 FO Data Creation")]//[Category("SFIC")]//42
        public void TC016_Create_FO_LegalEntityCS()
        {
            //var fo_test_datas = ExcelWorkBook.ReadFoundationData<LegalEntityCSFO>(FOType.legalentitycs);
            //foreach (LegalEntityCSFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            //foreach (LegalEntityCSFO fo_data in fo_test_datas) { LegalEntityCS.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Speciality
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("CPIJob")]
        public void TC017_Create_FO_Speciality()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SpecialityFO>(FOType.speciality);
            foreach (SpecialityFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (SpecialityFO fo_data in fo_test_datas) { Speciality.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ServiceLine
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC018_Create_FO_ServiceLine()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ServiceLineFO>(FOType.serviceline);
            foreach (ServiceLineFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ServiceLineFO fo_data in fo_test_datas) { ServiceLine.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_SubServiceLine
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("CPIJob")]
        public void TC019_Create_FO_SubServiceLine()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SubServiceLineFO>(FOType.subserviceline);
            foreach (SubServiceLineFO fo_data in fo_test_datas) { SubServiceLine.Create(fo_data); }
            foreach (SubServiceLineFO fo_data in fo_test_datas) { SubServiceLine.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Department
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("CPIJob")]
        public void TC020_Create_FO_Department()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<DepartmentFO>(FOType.department);
            foreach (DepartmentFO fo_data in fo_test_datas) { Department.Create(fo_data); }
            foreach (DepartmentFO fo_data in fo_test_datas) { Department.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobFamilyGroup
        /// </summary>
        [Test]
        [Category("Entity Not Editable via API")]
        //[Category("SFIC")]
        public void TC021_Create_FO_JobFamilyGroup()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFamilyGroupFO>(FOType.jobfamilygroup);
            foreach (JobFamilyGroupFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (JobFamilyGroupFO fo_data in fo_test_datas) { JobFamilyGroup.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobFamily
        /// </summary>
        [Test]
        [Category("Entity Not Editable via API")]
        //[Category("CPIJob")]
        public void TC022_Create_FO_JobFamily()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFamilyFO>(FOType.jobfamily);
            foreach (JobFamilyFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (JobFamilyFO fo_data in fo_test_datas) { JobFamily.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_CareerLevel
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC023_Create_FO_CareerLevel()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CareerLevelFO>(FOType.careerlevel);
            foreach (CareerLevelFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (CareerLevelFO fo_data in fo_test_datas) { CareerLevel.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobRoleType
        /// </summary>
        [Test]
        [Category("Entity Not Editable via API")]
        //[Category("CPIJob")]
        public void TC024_Create_FO_JobRoleType()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobRoleTypeFO>(FOType.jobroletype);
            foreach (JobRoleTypeFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (JobRoleTypeFO fo_data in fo_test_datas) { JobRoleType.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobFunction
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC025_Create_FO_JobFunction()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFunctionFO>(FOType.jobfunction);
            foreach (JobFunctionFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (JobFunctionFO fo_data in fo_test_datas) { JobFunction.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_RewardsDiversifier
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("CPIJob")]
        public void TC026_Create_FO_RewardsDiversifier()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<RewardsDiversifierFO>(FOType.rewardsdiversifier);
            foreach (RewardsDiversifierFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (RewardsDiversifierFO fo_data in fo_test_datas) { RewardsDiversifier.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Rank
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC027_Create_FO_Rank()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<RankFO>(FOType.rank);
            foreach (RankFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (RankFO fo_data in fo_test_datas) { Rank.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ServiceType
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC028_Create_FO_ServiceType()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ServiceTypeFO>(FOType.servicetype);
            foreach (ServiceTypeFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ServiceTypeFO fo_data in fo_test_datas) { ServiceType.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_PayGrade
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC029_Create_FO_PayGrade()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayGradeFO>(FOType.paygrade);
            foreach (PayGradeFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (PayGradeFO fo_data in fo_test_datas) { PayGrade.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_ActivityType
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC030_Create_FO_ActivityType()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ActivityTypeFO>(FOType.activitytype);
            foreach (ActivityTypeFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ActivityTypeFO fo_data in fo_test_datas) { ActivityType.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobClassification
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("CPIJob")]
        public void TC031_Create_FO_JobClassification()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobClassificationFO>(FOType.jobclassification);
            foreach (JobClassificationFO fo_data in fo_test_datas) { JobClassification.Create(fo_data); }
            foreach (JobClassificationFO fo_data in fo_test_datas) { JobClassification.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_JobClassificationCS
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]//41
        public void TC031_Create_FO_JobClassificationCS()
        {
            //var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobClassificationCSFO>(FOType.jobclassificationcs);
            //foreach (JobClassificationCSFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            //foreach (JobClassificationCSFO fo_data in fo_test_datas) { JobClassificationCS.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Frequency
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC032_Create_FO_Frequency()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<FrequencyFO>(FOType.frequency);
            foreach (FrequencyFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (FrequencyFO fo_data in fo_test_datas) { Frequency.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_PayRanges
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC033_Create_FO_PayRanges()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayRangesFO>(FOType.payranges);
            foreach (PayRangesFO fo_data in fo_test_datas) { PayRanges.Create(fo_data); }
            foreach (PayRangesFO fo_data in fo_test_datas) { PayRanges.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_PayGroup
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC034_Create_FO_PayGroup()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayGroupFO>(FOType.paygroup);
            foreach (PayGroupFO fo_data in fo_test_datas) { PayGroup.Create(fo_data); }
            foreach (PayGroupFO fo_data in fo_test_datas) { PayGroup.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_PayComponentGroup
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("CPIJob")]
        public void TC035_Create_FO_PayComponentGroup()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayComponentGroupFO>(FOType.paycomponentgroup);
            foreach (PayComponentGroupFO fo_data in fo_test_datas) { PayComponentGroup.Create(fo_data); }
            foreach (PayComponentGroupFO fo_data in fo_test_datas) { PayComponentGroup.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_PayComponent
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC036_Create_FO_PayComponent()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayComponentFO>(FOType.paycomponent);
            foreach (PayComponentFO fo_data in fo_test_datas) { PayComponent.Create(fo_data); }
            foreach (PayComponentFO fo_data in fo_test_datas) { PayComponent.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_Bank
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC037_Create_FO_Bank()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BankFO>(FOType.bank);
            foreach (BankFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (BankFO fo_data in fo_test_datas) { Bank.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_BelgiumWeeklyHours
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC038_Create_FO_BelgiumWeeklyHours()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BelgiumWeeklyHoursFO>(FOType.belgiumweeklyhours);
            foreach (BelgiumWeeklyHoursFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (BelgiumWeeklyHoursFO fo_data in fo_test_datas) { BelgiumWeeklyHours.Validate(fo_data); }
        }

        /// <summary>
        /// Test case for data creation and validation of FO_BrazilCNPJ
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC039_Create_FO_BrazilCNPJ()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BrazilCNPJFO>(FOType.brazilcnpj);
            foreach (BrazilCNPJFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (BrazilCNPJFO fo_data in fo_test_datas) { BrazilCNPJ.Validate(fo_data); }
        }
        /// <summary>
        /// Test case for data creation and validation of FO_CorporateAddress
        /// </summary>
        /// <summary>
        /// Test case for data creation and validation of FO_CurrencyExchangeRate
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC040_Create_FO_CurrencyExchangeRate()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CurrencyExchangeRateFO>(FOType.currencyexchangerate);
            foreach (CurrencyExchangeRateFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (CurrencyExchangeRateFO fo_data in fo_test_datas) { CurrencyExchangeRate.Validate(fo_data); }
        }
        /// <summary>
        /// Test case for data creation and validation of FO_EventReason
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC041_Create_FO_EventReason()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<EventReasonFO>(FOType.eventreason);
            foreach (EventReasonFO fo_data in fo_test_datas) { EventReason.Create(fo_data); }
            foreach (EventReasonFO fo_data in fo_test_datas) { EventReason.Validate(fo_data); }
        }
        /// <summary>
        /// Test case for data creation and validation of FO_NameFormat
        /// </summary>
        [Test]
        [Category("Entity Not Editable via API")]
        //[Category("CPIJob")]
        public void TC042_Create_FO_NameFormat()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<NameFormatFO>(FOType.nameformat);
            foreach (NameFormatFO fo_data in fo_test_datas) { NameFormat.Create(fo_data); }
            foreach (NameFormatFO fo_data in fo_test_datas) { NameFormat.Validate(fo_data); }
        }
        /// <summary>
        /// Test case for data creation and validation of FO_ProficiencyLevel
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("SFIC")]
        public void TC043_Create_FO_ProficiencyLevel()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ProficiencyLevelFO>(FOType.proficiencylevel);
            foreach (ProficiencyLevelFO fo_data in fo_test_datas) { FoundationObject.Create(fo_data); }
            foreach (ProficiencyLevelFO fo_data in fo_test_datas) { ProficiencyLevel.Validate(fo_data); }
        }
        /// <summary>
        /// Test case for data creation and validation of FO_WorkSchedule
        /// </summary>
        [Test]
        [Category("Step 01 FO Data Creation")]
        //[Category("CPIJob")]
        public void TC044_Create_FO_WorkSchedule()
        {
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<WorkScheduleFO>(FOType.workschedule);
            foreach (WorkScheduleFO fo_data in fo_test_datas) { WorkSchedule.Create(fo_data); }
            foreach (WorkScheduleFO fo_data in fo_test_datas) { WorkSchedule.Validate(fo_data); }
        }
        #endregion Test Data Creation and Validation via API

        #region FO Data Extraction

        [Test, Category("Step 02 FO Data Extraction")]
        public void TC046_ExtractFOData()
        {
            workflowparam.Driver = Driver;
            /*
             Generate Zone A File & Downloading to the QA batch server.
             */
            //workflowparam.FoObjectname = new List<string> { "activitytype", "geographicarea" };

            WorkFlow.ExtractFO(workflowparam);

            /* Display the intermitent loader */
            Driver.Url = $@"{Util.DirectoryPath}\dataloading.html";

            /* Wait until the data is loaded to the TDDH QA db*/
            TDDHQA.WaitFor_FO_DataLoading(Util.StartTime.ToUniversalTime());
        }

        [Test][Category("Reconfig")]
        public void Reconfigure()
        {
            workflowparam.Driver = Driver;
            /*
             Generate Zone A File & Downloading to the QA batch server.
             */
            workflowparam.FoObjectname = new List<string> { "activitytype", "bank", "belgiumweeklyhours", "brazilcnpj", "careerlevel", "codeblock", "corporateaddress", "costcenter", "currencyexchangerate", "department", "establishment", "eventreason", "frequency", "geographicarea", "geographicregion", "geozone", "jobclassification", "jobclassificationcs", "jobfamily", "jobfamilygroup", "jobfunction", "jobroletype", "legalentity", "legalentitycs", "location", "managementarea", "managementregion", "managementunit", "managerialcountry", "nameformat", "operatingunit", "paycomponent", "paycomponentgroup", "paygrade", "paygroup", "payranges", "proficiencylevel", "rank", "rewardsdiversifier", "serviceline", "servicetype", "speciality", "submanagementunit", "subserviceline", "workschedule", "businessunit_finance" };
            WorkFlow.ReconfigureITSDEV1Jobs(workflowparam);
        }

        #endregion FO Data Extraction

        #region Test Data validation in TDDH

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC047_Validate_FO_ActivityType()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ActivityTypeFO>(FOType.activitytype);
            foreach (ActivityTypeFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ActivityType(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC048_Validate_FO_Bank()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BankFO>(FOType.bank);
            foreach (BankFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Bank(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC049_Validate_FO_BelgiumWeeklyHours()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BelgiumWeeklyHoursFO>(FOType.belgiumweeklyhours);
            foreach (BelgiumWeeklyHoursFO fo_data in fo_test_datas) { dataaccess.Validate_FO_BelgiumWeeklyHours(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC050_Validate_FO_BrazilCNPJ()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<BrazilCNPJFO>(FOType.brazilcnpj);
            foreach (BrazilCNPJFO fo_data in fo_test_datas) { dataaccess.Validate_FO_BrazilCNPJ(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC051_Validate_FO_CareerLevel()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CareerLevelFO>(FOType.careerlevel);
            foreach (CareerLevelFO fo_data in fo_test_datas) { dataaccess.Validate_FO_CareerLevel(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC052_Validate_FO_CodeBlock()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CodeBlockFO>(FOType.codeblock);
            foreach (CodeBlockFO fo_data in fo_test_datas) { dataaccess.Validate_FO_CodeBlock(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC053_Validate_FO_CorporateAddress()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CorporateAddressFO>(FOType.corporateaddress);
            foreach (CorporateAddressFO fo_data in fo_test_datas) { dataaccess.Validate_FO_CorporateAddress(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC054_Validate_FO_CostCenter()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CostCenterFO>(FOType.costcenter);
            foreach (CostCenterFO fo_data in fo_test_datas) { dataaccess.Validate_FO_CostCenter(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC055_Validate_FO_CurrencyExchangeRate()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<CurrencyExchangeRateFO>(FOType.currencyexchangerate);
            foreach (CurrencyExchangeRateFO fo_data in fo_test_datas) { dataaccess.Validate_FO_CurrencyExchangeRate(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC056_Validate_FO_Department()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<DepartmentFO>(FOType.department);
            foreach (DepartmentFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Department(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC057_Validate_FO_Establishment()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<EstablishmentFO>(FOType.establishment);
            foreach (EstablishmentFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Establishment(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC058_Validate_FO_EventReason()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<EventReasonFO>(FOType.eventreason);
            foreach (EventReasonFO fo_data in fo_test_datas) { dataaccess.Validate_FO_EventReason(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC059_Validate_FO_Frequency()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<FrequencyFO>(FOType.frequency);
            foreach (FrequencyFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Frequency(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC060_Validate_FO_GeographicArea()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeographicAreaFO>(FOType.geographicarea);
            foreach (GeographicAreaFO fo_data in fo_test_datas) { dataaccess.Validate_FO_GeographicArea(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC061_Validate_FO_GeographicRegion()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeographicRegionFO>(FOType.geographicregion);
            foreach (GeographicRegionFO fo_data in fo_test_datas) { dataaccess.Validate_FO_GeographicRegion(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC062_Validate_FO_GeoZone()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<GeoZoneFO>(FOType.geozone);
            foreach (GeoZoneFO fo_data in fo_test_datas) { dataaccess.Validate_FO_GeoZone(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC063_Validate_FO_JobClassification()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobClassificationFO>(FOType.jobclassification);
            foreach (JobClassificationFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobClassification(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC064_Validate_FO_JobClassificationCS()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobClassificationCSFO>(FOType.jobclassificationcs);
            foreach (JobClassificationCSFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobClassificationCS(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC065_Validate_FO_JobFamily()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFamilyFO>(FOType.jobfamily);
            foreach (JobFamilyFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobFamily(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC066_Validate_FO_JobFamilyGroup()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFamilyGroupFO>(FOType.jobfamilygroup);
            foreach (JobFamilyGroupFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobFamilyGroup(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC067_Validate_FO_JobFunction()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobFunctionFO>(FOType.jobfunction);
            foreach (JobFunctionFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobFunction(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC068_Validate_FO_JobRoleType()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<JobRoleTypeFO>(FOType.jobroletype);
            foreach (JobRoleTypeFO fo_data in fo_test_datas) { dataaccess.Validate_FO_JobRoleType(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC069_Validate_FO_LegalEntity()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<LegalEntityFO>(FOType.legalentity);
            foreach (LegalEntityFO fo_data in fo_test_datas) { dataaccess.Validate_FO_LegalEntity(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC070_Validate_FO_LegalEntityCS()
        {
            //dataaccess = new FODataAccess(Driver);
            //var fo_test_datas = ExcelWorkBook.ReadFoundationData<LegalEntityCSFO>(FOType.legalentitycs);
            //foreach (LegalEntityCSFO fo_data in fo_test_datas) { dataaccess.Validate_FO_LegalEntityCS(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC071_Validate_FO_Location()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<LocationFO>(FOType.location);
            foreach (LocationFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Location(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC072_Validate_FO_ManagementArea()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementAreaFO>(FOType.managementarea);
            foreach (ManagementAreaFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ManagementArea(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC073_Validate_FO_ManagementRegion()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementRegionFO>(FOType.managementregion);
            foreach (ManagementRegionFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ManagementRegion(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC074_Validate_FO_ManagementUnit()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagementUnitFO>(FOType.managementunit);
            foreach (ManagementUnitFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ManagementUnit(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC075_Validate_FO_ManagerialCountry()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ManagerialCountryFO>(FOType.managerialcountry);
            foreach (ManagerialCountryFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ManagerialCountry(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC076_Validate_FO_NameFormat()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<NameFormatFO>(FOType.nameformat);
            foreach (NameFormatFO fo_data in fo_test_datas) { dataaccess.Validate_FO_NameFormat(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC077_Validate_FO_OperatingUnit()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<OperatingUnitFO>(FOType.operatingunit);
            foreach (OperatingUnitFO fo_data in fo_test_datas) { dataaccess.Validate_FO_OperatingUnit(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC078_Validate_FO_PayComponent()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayComponentFO>(FOType.paycomponent);
            foreach (PayComponentFO fo_data in fo_test_datas) { dataaccess.Validate_FO_PayComponent(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC079_Validate_FO_PayComponentGroup()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayComponentGroupFO>(FOType.paycomponentgroup);
            foreach (PayComponentGroupFO fo_data in fo_test_datas) { dataaccess.Validate_FO_PayComponentGroup(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC080_Validate_FO_PayGrade()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayGradeFO>(FOType.paygrade);
            foreach (PayGradeFO fo_data in fo_test_datas) { dataaccess.Validate_FO_PayGrade(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC081_Validate_FO_PayGroup()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayGroupFO>(FOType.paygroup);
            foreach (PayGroupFO fo_data in fo_test_datas) { dataaccess.Validate_FO_PayGroup(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC082_Validate_FO_PayRanges()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<PayRangesFO>(FOType.payranges);
            foreach (PayRangesFO fo_data in fo_test_datas) { dataaccess.Validate_FO_PayRanges(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC083_Validate_FO_ProficiencyLevel()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ProficiencyLevelFO>(FOType.proficiencylevel);
            foreach (ProficiencyLevelFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ProficiencyLevel(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC084_Validate_FO_Rank()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<RankFO>(FOType.rank);
            foreach (RankFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Rank(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC085_Validate_FO_RewardsDiversifier()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<RewardsDiversifierFO>(FOType.rewardsdiversifier);
            foreach (RewardsDiversifierFO fo_data in fo_test_datas) { dataaccess.Validate_FO_RewardsDiversifier(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC086_Validate_FO_ServiceLine()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ServiceLineFO>(FOType.serviceline);
            foreach (ServiceLineFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ServiceLine(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC087_Validate_FO_ServiceType()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<ServiceTypeFO>(FOType.servicetype);
            foreach (ServiceTypeFO fo_data in fo_test_datas) { dataaccess.Validate_FO_ServiceType(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC088_Validate_FO_Speciality()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SpecialityFO>(FOType.speciality);
            foreach (SpecialityFO fo_data in fo_test_datas) { dataaccess.Validate_FO_Speciality(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC089_Validate_FO_SubManagementUnit()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SubManagementUnitFO>(FOType.submanagementunit);
            foreach (SubManagementUnitFO fo_data in fo_test_datas) { dataaccess.Validate_FO_SubManagementUnit(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC090_Validate_FO_SubServiceLine()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<SubServiceLineFO>(FOType.subserviceline);
            foreach (SubServiceLineFO fo_data in fo_test_datas) { dataaccess.Validate_FO_SubServiceLine(fo_data); }
        }

        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC091_Validate_FO_WorkSchedule()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<WorkScheduleFO>(FOType.workschedule);
            foreach (WorkScheduleFO fo_data in fo_test_datas) { dataaccess.Validate_FO_WorkSchedule(fo_data); }
        }
        [Test, Category("Step 03 FO TDDH Validation")]
        public void TC092_Validate_FO_Businessunit_Finance()
        {
            dataaccess = new FODataAccess(Driver);
            var fo_test_datas = ExcelWorkBook.ReadFoundationData<WorkScheduleFO>(FOType.workschedule);
            foreach (WorkScheduleFO fo_data in fo_test_datas) { dataaccess.Validate_FO_WorkSchedule(fo_data); }
        }
        #endregion Test Data validation in TDDH
    }
}