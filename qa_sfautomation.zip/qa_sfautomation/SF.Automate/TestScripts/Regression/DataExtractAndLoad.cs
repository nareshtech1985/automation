﻿namespace EY_Test.TestScripts.Regression
{
    using DatabaseValidation;
    using EY_Test.PageObjects;
    using EY_Test.PageObjects.Modules;
    using NUnit.Framework;
    using Pom;
    using System;
    using System.Collections.Generic;
    using System.Threading;

    [TestFixture]
    public partial class TestSuite : TestRunner
    {
        #region Core HR Data Extraction
        [Test]
        [Category("02_Data_Extraction")]
        public void TCE001_ExtractCoreHRData()
        {
            Driver.Manage().Window.Maximize();
            Driver.Url = "https://e2133-tmn.hci.eu1.hana.ondemand.com/itspaces/shell/design";
            Util.Updatelog("Initiate the IFlow", "Stating IFlow Jobs", State.Done);
            WorkFlow.Run(new WorkFlowParameter() { Driver = Driver, Type = WorkFlowType.All });

            /* Open file explorer to view the automation folder */
            int i = 0;
            Driver.Navigate().GoToUrl(Util.TestConfiguration.GetCustomKeyValue("APIAutomationFolder"));
            Util.Updatelog("Place file in batch folder", "file placed in batch folder", State.Pass);
            do
            {
                Thread.Sleep(5000);
                Driver.Navigate().Refresh();
                i++;
            } while (i < 5);
            /* display the loader */
            Driver.Url = $@"{Util.DirectoryPath}\dataloading.html";
            /// --------------------------------------------------------------------------------------------------------------------------------------------------
            /// Change is passing the start time of the execution to check if the batch is available or not.
            /// Risk is the same batch should not be invoked by anyone during this execution which could cause a failure to the db validation.
            /// --------------------------------------------------------------------------------------------------------------------------------------------------
            TDDHQA.WaitFor_CoreHR_DataLoading(Util.StartTime.ToUniversalTime());

            /*
            if (fileGenerateTime != DateTime.MinValue)
            {
                TDDHQA.WaitForDataLoading(fileGenerateTime);
            }
            else
            {
                TDDHQA.WaitForDataLoading(DateTime.UtcNow.AddHours(3));
            }*/
            Thread.Sleep(TimeSpan.FromMinutes(1));
        }

        #endregion

        #region FO Data Extraction

        [Test]
        [Category("02_Data_Extraction")]
        public void TCE002_ExtractFoundationData()
        {
            workflowparam.Driver = Driver;
            /*
             Generate Zone A File & Downloading to the QA batch server.
             */
            //workflowparam.FoObjectname = new List<string> { "activitytype", "geographicarea" };

            WorkFlow.ExtractFO(workflowparam);

            /* Display the intermitent loader */
            Driver.Url = $@"{Util.DirectoryPath}\dataloading.html";

            /* Wait until the data is loaded to the TDDH QA db*/
            TDDHQA.WaitFor_FO_DataLoading(Util.StartTime.ToUniversalTime());
        }

        //[Test]
        //[Category("Reconfig")]
        public void Reconfigure()
        {
            workflowparam.Driver = Driver;
            /*
             Generate Zone A File & Downloading to the QA batch server.
             */
            workflowparam.FoObjectname = new List<string> { "activitytype", "bank", "belgiumweeklyhours", "brazilcnpj", "careerlevel", "codeblock", "corporateaddress", "costcenter", "currencyexchangerate", "department", "establishment", "eventreason", "frequency", "geographicarea", "geographicregion", "geozone", "jobclassification", "jobclassificationcs", "jobfamily", "jobfamilygroup", "jobfunction", "jobroletype", "legalentity", "legalentitycs", "location", "managementarea", "managementregion", "managementunit", "managerialcountry", "nameformat", "operatingunit", "paycomponent", "paycomponentgroup", "paygrade", "paygroup", "payranges", "proficiencylevel", "rank", "rewardsdiversifier", "serviceline", "servicetype", "speciality", "submanagementunit", "subserviceline", "workschedule", "businessunit_finance" };
            WorkFlow.ReconfigureITSDEV1Jobs(workflowparam);
        }

        #endregion FO Data Extraction    

        #region Common Method For Extracting FO & Core HR
        [Test]
        [Category("02_Data_Extraction")]
        public void TCE003_ExtractCombinedData()
        {
            workflowparam.Driver = Driver;

            /* Generate Zone A File & Downloading to the QA batch server. */
            /* workflowparam.FoObjectname = new List<string> { "ServiceLine","Department" }; */

            //workflowparam.FoObjectname = new List<string> { "ServiceLine", "Department" };
            //WorkFlow.GenerateExtract(workflowparam);
            //workflowparam.FoObjectname = new List<string> { "job", "timeoff" };
            WorkFlow.GenerateExtract_New(workflowparam);

            /* Display the intermitent loader */
            Driver.Url = $@"{Util.DirectoryPath}\dataloading.html";

            /* Wait until the data is loaded to the TDDH QA db*/
            TDDHQA.WaitForDataLoading(workflowparam);
        }

        [Test]
        public void SFTPTest()
        {
            List<string> downloadfiles = new List<string>();
            var ee = FileTransfer.DownloadFiles(new List<string> { "/int/outbound/foundationobject_dev" });
            var sftp = new SFTP(Driver);
            sftp.Login();
            foreach (var foders in new List<string> { "/int/outbound/foundationobject_dev" })
            {
                try
                {
                    sftp.NavigateTo(foders);
                    downloadfiles.Add(sftp.DownloadLatestFile());  //to update the date logic here.
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

        }
        #endregion
    }
}