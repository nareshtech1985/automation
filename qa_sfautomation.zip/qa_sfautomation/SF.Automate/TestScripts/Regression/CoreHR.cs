﻿namespace EY_Test.TestScripts.Regression
{
    using EY_Test.API.Framework;
    using EY_Test.Lib.DataHelpers;
    using NUnit.Framework;
    using Pom;
    using Pom.PageObjects;
    using SF.API.CoreHR.Scenarios;
    using SF.Parameter;
    using System;
    using Test.API.Scenarios;

    [TestFixture]
    public partial class SuccessFactor_Suite : TestRunner
    {
        private DBValidations dB;

        #region API Data Creation

        [Test]
        [Category("01_CoreHR")]

        public void TCC001_Create_Employee_Address_Change()
        {
            var scenario = CoreHRScenario.ADDRESS_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (AddressParameter data in ExcelWorkBook.ReadTestData<AddressParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                AddressChange.AddNewAddress(data);
            }
            //Revalidating the Record via API Call
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<AddressParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                AddressChange.ValidateDataChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        #region Time Off Scenarios

        [Test]
        [Category("01_CoreHR")]
        public void TCC002_Create_Employee_Paid_Leave_of_Absence()
        {
            if (TimeOff.parameters != null) TimeOff.parameters.Clear();
            var scenario = CoreHRScenario.PAID_LEAVE;
            HTMLReport.IsCreation = true;
            foreach (TimeOffParameter timeOff in ExcelWorkBook.ReadTestData<TimeOffParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = timeOff.personIdExternal;
                TimeOff.ApplyTimeOff(timeOff, scenario);
            }
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<TimeOffParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.personIdExternal;
                TimeOff.ValidateDataChange(data, scenario);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC003_Create_Employee_Unpaid_Leave_of_Absence()
        {
            if (TimeOff.parameters != null) TimeOff.parameters.Clear();
            var scenario = CoreHRScenario.UNPAID_LEAVE;
            HTMLReport.IsCreation = true;
            foreach (TimeOffParameter timeOff in ExcelWorkBook.ReadTestData<TimeOffParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = timeOff.personIdExternal;
                TimeOff.ApplyTimeOff(timeOff, scenario);
            }
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<TimeOffParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.personIdExternal;
                TimeOff.ValidateDataChange(data, scenario);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC004_Create_Employee_Return_From_Paid_Leave_of_Absence()
        {
            if (TimeOff.parameters != null) TimeOff.parameters.Clear();
            var scenario = CoreHRScenario.RETURN_PAID_LEAVE;
            HTMLReport.IsCreation = true;
            foreach (TimeOffParameter timeOff in ExcelWorkBook.ReadTestData<TimeOffParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = timeOff.personIdExternal;
                TimeOff.ReturnFromLeave(timeOff, scenario);
            }
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<TimeOffParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.personIdExternal;
                TimeOff.ValidateDataChange(data, scenario);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC005_Create_Employee_Return_From_Unpaid_Leave_of_Absence()
        {
            if (TimeOff.parameters != null) TimeOff.parameters.Clear();
            var scenario = CoreHRScenario.RETURN_UNPAID_LEAVE;
            HTMLReport.IsCreation = true;
            foreach (TimeOffParameter timeOff in ExcelWorkBook.ReadTestData<TimeOffParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = timeOff.personIdExternal;
                TimeOff.ReturnFromLeave(timeOff, scenario);
            }
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<TimeOffParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.personIdExternal;
                TimeOff.ValidateDataChange(data, scenario);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC006_Create_Employee_Long_Term_Disability()
        {
            if (TimeOff.parameters != null) TimeOff.parameters.Clear();
            var scenario = CoreHRScenario.LONG_TERM_DISABILITY;
            HTMLReport.IsCreation = true;
            foreach (TimeOffParameter timeOff in ExcelWorkBook.ReadTestData<TimeOffParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = timeOff.personIdExternal;
                TimeOff.ApplyLongDisability(timeOff);
            }
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<TimeOffParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.personIdExternal;
                TimeOff.ValidateDataChange(data, scenario);
            }
            CoreHRExecution.AddStatus(datas);
        }

        #endregion

        [Test]
        [Category("01_CoreHR")]
        public void TCC007_Create_Employee_Bank_Account_Change()
        {
            var scenario = CoreHRScenario.BANK_ACCOUNT_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (BankChangeParameter data in ExcelWorkBook.ReadTestData<BankChangeParameter>(scenario, Constants.CoreHR))
            {
                try
                {
                    HTMLReport.UserDetails = data.userId;
                    BankChange.ChangeBankinfo(data);
                }
                catch (Exception e)
                {
                    Util.Updatelog("Error", e.Message, State.Error);
                }
            }
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<BankChangeParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                BankChange.ValidateDataChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC008_Create_Employee_Class_Change()
        {
            var scenario = CoreHRScenario.CLASS_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (ClassChangeParameter data in ExcelWorkBook.ReadTestData<ClassChangeParameter>(scenario, Constants.CoreHR))
            {
                try
                {
                    HTMLReport.UserDetails = data.userId;
                    ClassChange.PerformClassChange(data);
                }
                catch (Exception ex)
                {
                    TestLog.Error(ex, "Error");
                }
            }
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<ClassChangeParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                ClassChange.ValidateDataChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC009_Create_Employee_Department_Change()
        {
            var scenario = CoreHRScenario.DEPARTMENT_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (DepartmentParameter data in ExcelWorkBook.ReadTestData<DepartmentParameter>(scenario, Constants.CoreHR))
            {
                try
                {
                    HTMLReport.UserDetails = data.userId;
                    DepartmentChange.PerformDepartmentChange(data);
                }
                catch (Exception e)
                {
                    Util.Updatelog("Create test data for department change", $"Data Creation Failure {e.Message}", State.Fail);
                }
            }
            var datas = RunTimeData<DepartmentParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                DepartmentChange.ValidateDataChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC010_Create_Employee_FTE_Change()
        {
            var scenario = CoreHRScenario.FTE_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (FTEParameter data in ExcelWorkBook.ReadTestData<FTEParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                FTEChange.PerformFTEHourChange(data);
            }
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<FTEParameter>.ReadOutputData(scenario);
            foreach (FTEParameter data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                FTEChange.ValidateDataChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC011_Create_Employee_Rank_Change_Promotion()
        {
            if (RankChange.parameters != null) RankChange.parameters.Clear();
            var scenario = CoreHRScenario.RANK_CHANGE_PROMOTION;
            HTMLReport.IsCreation = true;
            foreach (RankParameter data in ExcelWorkBook.ReadTestData<RankParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                RankChange.PerformPromotion(data);
            }
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<RankParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                RankChange.ValidatePromotionChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC012_Create_Employee_Rank_Change_Demotion()
        {
            if (RankChange.parameters != null) RankChange.parameters.Clear();

            var scenario = CoreHRScenario.RANK_CHANGE_DEMOTION;
            HTMLReport.IsCreation = true;
            foreach (RankParameter data in ExcelWorkBook.ReadTestData<RankParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                RankChange.PerformDemotion(data);
            }

            HTMLReport.IsCreation = false;
            var datas = RunTimeData<RankParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                RankChange.ValidateDemotionChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC013_Create_Employee_STD_Hours_Change()
        {
            var scenario = CoreHRScenario.STD_HRS_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (FTEParameter data in ExcelWorkBook.ReadTestData<FTEParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                StandardHour.PerformStandardHourChange(data);
            }
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<FTEParameter>.ReadOutputData(scenario);
            foreach (FTEParameter data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                StandardHour.ValidateDataChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC014_Create_Employee_Domestic_Transfer()
        {
            var scenario = CoreHRScenario.DOMESTIC_TRANSFER;
            HTMLReport.IsCreation = true;
            foreach (LocationParameter data in ExcelWorkBook.ReadTestData<LocationParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                LocationChange.PerformLocationChange(data);
            }

            HTMLReport.IsCreation = false;
            var datas = RunTimeData<LocationParameter>.ReadOutputData(scenario);
            foreach (LocationParameter data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                LocationChange.ValidateLocationChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC015_Create_Employee_Counselor_Information_Change()
        {
            var scenario = CoreHRScenario.CHANGE_COUNSELOR;
            HTMLReport.IsCreation = true;
            foreach (CounselorParameter data in ExcelWorkBook.ReadTestData<CounselorParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                CounselorChange.PerformCounselorChange(data);
            }

            HTMLReport.IsCreation = false;
            var datas = RunTimeData<CounselorParameter>.ReadOutputData(scenario);
            foreach (CounselorParameter data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                CounselorChange.ValidateDataChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC016_Create_Employee_Termination_Record()
        {
            var scenario = CoreHRScenario.TERMINATE_EMPLOYEE;
            HTMLReport.IsCreation = true;
            foreach (TerminateParameter data in ExcelWorkBook.ReadTestData<TerminateParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                TerminateEmployee.PerformTermination(data, scenario);
            }

            HTMLReport.IsCreation = false;
            var datas = RunTimeData<TerminateParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                TerminateEmployee.ValidateDataChange(data, scenario);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC017_Create_Employee_No_Show_Record()
        {
            var scenario = CoreHRScenario.NO_SHOW;
            HTMLReport.IsCreation = true;
            foreach (TerminateParameter data in ExcelWorkBook.ReadTestData<TerminateParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                TerminateEmployee.PerformTermination(data, scenario);
            }

            HTMLReport.IsCreation = false;
            var datas = RunTimeData<TerminateParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                TerminateEmployee.ValidateDataChange(data, scenario);
            }
            CoreHRExecution.AddStatus(datas);
        }

        //
        [Test]
        [Category("01_CoreHR")]
        public void TCC018_Create_Employee_Start_Date_Change()
        {
            if (StartDateChange.parameters != null) StartDateChange.parameters.Clear();
            var scenario = CoreHRScenario.START_DATE_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (StartDateParameter data in ExcelWorkBook.ReadTestData<StartDateParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                StartDateChange.PerformStartDateChange(data);
            }

            HTMLReport.IsCreation = false;
            var datas = RunTimeData<StartDateParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                StartDateChange.ValidateDataChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC019_Create_Employee_MC_Change_Record()
        {
            var scenario = CoreHRScenario.MC_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (DataChangeParameter data in ExcelWorkBook.ReadTestData<DataChangeParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                ManagerialCountryChange.PerformManagerialCountryChange(data);
            }

            //Revalidating the Record via API Call
            HTMLReport.IsCreation = false;
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                ManagerialCountryChange.ValidateDataChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        //
        [Test]
        [Category("01_CoreHR")]
        public void TCC020_Create_Employee_Global_Assignment_Record()
        {
            if (GlobalAssignment.parameters != null) GlobalAssignment.parameters.Clear();
            var scenario = CoreHRScenario.EMP_GLOBAL_ASSIGNMENT;
            HTMLReport.IsCreation = true;
            foreach (GlobalAssignmentParameter data in ExcelWorkBook.ReadTestData<GlobalAssignmentParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                GlobalAssignment.SendEmployeeOnGlobalAssignment(data);
            }

            HTMLReport.IsCreation = false;
            var datas = RunTimeData<GlobalAssignmentParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                var d = data;
                HTMLReport.UserDetails = data.userId;
                GlobalAssignment.ValidateGlobalAssignment(ref d);
            }
            CoreHRExecution.AddStatus(datas);
        }

        //
        [Test]
        [Category("01_CoreHR")]
        public void TCC021_Create_Employee_Concurrent_Assignment_Record()
        {
            var scenario = CoreHRScenario.CREATE_CONCURRENT_ASSIGNMENT;
            HTMLReport.IsCreation = true;
            foreach (DataChangeParameter data in ExcelWorkBook.ReadTestData<DataChangeParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                ConcurrentAssignment.CreateConcurrentAssignment(data);
            }

            HTMLReport.IsCreation = false;
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(scenario);
            foreach (DataChangeParameter data in datas)
            {
                ConcurrentAssignment.ValidateDataChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        //
        [Test]
        [Category("01_CoreHR")]
        public void TCC022_Create_Employee_End_Global_Assignment_Record()
        {
            if (GlobalAssignment.parameters != null) GlobalAssignment.parameters.Clear();
            var scenario = CoreHRScenario.RETURN_FROM_GLOBAL_ASSIGNMENT;
            HTMLReport.IsCreation = true;
            foreach (GlobalAssignmentParameter data in ExcelWorkBook.ReadTestData<GlobalAssignmentParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                GlobalAssignment.EndAssignment(data);
            }

            HTMLReport.IsCreation = false;
            var datas = RunTimeData<GlobalAssignmentParameter>.ReadOutputData(scenario);
            foreach (GlobalAssignmentParameter data in datas)
            {
                GlobalAssignment.ValidateEndofGlobalAssignment(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("01_CoreHR")]
        public void TCC023_Create_Employee_Legal_Entity_Change()
        {
            var scenario = CoreHRScenario.LEGAL_ENTITY_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (DataChangeParameter data in ExcelWorkBook.ReadTestData<DataChangeParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                LegalEntityChange.PerformLegalEntityChange(data);
            }

            HTMLReport.IsCreation = false;
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(scenario);
            foreach (var data in datas)
            {
                HTMLReport.UserDetails = data.userId;
                LegalEntityChange.ValidateDataChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        #endregion API Data Creation

        #region DB Data Validation

        [Test]
        [Category("03_CoreHR")]
        public void TCV041_Validate_Employee_Address_Change_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<AddressParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<AddressParameter>(CoreHRScenario.ADDRESS_CHANGE); }
            foreach (var data in datas)
            {
                dB.Validate_AddressData(data);
            }
            CoreHRExecution.AddStatus(datas);
        }

        [Test]
        [Category("03_CoreHR")]
        public void TCV042_Validate_Employee_Paid_Leave_of_Absence_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<TimeOffParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<TimeOffParameter>(CoreHRScenario.PAID_LEAVE); }
            foreach (var data in datas)
            {
                dB.Vaidate_PaidLeaveData(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV043_Validate_Employee_Unpaid_Leave_of_Absence_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<TimeOffParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<TimeOffParameter>(CoreHRScenario.UNPAID_LEAVE); }
            foreach (var data in datas)
            {
                dB.Validate_UnPaidLeaveData(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV044_Validate_Employee_Return_From_Paid_Leave_of_Absence_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<TimeOffParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<TimeOffParameter>(CoreHRScenario.RETURN_PAID_LEAVE); }
            foreach (var data in datas)
            {
                dB.Validate_ReturnFromPaidLeaveData(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV045_Validate_Employee_Return_From_Unpaid_Leave_of_Absence_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<TimeOffParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<TimeOffParameter>(CoreHRScenario.RETURN_UNPAID_LEAVE); }
            foreach (var data in datas)
            {
                dB.Validate_ReturnFromPaidLeaveData(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV046_Validate_Employee_Long_Term_Disability_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<TimeOffParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<TimeOffParameter>(CoreHRScenario.LONG_TERM_DISABILITY); }
            foreach (var data in datas)
            {
                dB.Validate_UnPaidLeaveData(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV047_Validate_Employee_Bank_Account_Change_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<BankChangeParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<BankChangeParameter>(CoreHRScenario.BANK_ACCOUNT_CHANGE); }
            foreach (var data in datas)
            {
                dB.Validate_BankDetails(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV048_Validate_Employee_Class_Change_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<ClassChangeParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<ClassChangeParameter>(CoreHRScenario.CLASS_CHANGE); }
            foreach (var data in datas)
            {
                dB.Validate_ClassChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV049_Validate_Employee_Department_Change_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<DataChangeParameter>(CoreHRScenario.DEPARTMENT_CHANGE); }
            foreach (var data in datas)
            {
                dB.Validate_Department_Change(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV050_Validate_Employee_FTE_Change_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<DataChangeParameter>(CoreHRScenario.FTE_CHANGE); }
            foreach (var data in datas)
            {
                dB.Validate_FTEChangeData(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV051_Validate_Employee_Rank_Change_Promotion_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<RankParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<RankParameter>(CoreHRScenario.RANK_CHANGE_PROMOTION); }
            foreach (var data in datas)
            {
                dB.Validate_RankChange_Demotion(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV052_Validate_Employee_Rank_Change_Demotion_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<RankParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<RankParameter>(CoreHRScenario.RANK_CHANGE_DEMOTION); }
            foreach (var data in datas)
            {
                dB.Validate_RankChange_Promotion(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV053_Validate_Employee_STD_Hours_Change_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<DataChangeParameter>(CoreHRScenario.STD_HRS_CHANGE); }
            foreach (var data in datas)
            {
                dB.Validate_StandardHourData(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV054_Validate_Employee_Domestic_Transfer_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<DataChangeParameter>(CoreHRScenario.DOMESTIC_TRANSFER); }
            foreach (var data in datas)
            {
                dB.Validate_DomesticTransferData(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV055_Validate_Employee_Counselor_Information_Change_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<DataChangeParameter>(CoreHRScenario.CHANGE_COUNSELOR); }
            foreach (var data in datas)
            {
                dB.Validate_CounselorChangeData(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV056_Validate_Employee_Termination_Record_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<TerminateParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<TerminateParameter>(CoreHRScenario.TERMINATE_EMPLOYEE); }
            foreach (var data in datas)
            {
                dB.Validate_TerminatedRecords(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV057_Validate_Employee_No_Show_Record_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<TerminateParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<TerminateParameter>(CoreHRScenario.NO_SHOW); }
            foreach (var data in datas)
            {
                dB.Validate_TerminatedRecords(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV058_Validate_Employee_Start_Date_Change_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<DataChangeParameter>(CoreHRScenario.START_DATE_CHANGE); }
            foreach (var data in datas)
            {
                dB.Validate_StartDateChange(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV059_Validate_Employee_MC_Change_Record_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<DataChangeParameter>(CoreHRScenario.MC_CHANGE); }
            foreach (var data in datas)
            {
                dB.Validate_MCChangeRecords(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV060_Validate_Employee_Global_Assignment_Record_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<GlobalAssignmentParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<GlobalAssignmentParameter>(CoreHRScenario.EMP_GLOBAL_ASSIGNMENT); }
            foreach (var data in datas)
            {
                dB.Validate_GlobalAssignment(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV061_Validate_Employee_Concurrent_Assignment_Record_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<DataChangeParameter>(CoreHRScenario.CREATE_CONCURRENT_ASSIGNMENT); }
            foreach (var data in datas)
            {
                dB.Validate_ConcurrentAssignment(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV062_Validate_Employee_End_Global_Assignment_Record_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<GlobalAssignmentParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<GlobalAssignmentParameter>(CoreHRScenario.RETURN_FROM_GLOBAL_ASSIGNMENT); }
            foreach (var data in datas)
            {
                dB.Validate_EndGAAssignment(data);
            }
            CoreHRExecution.AddStatus(datas);
        }


        [Test]
        [Category("03_CoreHR")]
        public void TCV063_Validate_Employee_Legal_Entity_Change_In_TDDH_DB()
        {
            dB = new DBValidations(Driver);
            var datas = RunTimeData<DataChangeParameter>.ReadOutputData(_objectname);
            if (datas.Count == 0) { ExcelWorkBook.ReadTestData<DataChangeParameter>(CoreHRScenario.LEGAL_ENTITY_CHANGE); }
            foreach (var data in datas)
            {
                dB.Validate_MCChangeRecords(data);
            }
            CoreHRExecution.AddStatus(datas);
        }
        #endregion
    }
}