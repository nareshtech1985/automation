﻿namespace EY_Test.TestScripts.Regression
{
    using System;
    using EY_Test.API.Framework;
    using EY_Test.Lib.DataHelpers;
    using NUnit.Framework;
    using Pom;
    using Pom.PageObjects;
    using SF.API.CoreHR.Scenarios;
    using SF.Parameter;
    using Test.API.Scenarios;

    [TestFixture]
    public partial class SuccessFactorPreviewTest : TestRunner
    {
        #region Application Specific Setup and TearDown

        /// <summary>
        /// These functions are specific to the program only
        /// </summary>
        [SetUp]
        public void StartUp()
        {
            var path = Util.DirectoryPath;
            currentCategory = (string)TestContext.CurrentContext.Test.Properties.Get("Category");
            switch (currentCategory)
            {
                case "Step 01 Data Setup":
                    Driver.Url = $@"{path}\apistatus.html";
                    HTMLReport.Driver = Driver;
                    HTMLReport.CallHistory.Clear();
                    HTMLReport.TestName = TestContext.CurrentContext.Test.Name.Replace("_", " ");
                    HTMLReport.UpdateStatusView();
                    break;

                case "Step 02 Data Extraction": Driver.Url = $@"about:blank"; break;
                case "Step 03 TDDH Validation": Driver.Url = $@"{path}\TDDH_Result.html"; break;
            }
        }

        [TearDown]
        public void StopTest()
        {
            switch (currentCategory)
            {
                case "Step 01 Data Setup":
                    HTMLReport.SaveReport();
                    break;

                case "Step 02 Data Extraction":
                    break;

                case "Step 03 TDDH Validation":
                    break;
            }
        }

        #endregion Application Specific Setup and TearDown

        #region API Data Creation

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC001_EMP_ADDRESS_CHANGE()
        {
            var scenario = CoreHRScenario.ADDRESS_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (AddressParameter data in ExcelWorkBook.ReadTestData<AddressParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                AddressChange.AddNewAddress(data);
            }
            //Revalidating the Record via API Call
            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<AddressParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                AddressChange.ValidateDataChange(data);
            }
        }

        #region Time Off Scenarios

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC002_EMP_PAID_LEAVE_OF_ABSENCE()
        {
            var scenario = CoreHRScenario.PAID_LEAVE;
            HTMLReport.IsCreation = true;
            foreach (TimeOffParameter timeOff in ExcelWorkBook.ReadTestData<TimeOffParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = timeOff.personIdExternal;
                TimeOff.ApplyTimeOff(timeOff, scenario);
            }
            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<TimeOffParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.personIdExternal;
                TimeOff.ValidateDataChange(data, scenario);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC003_EMP_UNPAID_LEAVE_OF_ABSENCE()
        {
            var scenario = CoreHRScenario.UNPAID_LEAVE;
            HTMLReport.IsCreation = true;
            foreach (TimeOffParameter timeOff in ExcelWorkBook.ReadTestData<TimeOffParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = timeOff.personIdExternal;
                TimeOff.ApplyTimeOff(timeOff, scenario);
            }
            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<TimeOffParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.personIdExternal;
                TimeOff.ValidateDataChange(data, scenario);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC004_EMP_RETURN_FROM_PAID_LEAVE_OF_ABSENCE()
        {
            var scenario = CoreHRScenario.RETURN_PAID_LEAVE;
            HTMLReport.IsCreation = true;
            foreach (TimeOffParameter timeOff in ExcelWorkBook.ReadTestData<TimeOffParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = timeOff.personIdExternal;
                TimeOff.ReturnFromLeave(timeOff, scenario);
            }
            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<TimeOffParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.personIdExternal;
                TimeOff.ValidateDataChange(data, scenario);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC005_EMP_RETURN_FROM_UNPAID_LEAVE_OF_ABSENCE()
        {
            var scenario = CoreHRScenario.RETURN_UNPAID_LEAVE;
            HTMLReport.IsCreation = true;
            foreach (TimeOffParameter timeOff in ExcelWorkBook.ReadTestData<TimeOffParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = timeOff.personIdExternal;
                TimeOff.ReturnFromLeave(timeOff, scenario);
            }
            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<TimeOffParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.personIdExternal;
                TimeOff.ValidateDataChange(data, scenario);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC006_EMP_EMPLOYEE_LONG_TERM_DISABILITY()
        {
            var scenario = CoreHRScenario.LONG_TERM_DISABILITY;
            HTMLReport.IsCreation = true;
            foreach (TimeOffParameter timeOff in ExcelWorkBook.ReadTestData<TimeOffParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = timeOff.personIdExternal;
                TimeOff.ApplyLongDisability(timeOff);
            }
            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<TimeOffParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.personIdExternal;
                TimeOff.ValidateDataChange(data, scenario);
            }
        }

        #endregion

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC007_EMP_BANK_ACCOUNT_CHANGE()
        {
            var scenario = CoreHRScenario.BANK_ACCOUNT_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (BankChangeParameter data in ExcelWorkBook.ReadTestData<BankChangeParameter>(scenario, Constants.CoreHR))
            {
                try
                {
                    HTMLReport.UserDetails = data.userId;
                    BankChange.ChangeBankinfo(data);
                }
                catch (Exception e)
                {
                    Util.Updatelog("Error", e.Message, State.Error);
                }
            }
            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<BankChangeParameter>.ReadOutputData(CoreHRScenario.BANK_ACCOUNT_CHANGE))
            {
                HTMLReport.UserDetails = data.userId;
                BankChange.ValidateDataChange(data);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC008_EMP_CLASS_CHANGE()
        {
            var scenario = CoreHRScenario.CLASS_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (ClassChangeParameter data in ExcelWorkBook.ReadTestData<ClassChangeParameter>(scenario, Constants.CoreHR))
            {
                try
                {
                    HTMLReport.UserDetails = data.userId;
                    ClassChange.PerformClassChange(data);
                }
                catch (Exception ex)
                {
                    TestLog.Error(ex, "Error");
                }
            }
            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<ClassChangeParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                ClassChange.ValidateDataChange(data);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC009_EMP_DEPARTMENT_CHANGE()
        {
            var scenario = CoreHRScenario.DEPARTMENT_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (DepartmentParameter data in ExcelWorkBook.ReadTestData<DepartmentParameter>(scenario, Constants.CoreHR))
            {
                try
                {
                    HTMLReport.UserDetails = data.userId;
                    DepartmentChange.PerformDepartmentChange(data);
                }
                catch (Exception e)
                {
                    Util.Updatelog("Create test data for department change", $"Data Creation Failure {e.Message}", State.Fail);
                }
            }
            foreach (var data in RunTimeData<DepartmentParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                DepartmentChange.ValidateDataChange(data);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC010_EMP_FTE_CHANGE()
        {
            var scenario = CoreHRScenario.FTE_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (FTEParameter data in ExcelWorkBook.ReadTestData<FTEParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                FTEChange.PerformFTEHourChange(data);
            }
            HTMLReport.IsCreation = false;
            foreach (FTEParameter data in RunTimeData<FTEParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                FTEChange.ValidateDataChange(data);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC011_EMP_RANK_CHANGE_PROMOTION()
        {
            var scenario = CoreHRScenario.RANK_CHANGE_PROMOTION;
            HTMLReport.IsCreation = true;
            foreach (RankParameter data in ExcelWorkBook.ReadTestData<RankParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                RankChange.PerformPromotion(data);
            }


            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<RankParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                RankChange.ValidatePromotionChange(data);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC012_EMP_RANK_CHANGE_DEMOTION()
        {
            var scenario = CoreHRScenario.RANK_CHANGE_DEMOTION;
            HTMLReport.IsCreation = true;
            foreach (RankParameter data in ExcelWorkBook.ReadTestData<RankParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                RankChange.PerformDemotion(data);
            }

            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<RankParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                RankChange.ValidateDemotionChange(data);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC013_EMP_STD_HRS_CHANGE()
        {
            var scenario = CoreHRScenario.STD_HRS_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (FTEParameter data in ExcelWorkBook.ReadTestData<FTEParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                StandardHour.PerformStandardHourChange(data);
            }
            HTMLReport.IsCreation = false;
            foreach (FTEParameter data in RunTimeData<FTEParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                StandardHour.ValidateDataChange(data);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC014_EMP_DOMESTIC_TRANSFER()
        {
            var scenario = CoreHRScenario.DOMESTIC_TRANSFER;
            HTMLReport.IsCreation = true;
            foreach (LocationParameter data in ExcelWorkBook.ReadTestData<LocationParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                LocationChange.PerformLocationChange(data);
            }

            HTMLReport.IsCreation = false;
            foreach (LocationParameter data in RunTimeData<LocationParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                LocationChange.ValidateLocationChange(data);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC015_EMP_CHANGE_COUNSELOR_INFORMATION()
        {
            var scenario = CoreHRScenario.CHANGE_COUNSELOR;
            HTMLReport.IsCreation = true;
            foreach (CounselorParameter data in ExcelWorkBook.ReadTestData<CounselorParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                CounselorChange.PerformCounselorChange(data);
            }

            HTMLReport.IsCreation = false;
            foreach (CounselorParameter data in RunTimeData<CounselorParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                CounselorChange.ValidateDataChange(data);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC016_EMP_TERMINATION()
        {
            var scenario = CoreHRScenario.TERMINATE_EMPLOYEE;
            HTMLReport.IsCreation = true;
            foreach (TerminateParameter data in ExcelWorkBook.ReadTestData<TerminateParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                TerminateEmployee.PerformTermination(data, scenario);
            }

            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<TerminateParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                TerminateEmployee.ValidateDataChange(data, scenario);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC017_EMP_NO_SHOW()
        {
            var scenario = CoreHRScenario.NO_SHOW;
            HTMLReport.IsCreation = true;
            foreach (TerminateParameter data in ExcelWorkBook.ReadTestData<TerminateParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                TerminateEmployee.PerformTermination(data, scenario);
            }

            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<TerminateParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                TerminateEmployee.ValidateDataChange(data, scenario);
            }
        }

        //
        [Test]
        [Category("Step 01 Data Setup")]
        public void TC018_EMP_START_DATE_CHANGE()
        {
            var scenario = CoreHRScenario.START_DATE_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (StartDateParameter data in ExcelWorkBook.ReadTestData<StartDateParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                StartDateChange.PerformStartDateChange(data);
            }

            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<StartDateParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                StartDateChange.ValidateDataChange(data);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC019_EMP_MC_CHANGE()
        {
            var scenario = CoreHRScenario.MC_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (DataChangeParameter data in ExcelWorkBook.ReadTestData<DataChangeParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                ManagerialCountryChange.PerformManagerialCountryChange(data);
            }

            //Revalidating the Record via API Call
            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<DataChangeParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                ManagerialCountryChange.ValidateDataChange(data);
            }
        }

        //
        [Test]
        [Category("Step 01 Data Setup")]
        public void TC020_EMP_SEND_GLOBAL_ASSIGNMENT()
        {
            var scenario = CoreHRScenario.EMP_GLOBAL_ASSIGNMENT;
            HTMLReport.IsCreation = true;
            foreach (GlobalAssignmentParameter data in ExcelWorkBook.ReadTestData<GlobalAssignmentParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                GlobalAssignment.SendEmployeeOnGlobalAssignment(data);
            }

            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<GlobalAssignmentParameter>.ReadOutputData(CoreHRScenario.EMP_GLOBAL_ASSIGNMENT))
            {
                var d = data;
                HTMLReport.UserDetails = data.userId;
                GlobalAssignment.ValidateGlobalAssignment(ref d);
            }
        }

        //
        [Test]
        [Category("Step 01 Data Setup")]
        public void TC021_EMP_CREATE_CONCURRENT_ASSIGNMENT()
        {
            var scenario = CoreHRScenario.CREATE_CONCURRENT_ASSIGNMENT;
            HTMLReport.IsCreation = true;
            foreach (DataChangeParameter data in ExcelWorkBook.ReadTestData<DataChangeParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                ConcurrentAssignment.CreateConcurrentAssignment(data);
            }

            HTMLReport.IsCreation = false;
            foreach (DataChangeParameter data in RunTimeData<DataChangeParameter>.ReadOutputData(scenario))
            {
                ConcurrentAssignment.ValidateDataChange(data);
            }
        }

        //
        [Test]
        [Category("Step 01 Data Setup")]
        public void TC022_EMP_RETURN_FROM_GLOBAL_ASSIGNMENT()
        {
            var scenario = CoreHRScenario.RETURN_FROM_GLOBAL_ASSIGNMENT;
            HTMLReport.IsCreation = true;
            foreach (GlobalAssignmentParameter data in ExcelWorkBook.ReadTestData<GlobalAssignmentParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                GlobalAssignment.EndAssignment(data);
            }

            HTMLReport.IsCreation = false;
            foreach (GlobalAssignmentParameter data in RunTimeData<GlobalAssignmentParameter>.ReadOutputData(scenario))
            {
                GlobalAssignment.ValidateEndofGlobalAssignment(data);
            }
        }

        [Test]
        [Category("Step 01 Data Setup")]
        public void TC023_EMP_LEGAL_ENTITY_CHANGE()
        {
            var scenario = CoreHRScenario.MC_CHANGE;
            HTMLReport.IsCreation = true;
            foreach (DataChangeParameter data in ExcelWorkBook.ReadTestData<DataChangeParameter>(scenario, Constants.CoreHR))
            {
                HTMLReport.UserDetails = data.userId;
                LegalEntityChange.PerformLegalEntityChange(data);
            }

            HTMLReport.IsCreation = false;
            foreach (var data in RunTimeData<DataChangeParameter>.ReadOutputData(scenario))
            {
                HTMLReport.UserDetails = data.userId;
                LegalEntityChange.ValidateDataChange(data);
            }
        }

        #endregion API Data Creation
    }
}