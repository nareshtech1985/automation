﻿

using SF.Parameter;
using System;

namespace EY_Test.TestScripts.InputObjects
{
    public class InputTestData
    {
        [ColumnHeader(1, "First Name")] public string firstname { get; set; }
        [ColumnHeader(2, "Last Name")] public string lastname { get; set; }
        [ColumnHeader(3, "GUI")] public string GUI { get; set; }
        [ColumnHeader(4, "GPN")] public string GPN { get; set; }
        [ColumnHeader(5, "LPN")] public string LPN { get; set; }
        [ColumnHeader(6, "UserId")] public string userid { get; set; }
        [ColumnHeader(7, "Start Date")] public string date { get; set; }
        [ColumnHeader(8, "Country")] public string country { get; set; }
        [ColumnHeader(9, "Rank")] public string rank { get; set; }
        [ColumnHeader(10, "Job Code")] public string jobcode { get; set; }
        [ColumnHeader(11, "Department ID")] public string departmentid { get; set; }
        [ColumnHeader(12, "Legal Entity ID")] public string legalEntityId { get; set; }
        [ColumnHeader(13, "Employee Class")] public string EmployeeClass { get; set; } = "Employee";
        [ColumnHeader(14, "Employment Type")] public string EmploymentType { get; set; } = "Permanent Contract";
        [ColumnHeader(15, "Hire Date")] public DateTime HireDate { get; set; }
    }
}
