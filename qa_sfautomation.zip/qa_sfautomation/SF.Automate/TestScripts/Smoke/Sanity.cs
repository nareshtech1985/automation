﻿namespace EY_Test.TestScripts.Smoke
{
    using cryptic;
    using EY_Test.PageObjects.Modules;
    using EY_Test.TestScripts.InputObjects;
    using NUnit.Framework;
    using Pom;
    using SF.API.CoreHR.Scenarios;
    using System;
    using System.Collections.Generic;
    using System.Threading;

    [TestFixture]
    public class Sanity : TestRunner
    {
        #region IDT Payload Verification

        [Test]
        [Category("IDT API Payload Test")]
        [TestCaseSource(nameof(ReconcileData))]
        public void Reconcile_EmployeeData(InputTestData temp)
        {
            Driver.Url = $@"{Util.DirectoryPath}\apistatus.html";
            IDTAction.ReconcileRecord(temp.GUI, temp.userid, Convert.ToDateTime(temp.date));
            Thread.Sleep(2000);
        }

        private static IEnumerable<InputTestData> ReconcileData()
        {
            yield return new InputTestData() { GUI = "3060958", userid = "3060958", date = "2021-11-24" };
            yield return new InputTestData() { GUI = "3060957", userid = "3060957", date = "2021-09-24" };
            yield return new InputTestData() { GUI = "3060955", userid = "3060955", date = "2021-11-01" };
            yield return new InputTestData() { GUI = "3060954", userid = "3060954", date = "2021-11-10" };
            yield return new InputTestData() { GUI = "3060953", userid = "3060953", date = "2021-11-24" };
        }

        #endregion

        #region Framwork-Helper-Scripts

        [Test]
        [Category("Data Extraction Test")]
        public void RetrivefilefromSFTP_ITSDEV()
        {
            var id = Util.StartTime;
            Util.StartTime = DateTime.Now.AddHours(-4);
            List<string> downloadFolder = new List<string> { "/int/outbound/test" };
            var downloadfiles = FileTransfer.DownloadFiles(downloadFolder);
            Util.CopyFileToShare(downloadfiles);
            Util.StartTime = id;
        }

        [Test]
        [Category("KeyGenerate")]
        public void GenerateKey()
        {
            Cred CypherProgram = new Cred() { Publickey = Util.TestConfiguration.GetCustomKeyValue("publicKey") };
            Console.WriteLine($"Cred: {CypherProgram.Encrypt("Fieldglass2022")}");
            Console.WriteLine($"Cred: {CypherProgram.Encrypt("Fieldglass@2022")}");


        }
        #endregion
    }

}