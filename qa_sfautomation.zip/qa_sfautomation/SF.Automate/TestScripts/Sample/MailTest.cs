﻿

namespace SF.Automate.TestScripts.Sample
{
    using cryptic;
    using NUnit.Framework;
    using Pom;
    using System;
    using System.Collections.Generic;

    [TestFixture]
    internal class MailTest
    {
        //[Test]
        public void SendMail()
        {
            Util.SendEmailReport(new TestSuite()
            {
                Environment = "ITSDEV1",
                MachineName = Environment.MachineName,
                Tests = new List<TestReport>()
            {
                new TestReport(){TestCaseId = "1",TestCaseName="First Test Case",TestCaseResult = "Pass",TestDataCount=1,TestModule="Module 1"},
                new TestReport(){TestCaseId = "1",TestCaseName="First Test Case",TestCaseResult = "Pass",TestDataCount=1,TestModule="Module 1"},
                new TestReport(){TestCaseId = "1",TestCaseName="First Test Case",TestCaseResult = "Pass",TestDataCount=1,TestModule="Module 1"},
                new TestReport(){TestCaseId = "1",TestCaseName="First Test Case",TestCaseResult = "Pass",TestDataCount=1,TestModule="Module 1"},
                new TestReport(){TestCaseId = "1",TestCaseName="First Test Case",TestCaseResult = "Pass",TestDataCount=1,TestModule="Module 1"}
            }
            });
        }

        //[Test]
        public void GenerateKey()
        {
            Cred CypherProgram = new Cred() { Publickey = "eY*21cbs" };
            Console.WriteLine(CypherProgram.Encrypt("qa2022*Mar"));
        }
    }
}
