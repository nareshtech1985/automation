﻿namespace EY_Test.API.FoundationObjects
{
    using EY_Test.API.Entities.Foundation;
    using EY_Test.API.Framework;
    using System;
    class JobFamilyGroup : IFOFunction<JobFamilyGroupFO>
    {
        public void Create(JobFamilyGroupFO fo_object)
        {
            /* script work in progress */
        }

        public void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public void Validate(JobFamilyGroupFO fo_object)
        {
            /* script work in progress */
        }
    }
}
