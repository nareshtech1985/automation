﻿namespace EY_Test.API.FoundationObjects
{
    using EY_Test.API.Entities.Foundation;
    using EY_Test.API.Framework;
    using System;
    class Establishment : IFOFunction<EstablishmentFO>
    {
        public void Create(EstablishmentFO fo_object)
        {
            /* script work in progress */
        }

        public void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public void Validate(EstablishmentFO fo_object)
        {
            /* script work in progress */
        }
    }
}
