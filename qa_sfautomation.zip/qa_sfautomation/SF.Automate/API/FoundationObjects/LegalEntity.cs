﻿namespace EY_Test.API.Entities.Foundation
{
    using EY_Test.API.Framework;
    using Newtonsoft.Json;
    using Pom;
    using POMFramework.Lib;
    using SF.APICore;
    using SF.Entity;

    public class LegalEntity : IFOFunction<CompanyFO>
    {
        public void Create(CompanyFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "FOCompany"
                },
                fo_object.country,
                fo_object.currency,
                fo_object.cust_gdentitycode,
                fo_object.cust_transfergroup,
                fo_object.externalCode,
                fo_object.startDate,
                fo_object.status,
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Formatting.Indented));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for location", "location created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for location", "location not created", State.APIFail);
            }
        }

        public void Generate_ZoneA_Extract()
        {
            
        }

        public void Validate(CompanyFO fo_object)
        {
            
        }
    }
}
