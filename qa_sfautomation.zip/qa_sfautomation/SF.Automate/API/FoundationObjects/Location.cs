﻿namespace EY_Test.API.FoundationObjects
{
    using EY_Test.API.Entities.Foundation;
    using EY_Test.API.Framework;
    using Newtonsoft.Json;
    using Pom;
    using POMFramework.Lib;
    using SF.APICore;
    using SF.Entity;

    public class Location : IFOFunction<LocationFO>
    {
        public void Create(LocationFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "FOLocation"
                },
                fo_object.addressCountry,
                fo_object.companyFlx,
                fo_object.customString7,
                fo_object.description,
                fo_object.externalCode,
                fo_object.geozoneFlx,
                fo_object.locationGroup,
                fo_object.name,
                fo_object.startDate,
                fo_object.status,
                fo_object.timezone
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Formatting.Indented));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for company", "company created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for company", "company not created", State.APIFail);
            }
        }

        public void Generate_ZoneA_Extract()
        {
            
        }

        public void Validate(LocationFO fo_object)
        {
            
        }
    }
}
