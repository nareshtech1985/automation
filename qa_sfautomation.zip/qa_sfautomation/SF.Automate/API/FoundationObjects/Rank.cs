﻿using EY_Test.API.Entities.Foundation;
using EY_Test.API.Framework;
using Newtonsoft.Json;
using Pom;
using POMFramework.Lib;
using SF.APICore;
using SF.Entity;

namespace EY_Test.API.FoundationObjects
{
    public class Rank : IFOFunction<RankFO>
    {
        public void Create(RankFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "NameFormatGO"
                },
                fo_object.externalCode,
                fo_object.externalName_defaultValue,
                fo_object.externalName_en_US
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Formatting.Indented));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for name format", "name format created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for name format", "name format not created", State.APIFail);
            }
        }

        public void Generate_ZoneA_Extract()
        {
            
        }

        public void Validate(RankFO fo_object)
        {
            
        }
    }
}
