﻿using EY_Test.API.Entities.Foundation;
using EY_Test.API.Framework;
using System;

namespace EY_Test.API.FoundationObjects
{
    class ManagementUnit : IFOFunction<ManagementUnitFO>
    {
        public void Create(ManagementUnitFO fo_object)
        {
            /* script work in progress */
        }

        public void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public void Validate(ManagementUnitFO fo_object)
        {
            /* script work in progress */
        }
    }
}
