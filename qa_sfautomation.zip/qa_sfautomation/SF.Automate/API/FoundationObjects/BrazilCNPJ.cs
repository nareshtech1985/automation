namespace EY_Test.API.FoundationObjects
{
    using EY_Test.API.Entities.Foundation;
    using EY_Test.API.Framework;
    using Newtonsoft.Json;
    using Pom;
    using POMFramework.Lib;
    using SF.APICore;
    using SF.Entity;
    public class BrazilCNPJ : IFOFunction<BrazilCNPJFO>
    {
        public void Create(BrazilCNPJFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "cust_Brazilcnpj"
                },
                fo_object.cust_description,
                fo_object.effectiveStartDate,
                fo_object.externalCode,
                fo_object.externalName,
                fo_object.mdfSystemStatus
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Formatting.Indented));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for brazil cnpj", "data for brazil cnpj created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for brazil cnpj", "data for brazil cnpj not created", State.APIFail);
            }
        }

        public void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public void Validate(BrazilCNPJFO fo_object)
        {
            /* script work in progress */
        }
    }
}