﻿namespace EY_Test.API.FoundationObjects
{
    using EY_Test.API.Entities.Foundation;
    using EY_Test.API.Framework;
    using System;

    class CareerLevel : IFOFunction<CareerLevelFO>
    {
        public void Create(CareerLevelFO fo_object)
        {
            /* script work in progress */
        }

        public void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public void Validate(CareerLevelFO fo_object)
        {
            /* script work in progress */
        }
    }
}
