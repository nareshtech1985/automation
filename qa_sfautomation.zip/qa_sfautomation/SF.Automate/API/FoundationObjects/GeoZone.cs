﻿using EY_Test.API.Entities.Foundation;
using EY_Test.API.Framework;
using Newtonsoft.Json;
using Pom;
using POMFramework.Lib;
using SF.APICore;
using SF.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EY_Test.API.FoundationObjects
{
    public class GeoZone : IFOFunction<GeoZoneFO>
    {
        public void Create(GeoZoneFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "FOGeozone"
                },
                fo_object.adjustmentPercentage,
                fo_object.externalCode,
                fo_object.name,
                fo_object.startDate,
                fo_object.status,
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Formatting.Indented));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for geozone", "geozone created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for geozone", "geozone not created", State.APIFail);
            }
        }

        public void Generate_ZoneA_Extract()
        {
            
        }

        public void Validate(GeoZoneFO fo_object)
        {
            
        }
    }
}
