﻿namespace EY_Test.API.FoundationObjects
{
    using EY_Test.API.Entities.Foundation;
    using EY_Test.API.Framework;
    using Newtonsoft.Json;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    class BelgiumWeeklyHours : IFOFunction<BelgiumWeeklyHoursFO>
    {
        public void Create(BelgiumWeeklyHoursFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "cust_BELGIUM_ACTUAL_WEEKLY_HOURS"
                },
                fo_object.effectiveStartDate,
                fo_object.externalCode,
                fo_object.externalName,
                fo_object.mdfSystemStatus,
                fo_object.cust_FTEHRSGFIS,
                fo_object.cust_STDHRSGFIS,
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Formatting.Indented));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for belgium actual weekly hours", "data for belgium actual weekly hours created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for belgium actual weekly hours", "data for belgium actual weekly hours not created", State.APIFail);
            }
        }

        public void Generate_ZoneA_Extract()
        {
            
        }

        public void Validate(BelgiumWeeklyHoursFO fo_object)
        {
            
        }
    }
}
