﻿namespace EY_Test.API.FoundationObjects
{
    using EY_Test.API.Entities.Foundation;
    using EY_Test.API.Framework;
    using Newtonsoft.Json;
    using Pom;
    using SF.APICore;
    using SF.Entity;

    public class ActivityType : IFOFunction<ActivityTypeFO>
    {
        public void Create(ActivityTypeFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "cust_activity_type"
                },
                fo_object.effectiveStartDate,
                fo_object.externalCode,
                fo_object.mdfSystemStatus,
                fo_object.externalName_defaultValue,
                fo_object.externalName_en_US,
                fo_object.cust_Description_defaultValue,
                fo_object.cust_Description_en_US
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Formatting.Indented));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for activity type", "activity type created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for activity type", "activity type not created", State.APIFail);
            }
        }

        public void Generate_ZoneA_Extract()
        {
            
        }

        public void Validate(ActivityTypeFO fo_object)
        {
            
        }
    }
}
