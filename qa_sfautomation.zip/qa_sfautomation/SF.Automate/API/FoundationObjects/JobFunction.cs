﻿namespace EY_Test.API.FoundationObjects
{
    using EY_Test.API.Entities.Foundation;
    using EY_Test.API.Framework;
    class JobFunction : IFOFunction<JobFunctionFO>
    {
        public void Create(JobFunctionFO fo_object)
        {
            throw new System.NotImplementedException();
        }

        public void Generate_ZoneA_Extract()
        {
            throw new System.NotImplementedException();
        }

        public void Validate(JobFunctionFO fo_object)
        {
            throw new System.NotImplementedException();
        }
    }
}
