﻿namespace EY_Test.API.FoundationObjects
{
    using EY_Test.API.Entities.Foundation;
    using EY_Test.API.Framework;
    using System;

    class GeographicRegion : IFOFunction<GeographicRegionFO>
    {
        public void Create(GeographicRegionFO fo_object)
        {
            /* script work in progress */
        }

        public void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public void Validate(GeographicRegionFO fo_object)
        {
            /* script work in progress */
        }
    }
}
