﻿

namespace EY_Test.API.Parameters.IDT.GUISearch
{
    using System;

    using System.Collections.Generic;

    public class IDTSearchInput
    {
        public string gui { get; set; } = "";
        public string fName { get; set; } = "";
        public bool fNameFlx { get; set; } = false;
        public string lName { get; set; } = "";
        public bool lNameFlx { get; set; } = false;
        public string slName { get; set; } = "";
        public bool slNameFlx { get; set; } = false;
        public string nationalId { get; set; } = "";
        public string nationalIdCtry { get; set; } = "";
        public string bDay { get; set; } = "";
        public string bMonth { get; set; } = "";
        public string bYear { get; set; } = "";
        public string doh { get; set; } = "";
        public string gender { get; set; } = "";
    }
    public class IDTSearchOutput
    {
        public bool respStatus { get; set; }
        public string displayMessage { get; set; }
        public string message { get; set; }
        public List<Gui> GUIs { get; set; }
    }

    public class Gui
    {
        public string GUI_CODE { get; set; }
        public string LPN_CODE { get; set; }
        public string GPN_CODE { get; set; }
        public string GUI_STATUS { get; set; }
        public string LPN_STATUS { get; set; }
        public string GPN_STATUS { get; set; }
        public string FIRST_NAME { get; set; }
        public string FIRST_NAME_PREF { get; set; }
        public string LAST_NAME { get; set; }
        public string LAST_NAME_PREF { get; set; }
        public string SECOND_LAST_NAME { get; set; }
        public string MIDDLE_NAME { get; set; }
        public string MIDDLE_NAME_PREF { get; set; }
        public string MAIDEN_NAME { get; set; }
        public string GENDER { get; set; }
        public DateTime DOB { get; set; }
        public string EMPLOYMENT_STATUS { get; set; }
        public DateTime DOH { get; set; }
        public object DOT { get; set; }
        public string GEO_COUNTRY_CODE { get; set; }
        public string MANAGERIAL_COUNTRY_CODE { get; set; }
        public string LEGAL_ENTITY_CODE { get; set; }
        public string LEGAL_ENTITY_NAME { get; set; }
        public string EMPLOYEE_CLASS_NAME { get; set; }
        public int IS_PRIMARY { get; set; }
    }


}
