﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace EY_Test.API.Parameters.IDT.Reconcile
{

    public class Reconcile
    {
        public Record record { get; set; }
    }

    public class Record
    {
        public Id id { get; set; }
        public List<Name> names { get; set; }
        public Empdetails empDetails { get; set; }
        public List<Nid> nIds { get; set; }
        public string kmsUserId { get; set; } = "";
        public string workerId { get; set; } = "";
        public string userId { get; set; } = "";
        public string personId { get; set; } = "";
        public string personUUId { get; set; } = "";
        [JsonProperty("event")]
        public string _event { get; set; } = "";
        public string eventReason { get; set; } = "";
    }

    public class Id
    {
        public string gui { get; set; } = "";
        public string lpn { get; set; } = "";
        public string gpn { get; set; } = "";
        public string gpnType { get; set; } = "1";
    }

    public class Empdetails
    {
        public string empClass { get; set; }
        public string empType { get; set; }
        public string leCode { get; set; }
        public string emplStatus { get; set; }
        public string mrCode { get; set; }
        public string gaCode { get; set; }
        public string grCode { get; set; }
        public string maCode { get; set; }
        public string gcCode { get; set; }
        public string mcCode { get; set; }
        public string doh { get; set; }
        public string dot { get; set; }
        public string isPrimary { get; set; } = "1";
    }

    public class Name
    {
        public string fName { get; set; } = "";
        public string fNamePref { get; set; } = "";
        public string lName { get; set; } = "";
        public string lNamePref { get; set; } = "";
        public string mName { get; set; } = "";
        public string mNamePref { get; set; } = "";
        public string maidenName { get; set; } = "";
        public string slName { get; set; } = "";
        public string gender { get; set; } = "";
        public string dob { get; set; } = "1900-01-01";
        public string startDate { get; set; } = "1900-01-01";
        public string endDate { get; set; } = "9999-12-30";
    }

    public class Nid
    {
        public string nationalIDCountry { get; set; } = "";
        public string nationalID { get; set; } = "";
    }

}
