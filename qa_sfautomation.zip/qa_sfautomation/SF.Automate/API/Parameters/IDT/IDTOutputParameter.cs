﻿
namespace EY_Test.API.Parameters.IDT
{
    using Newtonsoft.Json;

    public class IDTOutputParameter
    {
        [JsonProperty("CONTEXTID", NullValueHandling = NullValueHandling.Ignore)]
        public string Contextid { get; set; }

        [JsonProperty("CONTEXT_SOURCE", NullValueHandling = NullValueHandling.Ignore)]
        public string ContextSource { get; set; }

        [JsonProperty("CONTEXT_SOR", NullValueHandling = NullValueHandling.Ignore)]
        public string ContextSor { get; set; }

        [JsonProperty("GUI", NullValueHandling = NullValueHandling.Ignore)]
        public string Gui { get; set; }

        [JsonProperty("LPN", NullValueHandling = NullValueHandling.Ignore)]
        public string Lpn { get; set; }

        [JsonProperty("GPN", NullValueHandling = NullValueHandling.Ignore)]
        public string Gpn { get; set; }

        [JsonProperty("GUI_STATUS", NullValueHandling = NullValueHandling.Ignore)]
        public string GuiStatus { get; set; }

        [JsonProperty("LPN_STATUS", NullValueHandling = NullValueHandling.Ignore)]
        public string LpnStatus { get; set; }

        [JsonProperty("GPN_STATUS", NullValueHandling = NullValueHandling.Ignore)]
        public string GpnStatus { get; set; }

        [JsonProperty("GUI_MESSAGE", NullValueHandling = NullValueHandling.Ignore)]
        public string GuiMessage { get; set; }

        [JsonProperty("LPN_MESSAGE", NullValueHandling = NullValueHandling.Ignore)]
        public string LpnMessage { get; set; }

        [JsonProperty("GPN_MESSAGE", NullValueHandling = NullValueHandling.Ignore)]
        public string GpnMessage { get; set; }

        [JsonProperty("message", NullValueHandling = NullValueHandling.Ignore)]
        public string Message { get; set; }

        [JsonProperty("respStatus", NullValueHandling = NullValueHandling.Ignore)]
        public bool RespStatus { get; set; }

        [JsonProperty("messageTrace", NullValueHandling = NullValueHandling.Ignore)]
        public string MessageTrace { get; set; }
    }
}
