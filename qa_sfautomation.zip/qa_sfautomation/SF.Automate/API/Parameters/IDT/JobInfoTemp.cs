﻿namespace EY_Test.API.Parameters.IDT
{
    using Newtonsoft.Json;
    using SF.Entity;
    using System;
    using System.Collections.Generic;

    public partial class JobInfoTemp
    {
        [JsonProperty("results")]
        public List<Result> Results { get; set; }
    }

    public partial class Result
    {
        [JsonProperty("__metadata")]
        public Metadata Metadata { get; set; }

        [JsonProperty("seqNumber")]
        public string SeqNumber { get; set; }

        [JsonProperty("startDate")]
        public DateTime StartDate { get; set; }

        [JsonProperty("employeeClass")]
        public string EmployeeClass { get; set; }

        [JsonProperty("customString18")]
        public string CustomString18 { get; set; }

        [JsonProperty("emplStatus")]
        public string EmplStatus { get; set; }

        [JsonProperty("businessUnit")]
        public string BusinessUnit { get; set; }

        [JsonProperty("employmentType")]
        public string EmploymentType { get; set; }

        [JsonProperty("endDate")]
        public DateTime EndDate { get; set; }

        [JsonProperty("countryOfCompany")]
        public string CountryOfCompany { get; set; }

        [JsonProperty("customString5")]
        public string CustomString5 { get; set; }

        [JsonProperty("customString4")]
        public string CustomString4 { get; set; }

        [JsonProperty("customString21")]
        public string CustomString21 { get; set; }

        [JsonProperty("customString14")]
        public string CustomString14 { get; set; }

        [JsonProperty("customString15")]
        public string CustomString15 { get; set; }

        [JsonProperty("customString6")]
        public string CustomString6 { get; set; }

        [JsonProperty("company")]
        public string Company { get; set; }

        [JsonProperty("event")]
        public string Event { get; set; }
        [JsonProperty("eventReason")]
        public string EventReason { get; set; }
    }

}
