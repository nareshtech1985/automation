﻿namespace EY_Test.API.Parameters.IDT
{
    using Newtonsoft.Json;
    public class IDTInputParameter
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string contextId { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string contextSrc { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string contextSoR { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public bool isPfn { get; set; } = false;
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string lastName { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public bool isPln { get; set; } = false;
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string firstName { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public bool isPmn { get; set; } = false;
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string lastName2 { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string providedGUI { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string gender { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string dob { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public bool isBoomerang { get; set; } = true;
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string leCode { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string ecCode { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string etCode { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string mrCode { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string gcCode { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string mcCode { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string doh { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public string mode { get; set; } = "";
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)] public bool traceFlag { get; set; } = false;
    }
}
