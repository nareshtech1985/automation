﻿namespace SF.APICore
{
    using Newtonsoft.Json;
    using Pom;
    using SF.API.CoreHR.Scenarios;
    using SF.Entity;
    using SF.Entity.Employment;
    using SF.FO;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Reflection;

    #region Termination Enumeration

    /// <summary>
    /// Termination event type
    /// </summary>
    public enum TerminationType
    {

        // Death
        TAE,
        // Clean Up
        TAF,
        // Pension/Retirement
        TAG,
        // Separation by  Re-organization
        TAH,
        // Legal Entity Change
        TAI,
        // Change Employee Class
        TAJ,
        // Secondment
        TAK,
        // No Show
        TAL,
        // Separation
        TAM,
        // Career Break
        TAN,
        // Separation for Visa Reasons
        TAV
    }

    #endregion

    public class SFComponent
    {
        #region Common Properties
        protected static DataChangeParameter InitialValues { get; set; }
        protected static Employment Employment { get; set; }
        protected static PersonInfo Person { get; set; }
        #endregion

        #region Common Variables
        protected static List<string> SendToGACountries = new List<string>() { "USA", "GBR", "CHN", "JPN", "IND", "BRA", "CHE", "HUN" };

        protected static string upsertMessage = "Upsert Call Success";
        protected static string DataSheetPath = $@"{DirectoryPath}\Data\excel_data\DataSheet.xlsx";
        public static string DirectoryPath => Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        public static string OutPutFilePath => $@"{DirectoryPath}\{Util.TestConfiguration.GetCustomKeyValue("OutPutDataSheet")}";
        #endregion

        #region Common methods
        public static string CountryCode(string value) => SFApi.Get($"Territory?$format=json&$filter=territoryName eq '{value}'").results[0].territoryCode.Value;
        protected static string ToEpochTime(DateTime date)
        {
            TimeSpan t = date.AddDays(1) - new DateTime(1970, 1, 1);
            DateTimeOffset timeOffset = date.AddDays(1);

            int secondsSinceEpoch = (int)t.TotalSeconds;
            //Console.WriteLine($"Date: {date:d} | EPOCH Time : {secondsSinceEpoch} | EPOCH 2 : {timeOffset.ToUnixTimeMilliseconds()}");
            return timeOffset.ToUnixTimeMilliseconds().ToString();
        }
        public static string ToJsonDate(DateTime d) => $"/Date({ToEpochTime(d)})/";

        #endregion

        #region Core HR Common methods

        /// <summary>
        /// This is to terminate the employee with event reason. By default the termination type is Legal Entity Change - TAI
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        protected static bool TerminateEmployee(DataChangeParameter parameter, TerminationType termination = TerminationType.TAI)
        {
            GetCurrentJobInfo(parameter);

            var terminate = new
            {
                __metadata = new Metadata()
                {
                    Uri = $@"EmpEmploymentTermination"
                },
                eventReason = termination.ToString(),
                parameter.personIdExternal,
                endDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                parameter.userId,
                payrollEndDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                lastDateWorked = ToJsonDate(parameter.startDate.AddDays(-1)),
                bonusPayExpirationDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                benefitsEndDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                salaryEndDate = ToJsonDate(parameter.startDate.AddDays(-1)) //to make effective on the given end date
            };

            parameter.eventReason = "TAI";
            parameter.company = InitialValues.company;
            parameter.departmentid = InitialValues.departmentid;

            var body = JsonConvert.SerializeObject(terminate, Formatting.Indented);
            parameter.api_c_status = SFApi.Upsert(body);
            if (parameter.api_c_status.ToLower().Contains("success"))
            {
                IDTAction.ReconcileRecord(parameter.personIdExternal, parameter.userId, parameter.startDate);
                Util.Updatelog($"Terminate Employee for Legal Entity data {parameter.userId} ", "Data creation is successfull", State.APIPass);
                return true;
            }
            else
            {
                Util.Updatelog($"Terminate Employee for Legal Entity data {parameter.userId} ", "Data creation is failed", State.APIFail);
                return false;
            }
        }

        /// <summary>
        /// Read the current Job info (main attributes)
        /// </summary>
        protected static void GetCurrentJobInfo(DataChangeParameter P)
        {
            var query = $"EmpJob?$format=json&$select=userId,startDate,fte,customString2,customString3,customString4,customString5,customString11,customString12,customString16,customString18,customString21,customString33,jobCode,division,location,department,businessUnit,employeeClass,employmentType,regularTemp,holidayCalendarCode,timeTypeProfileCode,workscheduleCode,company,eventReason,customDouble20,payGrade,seqNumber,managerId,employeeClass,employmentType&$filter=userId eq '{P.userId}'&asOfDate={P.startDate:yyyy-MM-dd}&$orderby=startDate desc,seqNumber desc";
            var response = SFApi.Get(query).results[0];
            if (response != null)
            {
                InitialValues = new DataChangeParameter()
                {
                    startDate = response.startDate.Value,
                    company = response.company.Value,
                    userId = response.userId.Value,
                    speciality = response.division.Value,
                    managementregionid = response.businessUnit.Value,
                    managementcountryid = response.customString21.Value,
                    subservicelineid = response.customString3.Value,
                    departmentid = response.department.Value,
                    country = response.customString18.Value,
                    eventReason = response.eventReason.Value,
                    customString11 = response.customString11.Value
                };

                var ec = GetPicklistByOptionID((string)response.employeeClass.Value);
                var et = GetPicklistByOptionID((string)response.employmentType.Value);

                InitialValues.employeeClassCode = ec.externalCode;
                InitialValues.employeeClass = ec.optionId;
                InitialValues.employmentTypeCode = et.externalCode;
                InitialValues.employmentType = et.optionId;
            }
        }

        /// <summary>
        /// Selecting Random department
        /// </summary>
        /// <param name="company"></param>
        /// <returns></returns>
        protected static DeptDataStore GetDeptForLEChange(DataChangeParameter parameter)
        {
            //and startswith(cust_speciality,'{initialValues.speciality.Substring(0, 3)}') and cust_toSSL/externalCode eq '{initialValues.subservicelineid}' and externalCode ne '{initialValues.departmentid}'

            var deptlist = $"FODepartment?$format=json&$filter=cust_managerialcountry eq '{parameter.managementcountryid}' and cust_toeylegalentity/externalCode ne '{parameter.company}' and status eq 'A' &$expand=cust_tomanagementregion,cust_toeylegalentity,cust_toSSL,cust_toSSL/cust_toServiceLine&$select=cust_toeylegalentity/externalCode,cust_toeylegalentity/description_defaultValue,externalCode,description_defaultValue,cust_managerialcountry ,startDate,cust_tomanagementregion/externalCode,cust_tomanagementregion/description_defaultValue,cust_speciality,cust_tomanagementregion/externalCode,cust_tomanagementregionProp,cust_toeylegalentityProp,status,cust_toSSL/externalCode,cust_toSSL/cust_description_defaultValue,cust_toSSL/cust_toServiceLine/externalCode";

            List<DeptDataStore> deptid = new List<DeptDataStore>();
            dynamic departmentlist = SFApi.Get(deptlist);

            if (departmentlist != null)
            {
                foreach (dynamic dp in departmentlist.results)
                {
                    deptid.Add(new DeptDataStore()
                    {
                        Departmentid = dp.externalCode.Value,
                        DepartmentDescription = dp.description_defaultValue.Value,
                        LegalEntityId = dp.cust_toeylegalentityProp.Value,
                        LegalEntityDescription = dp.cust_toeylegalentity.description_defaultValue.Value,
                        ManagementRegionId = dp.cust_tomanagementregionProp.Value,
                        ManagementRegionDescription = dp.cust_tomanagementregion.description_defaultValue.Value,
                        ManagerialCountry = dp.cust_managerialcountry.Value,
                        Speciality = dp.cust_speciality.Value,
                        Startdate = dp.startDate.Value,
                        Status = dp.status.Value,
                        ServiceLine = dp.cust_toSSL.cust_toServiceLine.externalCode.Value,
                        SubServiceLine = dp.cust_toSSL.externalCode.Value,
                        SubServiceLineDescription = dp.cust_toSSL.cust_description_defaultValue.Value
                    });
                }

                if (deptid.Count == 0)
                {
                    throw new Exception("No Matching Dept found for the input user retry or check data");
                }

                Console.WriteLine($"Total dept applicable for this user is {deptid.Count}");
                Console.WriteLine($"Choosing a random entry ... ");

                DeptDataStore selectedDeptid = deptid[new Random().Next(deptid.Count)];
                Console.WriteLine($"Applying the following department id '{selectedDeptid.Departmentid}' to the user ");
                return selectedDeptid;
            }
            else
            {
                throw new Exception("No Entries Retrived for this user from the API Call , need manual review ");
            }
        }

        /// <summary>
        /// Selecting random legal entity
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        protected static LegalEntity GetNewLegalEntity(DataChangeParameter p)
        {
            if (InitialValues.company != null)
            {
                var leQuery = $"FOCompany?$format=json&$filter=country eq '{InitialValues.country}' and externalCode ne '{InitialValues.company}' and status eq 'A' &$select=externalCode,description_defaultValue";
                var leResponse = SFApi.Get(leQuery);

                List<LegalEntity> legalEntities = new List<LegalEntity>();
                foreach (dynamic result in leResponse.results)
                {
                    legalEntities.Add(new LegalEntity() { externalCode = result.externalCode.Value, description_defaultValue = result.description_defaultValue.Value });
                }

                int index = new Random().Next(legalEntities.Count);
                return legalEntities[index];
            }
            return new LegalEntity() { externalCode = InitialValues.company };
        }

        /// <summary>
        /// Get new legal entity based on the provided MC
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        protected static LegalEntity GetNewLegalEntityBasedOnMC(DataChangeParameter p)
        {
            if (InitialValues.company != null)
            {
                var leQuery = $"FOCompany?$format=json&$filter=country eq '{InitialValues.country}' and externalCode ne '{InitialValues.company}' and status eq 'A' &$select=externalCode,description_defaultValue";
                var leResponse = SFApi.Get(leQuery);

                List<LegalEntity> legalEntities = new List<LegalEntity>();
                foreach (dynamic result in leResponse.results)
                {
                    legalEntities.Add(new LegalEntity() { externalCode = result.externalCode.Value, description_defaultValue = result.description_defaultValue.Value });
                }

                int index = new Random().Next(legalEntities.Count);
                return legalEntities[index];
            }
            return new LegalEntity() { externalCode = InitialValues.company };
        }

        /// <summary>
        /// Get a new or randomized MC data
        /// </summary>
        /// <param name="P"></param>
        /// <param name="fromsamemr"></param>
        /// <returns></returns>
        /// <exception cref="FrameworkException"></exception>
        protected static DeptDataStore GetMCFor(DataChangeParameter P, bool fromsamemr = false)
        {
            string mrquery = "";
            if (fromsamemr) mrquery = $" and cust_tomanagementregion/externalCode eq '{P.managementregionid}' ";

            var query = $"FODepartment?$format=json&$filter=status eq 'A' and cust_toeylegalentity/country eq '{P.country}' and cust_managerialcountry ne '{P.managementcountryid}' {mrquery}&$top=5000&$expand=cust_tomanagementregion,cust_toeylegalentity,cust_toSSL,cust_toSSL/cust_toServiceLine&$select=cust_toeylegalentity/externalCode,cust_toeylegalentity/description_defaultValue,externalCode,description_defaultValue,cust_managerialcountry ,startDate,cust_tomanagementregion/externalCode,cust_tomanagementregion/description_defaultValue,cust_speciality,cust_tomanagementregion/externalCode,cust_tomanagementregionProp,cust_toeylegalentityProp,status,cust_toSSL/externalCode,cust_toSSL/cust_description_defaultValue,cust_toSSL/cust_toServiceLine/externalCode,cust_codeblock";
            List<DeptDataStore> deptid = new List<DeptDataStore>();
            do
            {
                dynamic response = SFApi.Get(query);

                foreach (dynamic dp in response.results)
                {
                    string mc = dp.cust_managerialcountry.Value;
                    string le = dp.cust_toeylegalentity.externalCode.Value;
                    if (!deptid.Any(x => x.ManagerialCountry.Equals(mc) && x.LegalEntityId.Equals(le)))
                    {
                        deptid.Add(new DeptDataStore()
                        {
                            Departmentid = dp.externalCode.Value,
                            DepartmentDescription = dp.description_defaultValue.Value,
                            LegalEntityId = dp.cust_toeylegalentityProp.Value,
                            LegalEntityDescription = dp.cust_toeylegalentity.description_defaultValue.Value,
                            ManagementRegionId = dp.cust_tomanagementregionProp.Value,
                            ManagementRegionDescription = dp.cust_tomanagementregion.description_defaultValue.Value,
                            ManagerialCountry = dp.cust_managerialcountry.Value,
                            Speciality = dp.cust_speciality.Value,
                            Startdate = dp.startDate.Value,
                            Status = dp.status.Value,
                            ServiceLine = dp.cust_toSSL.cust_toServiceLine.externalCode.Value,
                            SubServiceLine = dp.cust_toSSL.externalCode.Value,
                            SubServiceLineDescription = dp.cust_toSSL.cust_description_defaultValue.Value,
                            CodeBlock = dp.cust_codeblock.Value
                        });
                    }
                }

                try
                {
                    if (response.__next != null)
                    {
                        query = response.__next.Value;
                    }
                    else
                    {
                        break;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    break;
                }
            } while (true);

            if (deptid.Count == 0)
            {
                throw new FrameworkException("No MC Found via Query recheck!");
            }
            else if (deptid.Count >= 1)
            {
                var index = new Random().Next(deptid.Count);
                return deptid[index];
            }
            return new DeptDataStore(); // Only for failure case which will create failure records
        }

        /// <summary>
        /// Confirms whether the provided employee records is terminated or not
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        public static bool CheckIfUserIdTerminated(ref DataChangeParameter parameter)
        {
            try
            {
                var query = $"EmpEmploymentTermination?$filter=userId eq '{parameter.userId}'&$select=userId,endDate&$format=json&$asOfDate={parameter.startDate.AddDays(1):yyyy-MM-dd}";
                var response = SFApi.Get(query).results[0];
                if (response != null)
                {
                    parameter.terminatedDate = response.endDate.Value;
                    return true;
                }
            }
            catch (Exception e)
            {
                TestLog.Debug(e.Message);
            }
            return false;
        }

        /// <summary>
        /// Get next user id from the sequence
        /// </summary>
        /// <returns></returns>
        protected static string GetNextUserId()
        {
            long uid = 0;
            var location = $@"{Util.SolutionPath}\SF.ExternalFiles\seednumber.json";
            dynamic prop = JsonConvert.DeserializeObject(File.ReadAllText(location));
            for (int i = 1; i < 100; i++)
            {
                uid = Convert.ToInt64(prop.userId.Value) + 1;
                var query = $"User?$format=json&$orderby=userId  desc&$top=10&$select=userId&$filter=startswith(userId,'{uid}') and length(userId) eq 8";
                dynamic response = SFApi.Get(query);
                if (response.Value == null)
                {
                    var jsoncontent = JsonConvert.SerializeObject(new
                    {
                        prop.lpn,
                        prop.gpn,
                        userId = uid
                    }, Formatting.Indented);
                    using (StreamWriter e = new StreamWriter(new FileStream(location, FileMode.OpenOrCreate)))
                    {
                        e.WriteLine(jsoncontent);
                    }
                    break;
                }
            }
            return $"{uid}";
        }

        /// <summary>
        /// Get a new rank from the random list of ranks
        /// </summary>
        /// <param name="country"></param>
        /// <param name="rank"></param>
        /// <returns></returns>
        /// <exception cref="FrameworkException"></exception>
        protected static RankParameter GetNewRank(string country, string rank)
        {
            var reQuery = $"FOJobCode?$format=json&$expand=cust_country,cust_ranks&$top=10&$filter=cust_country/code eq '{country}' and status eq 'A' and cust_ranks/externalCode eq '{rank}' and cust_activity_type ne null &$select=cust_activity_type,externalCode,name_defaultValue,cust_ranks/externalCode,cust_country/code";
            List<RankParameter> ranks = new List<RankParameter>();
            dynamic response = SFApi.Get(reQuery);
            foreach (dynamic d in response.results)
            {
                ranks.Add(new RankParameter()
                {
                    rankId = d.cust_ranks.externalCode.Value,
                    country = d.cust_country.code.Value,
                    jobcode = d.externalCode.Value,
                    activityTypeCode = d.cust_activity_type.Value
                });
            }

            if (ranks.Count == 0)
            {
                throw new FrameworkException("unable to query the rank & jobcode for the ga request!, please try with another gui/userid");
            }

            var ind = new Random().Next(ranks.Count);
            return ranks[ind];
        }

        /// <summary>
        /// Get location details for the global assignments
        /// </summary>
        /// <param name="legalEntityId"></param>
        /// <returns></returns>
        /// <exception cref="FrameworkException"></exception>
        protected static Locationvariables GetGALocation(string legalEntityId)
        {
            var leQuery = $"FOLocation?$format=json&$expand=customString7Nav,geozoneFlxNav,locationGroupNav,companyFlxNav&$select=externalCode,description,customString7Nav,geozoneFlxNav,locationGroupNav&$filter=companyFlxNav/externalCode eq '{legalEntityId}'";
            dynamic response = SFApi.Get(leQuery).results;
            List<Locationvariables> locs = new List<Locationvariables>();
            foreach (dynamic d in response)
            {
                locs.Add(new Locationvariables()
                {
                    externalCode = d.externalCode.Value,
                    description = d.description.Value,
                    geographicregionid = d.locationGroupNav.externalCode.Value,
                    geographicareaid = d.customString7Nav.externalCode
                });
            }

            if (locs.Count == 0)
            {
                throw new FrameworkException("unable to query location, try again with another gui/userid");
            }
            var ind = new Random().Next(locs.Count);
            return locs[ind];
        }

        /// <summary>
        /// Read the basic employee details
        /// </summary>
        /// <param name="gui"></param>
        protected static void GetEmployeeInfo(string gui)
        {

            var query = $"EmpEmployment?$format=json&$filter=personIdExternal eq {gui}";
            try
            {
                var response = SFApi.Get(query).results[0];
                Employment = new Employment()
                {
                    originalStartDate = response.originalStartDate.Value,
                    personIdExternal = response.personIdExternal.Value,
                    userId = response.userId.Value
                };

            }
            catch (Exception e)
            {
                Employment = new Employment();
                TestLog.Info(e.Message);
            }

        }

        /// <summary>
        /// Read the personal information of user/gui
        /// </summary>
        /// <param name="gui"></param>
        protected static void GetPersonalInfo(string gui)
        {
            var query = $"PerPersonal?$top=1&$format=json&$filter=personIdExternal eq '{gui}' &$expand=personNav&$select=personNav/dateOfBirth,personIdExternal,firstName,lastName,gender";
            try
            {
                var response = SFApi.Get(query).results[0];
                Person = new PersonInfo()
                {
                    DateOfBirth = response.personNav.dateOfBirth.Value,
                    FirstName = response.firstName.Value,
                    LastName = response.lastName.Value,
                    Gender = response.gender.Value,
                };
            }
            catch (Exception e)
            {
                Person = new PersonInfo();
                TestLog.Info(e.Message);
            }
        }

        #endregion

        #region Picklist Methods

        /// <summary>
        /// returns the option id for the picklist and external code
        /// </summary>
        /// <param name="externalCode"></param>
        /// <param name="picklistId"></param>
        /// <returns></returns>
        protected static string GetPicklistOptionId(string externalCode, string picklistId)
        {
            string optionId = "";
            try
            {
                var q = $"https://api12preview.sapsf.eu/odata/v2/PicklistOption?$format=json&$filter=externalCode eq '{externalCode}' and picklist/picklistId eq '{picklistId}'$select=id";
                optionId = SFApi.Get(q).results[0].id;
            }
            catch (Exception)
            {
                optionId = "";
            }
            return optionId;
        }

        public static (string optionId, string label) GetPicklistLabelValue(string value)
        {
            var query = $"PicklistLabel?$format=json&$filter=optionId eq '{value}' and locale eq 'en_US'&$select=optionId,label";
            var response = SFApi.Get(query).results[0];

            string optionId = response.optionId.Value;
            string label = response.label.Value;

            return (optionId, label);
        }

        public static (string optionId, string label, string externalCode) GetPicklistByOptionID(string optionid)
        {
            var query = $"PicklistLabel?$format=json&$filter=locale eq 'en_US' and optionId eq '{optionid}'&$expand=picklistOption,picklistOption/picklist&$select=optionId,label,picklistOption/externalCode";
            var response = SFApi.Get(query).results[0];

            string optionId = response.optionId.Value;
            string label = response.label.Value;
            string externalCode = response.picklistOption.externalCode.Value;

            return (optionId, label, externalCode);
        }

        /// <summary>
        /// Recommended method for reading the picklist value based on the label, can be modified further based on the requirement
        /// </summary>
        /// <param name="picklistId"></param>
        /// <param name="_label"></param>
        /// <returns></returns>
        public static (string optionId, string label, string externalCode) GetPicklistByLabel(PicklistId picklistId, string _label)
        {
            var pck = picklistId.ToString().Replace("___", " ").Replace("__", "-").Trim();
            //var query = $"PicklistLabel?$format=json&$filter=locale eq 'en_US' and picklistOption/picklist eq '{pck}' and startswith(label,'{_label}')&$expand=picklistOption,picklistOption/picklist";

            var query = $"PickListValueV2?$format=json&$filter=PickListV2_id eq '{pck}' and label_en_US eq '{_label}'&$select=PickListV2_id,PickListV2_effectiveStartDate,externalCode,label_en_US,optionId,status";
            try
            {
                var response = SFApi.Get(query).results[0];
                string optionId = response.optionId.Value;
                string label = response.label_en_US.Value;
                string externalCode = response.externalCode.Value;
                return (optionId, label, externalCode);
            }
            catch (Exception)
            {
                return ("error in identifying picklist value", "error in identifying picklist value", "error in identifying picklist value");
            }
        }

        #endregion

        #region FO Methods

        #endregion
    }

    public class MCObject
    {
        public string ManagementCountry { get; set; }
        public string LegalEntity { get; set; }
    }

}
