﻿namespace SF.APICore
{
    internal interface IScenario<T> where T : class
    {



    }
}
