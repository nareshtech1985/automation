﻿using EY_Test.API.Entities;

namespace EY_Test.API.Framework
{
    public interface IFOFunction <T> where T : class
    {
        void Generate_ZoneA_Extract();
        void Create(T fo_object)  ;
        //void Edit(T fo_object);
        //void Delete(T fo_object);
        void Validate(T fo_object)  ;
    }
}
