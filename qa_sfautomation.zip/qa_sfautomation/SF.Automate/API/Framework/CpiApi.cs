﻿namespace SF.APICore
{
    using Pom;
    using RestSharp;
    using System;
    using System.Net;

    public class CpiApi : API
    {
        //public static string Apiauth { get; set; }

        public static void PostCallAsync(string URI)
        {
            var apiauth = Util.TestConfiguration.API_Credentials.Find(x => x.api.Equals("IDT"));
            var serviceurl = "";
            if (URI.Equals(string.Empty))
            {
                serviceurl = "https://e2133-iflmap.hcisbt.eu1.hana.ondemand.com/cxf/cm_EmpData_EmpInfoMCPD_ITS";
            }
            else if (URI.ToLower().StartsWith("https://"))
            {
                serviceurl = URI;
            }
            else
            {
                serviceurl = $"https://e2133-iflmap.hcisbt.eu1.hana.ondemand.com/cxf{URI}";
            }

            string seednumber = $"QA{ new Random().Next(99999)}";
            Console.WriteLine($"Seed Number for CPI Api Call : {seednumber} ");
            var xmlbody = $"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:dis=\"http://camel.apache.org/cxf/jaxws/dispatch\"> <soapenv:Header/> <soapenv:Body> <dis:InvokeOneWay>{seednumber}</dis:InvokeOneWay> </soapenv:Body> </soapenv:Envelope>";

            var client = new RestClient();
            var request = new RestRequest(serviceurl, Method.Post);
            request.AddHeader("Authorization", apiauth.authentication);
            request.AddHeader("X-Requested-With", "RestSharp");
            //request.AddParameter("application/xml", xmlbody, ParameterType.RequestBody);
            //request.RequestFormat = DataFormat.Xml;
            request.AddStringBody(xmlbody, DataFormat.Xml);

            RestResponse respone = client.ExecuteAsync(request).Result;
            if (respone.StatusCode == HttpStatusCode.OK || respone.StatusCode == HttpStatusCode.Accepted)
            {
                CreateLogFile(URI, xmlbody, "API Call Success!", "POST", "CPI");
                TestLog.Info($"\nURI : {URI}\n{xmlbody}\n{respone.Content}");
            }
            else
            {
                CreateLogFile(URI, xmlbody, $"API Call Failed with message : {respone.Content}", "POST", "CPI");
                TestLog.Debug($"\nURI : {URI}\n{xmlbody}\n{respone.Content}");
            }

        }
    }
}
