﻿namespace SF.APICore
{
    using EY_Test.API.Parameters.IDT;
    using EY_Test.API.Parameters.IDT.GUISearch;
    using Newtonsoft.Json;
    using Pom;
    using RestSharp;
    using System.Net;

    public class IDToolApi : API
    {
        public static string IDToolAuth { get; set; }
        private static APICredentials apiauthentication = Util.TestConfiguration.API_Credentials.Find(x => x.api.Equals("IDT"));
        public static IDTOutputParameter GenerateIdentifierAsync(IDTInputParameter parameter)
        {
            var output = new IDTOutputParameter();
            var serviceurl = $"{apiauthentication.baseurl}ey/talent/idt/svc/identifierTool.xsjs";
            var jsonbody = JsonConvert.SerializeObject(parameter, Formatting.Indented);
            var client = new RestClient();
            var request = new RestRequest(serviceurl, Method.Post);
            request.AddHeader("Authorization", apiauthentication.authentication);
            request.AddHeader("X-Requested-With", "RestSharp");
            //request.AddParameter("application/json", jsonbody, ParameterType.RequestBody);
            //request.RequestFormat = DataFormat.Json;
            request.AddStringBody(jsonbody, DataFormat.Json);

            RestResponse respone = client.ExecuteAsync(request).Result;
            if (respone.StatusCode == HttpStatusCode.OK || respone.StatusCode == HttpStatusCode.Accepted)
            {
                CreateLogFile(serviceurl, jsonbody, "API Call Success!", "POST", "IDT");
                TestLog.Info($"\nURI : {serviceurl}\n{jsonbody}\n{respone.Content}");
                output = JsonConvert.DeserializeObject<IDTOutputParameter>(respone.Content);
            }
            else
            {
                CreateLogFile(serviceurl, jsonbody, $"API Call Failed with message : {respone.Content}", "POST", "IDT");
                TestLog.Debug($"\nURI : {serviceurl}\n{jsonbody}\n{respone.Content}");
            }
            return output;
        }

        public static void ReconcileRecordAsync(string jsonbody)
        {
            var serviceurl = $"{apiauthentication.baseurl}ey/talent/idt/svc/insertReconciliationRecord.xsjs";
            var client = new RestClient();
            var request = new RestRequest(serviceurl, Method.Post);
            request.AddHeader("Authorization", IDToolAuth);
            request.AddHeader("X-Requested-With", "RestSharp");
            //request.AddParameter("application/json", jsonbody, ParameterType.RequestBody);
            //request.RequestFormat = DataFormat.Json;
            request.AddStringBody(jsonbody, DataFormat.Json);

            RestResponse respone = client.ExecuteAsync(request).Result;
            if (respone.StatusCode == HttpStatusCode.OK || respone.StatusCode == HttpStatusCode.Accepted)
            {
                CreateLogFile(serviceurl, jsonbody, "API Call Success!", "POST", "IDT");
                TestLog.Info($"\nURI : {serviceurl}\n{jsonbody}\n{respone.Content}");
            }
            else
            {
                CreateLogFile(serviceurl, jsonbody, $"API Call Failed with message : {respone.Content}", "POST", "IDT");
                TestLog.Debug($"\nURI : {serviceurl}\n{jsonbody}\n{respone.Content}");
                //Util.Updatelog("Execute IDT Reconciliation!", "Failed in Execution", State.APIFail);
            }
        }

        public static IDTSearchOutput SearchReservedIdentifiersAsync(IDTSearchInput input)
        {
            var jsonoutput = new IDTSearchOutput();
            var jsonbody = JsonConvert.SerializeObject(input, Formatting.Indented);
            var serviceurl = $"{apiauthentication.baseurl}ey/talent/idt/svc/guiSearch.xsjs";
            var client = new RestClient();
            var request = new RestRequest(serviceurl, Method.Post);
            request.AddHeader("Authorization", IDToolAuth);
            request.AddHeader("X-Requested-With", "RestSharp");
            //request.AddParameter("application/json", jsonbody, ParameterType.RequestBody);
            //request.RequestFormat = DataFormat.Json;
            request.AddStringBody(jsonbody, DataFormat.Json);

            RestResponse respone = client.ExecuteAsync(request).Result;
            if (respone.StatusCode == HttpStatusCode.OK || respone.StatusCode == HttpStatusCode.Accepted)
            {
                CreateLogFile(serviceurl, jsonbody, "API Call Success!", "POST", "IDT");
                TestLog.Info($"\nURI : {serviceurl}\n{jsonbody}\n{respone.Content}");
                jsonoutput = JsonConvert.DeserializeObject<IDTSearchOutput>(respone.Content);
            }
            else
            {
                CreateLogFile(serviceurl, jsonbody, $"API Call Failed with message : {respone.Content}", "POST", "IDT");
                TestLog.Debug($"\nURI : {serviceurl}\n{jsonbody}\n{respone.Content}");
                Util.Updatelog("Execute IDT Reconciliation!", "Failed in Execution", State.APIFail);
            }
            return jsonoutput;
        }

    }

}
