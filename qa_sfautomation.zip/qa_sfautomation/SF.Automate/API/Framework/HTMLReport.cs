﻿namespace EY_Test.API.Framework
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Interactions;
    using Pom;
    using System;
    using System.Collections.Generic;
    using System.IO;

    public class HTMLReport
    {
        public static string TestFolder { get; set; }
        public static string TestName { get; set; }
        public static string UserDetails { get; set; }

        public static List<StatusTable> CallHistory = new List<StatusTable>();
        public static bool IsCreation = false;
        public static IWebDriver Driver { get; set; }

        public static void UpdateStatusView()
        {
            try
            {
                IWebElement tcName = Driver.FindElement(By.Id("tcName"));
                //IWebElement userId = Driver.FindElement(By.Id("userId"));
                IWebElement tablebody = Driver.FindElement(By.XPath("//table/tbody"));

                string tableContent = "";
                foreach (var item in CallHistory)
                {
                    tableContent = $"{tableContent} {item.ToCreationRowItem}";
                }
                try
                {
                    ((IJavaScriptExecutor)Driver).ExecuteScript($"arguments[0].innerHTML='{TestName}'", tcName);
                    //((IJavaScriptExecutor)Driver).ExecuteScript($"arguments[0].innerHTML='{UserDetails}'", userId);
                    ((IJavaScriptExecutor)Driver).ExecuteScript($"arguments[0].innerHTML=arguments[1]", tablebody, tableContent);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                try
                {
                    By lastRow = By.XPath("//table/tbody/tr[last()]");
                    if (Driver.FindElements(lastRow).Count >= 1)
                    {
                        Actions a = new Actions(Driver);
                        a.MoveToElement(Driver.FindElement(lastRow)).Build().Perform();
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Skip UI Update");
            }

        }

        public static void SaveReport()
        {
            try
            {
                IWebElement tablebody = Driver.FindElement(By.XPath("//table/tbody"));
                var source = Driver.PageSource;
                var folderpath = $@"{Util.ResultPath}\{TestFolder}";
                if (!Directory.Exists(folderpath)) Directory.CreateDirectory(folderpath);
                var filepath = $@"{folderpath}\{TestName}.html";
                using (StreamWriter file = new StreamWriter(new FileStream(filepath, FileMode.OpenOrCreate)))
                {
                    file.Write(source);
                }
                TestLog.Info($"Created the HTML Log @ {filepath}");

            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
            }
        }
    }

    public class StatusTable
    {
        private string httpMethod;
        private string processName;
        private string responseTime;
        private string status;
        private string callType;
        private string message;

        public string Message
        {
            get => $"<td class=\"text-wrap\">{message}</td>";
            set => message = value;
        }

        public string HTTPMethod
        {
            get => httpMethod.ToLower().Equals("get") ? $"<td><span class=\"badge rounded-pill bg-secondary\">GET</span></td>" : $"<td><span class=\"badge rounded-pill bg-info text-dark\">POST</span></td>";
            set => httpMethod = value;
        }

        public string Processname
        {
            get => $"<td class=\"text-wrap\">{processName}</td>";
            set => processName = value;
        }

        public string ResponseTime
        {
            get => $"<td style='text-align: right;'>{responseTime}</td>";
            set => responseTime = value;
        }

        public string CallType
        {
            get => $"<td>{callType}</td>";
            set => callType = value;
        }

        public string Status
        {
            get => status.ToLower().Equals("failed") ? $"<td><span class=\"badge bg-danger\">Failed</span></td>" : $"<td><span class=\"badge bg-success\">Success</span></td>";
            set => status = value;
        }

        public string ToCreationRowItem
        {
            get => $"<tr>{Processname}{HTTPMethod}{Status}{Message}{ResponseTime}</tr>";
        }
    }
}
