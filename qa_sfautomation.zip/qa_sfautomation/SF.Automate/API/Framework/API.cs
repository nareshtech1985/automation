﻿namespace SF.APICore
{
    using Pom;
    using System;

    using System.IO;
    public class API
    {
        /// <summary>
        /// Creates Log file for each API Call
        /// </summary>
        /// <param name="URI"></param>
        /// <param name="body"></param>
        /// <param name="message"></param>
        /// <param name="http"></param>
        /// <param name="apitype"></param>
        protected static void CreateLogFile(string URI, string body, string message, string http, string apitype)
        {
            string _apilogfile = $@"{Util.ResultPath}\api_call_log\{apitype}_{http}_CALL_{ DateTime.Now:dd MM yyyy hh mm ss}.txt";
            using (StreamWriter e = new StreamWriter(new FileStream(_apilogfile, FileMode.OpenOrCreate)))
            {
                e.WriteLine($"Request URI : {URI}\n");
                e.WriteLine($"{body}");
                e.WriteLine($"{message}");
            }
            Console.WriteLine(message);
        }
    }
}