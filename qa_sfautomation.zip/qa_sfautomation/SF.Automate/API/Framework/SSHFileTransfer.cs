﻿

namespace EY_Test.API.Framework
{
    using cryptic;
    using Pom;
    using Renci.SshNet;
    using Renci.SshNet.Sftp;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading;
    public class SSHFileTransfer
    {
        private static readonly Cred CypherProgram = new Cred() { Publickey = Util.TestConfiguration.GetCustomKeyValue("publicKey") };
        private static readonly Credential Credential = Util.TestConfiguration.Credentials.Find(x => x.Name.Equals("SFTP", StringComparison.InvariantCultureIgnoreCase));

        public static void DownloadLatestFile(string remotefolder)
        {
            Thread myThread = new Thread(delegate ()
            {
                string host = @"https://sftp012.successfactors.eu/";
                using (SftpClient sftp = new SftpClient(host, Credential.UserName, CypherProgram.Decrypt(Credential.Password)))
                {
                    try
                    {
                        sftp.Connect();
                        SftpFile filetoDownload = sftp.ListDirectory(remotefolder).Where(x => !x.IsDirectory).OrderByDescending(x => x.LastWriteTimeUtc).FirstOrDefault();
                        TestLog.Info($"File Name {filetoDownload.Name}");
                        using (Stream filestream = File.OpenWrite($@"{Util.DownloadFolder}\{filetoDownload.Name}"))
                        {
                            TestLog.Info($"Downloading the file ... {filetoDownload.Name}");
                            sftp.DownloadFile(filetoDownload.FullName, filestream);
                            TestLog.Info($"Download completed ... {filetoDownload.Name}");
                        }
                        sftp.Disconnect();
                    }
                    catch (Exception er)
                    {
                        Console.WriteLine("An exception has been caught " + er.ToString());
                    }
                }
            });

            myThread.Start();
        }

        public static void DownloadLatestFileviaKey(string remotefolder)
        {
            var cred = Util.TestConfiguration.Credentials.Find(x => x.Name.Equals("SFTP", StringComparison.InvariantCultureIgnoreCase));
            PrivateKeyFile privateKey = new PrivateKeyFile(cred.PrivateKey);
            //PrivateKeyFile privateKey = new PrivateKeyFile(@"C:\1690809\Scripts\sf_automation\SFKey\sf_EYHRSTST1_private..ppk");
            var keysFile = new[] { privateKey };
            var method = new List<AuthenticationMethod>
                {
                    new PrivateKeyAuthenticationMethod(cred.UserName, keysFile)
                };
            ConnectionInfo info = new ConnectionInfo(cred.URL, cred.UserName, method.ToArray());
            using (SftpClient sftp = new SftpClient(info))
            {
                try
                {
                    sftp.Connect();
                    SftpFile filetoDownload = sftp.ListDirectory(remotefolder).Where(x => !x.IsDirectory).OrderByDescending(x => x.LastWriteTimeUtc).FirstOrDefault();
                    TestLog.Info($"File Name {filetoDownload.Name}");
                    using (Stream filestream = File.OpenWrite($@"{Util.DownloadFolder}\{filetoDownload.Name}"))
                    {
                        TestLog.Info($"Downloading the file ... {filetoDownload.Name}");
                        sftp.DownloadFile(filetoDownload.FullName, filestream);
                        TestLog.Info($"Download completed ... {filetoDownload.Name}");
                    }
                    sftp.Disconnect();
                }
                catch (Exception er)
                {
                    Console.WriteLine("An exception has been caught " + er.ToString());
                }
            }
        }

        public static void DownloadLatestFileviaUP(string remotefolder)
        {
            var cred = Util.TestConfiguration.Credentials.Find(x => x.Name.Equals("SFTP", StringComparison.InvariantCultureIgnoreCase));
            try
            {
                using (SftpClient sftp = new SftpClient(cred.URL, cred.UserName, CypherProgram.Decrypt(cred.Password)))
                {
                    try
                    {
                        sftp.Connect();
                        var filetoDownload = sftp.ListDirectory("/").ToList();

                        //TestLog.Info($"File Name {filetoDownload.Name}");
                        //using (Stream filestream = File.OpenWrite($@"{Util.DownloadFolder}\{filetoDownload.Name}"))
                        //{
                        //    TestLog.Info($"Downloading the file ... {filetoDownload.Name}");
                        //    sftp.DownloadFile(filetoDownload.FullName, filestream);
                        //    TestLog.Info($"Download completed ... {filetoDownload.Name}");
                        //}

                    }
                    catch (Exception er)
                    {
                        Console.WriteLine("An exception has been caught " + er.ToString());
                    }
                    finally
                    {
                        sftp.Disconnect();
                    }
                }
            }
            catch (Exception er)
            {

                Console.WriteLine("An exception has been caught " + er.ToString());
            }
        }
    }
}
