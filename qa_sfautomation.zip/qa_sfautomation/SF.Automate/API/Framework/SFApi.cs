﻿namespace SF.APICore
{
    using EY_Test.API.Framework;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using Pom;
    using RestSharp;
    using System;
    using System.Net;

    public class SFApi : API
    {
        public static string Apiauth { get; set; }

        /// <summary>
        /// This method will call the api in GET http method and retrive the data
        /// </summary>
        /// <param name="Uri"></param>
        /// <returns></returns>
        public static dynamic Get(string Uri)
        {
            var baseurl = "https://api12preview.sapsf.eu/odata/v2/";
            dynamic seriliazedString = "";
            var uri = Uri.StartsWith("http") ? Uri : $"{baseurl}{Uri}";
            var entity = Uri.Replace(baseurl, string.Empty);
            entity = entity.Substring(0, entity.IndexOf('?'));
            var apiName = $"Calling the entity {entity} for {(HTMLReport.IsCreation ? "test data preparation" : "reading data for validation")}";
            Console.WriteLine($"Calling the api via URI: {uri}");
            var client = new RestClient();
            var request = new RestRequest(uri, Method.Get);
            request.AddHeader("Accept", "*/*");
            request.AddHeader("Accept-Encoding", "gzip, deflate, br");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("Authorization", Apiauth);
            request.AddHeader("Content-Type", "application/json");
            try
            {
                DateTime start = DateTime.Now;
                RestResponse response = client.ExecuteAsync(request, Method.Get).Result;
                TimeSpan span = DateTime.Now - start;
                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    TestLog.Error($"GET Call Failed due to invalid Auth | URI : {uri}\n{response.Content}");
                    HTMLReport.CallHistory.Add(new StatusTable() { Processname = apiName, HTTPMethod = "GET", Status = "Failed", ResponseTime = $"{span.TotalSeconds:0.00} Sec", CallType = HTMLReport.IsCreation ? "Data Creation" : "Data Validation", Message = $" {response.Content} " });
                    CreateLogFile(uri, response.Content, "API Call Fail!", "ERROR_GET", "SF");
                }
                else
                {
                    var jsonContent = JObject.Parse(response.Content);
                    seriliazedString = JsonConvert.DeserializeObject(jsonContent["d"].ToString(), Type.GetType("null"));

                    if (seriliazedString.Value == "\"results\": []")
                    {
                        TestLog.Error($"GET Call Failure | URI : {uri}\n{response.Content}");
                        HTMLReport.CallHistory.Add(new StatusTable() { Processname = apiName, HTTPMethod = "GET", Status = "Failed", ResponseTime = $"{span.TotalSeconds:0.00} Sec", CallType = HTMLReport.IsCreation ? "Data Creation" : "Data Validation", Message = "GET request yielded empty result set" });
                        CreateLogFile(uri, response.Content, "API Call Fail!", "ERROR_GET", "SF");
                    }
                    else
                    {
                        TestLog.Info($"GET Call Success | URI : {uri}");
                        HTMLReport.CallHistory.Add(new StatusTable() { Processname = apiName, HTTPMethod = "GET", Status = "Success", ResponseTime = $"{span.TotalSeconds:0.00} Sec", CallType = HTMLReport.IsCreation ? "Data Creation" : "Data Validation", Message = "GET request yielded data result set" });
                        CreateLogFile(uri, response.Content, "API Call Success!", "GET", "SF");
                    }
                }
            }
            catch (Exception e)
            {
                TestLog.Error($"GET Call Failure | URI : {uri}\n{e.Message}");
                HTMLReport.CallHistory.Add(new StatusTable() { Processname = apiName, HTTPMethod = "GET", Status = "Failed", ResponseTime = $"0.00 Sec", CallType = $"Error in network : {e.Message}", Message = e.Message });
                CreateLogFile(uri, e.Message, "API Call Fail!", "ERROR_GET", "SF");
                seriliazedString = "\"results\": []";
            }
            HTMLReport.UpdateStatusView();
            return seriliazedString;
        }

        /// <summary>
        /// This method will call the api in POST http method and update/insert the record passed as provided in the request body. Business Rules are applied in the API Itself and the respective validation message would be thrown. Not all request will be successfull.
        /// </summary>
        /// <param name="jsoncontent"></param>
        /// <returns></returns>
        public static string Upsert(string jsoncontent)
        {
            var procesName = $"Creating data for : {HTMLReport.UserDetails}";
            string result = Constants.ACFail;
            var uri = "https://api12preview.sapsf.eu/odata/v2/upsert?$format=json";
            var client = new RestClient();
            var request = new RestRequest(uri, Method.Post);
            request.AddHeader("Authorization", Apiauth);
            request.AddStringBody(jsoncontent, DataFormat.Json);
            try
            {
                DateTime start = DateTime.Now;
                RestResponse response = client.ExecuteAsync(request, Method.Post).Result;
                TimeSpan span = DateTime.Now - start;

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    dynamic seriliazedString = JsonConvert.DeserializeObject(JObject.Parse(response.Content)["d"].ToString(), Converter.Settings);
                    string jsonresponse = JsonConvert.SerializeObject(seriliazedString[0], Converter.Settings);
                    var status = seriliazedString[0].status.Value;
                    string message = seriliazedString[0].message.Value;
                    if (message == null) message = "";
                    if (status == "ERROR")
                    {
                        HTMLReport.CallHistory.Add(new StatusTable() { Processname = procesName, HTTPMethod = "POST", Status = "Failed", ResponseTime = $"{span.TotalSeconds:0.00} Sec", CallType = HTMLReport.IsCreation ? "Data Creation" : "Data Validation", Message = message });
                        CreateLogFile(uri, $"Request Body: {jsoncontent} \nResponse : {jsonresponse}", "API Call Failed!", "POST_ERROR", "SF");
                        TestLog.Error($"\nURI : {uri}\nrequest body: {jsoncontent}\n{jsonresponse}");
                        Util.Updatelog($"Execute Post Request '{HTMLReport.UserDetails}'", $"Post Request Failed<br>{message}", State.Fail);
                    }
                    else if (status == "OK")
                    {
                        var msg = message.ToLower().Contains("warning") ? "[Warning logged in log file]" : "";
                        HTMLReport.CallHistory.Add(new StatusTable() { Processname = procesName, HTTPMethod = "POST", Status = "Success", ResponseTime = $"{span.TotalSeconds:0.00} Sec", CallType = HTMLReport.IsCreation ? "Data Creation" : "Data Validation", Message = $"Request Post Success! {msg}" });
                        CreateLogFile(uri, $"Request Body: {jsoncontent} \nResponse : {jsonresponse}", "API Call Success!", "POST_Success", "SF");
                        TestLog.Info($"\nURI : {uri}\nrequest body: {jsoncontent}\n{jsonresponse}");
                        result = Constants.ACPass;
                        Util.Updatelog($"Execute Post Request '{HTMLReport.UserDetails}'", $"Post Request Success", State.Pass);
                    }
                }
                else
                {
                    TestLog.Error(response.Content);
                    HTMLReport.CallHistory.Add(new StatusTable() { Processname = procesName, HTTPMethod = "POST", Status = "Failed", ResponseTime = $"{span.TotalSeconds:0.00} Sec", CallType = HTMLReport.IsCreation ? "Data Creation" : "Data Validation" });
                    Util.Updatelog($"Execute Post Request '{HTMLReport.UserDetails}'", $"Post Request Failed<br>{response.Content}", State.APIFail);
                }
            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
                HTMLReport.CallHistory.Add(new StatusTable() { Processname = procesName, HTTPMethod = "POST", Status = "Failed", ResponseTime = "0.00 Sec", CallType = $"Error in network : {e.Message}" });
                CreateLogFile(uri, e.Message, "API Call Failed!", "POST_Exception", "SF");
                Util.Updatelog($"Execute Post Request '{HTMLReport.UserDetails}'", $"Post Request Failed<br>{e.Message}", State.APIFail);
            }
            HTMLReport.UpdateStatusView();
            return result;
        }

        /// <summary>
        /// This method will call the api in POST http method and update/insert the record passed as provided in the request body. Business Rules are applied in the API Itself and the respective validation message would be thrown. Not all request will be successfull. This is same as Upsert method with a difference, the record purge parameter would be called along with this method.
        /// </summary>
        /// <param name="jsoncontent"></param>
        /// <returns></returns>
        public static string UpsertPurge(string jsoncontent)
        {
            var procesName = $"Creating data for user/gui : {HTMLReport.UserDetails}";
            string result = "Failed";
            var uri = "https://api12preview.sapsf.eu/odata/v2/upsert?purgeType=incremental&$format=json";
            var client = new RestClient(uri);
            var request = new RestRequest(uri, Method.Post);
            request.AddHeader("Authorization", Apiauth);
            request.AddStringBody(jsoncontent, DataFormat.Json);
            try
            {
                DateTime start = DateTime.Now;
                RestResponse response = client.ExecuteAsync(request, Method.Post).Result;
                TimeSpan span = DateTime.Now - start;

                if (response.StatusCode == HttpStatusCode.OK)
                {
                    dynamic seriliazedString = JsonConvert.DeserializeObject(JObject.Parse(response.Content)["d"].ToString());
                    string jsonresponse = JsonConvert.SerializeObject(seriliazedString[0], Converter.Settings);
                    var status = seriliazedString[0].status.Value;
                    var message = seriliazedString[0].message.Value;
                    if (status == "ERROR")
                    {
                        HTMLReport.CallHistory.Add(new StatusTable() { Processname = procesName, HTTPMethod = "POST", Status = "Failed", ResponseTime = $"{span.TotalSeconds:0.00} Sec", CallType = HTMLReport.IsCreation ? "Data Creation" : "Data Validation", Message = message });
                        CreateLogFile(uri, $"Request Body: {jsoncontent} \nResponse : {jsonresponse}", "API Call Failed!", "POST_ERROR", "SF");
                        TestLog.Error($"\nURI : {uri}\nrequest body: {jsoncontent}\n{jsonresponse}");
                        Util.Updatelog($"Execute Post Request '{HTMLReport.UserDetails}'", $"Post Request Failed<br>{message}", State.Fail);
                    }
                    else if (status == "OK")
                    {
                        HTMLReport.CallHistory.Add(new StatusTable() { Processname = procesName, HTTPMethod = "POST", Status = "Success", ResponseTime = $"{span.TotalSeconds:0.00} Sec", CallType = HTMLReport.IsCreation ? "Data Creation" : "Data Validation", Message = $"Request Post Success! {message}" });
                        CreateLogFile(uri, $"Request Body: {jsoncontent} \nResponse : {jsonresponse}", "API Call Success!", "POST_Success", "SF");
                        TestLog.Info($"\nURI : {uri}\nrequest body: {jsoncontent}\n{jsonresponse}");
                        result = Constants.ACPass;
                        Util.Updatelog($"Execute Post Request '{HTMLReport.UserDetails}'", $"Post Request Success", State.Pass);
                    }
                }
                else
                {
                    TestLog.Error(response.Content);
                    HTMLReport.CallHistory.Add(new StatusTable() { Processname = procesName, HTTPMethod = "POST", Status = "Failed", ResponseTime = $"{span.TotalSeconds:0.00} Sec", CallType = HTMLReport.IsCreation ? "Data Creation" : "Data Validation" });
                    Util.Updatelog($"Execute Post Request '{HTMLReport.UserDetails}'", $"Post Request Failed<br>{response.Content}", State.APIFail);
                }
            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
                HTMLReport.CallHistory.Add(new StatusTable() { Processname = procesName, HTTPMethod = "POST", Status = "Failed", ResponseTime = "0.00 Sec", CallType = $"Error in network : {e.Message}" });
                CreateLogFile(uri, e.Message, "API Call Failed!", "POST_Exception", "SF");
                Util.Updatelog($"Execute Post Request '{HTMLReport.UserDetails}'", $"Post Request Failed<br>{e.Message}", State.APIFail);
            }
            HTMLReport.UpdateStatusView();
            return result;
        }

        public static dynamic GetForImport(string Uri)
        {
            var baseurl = "https://api12preview.sapsf.eu/odata/v2/";
            dynamic seriliazedString = "";
            var uri = Uri.StartsWith("http") ? Uri : $"{baseurl}{Uri}";
            var entity = Uri.Replace(baseurl, string.Empty);
            entity = entity.Substring(0, entity.IndexOf('?'));
            var apiName = $"Calling the entity {entity} for {(HTMLReport.IsCreation ? "test data preparation" : "reading data for validation")}";
            Console.WriteLine($"Calling the api via URI: {uri}");
            var client = new RestClient(uri);
            var request = new RestRequest();
            request.AddHeader("Accept", "*/*");
            request.AddHeader("Accept-Encoding", "gzip, deflate, br");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("Authorization", Apiauth);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "JSESSIONID=3F7F64602310ED8642B0CC0C2C549D31.mo-e4dcb1b64");
            try
            {
                DateTime start = DateTime.Now;
                RestResponse response = client.ExecuteAsync(request, Method.Get).Result;
                TimeSpan span = DateTime.Now - start;
                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    TestLog.Error($"GET Call Failed due to invalid Auth | URI : {uri}\n{response.Content}");
                    // CreateLogFile(uri, response.Content, "API Call Fail!", "ERROR_GET", "SF");
                }
                else
                {
                    var jsonContent = JObject.Parse(response.Content);
                    seriliazedString = JsonConvert.DeserializeObject(jsonContent["d"].ToString(), Type.GetType("null"));

                    if (seriliazedString.Value == "\"results\": []")
                    {
                        TestLog.Error($"GET Call Failure | URI : {uri}\n{response.Content}");
                        // CreateLogFile(uri, response.Content, "API Call Fail!", "ERROR_GET", "SF");
                    }
                    else
                    {
                        TestLog.Info($"GET Call Success | URI : {uri}");
                        // CreateLogFile(uri, response.Content, "API Call Success!", "GET", "SF");
                    }
                }
            }
            catch (Exception e)
            {
                TestLog.Error($"GET Call Failure | URI : {uri}\n{e.Message}");
                // CreateLogFile(uri, e.Message, "API Call Fail!", "ERROR_GET", "SF");
            }
            // HTMLReport.UpdateStatusView();
            return seriliazedString;
        }

    }

    public enum HTTPMethod
    {
        POST,
        GET
    }
}
