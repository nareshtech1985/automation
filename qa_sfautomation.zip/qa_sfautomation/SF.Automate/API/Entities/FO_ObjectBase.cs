﻿namespace EY_Test.API.Entities
{
    using SF.Parameter;
    using System;
    public class FO_ObjectBase
    {
        [ColumnHeader(0, "SL No")]
        public int rowKey { get; set; }

        [ColumnHeader(1, "EFFECTIVE START DATE")]
        public DateTime startDate { get; set; }
        
        [ColumnHeader(94, "EFFECTIVE START DATE")]
        public DateTime endDate { get; set; }

        [ColumnHeader(95, "API CALL STATUS")]
        public string api_c_status { get; set; } = " ";

        [ColumnHeader(96, "API VALIDATION STATUS")]
        public string api_v_status { get; set; } = " ";

        [ColumnHeader(97, "TDDH DB STATUS")]
        public string db_v_status { get; set; } = "TDDH Validation Pass!";
    }
}
