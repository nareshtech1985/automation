﻿namespace EY_Test.API.Entities.Foundation
{
    public class ServiceLineFO : FO_ObjectBase, IFoundationObject
    {
    }
}