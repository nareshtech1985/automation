﻿namespace EY_Test.API.Entities.Foundation
{
    public class OperatingUnitFO : FO_ObjectBase, IFoundationObject
    {
    }
}