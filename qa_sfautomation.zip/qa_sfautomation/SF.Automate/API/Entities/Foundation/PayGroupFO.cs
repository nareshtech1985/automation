﻿namespace EY_Test.API.Entities.Foundation
{
    public class PayGroupFO : FO_ObjectBase, IFoundationObject
    {
    }
}