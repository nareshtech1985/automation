﻿namespace EY_Test.API.Entities.Foundation
{
    public class PayComponentGroupFO : FO_ObjectBase, IFoundationObject
    {
    }
}