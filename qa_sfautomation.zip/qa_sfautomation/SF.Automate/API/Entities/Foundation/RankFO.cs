﻿namespace EY_Test.API.Entities.Foundation
{
    public class RankFO : FO_ObjectBase, IFoundationObject
    {
        public object externalName_defaultValue { get; internal set; }
        public object externalCode { get; internal set; }
        public object externalName_en_US { get; internal set; }
    }
}