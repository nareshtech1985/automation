﻿namespace EY_Test.API.Entities.Foundation
{
    public class BankFO : FO_ObjectBase, IFoundationObject
    {
        public string externalCode { get; set; } = null;
        public string bankBranch { get; set; } = null;
        public string city { get; set; } = null;
        public string street { get; set; } = null;
        public string postalCode { get; set; } = null;
        public string businessIdentifierCode { get; set; } = null;
        public string bankName { get; set; } = null;
        public string bankCountry { get; set; } = null;
        public string effectiveStatus { get; set; } = null;
    }
}