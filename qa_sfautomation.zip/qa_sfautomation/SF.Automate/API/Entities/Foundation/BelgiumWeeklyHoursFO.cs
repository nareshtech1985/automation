﻿namespace EY_Test.API.Entities.Foundation
{
    public class BelgiumWeeklyHoursFO : FO_ObjectBase, IFoundationObject
    {
        public string effectiveStartDate { get; internal set; }
        public string externalCode { get; internal set; }
        public string externalName { get; internal set; }
        public string mdfSystemStatus { get; internal set; }
        public string cust_FTEHRSGFIS { get; internal set; }
        public string cust_STDHRSGFIS { get; internal set; }
    }
}