﻿namespace EY_Test.API.Entities.Foundation
{
    public class SpecialityFO : FO_ObjectBase, IFoundationObject
    {
    }
}