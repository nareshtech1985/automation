﻿namespace EY_Test.API.Entities.Foundation
{
    public class PayComponentFO : FO_ObjectBase, IFoundationObject
    {
    }
}