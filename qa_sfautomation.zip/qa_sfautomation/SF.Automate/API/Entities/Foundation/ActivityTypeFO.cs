﻿namespace EY_Test.API.Entities.Foundation
{
    public class ActivityTypeFO : FO_ObjectBase, IFoundationObject
    {
        public string effectiveStartDate { get; internal set; }
        public string externalCode { get; internal set; }
        public string externalName_defaultValue { get; internal set; }
        public string cust_Description_defaultValue { get; internal set; }
        public string mdfSystemStatus { get; internal set; }
        public string externalName_en_US { get; internal set; }
        public string cust_Description_en_US { get; internal set; }
    }
}