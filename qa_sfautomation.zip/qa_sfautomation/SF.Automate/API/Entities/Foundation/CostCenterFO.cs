﻿namespace EY_Test.API.Entities.Foundation
{
    public class CostCenterFO : FO_ObjectBase, IFoundationObject
    {
    }
}