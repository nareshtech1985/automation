﻿namespace EY_Test.API.Entities.Foundation
{
    public class CompanyCSFO : FO_ObjectBase, IFoundationObject
    {
    }
}