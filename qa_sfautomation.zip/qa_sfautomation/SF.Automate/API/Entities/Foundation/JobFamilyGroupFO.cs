﻿namespace EY_Test.API.Entities.Foundation
{
    public class JobFamilyGroupFO : FO_ObjectBase, IFoundationObject
    {
    }
}