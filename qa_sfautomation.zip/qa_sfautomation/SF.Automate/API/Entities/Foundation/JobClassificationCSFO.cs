﻿namespace EY_Test.API.Entities.Foundation
{
    public class JobClassificationCSFO : FO_ObjectBase, IFoundationObject
    {
    }
}