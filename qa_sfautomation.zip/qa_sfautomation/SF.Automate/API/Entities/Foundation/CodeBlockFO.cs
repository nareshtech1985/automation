﻿namespace EY_Test.API.Entities.Foundation
{
    public class CodeBlockFO : FO_ObjectBase, IFoundationObject
    {
    }
}