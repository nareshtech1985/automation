﻿namespace EY_Test.API.Entities.Foundation
{
    public class LocationFO : FO_ObjectBase, IFoundationObject
    {
        public string timezone { get; internal set; }
        public string status { get; internal set; }
        public string name { get; internal set; }
        public string locationGroup { get; internal set; }
        public string geozoneFlx { get; internal set; }
        public string externalCode { get; internal set; }
        public string description { get; internal set; }
        public string customString7 { get; internal set; }
        public string companyFlx { get; internal set; }
        public string addressCountry { get; internal set; }
    }
}