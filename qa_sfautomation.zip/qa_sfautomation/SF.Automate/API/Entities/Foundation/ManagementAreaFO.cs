﻿namespace EY_Test.API.Entities.Foundation
{
    public class ManagementAreaFO : FO_ObjectBase, IFoundationObject
    {
    }
}