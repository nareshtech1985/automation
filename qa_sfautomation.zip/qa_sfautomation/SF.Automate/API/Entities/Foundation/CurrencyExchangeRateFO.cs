﻿namespace EY_Test.API.Entities.Foundation
{
    public class CurrencyExchangeRateFO : FO_ObjectBase, IFoundationObject
    {
    }
}