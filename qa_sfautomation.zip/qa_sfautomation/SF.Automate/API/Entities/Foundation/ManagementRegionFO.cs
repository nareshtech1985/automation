﻿namespace EY_Test.API.Entities.Foundation
{
    public class ManagementRegionFO : FO_ObjectBase, IFoundationObject
    {
    }
}