﻿namespace EY_Test.API.Entities.Foundation
{
    public class EventReasonFO : FO_ObjectBase, IFoundationObject
    {
    }
}