﻿namespace EY_Test.API.Entities.Foundation
{
    public class SubManagementUnitFO : FO_ObjectBase, IFoundationObject
    {
    }
}