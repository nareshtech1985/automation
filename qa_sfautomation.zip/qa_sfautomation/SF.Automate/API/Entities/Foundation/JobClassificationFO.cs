﻿namespace EY_Test.API.Entities.Foundation
{
    public class JobClassificationFO : FO_ObjectBase, IFoundationObject
    {
    }
}