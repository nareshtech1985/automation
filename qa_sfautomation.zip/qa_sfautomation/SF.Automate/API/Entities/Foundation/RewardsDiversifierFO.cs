﻿namespace EY_Test.API.Entities.Foundation
{
    public class RewardsDiversifierFO : FO_ObjectBase, IFoundationObject
    {
    }
}