﻿namespace EY_Test.API.Entities.Foundation
{
    public class PayRangesFO : FO_ObjectBase, IFoundationObject
    {
    }
}