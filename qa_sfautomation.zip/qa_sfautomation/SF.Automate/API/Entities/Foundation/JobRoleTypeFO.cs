﻿namespace EY_Test.API.Entities.Foundation
{
    public class JobRoleTypeFO : FO_ObjectBase, IFoundationObject
    {
    }
}