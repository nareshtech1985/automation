﻿namespace EY_Test.API.Entities.Foundation
{
    public class DepartmentFO : FO_ObjectBase, IFoundationObject
    {
    }
}