﻿namespace EY_Test.API.Entities.Foundation
{
    public class GeoZoneFO : FO_ObjectBase, IFoundationObject
    {
        public string adjustmentPercentage { get; internal set; }
        public string externalCode { get; internal set; }
        public string name { get; internal set; }
        public string status { get; internal set; }
    }
}