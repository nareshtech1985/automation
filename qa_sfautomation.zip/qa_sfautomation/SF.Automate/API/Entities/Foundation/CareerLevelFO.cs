﻿namespace EY_Test.API.Entities.Foundation
{
    public class CareerLevelFO : FO_ObjectBase, IFoundationObject
    {
    }
}