﻿namespace EY_Test.API.Entities.Foundation
{
    public class NameFormatFO : FO_ObjectBase, IFoundationObject
    {
        public string externalCode { get; internal set; }
        public string externalName_defaultValue { get; internal set; }
        public string externalName_en_US { get; internal set; }
    }
}