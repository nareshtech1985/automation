﻿namespace EY_Test.API.Entities.Foundation
{
    public class BrazilCNPJFO : FO_ObjectBase, IFoundationObject
    {
        public object cust_description { get; internal set; }
        public object effectiveStartDate { get; internal set; }
        public object externalCode { get; internal set; }
        public object externalName { get; internal set; }
        public object mdfSystemStatus { get; internal set; }
    }
}