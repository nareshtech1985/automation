﻿namespace EY_Test.API.Entities.Foundation
{
    public class CompanyFO : FO_ObjectBase, IFoundationObject
    {
        public string country { get; set; }
        public string currency { get; set; }
        public string cust_gdentitycode { get; set; }
        public string cust_transfergroup { get; set; }
        public string externalCode { get; set; }
        public string status { get; set; }
    }
}