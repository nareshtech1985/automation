﻿namespace EY_Test.API.Entities.Foundation
{
    public class JobFunctionFO : FO_ObjectBase, IFoundationObject
    {
    }
}