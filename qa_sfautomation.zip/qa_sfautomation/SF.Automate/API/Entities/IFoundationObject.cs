﻿namespace EY_Test.API.Entities
{
    public interface IFoundationObject
    {

    }
}
