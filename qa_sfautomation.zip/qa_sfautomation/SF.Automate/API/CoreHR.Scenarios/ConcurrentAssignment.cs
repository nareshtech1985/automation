﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;

    public class ConcurrentAssignment : SFComponent
    {
        public static List<DataChangeParameter> parameters;

        public static void CreateConcurrentAssignment(DataChangeParameter parameter)
        {
            var country = SendToGACountries[new Random().Next(SendToGACountries.Count)];
            var tempparam = new DataChangeParameter()
            {
                userId = parameter.userId,
                startDate = parameter.startDate,
                managementcountryid = "x",
                country = country
            };

            GetCurrentJobInfo(tempparam);

            DeptDataStore dept = GetMCFor(tempparam);

            Locationvariables location = GetGALocation(dept.LegalEntityId);
            RankParameter rankParam = GetNewRank(country, "42");

            var newuserid = GetNextUserId();
            parameter.userId = newuserid;
            //New Concurrent Employment Create
            var employmnetbody = new
            {
                __metadata = new Metadata()
                {
                    Uri = "EmpEmployment"
                },
                startDate = ToJsonDate(parameter.startDate),
                parameter.personIdExternal,
                parameter.userId,
                originalStartDate = ToJsonDate(parameter.startDate),
                customDate22 = ToJsonDate(parameter.startDate),
                customDate2 = ToJsonDate(parameter.startDate)
            };

            //New Concurrent Job Info Create
            var jobBody = new
            {
                __metadata = new Metadata()
                {
                    Uri = "EmpJob"
                },
                parameter.userId,
                startDate = ToJsonDate(parameter.startDate),
                departmentEntryDate = ToJsonDate(parameter.startDate),
                customString33 = "40105", //Overtime Eligibility - PickList (Regular Pay no overtime defaulted) 
                isFulltimeEmployee = true,
                customString21 = dept.ManagerialCountry, // Managerial Country 
                customString22 = dept.CodeBlock, //Code Block
                payGrade = "PG00", // Pay Grade
                customString18 = country, // Country/Region
                customString11 = rankParam.rankId, // Rank
                customString12 = rankParam.activityTypeCode, // Activity Type
                managerId = "NO_MANAGER", // manager id
                customString16 = "1", // Experience Level / EY Grade ID
                businessUnit = dept.ManagementRegionId, // Management Region
                customDouble20 = "40", // FTE Hours
                locationEntryDate = ToJsonDate(parameter.startDate),
                holidayCalendarCode = "HOLIDAYCAL",
                eventReason = "HAE",
                isCompetitionClauseActive = false, //Competition Clause
                regularTemp = "57674", // Regular/Temporary - Picklist
                company = dept.LegalEntityId, // Legal Entity - 
                employeeClass = "32731", // employee class - Picklist / Non employee
                location = location.externalCode, // location
                workscheduleCode = "NORM", // Work Schedule
                //endDate = ToJsonDate(parameter.startDate.AddDays(160)),
                jobCode = rankParam.jobcode, // Job Code
                division = dept.Speciality, // Speciality
                timeTypeProfileCode = $"{country}_TIME_PROFILE", // timeTypeProfileCode
                companyEntryDate = ToJsonDate(parameter.startDate),
                fte = "1", // fte                
                standardHours = "40", // std hrs
                jobEntryDate = ToJsonDate(parameter.startDate),
                department = dept.Departmentid, // department id 
                employmentType = "61585", // Employee Type picklist
                customString5 = location.geographicareaid, // 	Geographic Area
                customString4 = location.geographicregionid, // Geographic region
                customString3 = dept.SubServiceLine, // Sub Service Line
                customString2 = dept.ServiceLine, // Service Line
                customString7 = location.geozone // Geo Zone
                //customString6 = "0003" // Management Area
            };
            parameter.eventReason = "HAE";
            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(employmnetbody, Converter.Settings));
            if (parameter.api_c_status.ToLower().Contains("success"))
            {
                parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(jobBody, Converter.Settings));
                if (parameter.api_c_status.ToLower().Contains("success"))
                {
                    Util.Updatelog("Create concurrent employment", "Concurrent employment & job created", State.APIPass);
                    IDTAction.ReconcileRecord(parameter.personIdExternal, parameter.userId, parameter.startDate);
                    var idt = IDTAction.SearchGUI(parameter.personIdExternal, parameter.userId, parameter.startDate);
                    parameter.gpn = idt.GPN_CODE;
                    parameter.lpn = idt.LPN_CODE;
                }
                else
                {
                    Util.Updatelog("Create concurrent employment", "Concurrent job info not created", State.APIFail);
                }
            }
            else
            {
                Util.Updatelog("Create concurrent employment", "Concurrent employment not created", State.APIFail);
            }
            RunTimeData<DataChangeParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.CREATE_CONCURRENT_ASSIGNMENT);

        }

        public static void ValidateDataChange(DataChangeParameter data)
        {
            var query = $"EmpJob/?$filter=userId eq '{data.userId}'&$format=json";
            try
            {
                var response = SFApi.Get(query).results[0];
                Assert.AreEqual(data.userId, response.userId.Value, "user id incorrect");
                Assert.AreEqual(data.eventReason, response.eventReason.Value, "user id incorrect");
                //Assert.AreEqual(data.startDate, response.startDate.Value, "effective start date not matching");
                data.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data created", "validation failed", State.APIPass);
            }
            catch
            {
                data.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data created", "validation failed", State.APIFail);
            }
        }
    }
}
