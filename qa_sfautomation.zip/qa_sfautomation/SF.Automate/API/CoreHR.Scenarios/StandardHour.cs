﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.Parameter;
    using System.Collections.Generic;

    public class StandardHour : SFComponent
    {
        public static List<FTEParameter> parameters;

        /// <summary>
        /// Need to check the Standard Hours Change
        /// </summary>
        /// <param name="parameter"></param>
        public static void PerformStandardHourChange(FTEParameter parameter)
        {
            parameter.eventReason = "AAC";
            var empjob = new
            {
                __metadata = new Metadata()
                {
                    Uri = "EmpJob"
                },
                parameter.userId,
                startDate = ToJsonDate(parameter.startDate),
                parameter.eventReason,
                parameter.fte,
                customDouble20 = parameter.ftehours,
                parameter.standardHours
            };
            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(empjob, Converter.Settings));
            if (parameter.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog($"Create Standard Hours Change test data for {parameter.userId} ", "Data creation is successfull", State.APIPass);
            }
            else
            {
                Util.Updatelog($"Create Standard Hours Change test data for {parameter.userId} ", "Data creation is failed", State.APIFail);
            }
            RunTimeData<FTEParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.STD_HRS_CHANGE);
        }

        public static void ValidateDataChange(FTEParameter parameter)
        {
            var query = $"EmpJob?$filter=(userId eq '{parameter.userId}' and eventReason eq 'AAC')&asOfDate={parameter.startDate:yyyy-MM-dd}&$format=json";
            var response = SFApi.Get(query).results[0];
            if (response != null)
            {
                try
                {

                    Assert.AreEqual(parameter.startDate, response.startDate.Value, "Effective date is not matching");
                    Assert.AreEqual(parameter.fte, response.fte.Value, "FTE Value is not matching");
                    Assert.AreEqual(parameter.ftehours, response.customDouble20.Value, "FTE Hours Value is not matching");
                    Assert.AreEqual(parameter.standardHours, response.standardHours.Value, "FTE Std Hrs Value is not matching");
                    parameter.api_v_status = Constants.AVPass;
                    Util.Updatelog($"Verify the Standard hours and respective fields are updated for user {parameter.userId}", "Value is as per the input data", State.APIPass);
                }
                catch
                {
                    parameter.api_v_status = Constants.AVFail;
                    Util.Updatelog($"Verify the Standard hours and respective fields are updated for user {parameter.userId}", "Value not as provided", State.APIFail);
                }
            }
            else
            {
                parameter.api_v_status = Constants.AVFail;
                Util.Updatelog($"Verify the Standard hours and respective fields are updated for user {parameter.userId}", "Value not as provided", State.APIFail);
            }
            RunTimeData<FTEParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.STD_HRS_CHANGE);
        }
    }
}