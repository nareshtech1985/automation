﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;
    using System.Threading;

    /// <summary>
    /// Logic used for class change logic
    ///
    /// Current logic change the class of employee to ->32733 & type to  --> 61574
    ///
    /// </summary>
    public class ClassChange : SFComponent
    {
        public static List<ClassChangeParameter> parameters;

        public static object RuntimeData { get; private set; }

        public static void ValidateDataChange(ClassChangeParameter parameter)
        {
            var res = GetEmployeeJobData(parameter);
            try
            {
                Assert.AreEqual(parameter.startDate, res.startDate, "Start date is not as per the data provided");
                //Assert.AreEqual("49541", res.emplStatus.ToString(), "Employee Status not changed to terminated");
                Assert.AreEqual(parameter.employeeClass, res.employeeClass, "Employee Class is not as expected");
                Assert.AreEqual(parameter.employmentType, res.employmentType, "Employment Type is not as expected");
                parameter.api_v_status = Constants.AVPass;
                Util.Updatelog($"Validate Test Data for Class Change for user id {parameter.userId}", $"Data Validation Success", State.APIPass);
            }
            catch (Exception e)
            {
                parameter.api_v_status = Constants.AVFail;
                Util.Updatelog($"Validate Test Data for Class Change for user id {parameter.userId}", $"Data error {e.Message}", State.Fail);
            }
        }

        /// <summary>
        /// For class change perform the soft termination with event reason as 'TAJ'
        /// </summary>
        private static string Step1_Termination(ClassChangeParameter parameter)
        {
            parameter.rowKey = 0;
            parameter.eventReason = "TAJ";

            var terminate = new
            {
                __metadata = new Entity.Metadata()
                {
                    Uri = $@"EmpEmploymentTermination"
                },
                parameter.eventReason,
                parameter.personIdExternal,
                endDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                parameter.userId,
                payrollEndDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                lastDateWorked = ToJsonDate(parameter.startDate.AddDays(-1)),
                bonusPayExpirationDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                benefitsEndDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                salaryEndDate = ToJsonDate(parameter.startDate.AddDays(-1)) //to make effective on the given end date
            };
            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(terminate, Converter.Settings));
            if (parameter.api_c_status.Contains(Constants.ACPass, StringComparison.InvariantCultureIgnoreCase))
            {
                Util.Updatelog("Perform termination prior to class change", "Termination success via api", State.APIPass);
            }
            else
            {
                Util.Updatelog("Perform termination prior to class change", "Termination unsuccess via api", State.Fail);
            }
            RunTimeData<ClassChangeParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.CLASS_CHANGE);
            return parameter.api_c_status;
        }

        private static string Step2_RehireWithNewClass(ClassChangeParameter parameter)
        {
            Thread.Sleep(6000);
            var employee = GetClassAndType(parameter);
            parameter.employeeClass = employee.classid;
            parameter.employmentType = employee.typeid;
            var empjob = new
            {
                __metadata = new Entity.Metadata()
                {
                    Uri = $@"EmpJob"
                },
                parameter.userId,
                startDate = ToJsonDate(parameter.startDate),
                eventReason = "RAB",
                parameter.employeeClass,
                parameter.employmentType
            };
            parameter.employeeClass = employee.classDesc;
            parameter.employmentType = employee.typeDesc;

            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(empjob, Converter.Settings));
            if (parameter.api_c_status.Contains(Constants.ACPass, StringComparison.InvariantCultureIgnoreCase))
            {
                Util.Updatelog("Perform class change", "Class change success via api", State.APIPass);
            }
            else
            {
                Util.Updatelog("Perform class change", "Class change unsuccess via api", State.Fail);
            }
            RunTimeData<ClassChangeParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.CLASS_CHANGE);
            return parameter.api_c_status;
        }

        private static (string classid, string typeid, string classDesc, string typeDesc) GetClassAndType(ClassChangeParameter parameter)
        {
            if (parameter is null)
            {
                throw new ArgumentNullException(nameof(parameter));
            }

            var classidquery = $"PicklistOption?$format=json&$expand=picklist,picklistLabels&$filter=picklist/picklistId eq 'EMPLOYEECLASS' and picklistLabels/label eq '{parameter.employeeClass}' and picklistLabels/locale eq 'en_US'&$select=id";
            var typeidquery = $"PicklistOption?$format=json&$expand=picklist,picklistLabels&$filter=picklist/picklistId eq 'employmentType' and picklistLabels/label eq '{parameter.employmentType}' and picklistLabels/locale eq 'en_US'&$select=id";
            var classid = SFApi.Get(classidquery).results[0].id;
            var typeid = SFApi.Get(typeidquery).results[0].id;
            var classDesc = parameter.employeeClass;
            var typeDesc = parameter.employmentType;
            return (classid, typeid, classDesc, typeDesc);
        }

        /// <summary>
        /// Terminate and Create the Rehire record with class changes
        /// </summary>
        /// <param name="parameter"></param>
        public static void PerformClassChange(ClassChangeParameter parameter)
        {
            var dtvariable = new DataChangeParameter() { userId = parameter.userId, startDate = parameter.startDate };
            if (!CheckIfUserIdTerminated(ref dtvariable)) //if not terminated, execute the termination scripts
            {
                Step1_Termination(parameter);
            }
            Step2_RehireWithNewClass(parameter); //perform rehire
        }

        public static ClassChangeParameter GetEmployeeJobData(ClassChangeParameter item)
        {
            var url = $"EmpJob?$filter=userId eq '{item.userId}'&$format=json&$format=json&$select=userId,startDate,eventReason,employeeClass,employmentType,emplStatus&asOfDate={item.startDate:yyyy-MM-dd}";
            var response = SFApi.Get(url).results[0];

            var employeeClassVal = GetPicklistLabelValue((string)response.employeeClass.Value);
            var employeeTypeVal = GetPicklistLabelValue((string)response.employmentType.Value);

            return new ClassChangeParameter()
            {
                userId = response.userId,
                startDate = response.startDate,
                employeeClass = employeeClassVal.label,
                employmentType = employeeTypeVal.label,
                eventReason = response.eventReason,
                emplStatus = response.emplStatus
            };
        }


    }
}