﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.Entity.Person;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class AddressChange : SFComponent
    {
        public static List<AddressParameter> parameters;

        public static Address CreateCountryBasedUpsertBody(AddressParameter parameter)
        {
            parameter.country = CountryCode(parameter.country);
            var picklistvalue = GetStateValue(parameter, parameter.country);
            parameter.state = picklistvalue.optionId;
            Address address = new Address()
            {
                Metadata = new Metadata() { Uri = "PerAddressDEFLT" },
                PersonIdExternal = Convert.ToInt64(parameter.personIdExternal),
                AddressType = parameter.addressType,
                StartDate = ToJsonDate(parameter.startDate),
                State = parameter.state,
                Country = parameter.country,
                Address1 = parameter.address1,
                Address2 = parameter.address2,
                Address3 = parameter.address3,
                Address4 = parameter.address4,
                //Address5 = parameter.address5, // Script commented based on release test on april 19th 2022
                City = parameter.city,
                ZipCode = parameter.zipCode
            };
            RunTimeData<AddressParameter>.MergeList(ref parameters, parameter);
            return address;
        }

        private static PicklistItems GetStateValue(AddressParameter s, string countrycode)
        {
            PicklistItems statevalue = new PicklistItems() { optionId = "invalid data", label = "invalid data" };
            List<string> statapplicablecountryList = new List<string>() { "aus", "aut", "bel", "bra", "chn", "deu", "est", "gbr", "ind", "lva", "mex", "nga", "usa" };

            if (statapplicablecountryList.Any(x => x.Equals(countrycode.ToLower())))
            {
                try
                {
                    var q = $@"PicklistLabel?$format=json&$filter=label eq '{s.state}' and locale eq 'en_US' and picklistOption/picklist eq 'STATE_{countrycode}'&$expand=picklistOption,picklistOption/picklist&$select=optionId,label";
                    dynamic result = SFApi.Get(q).results[0];
                    statevalue.optionId = result.optionId.Value;
                    statevalue.label = result.label.Value;
                }
                catch (Exception e)
                {
                    Console.WriteLine($"{e.Message}");
                }

                if (statevalue == null || statevalue.Equals(string.Empty))
                {
                    //Get Random Entry
                    var q1 = $"PicklistLabel?$format=json&$filter=locale eq 'en_US' and picklistOption/picklist eq 'STATE_{countrycode}'&$expand=picklistOption,picklistOption/picklist&$select=optionId,label";
                    dynamic values = SFApi.Get(q1).results;
                    List<PicklistItems> states = new List<PicklistItems>();
                    foreach (dynamic item in values)
                    {
                        states.Add(new PicklistItems()
                        {
                            optionId = item.optionId.Value,
                            label = item.label.Value
                        });
                    }
                    var i = new Random().Next(states.Count);
                    statevalue = states[i];
                    Console.WriteLine($"Input state not found hence using the random state value for this user '{states[i].label}'");
                }
            }
            else
            {
                statevalue.optionId = s.state;
                statevalue.label = s.state;
            }
            return statevalue;
        }

        public static AddressParameter AddNewAddress(AddressParameter parameter)
        {
            var addressbody = CreateCountryBasedUpsertBody(parameter);
            var body = JsonConvert.SerializeObject(addressbody, Formatting.Indented);
            parameter.api_c_status = SFApi.Upsert(body);
            RunTimeData<AddressParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.ADDRESS_CHANGE);
            return parameter;
        }

        public static void ValidateDataChange(AddressParameter parameter)
        {
            try
            {
                var body = $@"PerAddressDEFLT?$format=json&$filter=personIdExternal eq '{parameter.personIdExternal}' and  startDate eq '{parameter.startDate:yyyy-MM-dd}' and addressType eq '{parameter.addressType}'&fromDate=2020-11-01";
                dynamic response = SFApi.Get(body.Trim()).results[0];

                Assert.That(parameter.address1.Equals(response.address1.Value), "Address Line 1 Info is not matching");
                Assert.That(parameter.address2.Equals(response.address2.Value), "Address Line 2 Info is not matching");
                Assert.That(parameter.address3.Equals(response.address3.Value), "Address Line 3 Info is not matching");
                Assert.That(parameter.city.Equals(response.city.Value), "City Info is not matching");
                //Assert.That(parameter.state.Equals(response.state.Value), "State Info is not matching");
                // To be Corrected once db change added
                Assert.That(parameter.country.Equals(response.country.Value), "Country Code Info is not matching");
                Assert.That(parameter.addressType.Equals(response.addressType.Value), "Address Type Info is not matching");

                Util.Updatelog("Verify the data via API Call", "Data matches with the input data", State.APIPass);
                parameter.api_v_status = Constants.AVPass;
                //Country based enhancement to be done based on demand
            }
            catch (Exception e)
            {
                Util.Updatelog("Verify the data via API Call", $"Data not matching with the input<br>Error details : {e.Message}", State.APIFail);
                parameter.api_v_status = Constants.AVFail;
            }
            RunTimeData<AddressParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.ADDRESS_CHANGE);
        }
    }

    public class PicklistItems
    {
        public string optionId { get; set; }
        public string label { get; set; }
    }
}