﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;

    public class LocationChange : SFComponent
    {
        public static List<LocationParameter> parameters;

        public static void PerformLocationChange(LocationParameter parameter)
        {
            var location = GetNewLocation(parameter);
            parameter.location = location.externalCode;
            parameter.locationDesc = location.description;
            var empjob = new
            {
                __metadata = new Metadata()
                {
                    Uri = "EmpJob"
                },
                parameter.userId,
                startDate = ToJsonDate(parameter.startDate),
                eventReason = "AAD",
                parameter.location,
            };

            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(empjob, Converter.Settings));
            if (parameter.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog($"Create domestice transfer for the user {parameter.userId} ", "Data creation is successfull", State.APIPass);
            }
            else
            {
                Util.Updatelog($"Create domestice transfer for the user {parameter.userId} ", "Data creation is failed", State.APIFail);
            }
            RunTimeData<LocationParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.DOMESTIC_TRANSFER);
        }

        private static Locationvariables GetNewLocation(DataChangeParameter d)
        {
            var query = $"EmpJob?$format=json&$filter=userId eq '{d.userId}'&$expand=locationNav&$select=location,locationNav/customString7,locationNav/locationGroup,locationNav/geozoneFlx,locationNav/status,company,countryOfCompany&asOfDate={d.startDate:yyyy-MM-dd}";
            Locationvariables locationvariables = null;
            try
            {
                var response = SFApi.Get(query).results[0];
                if (response != null)
                {
                    locationvariables = new Locationvariables()
                    {
                        externalCode = response.location.Value,
                        geographicareaid = response.locationNav.customString7.Value,
                        geographicregionid = response.locationNav.locationGroup.Value,
                        geozone = response.locationNav.geozoneFlx.Value,
                        legalentityid = response.company.Value,
                        country = response.countryOfCompany.Value
                    };
                }
            }
            catch (Exception e)
            {
                TestLog.Debug($"Unable to read location details of the user due to the exception : {e.Message}");
            }

            try
            {
                var queryLocation = $"FOLocation?$format=json&$filter=locationGroupNav/externalCode eq '{locationvariables.geographicregionid}' and customString7Nav/externalCode eq '{locationvariables.geographicareaid}' and companyFlxNav/country eq '{locationvariables.country}'&$expand=customString7Nav,geozoneFlxNav,locationGroupNav,companyFlxNav&$select=externalCode,description,status";
                var respon = SFApi.Get(queryLocation);
                List<Locationvariables> variables = new List<Locationvariables>();
                foreach (dynamic elem in respon.results)
                {
                    variables.Add(new Locationvariables()
                    {
                        externalCode = elem.externalCode.Value,
                        description = elem.description.Value
                    });
                }

                int i = new Random().Next(variables.Count);
                var loc = variables[i];
                TestLog.Info($"Selecting the random new location as follows | Location : {loc.externalCode} | Desc : {loc.description} | ");
                return loc;
            }
            catch (Exception e)
            {
                TestLog.Debug($"Unable to select random location for the user due to the exception : {e.Message}");
            }

            return locationvariables;
        }

        public static void ValidateLocationChange(LocationParameter parameter)
        {
            var p = parameter;
            var query = $"EmpJob?$format=json&$filter=userId eq '{parameter.userId}'&$expand=locationNav&$select=location,locationNav/customString7,locationNav/locationGroup,locationNav/geozoneFlx,locationNav/status,userId,startDate,company&asOfDate={parameter.startDate:yyyy-MM-dd}";

            try
            {
                var response = SFApi.Get(query).results[0];
                if (response != null)
                {
                    try
                    {
                        Assert.AreEqual(p.userId, response.userId.Value, "user id not matching");
                        Assert.AreEqual(p.startDate, response.startDate.Value, "start date not matching");
                        Assert.AreEqual(p.location, response.location.Value, "new location updated not matching");
                        parameter.api_v_status = Constants.AVPass;
                        Util.Updatelog($"Validate the location change for user id {p.userId}", "Validation success", State.APIPass);
                    }
                    catch
                    {
                        parameter.api_v_status = Constants.AVFail;
                        Util.Updatelog($"Validate the location change for user id {p.userId}", "Validation failure", State.Fail);
                    }
                }
            }
            catch (Exception e)
            {
                parameter.api_v_status = Constants.AVFail;
                TestLog.Debug($"Unable to read location details of the user due to the exception : {e.Message}");
            }
            RunTimeData<LocationParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.DOMESTIC_TRANSFER);
        }
    }


}