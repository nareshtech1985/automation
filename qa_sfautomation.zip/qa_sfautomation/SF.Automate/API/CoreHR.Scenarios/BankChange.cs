﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.Entity.Bank;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;

    public class BankChange : SFComponent
    {
        public static List<BankChangeParameter> parameters;

        private static int bankcheckcounter = 0;

        public static PayType GetApplicablePaymentType(ref BankChangeParameter parameter)
        {
            var countrycode = CountryCode(parameter.country);
            parameter.bankCountryCode = countrycode;
            var custompaytype = $"CustomPayTypeAssignment?$format=json&$filter=country eq '{countrycode}'";
            dynamic respnse = SFApi.Get(custompaytype);

            List<PayTypeAssignment> typeAssignments = new List<PayTypeAssignment>();
            foreach (dynamic s in respnse.results)
            {
                typeAssignments.Add(new PayTypeAssignment()
                {
                    ExternalCode = s.externalCode.Value,
                    CustomPayTypeExternalCode = s.CustomPayType_externalCode.Value
                });
            }
            PayTypeAssignment paytype1 = new PayTypeAssignment();
            if (parameter.paymentType.ToLower().Equals("main"))
            {
                paytype1 = typeAssignments.Find(x => x.CustomPayTypeExternalCode.ToLower().Contains("main"));
            }
            else
            {
                paytype1 = typeAssignments.FindAll(x => !x.CustomPayTypeExternalCode.ToLower().Contains("main")).FirstOrDefault();
            }

            PayType payType = new PayType()
            {
                ExternalCode = "MainPayment",
                ExternalNameLocalized = "Main Payment Method",
                StandardPayType = "MAIN"
            };
            var query2 = $"CustomPayType('{paytype1.CustomPayTypeExternalCode}')?$format=json";
            dynamic response2 = SFApi.Get(query2);
            if (response2 != null)
            {
                payType = new PayType()
                {
                    ExternalCode = response2.externalCode.Value,
                    ExternalNameLocalized = response2.externalName_localized.Value,
                    StandardPayType = response2.standardPayType.Value
                };
            }

            return payType;
        }

        public static string GetPaymentMethod(ref BankChangeParameter parameter)
        {
            string method = "05";
            var query1 = $"PaymentMethodV3?$format=JSON&$select=externalCode,externalName_en_US&$filter=externalName_en_US eq '{parameter.paymentMethod}'&fromDate=2020-01-01";
            dynamic response = SFApi.Get(query1).results[0];
            if (response != null)
            {
                method = response.externalCode.Value;
            }
            parameter.paymentMethod = method;
            return method;
        }

        public static void ChangeBankinfo(BankChangeParameter parameter)
        {
            //check if user doesnot have main, then create a main account first
            var mainpaymentexternalCode = CheckAndCreateMainPayment(new BankChangeParameter() { paymentType = parameter.paymentType, personIdExternal = parameter.personIdExternal, userId = parameter.personIdExternal, startDate = parameter.startDate, paymentMethod = parameter.paymentMethod, country = parameter.country, bankName = parameter.bankName, bankAccountNumber = $"0{parameter.bankAccountNumber}1" });

            var paytype = GetApplicablePaymentType(ref parameter);
            string exisitingExternalcode = GetCurrentPaymentinfo(parameter);

            if (exisitingExternalcode.Equals(string.Empty))
            {
                if (parameter.paymentType.ToLower().Equals("main")) //when the payment type is main and no exsisting record
                {
                    exisitingExternalcode = $"{parameter.userId}1";
                }
                else if (!parameter.paymentType.ToLower().Equals("main") && !mainpaymentexternalCode.Equals(string.Empty)) //when payment type is not main and doesn't have exsisting record, but has a main payment type
                {
                    exisitingExternalcode = $"{(Convert.ToInt64(mainpaymentexternalCode) + 1)}";
                }
            }

            var bankdetails = GetBank(parameter);
            var bankbody = new
            {
                __metadata = new Metadata()
                {
                    Uri = "PaymentInformationV3"
                },
                worker = parameter.personIdExternal,
                effectiveStartDate = ToJsonDate(parameter.startDate),
                toPaymentInformationDetailV3 = new
                {
                    __metadata = new Metadata()
                    {
                        Uri = "PaymentInformationDetailV3"
                    },
                    accountOwner = "SFAPI",
                    externalCode = exisitingExternalcode,
                    PaymentInformationV3_effectiveStartDate = ToJsonDate(parameter.startDate),
                    PaymentInformationV3_worker = parameter.personIdExternal,
                    bank = bankdetails.ExternalCode,
                    accountNumber = parameter.bankAccountNumber,
                    routingNumber = bankdetails.RoutingNumber,
                    payType = paytype.StandardPayType,
                    customPayType = paytype.ExternalCode,
                    bankCountry = bankdetails.BankCountry,
                    paymentMethod = GetPaymentMethod(ref parameter)
                }
            };
            parameter.externalCode = exisitingExternalcode;
            parameter.bankName = bankdetails.BankName;
            parameter.routingNumber = bankdetails.RoutingNumber;
            parameter.paymentType = paytype.StandardPayType;

            var body = JsonConvert.SerializeObject(bankbody, Formatting.Indented);
            parameter.api_c_status = SFApi.Upsert(body);
            if (parameter.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create/Modify bank account data", "Data created/modified", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create/Modify bank account data", $"Unable to create/modify data {parameter.Bankinfo} ", State.APIFail);
            }
            RunTimeData<BankChangeParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.BANK_ACCOUNT_CHANGE);
        }

        private static string CheckAndCreateMainPayment(BankChangeParameter parameter)
        {
            string exisitingExternalcode = "";
            if (!parameter.paymentType.ToLower().Equals("main"))
            {
                var newparam = parameter;
                newparam.paymentType = "MAIN";
                var paytype = GetApplicablePaymentType(ref newparam);
                exisitingExternalcode = GetCurrentPaymentinfo(newparam);
                if (exisitingExternalcode.Equals(string.Empty)) //IF MAIN PAYMENT DOENOT EXSIST THIS CODE WILL CREATE AN ENTRY
                {
                    bankcheckcounter = 0;
                    exisitingExternalcode = $"{newparam.userId}1";
                    var bankdetails = GetBank(newparam);
                    var bankbody = new
                    {
                        __metadata = new Metadata()
                        {
                            Uri = "PaymentInformationV3"
                        },
                        worker = newparam.personIdExternal,
                        effectiveStartDate = ToJsonDate(newparam.startDate),
                        toPaymentInformationDetailV3 = new
                        {
                            __metadata = new Metadata()
                            {
                                Uri = "PaymentInformationDetailV3"
                            },
                            accountOwner = "This is a Test Entry",
                            externalCode = exisitingExternalcode,
                            PaymentInformationV3_effectiveStartDate = ToJsonDate(newparam.startDate),
                            PaymentInformationV3_worker = newparam.personIdExternal,
                            bank = bankdetails.ExternalCode,
                            accountNumber = newparam.bankAccountNumber,
                            routingNumber = bankdetails.RoutingNumber,
                            payType = paytype.StandardPayType,
                            customPayType = paytype.ExternalCode,
                            bankCountry = bankdetails.BankCountry,
                            paymentMethod = GetPaymentMethod(ref newparam)
                        }
                    };
                    parameter.externalCode = exisitingExternalcode;
                    parameter.bankName = bankdetails.BankName;
                    parameter.routingNumber = bankdetails.RoutingNumber;
                    parameter.paymentType = paytype.StandardPayType;
                    var body = JsonConvert.SerializeObject(bankbody, Formatting.Indented);

                    parameter.api_c_status = SFApi.Upsert(body);

                    if (parameter.api_c_status.ToLower().Contains("success"))
                    {
                        Util.Updatelog("Create/Modify bank account data", "Data created/modified", State.APIPass);
                    }
                    else
                    {
                        Util.Updatelog("Create/Modify bank account data", $"Unable to create/modify data {parameter.Bankinfo} ", State.APIFail);
                    }
                    RunTimeData<BankChangeParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.BANK_ACCOUNT_CHANGE);
                }
            }
            return exisitingExternalcode;
        }

        private static string GetCurrentPaymentinfo(BankChangeParameter parameter)
        {
            string externalcode = string.Empty;
            if (parameter.paymentType.ToLower().Equals("main"))
            {
                try
                {
                    var bankinfo = $"PaymentInformationDetailV3?$filter=PaymentInformationV3_worker eq '{parameter.personIdExternal}' and payType eq 'MAIN'&$select=externalCode,payType&$format=json&$orderby=PaymentInformationV3_effectiveStartDate desc&$top=1";
                    externalcode = SFApi.Get(bankinfo).results[0].externalCode;
                }
                catch (Exception)
                {
                    externalcode = string.Empty;
                }
            }
            else
            {
                try
                {
                    var bankinfo = $"PaymentInformationDetailV3?$filter=PaymentInformationV3_worker eq '{parameter.personIdExternal}' and payType ne 'MAIN'&$select=externalCode,payType&$format=json&$orderby=PaymentInformationV3_effectiveStartDate desc&$top=1";
                    externalcode = SFApi.Get(bankinfo).results[0].externalCode;
                }
                catch (Exception)
                {
                    externalcode = string.Empty;
                }
            }
            return externalcode;
        }

        private static Bank GetBank(BankChangeParameter parameter)
        {
            var randombankname = new List<string>() { "HSBC", "HDFC", "ICIC", "JP", "Federal", "Well", "1", "bank" };

            var bankinfo = $"Bank?$filter=startswith(bankName,'{parameter.bankName}') and effectiveStatus eq 'A' and bankCountry eq '{parameter.bankCountryCode}'&$format=json&$select=bankCountry,externalCode,bankName,routingNumber,cust_BankID";
            dynamic banks = SFApi.Get(bankinfo);
            List<Bank> banklist = new List<Bank>();
            foreach (dynamic item in banks.results)
            {
                banklist.Add(new Bank()
                {
                    ExternalCode = item.externalCode.Value,
                    RoutingNumber = item.routingNumber.Value,
                    BankName = item.bankName.Value,
                    BankCountry = item.bankCountry.Value,
                    CustBankId = item.cust_BankID.Value
                });
            }

            if (banklist.Count == 0)
            {
                if (bankcheckcounter > 3)
                {
                    throw new Exception($"Bank info not found for the parameters -> {parameter.bankName} - {parameter.bankCountryCode}");
                }
                bankcheckcounter++;

                return GetBank(new BankChangeParameter() { bankCountryCode = parameter.bankCountryCode, bankName = randombankname[new Random().Next(randombankname.Count)] });
            }
            else if (banklist.Count == 1)
            {
                return banklist[0];
            }
            else
            {
                int i = new Random().Next(banklist.Count);
                return banklist[i];
            }
        }

        public static void ValidateDataChange(BankChangeParameter item)
        {
            Thread.Sleep(1000);
            var bankinfo = $"PaymentInformationDetailV3?$format=json&fromDate=2020-1-1&$filter=PaymentInformationV3_worker eq  '{item.personIdExternal}' and PaymentInformationV3_effectiveStartDate eq '{item.startDate:yyyy-MM-dd}'";

            if (!item.paymentType.ToLower().Equals("main"))
            {
                bankinfo = $"PaymentInformationDetailV3?$format=json&fromDate=2020-1-1&$filter=PaymentInformationV3_worker eq  '{item.personIdExternal}' and PaymentInformationV3_effectiveStartDate eq '{item.startDate:yyyy-MM-dd}' and payType ne 'MAIN'";
            }
            try
            {
                dynamic response = SFApi.Get(bankinfo).results[0];

                string accountNumber = response.accountNumber;
                DateTime effectiveDate = response.PaymentInformationV3_effectiveStartDate;

                Assert.AreEqual(item.bankAccountNumber, accountNumber, "Account Number Populated is incorrect");
                Assert.AreEqual(item.startDate, effectiveDate, "Start date is incorrect");
                item.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the bank data created/modified", "Data looks Good!", State.APIPass);
            }
            catch
            {
                item.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the bank data created/modified", "Data not looks Good!", State.APIFail);
            }
        }
    }
}