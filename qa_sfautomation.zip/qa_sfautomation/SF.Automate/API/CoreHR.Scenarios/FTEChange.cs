﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;

    public class FTEChange : SFComponent
    {
        public static List<FTEParameter> parameters;

        public static void PerformFTEHourChange(FTEParameter parameter)
        {
            var empjob = new
            {
                __metadata = new Metadata()
                {
                    Uri = "EmpJob"
                },
                parameter.userId,
                startDate = ToJsonDate(parameter.startDate),
                eventReason = "AAC",
                parameter.fte,
                customDouble20 = parameter.ftehours,
                parameter.standardHours
            };
            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(empjob, Converter.Settings));
            if (parameter.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog($"Create FTE Hours Change test data for {parameter.userId} ", "Data creation is successfull", State.APIPass);
            }
            else
            {
                Util.Updatelog($"Create FTE Hours Change test data for {parameter.userId} ", "Data creation is failed", State.APIFail);
            }
            RunTimeData<FTEParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.FTE_CHANGE);
        }

        public static void ValidateDataChange(FTEParameter parameter)
        {
            var query = $"EmpJob?$filter=(userId eq '{parameter.userId}' and eventReason eq 'AAC')&asOfDate={parameter.startDate:yyyy-MM-dd}&$format=json";
            var response = SFApi.Get(query).results[0];
            if (response != null)
            {
                try
                {

                    Assert.AreEqual(parameter.startDate, response.startDate.Value, "Effective date is not matching");
                    Assert.AreEqual(parameter.fte, response.fte.Value, "FTE Value is not matching");
                    Assert.AreEqual(parameter.ftehours, response.customDouble20.Value, "FTE Value is not matching");
                    Assert.AreEqual(parameter.standardHours, response.standardHours.Value, "FTE Value is not matching");
                    parameter.api_v_status = Constants.AVPass;
                    Util.Updatelog($"Verify the fte hours and respective fields are updated for user {parameter.userId}", "Value is as per the input data", State.APIPass);
                }
                catch (Exception)
                {
                    parameter.api_v_status = Constants.AVFail;
                    Util.Updatelog($"Verify the fte hours and respective fields are updated for user {parameter.userId}", "Value not as provided", State.APIFail);
                }
            }
            else
            {
                parameter.api_v_status = Constants.AVFail;
                Util.Updatelog($"Verify the fte hours and respective fields are updated for user {parameter.userId}", "No Response from System", State.APIFail);
            }
            RunTimeData<FTEParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.FTE_CHANGE);
        }
    }
}