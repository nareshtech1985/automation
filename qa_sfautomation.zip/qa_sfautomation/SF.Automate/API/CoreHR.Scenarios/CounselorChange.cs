﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Constants;
    using SF.Entity;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using Converter = Pom.Converter;
    public class CounselorChange : SFComponent
    {
        public static List<CounselorParameter> parameters;


        public static void PerformCounselorChange(CounselorParameter parameter)
        {
            parameter.eventReason = "AAY";
            parameter.managerId = GetRandomManager(parameter);
            var empjob = new
            {
                __metadata = new Metadata()
                {
                    Uri = "EmpJob"
                },
                parameter.userId,
                startDate = ToJsonDate(parameter.startDate),
                parameter.eventReason,
                parameter.managerId
            };


            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(empjob, Converter.Settings));
            if (parameter.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog($"Change the counselor of the user {parameter.userId} ", "Data creation is successfull", State.APIPass);
            }
            else
            {
                Util.Updatelog($"Change the counselor of the user {parameter.userId} ", "Data creation is failed", State.APIFail);
            }
            RunTimeData<CounselorParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.CHANGE_COUNSELOR);
        }

        private static string GetRandomManager(DataChangeParameter parameter)
        {
            string defaultManager = "";
            //and businessUnit eq '0040' and customString5 eq '0003' and customString4 eq '0018' and customString3 eq '0706' and customString2 eq '07' and department eq 'GBR07-700236' and customString6 eq '0003'
            var query = $"EmpJob?$format=json&$filter=userId eq '{parameter.userId}'&asOfDate={parameter.startDate:yyyy-MM-dd}&$select=userId,customString5,customString4,customString6,businessUnit,customString2,customString3,department,customString11";
            try
            {
                var queryResponse = SFApi.Get(query).results[0];
                if (queryResponse != null)
                {
                    var group = new
                    {
                        businessUnit = queryResponse.businessUnit.Value,
                        customString5 = queryResponse.customString5.Value,
                        customString4 = queryResponse.customString4.Value,
                        customString3 = queryResponse.customString3.Value,
                        customString2 = queryResponse.customString2.Value,
                        department = queryResponse.department.Value,
                        customString6 = queryResponse.customString6.Value,
                        rank = queryResponse.customString11.Value
                    };

                    if (group != null)
                    {
                        var groups = RankGrouping.FromJson(File.ReadAllText($@"{DirectoryPath}\Data\json_data\RankGroup.json"));

                        RankGrouping currentItem = groups.Find(x => x.Id.Equals(group.rank));
                        RankGrouping newItem = new RankGrouping() { Id = group.rank };

                        if (groups.Any(x => x.Order < currentItem.Order && x.Group.Equals(currentItem.Group)))
                        {
                            newItem = groups.Find(x => x.Order == currentItem.Order - 1 && x.Group.Equals(currentItem.Group));
                        }

                        try
                        {
                            //and department eq '{group.department}'
                            var managerListQuery = $"EmpJob?$format=json&$filter=businessUnit eq '{group.businessUnit}' and customString5 eq '{group.customString5}' and customString4 eq '{group.customString4}' and customString3 eq '{group.customString3}' and customString2 eq '{group.customString2}' and customString6 eq '{group.customString6}' and customString11 eq '{newItem.Id}' and userNav/personKeyNav/personIdExternal ne null &asOfDate={parameter.startDate:yyyy-MM-dd}&$select=userId,customString5,customString4,customString6,businessUnit,customString2,customString3,department,customString11,userNav/personKeyNav/personIdExternal&$expand=userNav,userNav/personKeyNav";

                            var managerlist = SFApi.Get(managerListQuery);

                            List<string> managers = new List<string>();
                            foreach (dynamic item in managerlist.results)
                            {
                                managers.Add(item.userNav.personKeyNav.personIdExternal.Value);
                            }

                            int i = new Random().Next(managers.Count);
                            defaultManager = managers[i];
                        }
                        catch (Exception e)
                        {
                            TestLog.Error($"Unable to select the random managers | Excepton {e.Message}");
                        }
                    }
                }
            }
            catch (Exception e)
            {
                TestLog.Error($"Error is manage selection | Exception {e.Message}");
            }
            TestLog.Info($"Random Manager Selected is {defaultManager}");
            return defaultManager;
        }

        public static void ValidateDataChange(CounselorParameter parameter)
        {
            var p = parameter;
            var query = $"EmpJob?$format=json&$filter=userId eq '{parameter.userId}'&asOfDate={parameter.startDate:yyyy-MM-dd}";

            try
            {
                var response = SFApi.Get(query).results[0];
                if (response != null)
                {
                    try
                    {
                        Assert.AreEqual(p.userId, response.userId.Value, "user id not matching");
                        Assert.AreEqual(p.startDate, response.startDate.Value, "start date not matching");
                        Assert.AreEqual(p.managerId, response.managerId.Value, "counselor changed not matching with input data");
                        TestLog.Info($"Location change api validation success for user id {p.userId}");
                        Util.Updatelog($"Validate the location change for user id {p.userId}", "Validation success", State.APIPass);
                        parameter.api_v_status = Constants.AVPass;
                    }
                    catch (Exception)
                    {
                        parameter.api_v_status = Constants.AVFail;
                        Util.Updatelog($"Validate the location change for user id {p.userId}", "Validation failure", State.Fail);
                    }
                }
            }
            catch (Exception e)
            {
                parameter.api_v_status = Constants.AVFail;
                TestLog.Debug($"Unable to read location details of the user due to the exception : {e.Message}");
            }
            RunTimeData<CounselorParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.CHANGE_COUNSELOR);
        }
    }
}