﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Constants;
    using SF.Entity;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using Converter = Pom.Converter;

    public class RankChange : SFComponent
    {
        public static List<RankParameter> parameters;

        public static void PerformPromotion(RankParameter parameter)
        {
            (string rankid, string managerlevel, string country, string jobcode) currentValueSet = GetCurrentRank(parameter);
            (string rankid, string managerlevel, string country, string jobcode) newValueSet = currentValueSet;
            if (parameter.rankId.ToLower().Equals("choose random"))
            {
                try
                {
                    if (Convert.ToInt32(newValueSet.managerlevel) >= 4)
                    {
                        //Get New Rank

                        newValueSet = GetNewRandomPromotion(currentValueSet);
                    }
                    else
                    {
                        newValueSet.managerlevel = $"{Convert.ToInt32(newValueSet.managerlevel) + 1}";
                        //Get Next JobCode with Current Level+1
                        var query = $"FOJobCode?$format=json&$expand=cust_ranks,cust_country&$filter=cust_ranks/externalCode eq {newValueSet.rankid} and cust_country/code eq '{newValueSet.country}' and cust_Experiencelevel eq '{newValueSet.managerlevel}'&$select=externalCode,cust_ranks/externalCode,cust_country/code,cust_Experiencelevel";

                        var items = SFApi.Get(query);
                        //OutputExcel.Rank_Change_Output_Data(parameter);
                        List<string> jccodes = new List<string>();
                        foreach (dynamic item in items.results)
                        {
                            jccodes.Add(item.externalCode.Value);
                        }
                        newValueSet.jobcode = jccodes[new Random().Next(jccodes.Count)];
                    }
                }
                catch (Exception)
                {
                    //no change
                    newValueSet = currentValueSet;
                }
            }
            else
            {
                newValueSet.rankid = parameter.rankId;
            }

            if (!parameter.jobcode.ToLower().Equals("choose random"))
            {
                newValueSet.jobcode = parameter.jobcode;
            }

            parameter.eygrade = newValueSet.managerlevel;
            parameter.rankId = newValueSet.rankid;
            parameter.jobcode = newValueSet.jobcode;

            var promotiondata = new
            {
                __metadata = new Metadata()
                {
                    Uri = $@"EmpJob"
                },
                parameter.userId,
                startDate = ToJsonDate(parameter.startDate),
                eventReason = "AAP",
                jobCode = parameter.jobcode,
                customString11 = parameter.rankId,
                customString16 = parameter.eygrade
            };

            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(promotiondata, Converter.Settings));

            if (parameter.api_c_status.Contains("Success"))
            {
                Util.Updatelog($"Create rank change via promotion for user {parameter.userId}", $"Rank change is success", State.APIPass);
            }
            else
            {
                Util.Updatelog($"Create rank change via promotion for user {parameter.userId}", $"Rank change is failure", State.APIPass);
            }
            RunTimeData<RankParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.RANK_CHANGE_PROMOTION);
        }

        private static (string rankid, string managerlevel, string country, string jobcode) GetNewRandomPromotion((string rankid, string managerlevel, string country, string jobcode) currentValueSet)
        {
            var groups = RankGrouping.FromJson(File.ReadAllText($@"{DirectoryPath}\Data\json_data\RankGroup.json"));

            RankGrouping currentItem = groups.Find(x => x.Id.Equals(currentValueSet.rankid));
            RankGrouping newItem = new RankGrouping();
            //Promotion
            if (groups.Any(x => x.Order < currentItem.Order && x.Group.Equals(currentItem.Group)))
            {
                newItem = groups.Find(x => x.Order == currentItem.Order - 1 && x.Group.Equals(currentItem.Group));
                currentValueSet.managerlevel = $"1";
            }

            if (newItem == null || newItem.Id == null)
            {
                //Take random Rank
                newItem = groups[new Random().Next(groups.Count)];
                currentValueSet.managerlevel = $"1";
            }

            var query = $"FOJobCode?$format=json&$expand=cust_ranks,cust_country&$filter=cust_ranks/externalCode eq {newItem.Id} and cust_country/code eq '{currentValueSet.country}' and cust_Experiencelevel eq '{currentValueSet.managerlevel}'&$select=externalCode,cust_ranks/externalCode,cust_country/code,cust_Experiencelevel";

            var items = SFApi.Get(query);
            List<string> jccodes = new List<string>();
            foreach (dynamic item in items.results)
            {
                jccodes.Add(item.externalCode.Value);
            }

            var dataobject = (
                rankid: newItem.Id, currentValueSet.managerlevel, currentValueSet.country,
                jobcode: jccodes[new Random().Next(jccodes.Count)]
            );
            return dataobject;
        }

        private static (string rankid, string managerlevel, string country, string jobcode) GetNewRandomDemotion((string rankid, string managerlevel, string country, string jobcode) currentValueSet)
        {
            var groups = RankGrouping.FromJson(File.ReadAllText($@"{DirectoryPath}\Data\json_data\RankGroup.json"));

            RankGrouping currentItem = groups.Find(x => x.Id.Equals(currentValueSet.rankid));
            RankGrouping newItem = new RankGrouping();
            //Promotion
            if (groups.Any(x => x.Order > currentItem.Order && x.Group.Equals(currentItem.Group)))
            {
                newItem = groups.Find(x => x.Order == currentItem.Order + 1 && x.Group.Equals(currentItem.Group));
                currentValueSet.managerlevel = $"1";
            }

            if (newItem == null || newItem.Id == null)
            {
                //Take random Rank
                var rankset = groups.FindAll(x => x.Order >= currentItem.Order && x.Group.Equals(currentItem.Group));
                if (rankset.Count == 0)
                {
                    rankset = groups.FindAll(x => x.Order >= currentItem.Order);
                }
                newItem = rankset[new Random().Next(rankset.Count)];
                currentValueSet.managerlevel = $"1";
            }

            var query = $"FOJobCode?$format=json&$expand=cust_ranks,cust_country&$filter=cust_ranks/externalCode eq {newItem.Id} and cust_country/code eq '{currentValueSet.country}' and cust_Experiencelevel eq '{currentValueSet.managerlevel}'&$select=externalCode,cust_ranks/externalCode,cust_country/code,cust_Experiencelevel";

            var items = SFApi.Get(query);
            List<string> jccodes = new List<string>();
            foreach (dynamic item in items.results)
            {
                jccodes.Add(item.externalCode.Value);
            }

            var dataobject = (
                rankid: newItem.Id, currentValueSet.managerlevel, currentValueSet.country,
                jobcode: jccodes[new Random().Next(jccodes.Count)]
            );
            return dataobject;
        }

        private static (string rankid, string managerlevel, string country, string jobcode) GetCurrentRank(DataChangeParameter parameter)
        {
            var query = $"EmpJob?$filter=userId eq '{parameter.userId}'&$format=json&asOfDate={parameter.startDate:yyyy-MM-dd}&$select=customString11,jobCode,customString16,countryOfCompany,customString18";
            var response = SFApi.Get(query).results[0];

            var dataobject = (
                rankid: (string)response.customString11.Value,
                managerlevel: (string)response.customString16.Value,
                country: (string)response.countryOfCompany.Value,
                jobcode: (string)response.jobCode.Value
            );
            return dataobject;
        }

        public static void PerformDemotion(RankParameter parameter)
        {
            (string rankid, string managerlevel, string country, string jobcode) currentValueSet = GetCurrentRank(parameter);
            (string rankid, string managerlevel, string country, string jobcode) newValueSet = currentValueSet;
            if (parameter.rankId.ToLower().Equals("choose random"))
            {
                try
                {
                    if (Convert.ToInt32(newValueSet.managerlevel) == 1)
                    {
                        //Get New Rank

                        newValueSet = GetNewRandomDemotion(currentValueSet);
                    }
                    else
                    {
                        newValueSet.managerlevel = $"{Convert.ToInt32(newValueSet.managerlevel) - 1}";
                        //Get Next JobCode with Current Level+1
                        var query = $"FOJobCode?$format=json&$expand=cust_ranks,cust_country&$filter=cust_ranks/externalCode eq {newValueSet.rankid} and cust_country/code eq '{newValueSet.country}' and cust_Experiencelevel eq '{newValueSet.managerlevel}'&$select=externalCode,cust_ranks/externalCode,cust_country/code,cust_Experiencelevel";

                        var items = SFApi.Get(query);

                        //OutputExcel.Rank_Change_Output_Data(parameter);

                        List<string> jccodes = new List<string>();
                        foreach (dynamic item in items.results)
                        {
                            jccodes.Add(item.externalCode.Value);
                        }
                        newValueSet.jobcode = jccodes[new Random().Next(jccodes.Count)];
                    }
                }
                catch (Exception)
                {
                    //no change
                    newValueSet = currentValueSet;
                }
            }
            else
            {
                newValueSet.rankid = parameter.rankId;
            }

            if (!parameter.jobcode.ToLower().Equals("choose random"))
            {
                newValueSet.jobcode = parameter.jobcode;
            }

            parameter.eygrade = newValueSet.managerlevel;
            parameter.rankId = newValueSet.rankid;
            parameter.jobcode = newValueSet.jobcode;

            var promotiondata = new
            {
                __metadata = new Metadata()
                {
                    Uri = $@"EmpJob"
                },
                parameter.userId,
                startDate = ToJsonDate(parameter.startDate),
                eventReason = "AAU",
                jobCode = parameter.jobcode,
                customString11 = parameter.rankId,
                customString16 = parameter.eygrade
            };

            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(promotiondata, Converter.Settings));

            if (parameter.api_c_status.Contains("Success"))
            {
                Util.Updatelog($"Create rank change via demotion for user {parameter.userId}", $"Rank change is success", State.APIPass);
            }
            else
            {
                Util.Updatelog($"Create rank change via demotion for user {parameter.userId}", $"Rank change is failure", State.APIPass);
            }
            RunTimeData<RankParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.RANK_CHANGE_DEMOTION);
        }

        public static void ValidatePromotionChange(RankParameter parameter)
        {
            var query = $"EmpJob?$format=json&asOfDate={parameter.startDate:yyyy-MM-dd}&$filter=userId eq '{parameter.userId}'&$select=userId,startDate,customString11,jobCode,customString16,countryOfCompany,customString18,eventReason";
            try
            {
                var response = SFApi.Get(query).results[0];
                Assert.AreEqual(parameter.userId, response.userId.Value, "User id not matching");
                Assert.AreEqual(parameter.startDate, response.startDate.Value, "User id not matching");
                Assert.AreEqual(parameter.rankId, response.customString11.Value, "Rank value is not matching");
                Assert.AreEqual("AAP", response.eventReason.Value, "Event reason is not matching");
                parameter.api_v_status = Constants.AVPass;
                Util.Updatelog($"Validate rank change data created for user {parameter.userId}", "Data validation success", State.APIPass);
            }
            catch (Exception e)
            {
                parameter.api_v_status = Constants.AVFail;
                Util.Updatelog($"Validate rank change data created for user {parameter.userId}", $"Data validation failed,{e.Message}", State.APIPass);
            }
            RunTimeData<RankParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.RANK_CHANGE_PROMOTION);
        }

        public static void ValidateDemotionChange(RankParameter parameter)
        {
            var query = $"EmpJob?$format=json&asOfDate={parameter.startDate:yyyy-MM-dd}&$filter=userId eq '{parameter.userId}'&$select=userId,startDate,customString11,jobCode,customString16,countryOfCompany,customString18,eventReason";
            try
            {
                var response = SFApi.Get(query).results[0];

                Assert.AreEqual(parameter.userId, response.userId.Value, "User id not matching");
                Assert.AreEqual(parameter.startDate, response.startDate.Value, "User id not matching");
                Assert.AreEqual(parameter.rankId, response.customString11.Value, "Rank value is not matching");
                Assert.AreEqual("AAU", response.eventReason.Value, "Event reason is not matching");
                parameter.api_v_status = Constants.AVPass;
                Util.Updatelog($"Validate rank change data created for user {parameter.userId}", "Data validation success", State.APIPass);
            }
            catch (Exception e)
            {
                parameter.api_v_status = Constants.AVFail;
                Util.Updatelog($"Validate rank change data created for user {parameter.userId}", $"Data validation failed,{e.Message}", State.APIPass);
            }
        }
    }
}