﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity.EmployeeTimeOff;
    using SF.Parameter;
    using SpreadsheetLight;
    using System;
    using System.Collections.Generic;

    public class TimeOff : SFComponent
    {
        public static List<TimeOffParameter> parameters;

        public static void ApplyTimeOff(TimeOffParameter param, CoreHRScenario scenario)
        {
            try
            {
                long userid = Convert.ToInt64(param.personIdExternal);
                var timeProfile = GetProfile(userid);
                var leaveType = GetTimeType(param.LeaveType, timeProfile);
                var guid = $"{Guid.NewGuid():N}";
                param.Guid = guid;
                param.LeaveTypeCode = leaveType.Split('$')[0];
                param.LeaveDescription = leaveType.Split('$')[1];

                var paidLeave = new EmployeeTime()
                {
                    Metadata = new Entity.Metadata()
                    {
                        Uri = $@"https://api12preview.sapsf.eu/odata/v2/EmployeeTime('{guid}')",
                        Type = "SFOData.EmployeeTime"
                    },
                    UserId = Convert.ToInt64(param.personIdExternal),
                    StartDate = ToJsonDate(param.startDate),
                    EndDate = ToJsonDate(param.endDate),
                    LoaActualReturnDate = null,
                    TimeType = param.LeaveTypeCode,
                    LoaExpectedReturnDate = ToJsonDate(param.endDate.AddDays(1))
                };

                param.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(paidLeave, Converter.Settings));
                if (param.api_c_status.ToLower().Contains("fail"))
                {
                    Util.Updatelog($"Create test data for user {param.ParameterShort}", "test data creation failed", State.APIFail);
                }
                else
                {
                    Util.Updatelog($"Create test data for user {param.ParameterShort}", "test data created", State.APIPass);
                }
            }
            catch (Exception e)
            {
                Util.Updatelog($"Create test data for user {param.ParameterShort}", $"Data creation failed<br>{e.Message}", State.APIFail);
            }
            finally
            {
                RunTimeData<TimeOffParameter>.MergeListAndSave(ref parameters, param, scenario);
            }
        }

        public static void ApplyLongDisability(TimeOffParameter param)
        {
            try
            {
                long userid = Convert.ToInt64(param.personIdExternal);
                var timeProfile = GetProfile(userid);
                var leaveType = GetTimeType(param.LeaveType, timeProfile);
                var guid = $"{Guid.NewGuid():N}";
                param.Guid = guid;
                param.LeaveTypeCode = leaveType.Split('$')[0];
                param.LeaveDescription = leaveType.Split('$')[1];

                var paidLeave = new EmployeeTime()
                {
                    Metadata = new Entity.Metadata()
                    {
                        Uri = $@"https://api12preview.sapsf.eu/odata/v2/EmployeeTime('{guid}')",
                        Type = "SFOData.EmployeeTime"
                    },
                    UserId = Convert.ToInt64(param.personIdExternal),
                    StartDate = ToJsonDate(param.startDate),
                    EndDate = ToJsonDate(param.endDate),
                    LoaActualReturnDate = null,
                    TimeType = param.LeaveTypeCode,
                    LoaExpectedReturnDate = ToJsonDate(param.endDate.AddDays(1))
                };

                param.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(paidLeave, Converter.Settings));
                if (param.api_c_status.ToLower().Contains("fail"))
                {
                    Util.Updatelog($"Create test data for user {param.ParameterShort}", "test data creation failed", State.APIFail);
                }
                else
                {
                    Util.Updatelog($"Create test data for user {param.ParameterShort}", "test data created", State.APIPass);
                }
            }
            catch (Exception e)
            {
                Util.Updatelog($"Create test data for user {param.ParameterShort}", $"Data creation failed<br>{e.Message}", State.APIFail);
            }
            finally
            {
                RunTimeData<TimeOffParameter>.MergeListAndSave(ref parameters, param, CoreHRScenario.LONG_TERM_DISABILITY);
            }
        }

        public static void ReturnFromLeave(TimeOffParameter param, CoreHRScenario scenario)
        {
            //long userid = Convert.ToInt64(timeOff.personIdExternal);
            try
            {
                GetActiveLeaveRequest(ref param);
                if (!param.Guid.Equals(string.Empty))
                {
                    var returnBody = new
                    {
                        __metadata = new Entity.Metadata()
                        {
                            Uri = $@"https://api12preview.sapsf.eu/odata/v2/EmployeeTime('{param.Guid}')",
                            Type = "SFOData.EmployeeTime"
                        },

                        endDate = ToJsonDate(param.endDate),
                        loaActualReturnDate = ToJsonDate(param.endDate.AddDays(1)),
                    };
                    param.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(returnBody, Converter.Settings));
                    if (param.api_c_status.ToLower().Contains("fail"))
                    {
                        Util.Updatelog($"Create test data for user {param.ParameterShort}", "test data creation failed", State.Fail);
                    }
                    else
                    {
                        Util.Updatelog($"Create test data for user {param.ParameterShort}", "test data created", State.Pass);
                    }
                }
                else
                {
                    Util.Updatelog($"Create test data for user {param.ParameterShort}", "test data creation failed", State.Pass);
                    param.api_c_status = "Failed";
                }
            }
            catch (Exception e)
            {
                Util.Updatelog($"Create test data for user {param.ParameterShort}", $"Data creation failed<br>{e.Message}", State.APIFail);
            }
            finally
            {
                RunTimeData<TimeOffParameter>.MergeListAndSave(ref parameters, param, scenario);
            }
        }

        public static dynamic GET(TimeOffParameter obj)
        {
            string timeoff = $@"EmployeeTime?$filter=externalCode eq '{obj.Guid}'&$format=json&$expand=timeTypeNav";
            var response = SFApi.Get(timeoff);
            return response;
        }


        public static void ReadTestData(string sheetName)
        {
            parameters = new List<TimeOffParameter>();
            using (SLDocument doc = new SLDocument(DataSheetPath))
            {
                doc.SelectWorksheet(sheetName);
                var prop = doc.GetWorksheetStatistics();
                for (int i = 2; i <= prop.EndRowIndex; i++)
                {
                    if (!doc.GetCellValueAsString($"A{i}").Equals(string.Empty))
                    {
                        parameters.Add(new TimeOffParameter()
                        {
                            rowKey = (i - 1),
                            personIdExternal = doc.GetCellValueAsString($"A{i}"),
                            startDate = doc.GetCellValueAsDateTime($"B{i}"),
                            endDate = doc.GetCellValueAsDateTime($"C{i}"),
                            LeaveType = doc.GetCellValueAsString($"D{i}"),
                            Guid = doc.GetCellValueAsString($"E{i}"),
                            LeaveDescription = doc.GetCellValueAsString($"F{i}")
                        });
                    }
                }
            }
        }


        public static void ValidateDataChange(TimeOffParameter parameter, CoreHRScenario scenario)
        {
            try
            {
                dynamic response = GET(parameter).results[0];//taking first record only for now
                parameter.LeaveDescription = response.timeTypeNav.externalName_defaultValue.Value;

                DateTime startDate = response.startDate.Value;
                DateTime endDate = response.endDate.Value;
                string status = response.approvalStatus.Value;
                parameter.LeaveDescription = response.timeTypeNav.externalName_defaultValue.Value;

                Assert.AreEqual(parameter.personIdExternal, response.userId.Value, "GUI not matching");
                Assert.AreEqual($"{parameter.startDate:yyyy-MM-dd}", $"{startDate:yyyy-MM-dd}", "Start Date not matching");
                //Assert.AreEqual($"{parameters.endDate:yyyy-MM-dd}", $"{endDate:yyyy-MM-dd}", "End Date not matching");
                Assert.AreEqual("approved", status.ToLower(), "Leave request approval status is not as expected"); // to be corrected
                Util.Updatelog("Check the leave request data", "Data parameters are valid and looks good", State.APIPass);
                parameter.api_v_status = Constants.AVPass;
            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
                Util.Updatelog("Check the leave request data", "Data parameters are not as per input", State.APIFail);
                parameter.api_v_status = Constants.AVFail;
            }
            finally
            {
                RunTimeData<TimeOffParameter>.MergeListAndSave(ref parameters, parameter, scenario);
            }
        }

        private static void GetActiveLeaveRequest(ref TimeOffParameter timeOff)
        {
            string uri = $@"EmployeeTime?$format=json&$expand=timeTypeNav&$filter=userId eq '{timeOff.personIdExternal}' and approvalStatus eq 'APPROVED' and startswith(timeTypeNav/externalName_defaultValue,'{timeOff.LeaveType}')";
            try
            {
                dynamic timeProfile = SFApi.Get(uri).results[0];
                timeOff.Guid = timeProfile.externalCode.Value;
                timeOff.startDate = timeProfile.startDate.Value;
                timeOff.endDate = timeProfile.endDate.Value;
                timeOff.LeaveTypeCode = timeProfile.timeType.Value;
                timeOff.LeaveDescription = timeProfile.timeTypeNav.externalName_defaultValue.Value;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

        }

        private static string GetProfile(long userid)
        {
            string timeProfile = "";
            string empJob = $@"EmpJob?$filter=userId eq '{userid}'&$select=timeTypeProfileCode&$format=json&$top=1";
            try
            {
                timeProfile = SFApi.Get(empJob).results[0].timeTypeProfileCode.Value;
                //Console.WriteLine(timeProfile);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine($"Reading TimeProfile Value as : {timeProfile}");
            return timeProfile;
        }

        private static string GetTimeType(string leaveType, string timeProfile)
        {
            string timeType = "PDLVOTH$Paid - Leave-Other";
            string empJob = $@"AvailableTimeType?$format=JSON&$expand=timeTypeNav&$filter=TimeTypeProfile_externalCode eq '{timeProfile}' and startswith(timeTypeNav/externalName_defaultValue,'{leaveType}')&$select=externalCode,timeTypeNav/externalName_defaultValue&";
            try
            {
                var response = SFApi.Get(empJob);
                List<string> selectlist = new List<string>();
                foreach (var r in response.results)
                {
                    selectlist.Add($"{r.externalCode.Value}${r.timeTypeNav.externalName_defaultValue}");
                }

                int index = new Random().Next(selectlist.Count);
                timeType = selectlist[index];
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine($"Reading TimeProfile Value as : {timeType}");
            return timeType;
        }
    }
}