﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.API.Parameters.IDT;
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;
    using System.IO;

    public class ManagerialCountryChange : SFComponent
    {
        public static List<DataChangeParameter> parameters;

        public static void PerformManagerialCountryChange(DataChangeParameter parameter)
        {
            try
            {
                DeptDataStore MC_Data = new DeptDataStore();
                GetEmployeeInfo(parameter.personIdExternal);
                //Get personinfo
                GetPersonalInfo(parameter.personIdExternal);
                // Need to implement a logic to go directly when the employee is terminated
                if (!CheckIfUserIdTerminated(ref parameter))
                {
                    //perform termination prior to change LE & MC | US based case need to create. 
                    TerminateEmployee(parameter, TerminationType.TAH); //Separation by  Re-organization
                }
                else
                {
                    GetCurrentJobInfo(parameter);
                }

                if (parameter.IsSameMR.ToLower().Equals("yes"))
                {
                    InitialValues.eventReason = "RAA";
                    if (InitialValues.country.Equals("USA"))
                    {
                        InitialValues.eventReason = "RAB";// For America use the event reason as this per the guidance recevied
                    }
                }
                else
                {
                    var newuserid = GetNextUserId();
                    InitialValues.userId = newuserid;
                    InitialValues.eventReason = "HAI"; // Hire due to Re-organization
                }

                MC_Data = GetMCFor(InitialValues, parameter.IsSameMR.ToLower().Equals("yes"));
                InitialValues.personIdExternal = parameter.personIdExternal;
                InitialValues.startDate = parameter.startDate;
                InitialValues.managementcountryid = MC_Data.ManagerialCountry;
                InitialValues.company = MC_Data.LegalEntityId;
                InitialValues.departmentid = MC_Data.Departmentid;
                InitialValues.speciality = MC_Data.Speciality;
                InitialValues.serviceLineId = MC_Data.ServiceLine;
                InitialValues.subservicelineid = MC_Data.SubServiceLine;
                InitialValues.managementregionid = MC_Data.ManagementRegionId;

                Locationvariables location = GetGALocation(MC_Data.LegalEntityId);
                RankParameter rankParam = GetNewRank(InitialValues.country, "42");

                if (!parameter.IsSameMR.ToLower().Equals("yes"))
                {
                    //New Concurrent Employment Create
                    var employmnetbody = new
                    {
                        __metadata = new Metadata()
                        {
                            Uri = "EmpEmployment"
                        },

                        startDate = ToJsonDate(parameter.startDate),
                        parameter.personIdExternal,
                        InitialValues.userId,
                        originalStartDate = ToJsonDate(Employment.originalStartDate),
                        customDate2 = ToJsonDate(parameter.startDate),
                        isRehire = true
                    };

                    var empstat = SFApi.Upsert(JsonConvert.SerializeObject(employmnetbody, Converter.Settings));
                }

                var idtInfo = IDToolApi.GenerateIdentifierAsync(new IDTInputParameter()
                {
                    contextId = $"{InitialValues.personIdExternal}:{InitialValues.startDate:yyyyMMdd}",
                    contextSrc = "SFEC",
                    contextSoR = "sfec",
                    gender = Person.Gender,
                    dob = $"{Person.DateOfBirth:yyyy-MM-dd}",
                    lastName = Person.LastName,
                    firstName = Person.FirstName,
                    providedGUI = InitialValues.personIdExternal,
                    leCode = InitialValues.company,
                    ecCode = InitialValues.employeeClassCode,
                    etCode = InitialValues.employmentTypeCode,
                    mrCode = InitialValues.managementregionid,
                    gcCode = InitialValues.country,
                    mcCode = InitialValues.managementcountryid,
                    doh = $"{InitialValues.startDate:yyyy-MM-dd}",
                    mode = "AM",
                    traceFlag = false
                });

                InitialValues.gpn = idtInfo.Gpn;
                InitialValues.lpn = $"{idtInfo.Lpn}";

                InitialValues.startDate = parameter.startDate;
                var lechangejob = new
                {
                    __metadata = new Metadata()
                    {
                        Uri = "EmpJob"
                    },
                    InitialValues.userId,
                    InitialValues.eventReason,
                    startDate = ToJsonDate(InitialValues.startDate),
                    InitialValues.company,
                    department = InitialValues.departmentid,
                    division = InitialValues.speciality,
                    customString2 = InitialValues.serviceLineId,
                    customString3 = InitialValues.subservicelineid,
                    businessUnit = InitialValues.managementregionid,
                    customString21 = InitialValues.managementcountryid,
                    customString15 = InitialValues.lpn,
                    customString14 = InitialValues.gpn,
                    InitialValues.managerId,
                    timeTypeProfileCode = $"{InitialValues.country}_TIME_PROFILE",
                    workscheduleCode = "NORM",

                    /// ------------------------------------------------------------------------------------------- ///
                    /// FIELDS APPLICABLE WHEN HIRING ONLY ///
                    /// ------------------------------------------------------------------------------------------- ///
                    departmentEntryDate = ToJsonDate(parameter.startDate),
                    customString33 = "40105", //Overtime Eligibility - PickList (Regular Pay no overtime defaulted) 
                    isFulltimeEmployee = true,
                    payGrade = "PG00",
                    standardHours = "40",
                    customDouble20 = "40", // FTE Hours
                    locationEntryDate = ToJsonDate(parameter.startDate),
                    holidayCalendarCode = "HOLIDAYCAL",
                    InitialValues.employeeClass, //EMPLOYEE CLASS
                    InitialValues.employmentType, //EMPLOYEE TYPE
                    customString22 = MC_Data.CodeBlock,
                    customString18 = InitialValues.country, // Country/Region
                    jobCode = rankParam.jobcode,
                    customString11 = rankParam.rankId, // Rank
                    customString12 = rankParam.activityTypeCode, // Activity Type
                    customString16 = "1",
                    regularTemp = "57674",
                    location = location.externalCode, // location
                    customString5 = location.geographicareaid, // 	Geographic Area
                    customString4 = location.geographicregionid, // Geographic region
                    customString7 = location.geozone // Geo Zone
                };


                InitialValues.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(lechangejob, Converter.Settings));

                if (InitialValues.api_c_status.ToLower().Contains("success"))
                {
                    Util.Updatelog($"Create Managerial Country Change data {parameter.userId} ", "Data creation is successfull", State.APIPass);

                    //On Successfull Rehire execute the IDT Call.
                    IDTAction.ReconcileRecord(InitialValues.personIdExternal, InitialValues.userId, InitialValues.startDate);

                }
                else
                {
                    Util.Updatelog($"Create Managerial Country Change data {parameter.userId} ", "Data creation is failed", State.APIFail);
                }
                //RunTimeData<DataChangeParameter>.MergeListAndSave(ref parameters, InitialValues, CoreHRScenario.MC_CHANGE);
            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
                Util.Updatelog($"Please review test data", $"Failed {e.Message}", State.APIFail);
            }
            finally
            {
                RunTimeData<DataChangeParameter>.MergeListAndSave(ref parameters, InitialValues, CoreHRScenario.MC_CHANGE);
            }
        }

        private static DataChangeParameter GetNewGpn(DataChangeParameter initialValues)
        {
            var location = Util.TestConfiguration.GetCustomKeyValue("seednumber");
            dynamic prop = JsonConvert.DeserializeObject(File.ReadAllText(location));
            for (int i = 1; i < 100; i++)
            {
                long uid = Convert.ToInt64(prop.lpn.Value) + i;
                var query = $"EmpJob?$format=json&$asOfDate={initialValues.startDate:yyyy-MM-dd}&$select=userId,customString15&$filter=startswith(customString15,'{uid}')";
                dynamic response = SFApi.Get(query);
                if (response.Value == null)
                {
                    initialValues.lpn = $"{uid}";
                    initialValues.gpn = $"{initialValues.managementcountryid}{uid}";
                    var jsoncontent = JsonConvert.SerializeObject(new
                    {
                        initialValues.lpn,
                        initialValues.gpn,
                        userId = prop.userId.Value
                    }, Formatting.Indented);
                    using (StreamWriter e = new StreamWriter(new FileStream(location, FileMode.OpenOrCreate)))
                    {
                        e.WriteLine(jsoncontent);
                    }
                    break;
                }
            }
            return initialValues;
        }

        public static void ValidateDataChange(DataChangeParameter parameter)
        {
            var url = $"EmpJob?$filter=userId eq '{parameter.userId}'&$format=json&$format=json&asOfDate={parameter.startDate:yyyy-MM-dd}";
            var response = SFApi.Get(url).results[0]; // First Record in Desc will be rehire record validate that
            if (response != null)
            {
                try
                {
                    DataChangeParameter p = new DataChangeParameter()
                    {
                        startDate = response.startDate.Value,
                        company = response.company.Value,
                        departmentid = response.department.Value,
                        speciality = response.division.Value,
                        serviceLineId = response.customString2.Value,
                        subservicelineid = response.customString3.Value,
                        managementregionid = response.businessUnit.Value,
                        managementcountryid = response.customString21.Value,
                        lpn = response.customString15.Value,
                        gpn = response.customString14.Value,
                        managerId = response.managerId.Value,
                        eventReason = response.eventReason.Value
                    };

                    //Assert.AreEqual(parameter.startDate, p.startDate, "startDate not matching");
                    Assert.AreEqual(parameter.company, p.company, "company not matching");
                    Assert.AreEqual(parameter.departmentid, p.departmentid, "departmentid not matching");
                    Assert.AreEqual(parameter.speciality, p.speciality, "speciality not matching");
                    //Assert.AreEqual(parameter.lpn, p.lpn, "lpn not matching");
                    //Assert.AreEqual(parameter.gpn, p.gpn, "gpn not matching");
                    Assert.AreEqual(parameter.managementcountryid, p.managementcountryid, "managementcountryid not matching");
                    parameter.api_v_status = Constants.AVPass;
                    Util.Updatelog("Check the MC change record reflected as input data", $"MC change data looks good", State.Pass);
                }
                catch (Exception e)
                {
                    parameter.api_v_status = Constants.AVFail;
                    Util.Updatelog("Check the MC change record reflected as input data", $"MC change data not looks good, {e.Message}", State.Fail);
                }
                RunTimeData<DataChangeParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.MC_CHANGE);
            }
        }
    }
}
