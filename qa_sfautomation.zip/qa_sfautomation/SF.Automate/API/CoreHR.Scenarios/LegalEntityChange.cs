﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;

    public class LegalEntityChange : SFComponent
    {

        public static List<DataChangeParameter> parameters;

        public static void PerformLegalEntityChange(DataChangeParameter parameter)
        {
            try
            {
                // Need to implement a logic to go directly when the employee is terminated
                if (!CheckIfUserIdTerminated(ref parameter))
                {
                    TestLog.Info("Terminating the Record for Change");
                    TerminateEmployee(parameter); //perform termination prior to change LE & MC | US based case need to create. 
                }
                else
                {
                    TestLog.Info("Already Terminated Record");
                    GetCurrentJobInfo(parameter);
                }
                InitialValues.eventReason = "RAA";
                if (InitialValues.country.Equals("USA"))
                {
                    InitialValues.eventReason = "RAB";
                }

                var newdepartment = GetDeptForLEChange(InitialValues);
                InitialValues.personIdExternal = parameter.personIdExternal;
                InitialValues.startDate = parameter.startDate;
                InitialValues.company = newdepartment.LegalEntityId;
                InitialValues.departmentid = newdepartment.Departmentid;
                InitialValues.speciality = newdepartment.Speciality;
                InitialValues.serviceLineId = newdepartment.ServiceLine;
                InitialValues.subservicelineid = newdepartment.SubServiceLine;
                InitialValues.managementregionid = newdepartment.ManagementRegionId;
                var lechangejob = new
                {
                    __metadata = new Metadata()
                    {
                        Uri = "EmpJob"
                    },
                    parameter.userId,
                    InitialValues.eventReason,
                    startDate = ToJsonDate(InitialValues.startDate),
                    InitialValues.company,
                    department = InitialValues.departmentid,
                    division = InitialValues.speciality,
                    customString2 = InitialValues.serviceLineId,
                    customString3 = InitialValues.subservicelineid,
                    businessUnit = InitialValues.managementregionid,
                };


                parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(lechangejob, Converter.Settings));

                if (parameter.api_c_status.ToLower().Contains("success"))
                {
                    Util.Updatelog($"Create Legal Entity Change data {parameter.userId} ", "Data creation is successfull", State.APIPass);
                }
                else
                {
                    Util.Updatelog($"Create Legal Entity Change data {parameter.userId} ", "Data creation is failed", State.APIFail);
                }
                RunTimeData<DataChangeParameter>.MergeListAndSave(ref parameters, InitialValues, CoreHRScenario.LEGAL_ENTITY_CHANGE);
            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
                Util.Updatelog($"Create Legal Entity Change data {parameter.userId} ", $"User at MC {InitialValues.managementcountryid} & LE {InitialValues.company}, No Othe LE Obtained in Query, Retry With Someother data", State.APIFail);
                parameter.api_c_status = "Fail";
            }
        }

        public static void ValidateDataChange(DataChangeParameter parameter)
        {
            var url = $"EmpJob?$filter=userId eq '{parameter.userId}'&$format=json&$format=json&asOfDate={parameter.startDate:yyyy-MM-dd}";
            var response = SFApi.Get(url).results[0]; // First Record in Desc will be rehire record validate that
            if (response != null)
            {
                try
                {
                    DataChangeParameter p = new DataChangeParameter()
                    {
                        startDate = response.startDate.Value,
                        company = response.company.Value,
                        departmentid = response.department.Value,
                        speciality = response.division.Value,
                        serviceLineId = response.customString2.Value,
                        subservicelineid = response.customString3.Value,
                        managementregionid = response.businessUnit.Value,
                        managementcountryid = response.customString21.Value,
                        lpn = response.customString15.Value,
                        gpn = response.customString14.Value,
                        managerId = response.managerId.Value
                    };

                    Assert.AreEqual(parameter.startDate, p.startDate, "startDate not matching");
                    Assert.AreEqual(parameter.company, p.company, "company not matching");
                    Assert.AreEqual(parameter.departmentid, p.departmentid, "departmentid not matching");
                    Assert.AreEqual(parameter.speciality, p.speciality, "speciality not matching");
                    Assert.AreEqual(parameter.managementcountryid, p.managementcountryid, "managementcountryid not matching");
                    parameter.api_v_status = Constants.AVPass;
                    Util.Updatelog("Check the LE change record reflected as input data", $"LE change data looks good", State.Pass);
                }
                catch
                {
                    parameter.api_v_status = Constants.AVFail;
                    Util.Updatelog("Check the LE change record reflected as input data", $"LE change data not looks good", State.Fail);
                }
                RunTimeData<DataChangeParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.LEGAL_ENTITY_CHANGE);
            }
        }
    }
}