﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.API.Parameters.IDT;
    using EY_Test.API.Parameters.IDT.GUISearch;
    using EY_Test.API.Parameters.IDT.Reconcile;
    using Newtonsoft.Json;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class IDTAction : SFComponent
    {
        /// <summary>
        /// This method is used for the process of reconciling the job record after life changing events such as Termination, Hire, Rehire, GA, Concurrent Assignments
        /// </summary>
        /// <param name="personIdExternal"></param>
        /// <param name="userId"></param>
        /// <param name="startDate"></param>
        public static void ReconcileRecord(string personIdExternal, string userId, DateTime startDate)
        {
            Record record = new Record();

            List<Name> names = new List<Name>();
            List<Nid> nids = new List<Nid>();

            var query = $"EmpEmployment?$format=json&$expand=jobInfoNav,personNav,personNav/personalInfoNav,personNav/nationalIdNav&$filter=personIdExternal eq '{personIdExternal}' and userId eq '{userId}'&$select=personIdExternal,userId,startDate,endDate,originalStartDate,personNav/dateOfBirth,personNav/personId,personNav/personalInfoNav/firstName,personNav/personalInfoNav/lastName,personNav/personalInfoNav/gender,personNav/perPersonUuid,jobInfoNav/countryOfCompany,jobInfoNav/employeeClass,jobInfoNav/employmentType,jobInfoNav/emplStatus,jobInfoNav/company,jobInfoNav/businessUnit,jobInfoNav/customString5,jobInfoNav/customString4,jobInfoNav/customString6,jobInfoNav/customString18,jobInfoNav/customString21,jobInfoNav/startDate,jobInfoNav/endDate,personNav/nationalIdNav/country,personNav/nationalIdNav/cardType,personNav/nationalIdNav/nationalId,jobInfoNav/event,jobInfoNav/eventReason,jobInfoNav/seqNumber,jobInfoNav/customString15,jobInfoNav/customString14,personNav/personalInfoNav/startDate,personNav/personalInfoNav/endDate";
            try
            {
                dynamic response = SFApi.Get(query).results[0];

                dynamic personInfo = response.personNav;
                dynamic personData = personInfo.personalInfoNav.results.ToString() != "[]" ? personInfo.personalInfoNav.results[0] : null;
                JobInfoTemp jobinfos = new JobInfoTemp();
                jobinfos = JsonConvert.DeserializeObject<JobInfoTemp>(response.jobInfoNav.ToString());
                var jobinfo = jobinfos.Results[0];

                dynamic Nid = personInfo.nationalIdNav.results.ToString() != "[]" ? personInfo.nationalIdNav.results[0] : null;

                names = new List<Name>
                {
                    new Name()
                    {
                        fName = personData.firstName.Value,
                        lName = personData.lastName.Value,
                        gender = personData.gender.Value,
                        dob = $"{personInfo.dateOfBirth.Value:yyyy-MM-dd}",
                        startDate = $"{personData.startDate.Value:yyyy-MM-dd}",
                        endDate = $"{personData.endDate.Value:yyyy-MM-dd}"
                    }
                };

                if (Nid != null)
                {
                    nids = new List<Nid>
                    {
                        new Nid()
                        {
                        nationalID = Nid.nationalId.Value,
                        nationalIDCountry = Nid.country.Value
                        }
                    };
                }

                record = new Record()
                {
                    id = new Id()
                    {
                        gui = personIdExternal,
                        lpn = jobinfo.CustomString15,
                        gpn = jobinfo.CustomString14,
                    },
                    empDetails = new Empdetails()
                    {
                        empClass = SFComponent.GetPicklistByOptionID(jobinfo.EmployeeClass).externalCode,
                        empType = SFComponent.GetPicklistByOptionID(jobinfo.EmploymentType).externalCode,
                        leCode = jobinfo.Company,
                        emplStatus = SFComponent.GetPicklistByOptionID(jobinfo.EmplStatus).externalCode,
                        mrCode = jobinfo.BusinessUnit,
                        gaCode = jobinfo.CustomString5,
                        grCode = jobinfo.CustomString4,
                        maCode = jobinfo.CustomString6,
                        gcCode = jobinfo.CustomString18,
                        mcCode = jobinfo.CustomString21,
                        doh = $"{response.startDate.Value:yyyy-MM-dd}",
                        dot = $"{response.endDate.Value:yyyy-MM-dd}"
                    },
                    names = names,
                    nIds = nids,
                    kmsUserId = "",
                    workerId = "",
                    userId = userId,
                    personId = personInfo.personId.Value,
                    personUUId = personInfo.perPersonUuid.Value,
                    eventReason = jobinfo.EventReason,
                    _event = SFComponent.GetPicklistByOptionID(jobinfo.Event).externalCode
                };

                #region ID Search & Generation incase of blank GPN LPN Records

                if (record.id.gpn == null || record.id.lpn == null)
                {
                    var reservedValues = IDToolApi.SearchReservedIdentifiersAsync(new IDTSearchInput() { gui = record.id.gui });
                generate:
                    if (reservedValues.GUIs.Count == 0)
                    {
                        #region Generate GPN, LPN etc..

                        var reserverval = IDToolApi.GenerateIdentifierAsync(new IDTInputParameter()
                        {
                            contextId = $"{personIdExternal}:{startDate:yyyyMMdd}",
                            contextSrc = "SFEC",
                            contextSoR = "sfec",
                            gender = names[0].gender,
                            dob = names[0].dob,
                            lastName = names[0].lName,
                            firstName = names[0].fName,
                            providedGUI = personIdExternal,
                            leCode = record.empDetails.leCode,
                            ecCode = record.empDetails.empClass,
                            etCode = record.empDetails.empType,
                            mrCode = record.empDetails.mrCode,
                            gcCode = record.empDetails.gcCode,
                            mcCode = record.empDetails.mcCode,
                            doh = record.empDetails.doh,
                            mode = "AM",
                            traceFlag = false
                        });
                        record.id.gpn = reserverval.Gpn;
                        record.id.lpn = reserverval.Lpn;

                        #endregion Generate GPN, LPN etc..
                    }
                    else
                    {
                        #region Search and Get GPN & LPN

                        var reserverval = reservedValues.GUIs.Find(x => x.GUI_STATUS.Equals("0") && x.EMPLOYMENT_STATUS.ToLower().Equals(string.Empty) && x.MANAGERIAL_COUNTRY_CODE.Equals(jobinfo.CustomString21));
                        if (reserverval == null)
                        {
                            reservedValues.GUIs.Clear();
                            goto generate;
                        }

                        record.id.gpn = reserverval.GPN_CODE;
                        record.id.lpn = reserverval.LPN_CODE;

                        #endregion Search and Get GPN & LPN
                    }

                    /// -------------------------------------------------------------------------- ///
                    /// To Update the Job record if the GPN & LPN is not updated for the records
                    /// -------------------------------------------------------------------------- ///
                    var jobbody = new
                    {
                        __metadata = new Metadata()
                        {
                            Uri = $"EmpJob(seqNumber={jobinfo.SeqNumber}L,startDate=datetime'{startDate:yyyy-MM-dd}T00:00:00',userId='{userId}')"
                        },
                        customString15 = record.id.lpn,
                        customString14 = record.id.gpn,
                    };

                    var resp = SFApi.Upsert(JsonConvert.SerializeObject(jobbody, Converter.Settings));
                    TestLog.Info($"Data Update response : {resp}");
                }

                #endregion ID Search & Generation incase of blank GPN LPN Records

                Reconcile reconcile = new Reconcile()
                {
                    record = record
                };

                var reconilebody = JsonConvert.SerializeObject(reconcile, Formatting.Indented);
                TestLog.Debug($"\n{reconilebody}");
                IDToolApi.ReconcileRecordAsync(reconilebody);
            }
            catch (Exception e)
            {
                TestLog.Info(e.Message);
            }
        }

        public static Gui SearchGUI(string personIdExternal, string userId, DateTime startDate)
        {
            IDTSearchOutput reservedValues = IDToolApi.SearchReservedIdentifiersAsync(new IDTSearchInput() { gui = personIdExternal });

            if (reservedValues.GUIs.Count > 0)
            {
                return reservedValues.GUIs.Last();
            }
            else
            {
                return new Gui();
            }
        }
    }
}