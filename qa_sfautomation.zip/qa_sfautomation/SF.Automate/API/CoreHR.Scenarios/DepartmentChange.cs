﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;

    public class DepartmentChange : SFComponent
    {
        public static List<DepartmentParameter> parameters;

        public static void PerformDepartmentChange(DepartmentParameter parameter)
        {
            parameter.departmentid = parameter.departmentid.Equals("Choose Random", StringComparison.OrdinalIgnoreCase) ? GetRandomDepartmentId(ref parameter).Departmentid : parameter.departmentid;

            var empjob = new
            {
                __metadata = new Metadata()
                {
                    Uri = $@"EmpJob"
                },
                parameter.userId,
                startDate = ToJsonDate(parameter.startDate),
                eventReason = "AAS",
                department = parameter.departmentid,
            };
            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(empjob, Converter.Settings));
            if (parameter.api_c_status.Contains(Constants.ACPass, StringComparison.InvariantCultureIgnoreCase))
            {
                Util.Updatelog($"Change department for user id {parameter.userId}", "Change success!", State.APIPass);
            }
            else
            {
                Util.Updatelog($"Change department for user id {parameter.userId}", "Change failed!", State.Fail);
            }
            RunTimeData<DepartmentParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.DEPARTMENT_CHANGE);
        }

        private static DeptDataStore GetRandomDepartmentId(ref DepartmentParameter parameter)
        {
            var empjob = $"EmpJob?$format=json&$filter=userId eq '{parameter.userId}'&$select=userId,businessUnit,customString21,company,division,customString3,department&asofDate={parameter.startDate:yyyy-MM-dd}";
            var response = SFApi.Get(empjob).results[0];

            var empjobinfo = new
            {
                response.userId,
                speciality = response.division,
                managementregionid = response.businessUnit,
                managementcountryid = response.customString21,
                legalentityid = response.company,
                subservicelineid = response.customString3,
                currentdepartmentid = response.department
            };

            parameter.departmentid = empjobinfo.currentdepartmentid;
            string speciality = empjobinfo.speciality.Value;

            var deptlist = $"FODepartment?$format=json&$filter=cust_managerialcountry eq '{empjobinfo.managementcountryid}' and cust_tomanagementregion/externalCode eq '{empjobinfo.managementregionid}' and cust_toeylegalentity/externalCode eq '{empjobinfo.legalentityid}' and startswith(cust_speciality,'{speciality.Substring(0, 3)}') and cust_toSSL/externalCode eq '{empjobinfo.subservicelineid}' and externalCode ne '{empjobinfo.currentdepartmentid}' &$expand=cust_tomanagementregion,cust_toeylegalentity,cust_toSSL&$select=cust_toeylegalentity/externalCode,cust_toeylegalentity/description_defaultValue,externalCode,description_defaultValue,cust_managerialcountry ,startDate,cust_tomanagementregion/externalCode,cust_tomanagementregion/description_defaultValue,cust_speciality,cust_tomanagementregion/externalCode,cust_tomanagementregionProp,cust_toeylegalentityProp,status,cust_toSSL/externalCode,cust_toSSL/cust_description_defaultValue";

            List<DeptDataStore> deptid = new List<DeptDataStore>();
            dynamic departmentlist = SFApi.Get(deptlist);

            if (departmentlist != null)
            {
                foreach (dynamic dp in departmentlist.results)
                {
                    deptid.Add(new DeptDataStore()
                    {
                        Departmentid = dp.externalCode,
                        DepartmentDescription = dp.description_defaultValue,
                        LegalEntityId = dp.cust_toeylegalentityProp,
                        LegalEntityDescription = dp.cust_toeylegalentity.description_defaultValue,
                        ManagementRegionId = dp.cust_tomanagementregionProp,
                        ManagementRegionDescription = dp.cust_tomanagementregion.description_defaultValue,
                        ManagerialCountry = dp.cust_managerialcountry,
                        Speciality = dp.cust_speciality,
                        Startdate = dp.startDate,
                        Status = dp.status,
                        SubServiceLine = dp.cust_toSSL.externalCode,
                        SubServiceLineDescription = dp.cust_toSSL.cust_description_defaultValue
                    });
                }

                if (deptid.Count == 0)
                {
                    throw new Exception("No Matching Dept found for the input user retry or check data");
                }

                Console.WriteLine($"Total dept applicable for this user is {deptid.Count}");
                Console.WriteLine($"Choosing a random entry ... ");

                DeptDataStore selectedDeptid = deptid[new Random().Next(deptid.Count)];
                Console.WriteLine($"Applying the following department id '{selectedDeptid.Departmentid}' to the user ");
                return selectedDeptid;
            }
            else
            {
                throw new Exception("No Entries Retrived for this user from the API Call , need manual review ");
            }
        }

        public static void ValidateDataChange(DepartmentParameter parameter)
        {
            var empjob = $"EmpJob?$format=json&$filter=userId eq '{parameter.userId}'&$select=userId,startDate,eventReason,businessUnit,customString21,company,division,customString3,department&asofDate={parameter.startDate:yyyy-MM-dd}";
            var response = SFApi.Get(empjob).results[0];

            var empjobinfo = new
            {
                userId = response.userId.Value,
                startDate = response.startDate.Value,
                eventReason = response.eventReason.Value,
                speciality = response.division.Value,
                managementregionid = response.businessUnit.Value,
                managementcountryid = response.customString21.Value,
                legalentityid = response.company.Value,
                subservicelineid = response.customString3.Value,
                currentdepartmentid = response.department.Value
            };

            var dptid = parameter.departmentid;
            var effdt = parameter.startDate;
            parameter.departmentid = empjobinfo.currentdepartmentid;
            try
            {
                TestLog.Info($"Dept ID: {empjobinfo.currentdepartmentid}, Start Date : {empjobinfo.startDate}, EventReason {empjobinfo.eventReason}");
                TestLog.Info($"Dept ID: {dptid}, Start Date : {effdt}, EventReason AAS");
                Assert.That(dptid.Equals(empjobinfo.currentdepartmentid), "Department is not changed");
                Assert.That(effdt.Equals(empjobinfo.startDate), "Effective Date mismatch");
                Assert.That("AAS".Equals(empjobinfo.eventReason), "Event reason not matching");
                parameter.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate department change", "Data changed", State.APIPass);
            }
            catch (Exception)
            {
                parameter.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate department change", "Data not changed", State.Fail);
            }
            RunTimeData<DepartmentParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.DEPARTMENT_CHANGE);
        }
    }
}