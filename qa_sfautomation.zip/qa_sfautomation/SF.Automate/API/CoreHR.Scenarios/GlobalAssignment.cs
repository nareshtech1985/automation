﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;

    public class GlobalAssignment : SFComponent
    {
        public static List<GlobalAssignmentParameter> parameters;

        /**
         * Send Employement to Global assignment
         */
        public static void SendEmployeeOnGlobalAssignment(GlobalAssignmentParameter parameter)
        {
            #region Create AGA Record
            /** Create away on global assignment record for the home record **/
            var aga_record = new
            {
                __metadata = new Metadata()
                {
                    Uri = "EmpJob"
                },
                parameter.userId,
                startDate = ToJsonDate(parameter.startDate),
                eventReason = "AGA"
            };

            var aga_result = SFApi.Upsert(JsonConvert.SerializeObject(aga_record, Converter.Settings));
            GetCurrentJobInfo(new DataChangeParameter() { userId = parameter.userId, personIdExternal = parameter.personIdExternal, startDate = parameter.startDate });
            GlobalAssignmentParameter globalAssignment = new GlobalAssignmentParameter()
            {
                userId = InitialValues.userId,
                personIdExternal = InitialValues.personIdExternal,
                startDate = InitialValues.startDate,
                eventReason = InitialValues.eventReason,
                api_c_status = aga_result
            };
            RunTimeData<GlobalAssignmentParameter>.MergeListAndSave(ref parameters, globalAssignment, CoreHRScenario.EMP_GLOBAL_ASSIGNMENT);

            #endregion

            #region Employment Info Update
            parameter.newuserid = GetNextUserId();
            /** Create global assignment employment info **/
            var ga_record = new
            {
                __metadata = new Metadata()
                {
                    Uri = "EmpGlobalAssignment"
                },
                customString101 = "49683", //To be changed to random selection
                assignmentType = "49654", //To be changed to random selection
                plannedEndDate = ToJsonDate(parameter.endDate),
                startDate = ToJsonDate(parameter.startDate),
                customString102 = "000000000", //To be changed to random selection
                parameter.personIdExternal,
                userId = parameter.newuserid
            };

            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(ga_record, Converter.Settings));
            if (parameter.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create Global assignment employmentinfo", $"Global assignment employmentinfo is created with user id : {parameter.newuserid}", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create Global assignment employmentinfo", $"Global assignment employmentinfo is created with user id : {parameter.newuserid}", State.Fail);
            }

            RunTimeData<GlobalAssignmentParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.EMP_GLOBAL_ASSIGNMENT);
            #endregion

            #region Job Info Update
            /** Create the job info record for the global assignments **/
            var param = (parameter.hostLocation.ToLower().Equals("us")) ? GetUSParams(parameter) : GetNonUSParams(parameter);

            var job_record = new
            {
                __metadata = new Metadata()
                {
                    Uri = "EmpJob"
                },
                param.userId,
                startDate = ToJsonDate(param.startDate),
                param.employeeClass,
                param.holidayCalendarCode,
                param.businessUnit,
                param.workscheduleCode,
                param.employmentType,
                param.customString5,
                param.jobCode,
                param.customString4,
                param.customString3,
                param.customString11,
                param.customString2,
                param.eventReason,
                param.division,
                param.timeTypeProfileCode,
                param.company,
                param.location,
                param.isFulltimeEmployee,
                param.managerId,
                param.fte,
                param.customDouble20,
                param.standardHours,
                param.department,
                customString16 = "1",
                customString66 = param.hostLocation.Equals("CAN") ? "30790" : null
            };

            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(job_record, Converter.Settings));

            if (parameter.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create Global assignment jobinfo", $"Global assignment jobinfo is created with user id : {parameter.newuserid}", State.APIPass);
                IDTAction.ReconcileRecord(parameter.personIdExternal, param.userId, param.startDate);
                var idt = IDTAction.SearchGUI(parameter.personIdExternal, param.userId, parameter.startDate);
                parameter.GPN = idt.GPN_CODE;
                parameter.LPN = idt.LPN_CODE;
            }
            else
            {
                Util.Updatelog("Create Global assignment jobinfo", $"Global assignment jobinfo is created with user id : {parameter.newuserid}", State.Fail);
            }
            RunTimeData<GlobalAssignmentParameter>.MergeListAndSave(ref parameters, param, CoreHRScenario.EMP_GLOBAL_ASSIGNMENT);
            #endregion
        }

        private static GlobalAssignmentParameter GetNonUSParams(GlobalAssignmentParameter parameter)
        {
            List<string> applicablecountries = SendToGACountries.FindAll(x => !x.Equals(InitialValues.country) && !x.Equals("USA"));
            string country = applicablecountries[new Random().Next(applicablecountries.Count)];
            if (!parameter.hostLocation.Equals("non us", StringComparison.InvariantCultureIgnoreCase))
            {
                country = parameter.hostLocation;
            }
            var dataparam = new DataChangeParameter()
            {
                userId = parameter.userId,
                startDate = parameter.startDate,
                managementcountryid = "x",
                country = country
            };

            GetCurrentJobInfo(dataparam);
            DeptDataStore dept = GetMCFor(dataparam);
            Locationvariables location = GetGALocation(dept.LegalEntityId);
            RankParameter rankParameter = GetNewRank(country, InitialValues.customString11);

            return new GlobalAssignmentParameter()
            {
                userId = parameter.newuserid,
                startDate = parameter.startDate,
                employeeClass = "32732",// Employee
                holidayCalendarCode = "HOLIDAYCAL", // For non us records the calendar to set as global
                businessUnit = dept.ManagementRegionId,
                workscheduleCode = "NORM",
                employmentType = "61581",
                customString5 = location.geographicareaid,
                jobCode = rankParameter.jobcode,
                customString4 = location.geographicregionid,
                customString3 = dept.SubServiceLine,
                customString11 = rankParameter.rankId,//RANK
                customString2 = dept.ServiceLine,
                eventReason = "ABD",
                division = dept.Speciality,
                timeTypeProfileCode = $"{country}_TIME_PROFILE",
                company = dept.LegalEntityId,
                location = location.externalCode,
                department = dept.Departmentid,
                hostLocation = country
            };
        }

        private static GlobalAssignmentParameter GetUSParams(GlobalAssignmentParameter parameter)
        {
            /*var applicablecountries = SendToGACountries.FindAll(x => !x.Equals(InitialValues.country));*/
            /*
            var country = "USA";
            var dataparam = new DataChangeParameter()
            {
                userId = parameter.userId,
                startDate = parameter.startDate,
                managementcountryid = "x",
                country = country
            };

            GetCurrentJobInfo(dataparam);
            DeptDataStore dept = GetMCFor(dataparam);
            Locationvariables location = GetGALocation(dept.LegalEntityId);
            RankParameter rankParameter = GetNewRank(country, "42");
            */
            return new GlobalAssignmentParameter()
            {
                userId = parameter.newuserid,
                startDate = parameter.startDate,
                employeeClass = "32732",
                holidayCalendarCode = "USA_Holiday_Calendar",
                businessUnit = "0060",
                workscheduleCode = "NORM",
                employmentType = "61581",
                customString5 = "0001",
                jobCode = "USA00-979214",
                customString4 = "0019",
                customString3 = "0201",
                customString11 = "04",
                customString2 = "02",
                eventReason = "ABD",
                division = "CBS010",
                timeTypeProfileCode = "USA_TIME_PROFILE",
                company = "000686",
                location = "US008",
                department = "USA00-100003",
                hostLocation = "USA"
            };
        }


        public static void ValidateGlobalAssignment(ref GlobalAssignmentParameter parameter)
        {
            parameter.api_v_status = Constants.AVPass;//to be reviewed
            var url = $"EmpJob?$filter=userId eq '{parameter.userId}'&$format=json&$format=json&asOfDate={parameter.startDate:yyyy-MM-dd}";
            try
            {
                var response = SFApi.Get(url).results[0];

                //Assert.AreEqual(data.startDate.AddDays(1), x.startDate, "End date is not as per the data provided");
                Assert.AreEqual("49548", response.emplStatus.Value, "Employee Status not changed to terminated");
                Assert.AreEqual("ABD", response.eventReason.Value, "Event id is not matching or not the expected");
                //Assert.AreEqual(eventreason, x.eventReason, "Event Reason is not as per the input data");
                parameter.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the test data for Termination", "Data validation sucess!", State.APIPass);
            }
            catch
            {
                Util.Updatelog("Validate the test data for Termination", "Data validation failed!", State.Fail);
            }
        }

        public static void EndAssignment(GlobalAssignmentParameter parameter)
        {
            #region EGA & BGA Record Creation
            parameter.eventReason = "TAO";
            var terminate = new
            {
                __metadata = new Metadata()
                {
                    Uri = $@"EmpEmploymentTermination"
                },
                parameter.eventReason,
                parameter.personIdExternal,
                endDate = ToJsonDate(parameter.endDate),
                parameter.userId,
                payrollEndDate = ToJsonDate(parameter.endDate),
                lastDateWorked = ToJsonDate(parameter.endDate),
                bonusPayExpirationDate = ToJsonDate(parameter.endDate),
                benefitsEndDate = ToJsonDate(parameter.endDate),
                salaryEndDate = ToJsonDate(parameter.endDate) //to make effective on the given end date
            };
            parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(terminate, Converter.Settings));
            if (parameter.api_c_status.ToLower().Contains("fail"))
            {
                Util.Updatelog($"Executer return from GA for {parameter.ParameterShort}", "test data creation failed", State.Fail);
            }
            else
            {
                Util.Updatelog($"Executer return from GA for {parameter.ParameterShort}", "test data created", State.Pass);
            }

            RunTimeData<GlobalAssignmentParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.RETURN_FROM_GLOBAL_ASSIGNMENT);

            #endregion
        }

        public static void ValidateEndofGlobalAssignment(GlobalAssignmentParameter parameter)
        {
            var url = $"EmpJob?$filter=userId eq '{parameter.userId}'&$format=json&$format=json&asOfDate={parameter.endDate.AddDays(1):yyyy-MM-dd}";
            var response = SFApi.Get(url).results[0];
            try
            {
                //Assert.AreEqual(parameter.startDate, response.startDate.Value, "Start date is not as per the data provided");
                Assert.AreEqual("49548", response.emplStatus.Value, "Employee Status not changed to terminated");
                Assert.AreEqual("TAO", response.eventReason.Value, "Event id is not matching or not the expected");
                //Assert.AreEqual(eventreason, x.eventReason, "Event Reason is not as per the input data");
                parameter.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the test data created", "Data validation sucess!", State.APIPass);
            }
            catch
            {
                Util.Updatelog("Validate the test data created", "Data validation failed!", State.Fail);
            }
        }
    }
}

/*
 *
public static object ToUSABody(GlobalAssignmentParameter parameter)
{
    return new
    {
        __metadata = new Metadata()
        {
            Uri = "EmpJob"
        },
        userId = parameter.newuserid,
        startDate = ToJsonDate(parameter.startDate),
        employeeClass = "32732",
        holidayCalendarCode = "USA_Holiday_Calendar",
        businessUnit = "0003",
        workscheduleCode = "NORM",
        employmentType = "61581",
        customString5 = "0001",
        jobCode = "USA00-979205",
        customString4 = "0019",
        customString3 = "0908",
        customString11 = "05",
        customString2 = "09",
        eventReason = "ABD",
        division = "CBS010",
        timeTypeProfileCode = "USA_TIME_PROFILE",
        company = "000686",
        location = "US008"
    };
}

public static object ToNonUSABody(GlobalAssignmentParameter parameter)
{
    var dataparam = new DataChangeParameter()
    {
        userId = parameter.userId,
        startDate = parameter.startDate,
    };

    GetCurrentJobInfo(dataparam);
    var applicablecountries = SendToGACountries.FindAll(x => !x.Equals(InitialValues.country));
    var country = applicablecountries[new Random().Next(applicablecountries.Count)];
    DeptDataStore dept = GetMCFor(new DataChangeParameter()
    {
        managementcountryid = "x",
        country = country
    });

    Locationvariables location = GetGALocation(dept.LegalEntityId);
    RankParameter rankParameter = GetNewRank(country, "42");// to be removed!

    return new
    {
        __metadata = new Metadata()
        {
            Uri = "EmpJob"
        },
        userId = parameter.newuserid,
        startDate = ToJsonDate(parameter.startDate),
        employeeClass = "32732",// Employee
        holidayCalendarCode = "HOLIDAYCAL", // For non us records the calendar to set as global
        businessUnit = dept.ManagementRegionId,
        workscheduleCode = "NORM",
        employmentType = "61581",
        customString5 = location.geographicareaid,
        jobCode = rankParameter.jobcode,
        customString4 = location.geographicregionid,
        customString3 = dept.SubServiceLine,
        customString11 = rankParameter.rankId,//RANK
        customString2 = dept.ServiceLine,
        eventReason = "ABD",
        division = dept.Speciality,
        timeTypeProfileCode = $"{country}_TIME_PROFILE",
        company = dept.LegalEntityId,
        location = location.externalCode
    };
}
*
*/