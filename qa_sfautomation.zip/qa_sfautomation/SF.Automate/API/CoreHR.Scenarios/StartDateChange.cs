﻿namespace Test.API.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;

    public class StartDateChange : SFComponent
    {
        public static List<StartDateParameter> parameters;

        public static void PerformStartDateChange(StartDateParameter parameter)
        {
            try
            {

                // Get the entry details as per the data input
                var getquery = $"EmpJob?$format=json&$select=userId,startDate,fte,customString2,customString3,customString4,customString5,customString11,customString12,customString16,customString18,customString33,jobCode,division,location,businessUnit,employeeClass,employmentType,regularTemp,holidayCalendarCode,timeTypeProfileCode,workscheduleCode,company,eventReason,customDouble20,payGrade,seqNumber,managerId,customString14,customString15,&$filter=userId eq '{parameter.userId}' and startDate eq '{parameter.startDate:yyyy-MM-dd}' &fromDate=2020-11-16&$orderby=startDate desc,seqNumber desc";
                dynamic getResponse = SFApi.Get(getquery).results[0];

                var postpurgeBody = new
                {
                    __metadata = new Metadata()
                    {
                        Uri = $"https://api12preview.sapsf.eu/odata/v2/EmpJob(seqNumber={getResponse.seqNumber.Value}L,startDate=datetime'{getResponse.startDate.Value:yyyy-MM-dd}T00:00:00',userId='{getResponse.userId}')",
                        Type = "SFOData.EmpJob"
                    },
                    operation = "DELETE",
                    eventReason = getResponse.eventReason.Value
                };

                var postchangeBody = new
                {
                    __metadata = new Metadata()
                    {
                        Uri = $"EmpJob"
                    },
                    userId = getResponse.userId.Value,
                    startDate = ToJsonDate(parameter.newstartdate),//Change of date record here
                    businessUnit = getResponse.businessUnit.Value,
                    workscheduleCode = getResponse.workscheduleCode.Value,
                    regularTemp = getResponse.regularTemp.Value,
                    jobCode = getResponse.jobCode.Value,
                    division = getResponse.division.Value,
                    timeTypeProfileCode = getResponse.timeTypeProfileCode.Value,
                    customDouble20 = getResponse.customDouble20.Value,
                    fte = getResponse.fte.Value,
                    payGrade = getResponse.payGrade.Value,
                    company = getResponse.company.Value,
                    employeeClass = getResponse.employeeClass.Value,
                    customString18 = getResponse.customString18.Value,
                    holidayCalendarCode = getResponse.holidayCalendarCode.Value,
                    employmentType = getResponse.employmentType.Value,
                    customString5 = getResponse.customString5.Value,
                    customString4 = getResponse.customString4.Value,
                    customString3 = getResponse.customString3.Value,
                    customString11 = getResponse.customString11.Value,
                    customString33 = getResponse.customString33.Value,
                    customString2 = getResponse.customString2.Value,
                    customString12 = getResponse.customString12.Value,
                    managerId = getResponse.managerId.Value,
                    eventReason = getResponse.eventReason.Value,
                    customString16 = getResponse.customString16.Value,
                    location = getResponse.location.Value
                };

                parameter.eventReason = getResponse.eventReason.Value;
                parameter.lpn = getResponse.customString15.Value;
                parameter.gpn = getResponse.customString14.Value;

                //Calling the Post Methods..
                var pbody = $@"[{JsonConvert.SerializeObject(postpurgeBody, Formatting.Indented)} , {JsonConvert.SerializeObject(postchangeBody, Formatting.Indented)} ]";

                parameter.api_c_status = SFApi.UpsertPurge(pbody);

                if (parameter.api_c_status.ToLower().Contains("success"))
                {
                    Util.Updatelog($"Post the Start Data Change Request for User : {parameter.userId} Eff Dt : {parameter.newstartdate:yyyy-MM-dd}", "Request Success", State.APIPass);
                }
                else
                {
                    Util.Updatelog($"Post the Start Data Change Request for User : {parameter.userId} Eff Dt : {parameter.newstartdate:yyyy-MM-dd}", "Request failed", State.Fail);
                }

            }
            catch (Exception e)
            {
                Util.Updatelog($"Post the Start Data Change Request for User : {parameter.userId} Eff Dt : {parameter.newstartdate:yyyy-MM-dd}", $"Request failed {e.Message}", State.Fail);
                TestLog.Error($"Error on data creation : {e.Message}");
            }
            RunTimeData<StartDateParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.START_DATE_CHANGE);
        }

        public static void ValidateDataChange(StartDateParameter parameter)
        {
            // Get the entry details as per the data input
            var getquery = $"EmpJob?$format=json&$select=userId,startDate,fte,customString2,customString3,customString4,customString5,customString11,customString12,customString16,customString18,customString33,jobCode,division,location,businessUnit,employeeClass,employmentType,regularTemp,holidayCalendarCode,timeTypeProfileCode,workscheduleCode,company,eventReason,customDouble20,payGrade,seqNumber,managerId&$filter=userId eq '{parameter.userId}' and startDate eq '{parameter.newstartdate:yyyy-MM-dd}' &fromDate=2020-11-16&$orderby=startDate desc,seqNumber desc";
            try
            {
                dynamic getResponse = SFApi.Get(getquery).results[0];
                if (getResponse != null)
                {
                    Assert.AreEqual(parameter.userId, getResponse.userId.Value, "User Id not matching");
                    Assert.AreEqual(parameter.newstartdate, getResponse.startDate.Value, "New Start date is not matching");
                    parameter.api_v_status = Constants.AVPass;
                    Util.Updatelog("Check the values are created/updated as per input data", "Data is valid", State.APIPass);
                }
                else
                {
                    Util.Updatelog($"Expected Values : {parameter.userId} | {parameter.newstartdate:yyyy-MM-dd}", $"No Result", State.APIFail);
                }
            }
            catch
            {
                Util.Updatelog($"Expected Values : {parameter.userId} | {parameter.newstartdate:yyyy-MM-dd}", $"Values are different", State.APIFail);
                parameter.api_v_status = Constants.AVFail;
            }
            RunTimeData<StartDateParameter>.MergeListAndSave(ref parameters, parameter, CoreHRScenario.START_DATE_CHANGE);
        }
    }
}
