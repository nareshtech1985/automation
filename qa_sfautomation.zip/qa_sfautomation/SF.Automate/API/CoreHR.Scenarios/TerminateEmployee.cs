﻿namespace SF.API.CoreHR.Scenarios
{
    using EY_Test.Lib.DataHelpers;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;

    public class TerminateEmployee : SFComponent
    {
        public static List<TerminateParameter> parameters;

        /// <summary>
        /// This will terminate the employee
        /// </summary>
        /// <param name="parameter"></param>
        public static void PerformTermination(TerminateParameter parameter, CoreHRScenario scenario)
        {
            try
            {
                parameter.eventReason = GetEventReason(parameter);
                var terminate = new
                {
                    __metadata = new Entity.Metadata()
                    {
                        Uri = $@"EmpEmploymentTermination"
                    },
                    parameter.eventReason,
                    parameter.personIdExternal,
                    endDate = ToJsonDate(parameter.startDate),
                    parameter.userId,
                    payrollEndDate = ToJsonDate(parameter.startDate),
                    lastDateWorked = ToJsonDate(parameter.startDate),
                    bonusPayExpirationDate = ToJsonDate(parameter.startDate),
                    benefitsEndDate = ToJsonDate(parameter.startDate),
                    salaryEndDate = ToJsonDate(parameter.startDate) //to make effective on the given end date
                };
                parameter.TerminationDate = parameter.startDate;
                parameter.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(terminate, Converter.Settings));
                if (parameter.api_c_status.ToLower().Contains(Constants.ACFail, StringComparison.InvariantCultureIgnoreCase))
                {
                    Util.Updatelog($"Create test data for user {parameter.ParameterShort}", "test data creation failed", State.Fail);
                }
                else
                {
                    Util.Updatelog($"Create test data for user {parameter.ParameterShort}", "test data created", State.Pass);
                }
            }
            catch (Exception e)
            {
                Util.Updatelog($"Create test data for user {parameter.ParameterShort}", $"test data creation failed {e.Message}", State.Fail);
            }
            RunTimeData<TerminateParameter>.MergeListAndSave(ref parameters, parameter, scenario);
        }

        public static void ValidateDataChange(TerminateParameter parameter, CoreHRScenario scenario)
        {
            string empJob = $@"EmpJob?$filter=userId eq '{parameter.userId}'&$select=startDate,eventReason,emplStatus,userId&$format=json&toDate={parameter.startDate.AddDays(365):yyyy-MM-dd}&$orderby=startDate desc&$top=1";
            try
            {
                var response = SFApi.Get(empJob).results[0];
                var x = new TerminateParameter()
                {
                    userId = response.userId.Value,
                    startDate = response.startDate.Value,
                    emplStatus = response.emplStatus.Value,
                    eventReason = response.eventReason.Value
                };

                //Assert.AreEqual(parameter.startDate.AddDays(1), x.startDate, "End date is not as per the data provided"); // to be reviewed
                Assert.AreEqual("49548", x.emplStatus.ToString(), "Employee Status not changed to terminated");
                var eventreason = GetEventReason(parameter);
                Assert.AreEqual(eventreason, x.eventReason, "Event Reason is not as per the input data");
                parameter.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the test data for Termination", "Data validation sucess!", State.APIPass);
            }
            catch (Exception)
            {
                parameter.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the test data for Termination", $"Data validation failed!", State.Fail);
            }
            RunTimeData<TerminateParameter>.MergeListAndSave(ref parameters, parameter, scenario);
        }


        public static string GetEventReason(TerminateParameter parameter)
        {
            var str = $"FOEventReason?$format=json&$filter=name eq '{parameter.eventReason}' and  eventNav/externalCode eq '26'&$expand=eventNav&$select=externalCode";
            string eventreason = "TAM";
            try
            {
                eventreason = SFApi.Get(str).results[0].externalCode;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine($"Event reason selected per data {parameter.eventReason} is '{eventreason}' ");
            return eventreason;
        }
    }
}