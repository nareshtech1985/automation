﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    using System;
    using System.Reflection;

    public class NameFormat
    {
        public static void Create(NameFormatFO fo_object)
        {
            var _elements = fo_object._Elements.Split('$');

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(fo_object, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for name format", "name format created", State.APIPass);
                #region Creating name elements
                foreach (var item in _elements)
                {
                    var _nelem = new NameElementGO() { metadata = new Metadata() { Uri = "NameElementGO" }, externalCode = item, NameFormatGO_externalCode = fo_object.externalCode };
                    var res = SFApi.Upsert(JsonConvert.SerializeObject(_nelem, Converter.Settings));
                    if (res.Contains("success", StringComparison.InvariantCultureIgnoreCase))
                    {
                        TestLog.Info($"Name element created successfully for the Nameformat {fo_object.externalCode}");
                    }
                    else
                    {
                        TestLog.Info($"Unable to create name element for the Nameformat {fo_object.externalCode}");
                    }
                }
                #endregion
            }
            else
            {
                Util.Updatelog("Create test data for name format", "name format not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {
            TestLog.Info($"Scripting to be done!");
        }

        public static void Validate(NameFormatFO fo_object)
        {
            //Verifying the name format
            var query = $"NameFormatGO?$filter=externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for NameFormatGO", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for NameFormatGO", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }

            //Verifying the name elements 
            query = $"NameElementGO?$filter=NameFormatGO_externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results;
                string actualValue = "";
                foreach (dynamic res in response)
                {
                    actualValue = $"{actualValue}{res.externalCode.Value}$";
                }
                Assert.AreEqual(fo_object._Elements, actualValue.Substring(0, actualValue.Length - 1), "Name elements are not matching");
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for NameFormatGO", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for NameFormatGO", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
        }
    }
}

