﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    using System;
    using System.Reflection;

    internal class CurrencyExchangeRate
    {
        public static void Create(CurrencyExchangeRateFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "CurrencyExchangeRate"
                },
                fo_object.effectiveStartDate,
                fo_object.effectiveStatus,
                fo_object.exchangeRate,
                fo_object.externalCode,
                fo_object.currencyExchangeRateType,
                fo_object.externalName_defaultValue,
                fo_object.sourceCurrency,
                fo_object.targetCurrency
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for currency exchange rate", "data for currency exchange rate created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for currency exchange rate", "data for currency exchange rate not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public static void Validate(CurrencyExchangeRateFO fo_object)
        {
            var query = $"CurrencyExchangeRate?$filter=externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                /* remaining fields to be added during the script debugging */
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for currency exchange rate ", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for currency exchange rate ", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
        }
    }
}
