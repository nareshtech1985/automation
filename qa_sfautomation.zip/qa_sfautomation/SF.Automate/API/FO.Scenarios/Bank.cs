﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    using System;
    using System.IO;
    using System.Text;

    public class Bank
    {
        public static void Create(BankFO fo_object)
        {
            var bankquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "Bank"
                },
                fo_object.externalCode,
                fo_object.bankBranch,
                fo_object.city,
                fo_object.street,
                fo_object.postalCode,
                fo_object.businessIdentifierCode,
                fo_object.bankName,
                fo_object.bankCountry,
                fo_object.effectiveStatus,
                fo_object.cust_BankID
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(bankquery, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for bank", "Bank created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for bank", "Bank not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {
            try
            {
                var filename = $@"{Util.ResultPath}\file_Bank_{DateTime.Now:yyyyMMddThhmmss}.txt";
                var bankfilestream = new FileStream(filename, FileMode.OpenOrCreate);
                using (StreamWriter bankfile = new StreamWriter(bankfilestream, Encoding.UTF8))
                {
                    bool nextflag = false;

                    var header = "External Code|Bank Country|Bank Name|Bank ID|Bank Branch ID|Routing Number|SWIFT/Bank Identifier Code|Postal Code|City|Street|Status";
                    bankfile.WriteLine(header);

                    try
                    {
                        var query = "Bank?paging=snapshot&$format=json";
                        var response = SFApi.Get(query);
                        do
                        {
                            if (response.Value == "\"results\": []")
                            {
                                break;
                            }
                            nextflag = false;
                            foreach (dynamic rowitem in response.results)
                            {
                                string lineitem = $@"{rowitem.externalCode.Value}|{rowitem.bankCountry.Value}|{rowitem.bankName.Value}|{rowitem.cust_BankID.Value}|{rowitem.bankBranch.Value}|{rowitem.routingNumber.Value}|{rowitem.businessIdentifierCode.Value}|{rowitem.postalCode.Value}|{rowitem.city.Value}|{rowitem.street.Value}|{rowitem.effectiveStatus.Value}";
                                bankfile.WriteLine(lineitem);
                            }
                            if (response.__next.Value != null)
                            {
                                nextflag = true;
                                response = SFApi.GetForImport(response.__next.Value);
                            }
                        } while (nextflag);
                    }
                    catch (Exception e2)
                    {
                        TestLog.Error(e2.Message);
                    }
                }
            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
            }
        }

        public static void Validate(BankFO fo_object)
        {
            var query = $"Bank?paging=snapshot&$format=json&$filter=externalCode eq '{fo_object.externalCode}'";
            try
            {
                dynamic response = SFApi.Get(query).results[0];

                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "Code not matching");
                Assert.AreEqual(fo_object.bankBranch, response.bankBranch.Value, "Branch not matching");
                Assert.AreEqual(fo_object.city, response.city.Value, "City not matching");
                Assert.AreEqual(fo_object.street, response.street.Value, "Street not matching");
                Assert.AreEqual(fo_object.postalCode, response.postalCode.Value, "Postal Code not matching");
                Assert.AreEqual(fo_object.businessIdentifierCode, response.businessIdentifierCode.Value, "Business Identified not matching");
                Assert.AreEqual(fo_object.bankName, response.bankName.Value, "Bank Name not matching");
                Assert.AreEqual(fo_object.bankCountry, response.bankCountry.Value, "Bank Country not matching");
                Assert.AreEqual(fo_object.effectiveStatus, response.effectiveStatus.Value, "Effectiv Status not matching");

                fo_object.api_v_status = Constants.AVPass; Util.Updatelog("Check the values are as input data", "Data is matching", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail; Util.Updatelog("Check the values are as input data", "Data is NOT matching", State.APIFail);
                TestLog.Error($"No Result found! {e.Message} ");
            }
        }
    }
}