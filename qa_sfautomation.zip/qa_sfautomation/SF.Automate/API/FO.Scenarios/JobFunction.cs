﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    using System;
    using System.Reflection;

    internal class JobFunction
    {
        public static void Create(JobFunctionFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "FOJobFunction"
                },
                fo_object.externalCode,
                fo_object.startDate,
                fo_object.status,
                fo_object.description_defaultValue,
                fo_object.description_en_US,
                fo_object.name_defaultValue,
                fo_object.name_en_US,
                fo_object.cust_CareerLevelProp,
                fo_object.cust_JobRoleTypeProp
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for job function", "data for job function created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for job function", "data for job function not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {
            TestLog.Info($"Scripting to be done!");
        }

        public static void Validate(JobFunctionFO fo_object)
        {
            var query = $"FOJobFunction?$filter=externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                /* remaining fields to be added during the script debugging */
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for Job Function", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for Job Function", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
        }
    }
}
