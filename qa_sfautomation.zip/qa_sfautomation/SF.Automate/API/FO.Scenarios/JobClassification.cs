﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.FO;
    using SF.FOEntities;
    using System;
    using System.Reflection;

    public class JobClassification : SFComponent
    {
        public static void Create(JobClassificationFO fo_object)
        {
            fo_object.regularTemporary = GetPicklistByLabel(PicklistId.regular__temp, fo_object.regularTemporary).externalCode;

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(fo_object, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for job family", "data for job family created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for job family", "data for job family not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {

        }

        public static void Validate(JobClassificationFO fo_object)
        {
            var query = $"FOJobCode?$filter=externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                Assert.AreEqual(fo_object.description, response.description.Value, "description not matching");
                Assert.AreEqual(fo_object._startDate, response.startDate.Value, "start date not matching");
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for Job Family", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for Job Family", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
        }
    }
}

