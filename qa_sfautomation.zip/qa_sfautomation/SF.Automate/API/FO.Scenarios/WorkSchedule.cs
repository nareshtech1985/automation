﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.FOEntities;
    using System;
    using System.Reflection;

    public class WorkSchedule
    {
        public static void Create(WorkScheduleFO fo_object)
        {
            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(fo_object, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for name format", "name format created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for name format", "name format not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {

        }

        public static void Validate(WorkScheduleFO fo_object)
        {
            var query = $"WorkSchedule?$filter=externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                Assert.AreEqual(fo_object._startingDate, response.startingDate.Value, "starting date not matching");
                Assert.AreEqual(fo_object.externalName_defaultValue, response.externalName_defaultValue.Value, "name not matching");
                /* remaining fields to be added during the script debugging */
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for Rank", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for Rank", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }

            query = $"WorkScheduleDay?$filter=WorkSchedule_externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results;
                foreach (dynamic _day in response)
                {
                    Assert.AreEqual(fo_object.externalCode, _day.WorkSchedule_externalCode.Value, "external code not matching");
                    int d = Convert.ToInt32(_day.day.Value);
                    if (d <= Convert.ToInt32(fo_object.averageWorkingDaysPerWeek))
                    {
                        Assert.AreEqual($"{Convert.ToInt32(fo_object.averageHoursPerDay):00}:00", _day.hoursAndMinutes.Value, $"average hours per day not matching for day {d}");
                    }
                }
            }
            catch (Exception e)
            {
                TestLog.Error($"Work schedule days not matching! {e.Message}");
            }
        }
    }
}
