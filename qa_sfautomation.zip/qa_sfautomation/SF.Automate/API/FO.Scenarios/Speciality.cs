﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    using System;
    using System.Reflection;
    using System.Web;

    public class Speciality
    {
        public static void Create(SpecialityFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "FODivision"
                },
                fo_object.effectiveStartDate,
                fo_object.externalCode,

            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for name format", "name format created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for name format", "name format not created", State.APIFail);
            }
        }

        internal static string GetExternalCode(string _name)
        {
            var encodev = HttpUtility.UrlEncode(_name);
            var query = $"FODivision?$filter=name eq '{encodev}'&$format=json";
            return SFApi.Get(query).results[0].externalCode.Value;
        }

        public static void Generate_ZoneA_Extract()
        {

        }

        public static void Validate(SpecialityFO fo_object)
        {
            var query = $"FODivision?$filter=externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                /* remaining fields to be added during the script debugging */
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for Rank", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for Rank", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
        }
    }
}
