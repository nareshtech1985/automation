﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    using System;

    internal class BusinessUnit_Finance
    {
        public static void Create(BusinessUnit_FinanceFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "cust_business_unit_finance"
                },
                fo_object.description,
                fo_object.cust_Description_defaultValue,
                fo_object.cust_Description_en_US,
                fo_object.externalCode,
                fo_object.name,
                fo_object.externalName_defaultValue,
                fo_object.externalName_en_US,
                fo_object.effectiveStartDate,
                fo_object.mdfSystemStatus,
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for business unit", "data for business unit created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for business unit", "data for business unit not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public static void Validate(BusinessUnit_FinanceFO fo_object)
        {
            var query = $"cust_business_unit_finance?paging=snapshot&$format=json&$filter=externalCode eq '{fo_object.externalCode}'";
            try
            {
                dynamic response = SFApi.Get(query).results[0];

                Assert.AreEqual(fo_object.cust_Description_defaultValue, response.cust_Description_defaultValue.Value, "description_defaultValue is not matching");
                Assert.AreEqual(fo_object.cust_Description_en_US, response.cust_Description_en_US.Value, "description_en_US is not matching");
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode is not matching");
                Assert.AreEqual(fo_object.externalName_defaultValue, response.externalName_defaultValue.Value, "name_defaultValue is not matching");
                Assert.AreEqual(fo_object.externalName_en_US, response.externalName_en_US.Value, "name_en_US is not matching");
                Assert.AreEqual(fo_object._effectiveStartDate, response.effectiveStartDate.Value, "startDate is not matching");
                Assert.AreEqual(fo_object.mdfSystemStatus, response.mdfSystemStatus.Value, "status is not matching");

                fo_object.api_v_status = Constants.AVPass; Util.Updatelog("Check the values are as input data", "Data is matching", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail; Util.Updatelog("Check the values are as input data", "Data is NOT matching", State.APIFail);
                TestLog.Error($"No Result found! {e.Message} ");
            }
        }
    }
}
