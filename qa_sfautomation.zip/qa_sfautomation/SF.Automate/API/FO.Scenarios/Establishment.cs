﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    //Sap1213%
    using System;
    using System.Reflection;

    internal class Establishment
    {
        public static void Create(EstablishmentFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "cust_establishmentid"
                },
                fo_object.cust_description,
                fo_object.effectiveStartDate,
                fo_object.externalCode,
                fo_object.externalName,
                fo_object.mdfSystemStatus
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for establishment", "data for establishment created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for establishment", "data for establishment not created", State.APIFail);
            }
        }

        internal static string GetExternalCode(string _name)
        {
            if (_name != null)
            {
                var query = $"cust_establishmentid?$filter=externalName_defaultValue eq '{_name}'&$format=json";
                return SFApi.Get(query).results[0].externalCode.Value;
            }
            return null;

        }

        public static void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public static void Validate(EstablishmentFO fo_object)
        {
            var query = $"cust_establishmentid?$filter=externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                // to be added based on required demand
                /* remaining fields to be added during the script debugging */
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for establishment id ", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for establishment id ", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
        }
    }
}
