﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.FOEntities;
    using System;
    using System.Reflection;
    using LegalEntity = FOEntities.LegalEntity;

    public class Location : SFComponent
    {
        public static void Create(LocationFO fo_object)
        {
            fo_object.geozoneFlx = GeoZone.GetExternalCode(fo_object.geozoneFlx); //Geozone
            fo_object.customString7 = GeographicArea.GetExternalCode(fo_object.customString7); //Geographic Area
            fo_object.locationGroup = GeographicRegion.GetExternalCode(fo_object.locationGroup); //Geographic Region
            fo_object.companyFlx = LegalEntity.GetExternalCode(fo_object.companyFlx);
            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(fo_object, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for company", "company created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for company", "company not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {

        }

        public static void Validate(LocationFO fo_object)
        {
            var query = $"FOLocation?$filter=externalCode eq '{fo_object.externalCode}'&$format=json&$expand=addressNavDEFLT";
            dynamic locationResponse = SFApi.Get(query).results[0];
            #region Validating the Location Data
            try
            {

                Assert.AreEqual(fo_object.externalCode, locationResponse.externalCode.Value, "externalCode not matching");
                Assert.AreEqual(fo_object._startDate, locationResponse.startDate.Value, "start date not matching");
                Assert.AreEqual(fo_object.description, locationResponse.description.Value, "description not matching");
                Assert.AreEqual(fo_object.name, locationResponse.name.Value, "name not matching");
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for FOLocation", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for FOLocation ", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
            #endregion

            #region Validating the Corporate address data
            dynamic corpadd = locationResponse.addressNavDEFLT;
            try
            {

                //Assert.AreEqual(fo_object.addressCountry, corpadd.country.Value, "address country not matching");
                Assert.AreEqual(fo_object._startDate, corpadd.startDate.Value, "address country not matching");
                Assert.AreEqual(fo_object.addressAddress1, corpadd.address1.Value, "address line 1 not matching");
                Assert.AreEqual(fo_object.addressAddress2, corpadd.address2.Value, "address line 2 not matching");
                Assert.AreEqual(fo_object.addressZipCode, corpadd.zipCode.Value, "address line 2 not matching");
                Assert.AreEqual(fo_object.addressCity, corpadd.city.Value, "address city not matching");
                var picklistName = GetPicklistByOptionID($"{corpadd.state.Value}").label;
                Assert.AreEqual(fo_object.addressState, picklistName, "address state not matching");

                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for FOCorporateAddress", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for FOCorporateAddress", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
            #endregion
        }
    }
}
