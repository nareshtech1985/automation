﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    using System;
    using System.Web;

    internal class ManagementRegion
    {
        public static void Create(ManagementRegionFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "FOBusinessUnit"
                },
                fo_object.cust_managementarea,
                fo_object.description,
                fo_object.description_defaultValue,
                fo_object.description_en_US,
                fo_object.entityUUID,
                fo_object.externalCode,
                fo_object.name,
                fo_object.name_defaultValue,
                fo_object.name_en_US,
                fo_object.startDate,
                fo_object.status,
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for management region", "data for management region created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for management region", "data for management region not created", State.APIFail);
            }
        }

        internal static string GetExternalCode(string _name)
        {
            var encodev = HttpUtility.UrlEncode(_name);
            var query = $"FOBusinessUnit?$filter=name eq '{encodev}'&$format=json";
            return SFApi.Get(query).results[0].externalCode.Value;
        }

        public static void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public static void Validate(ManagementRegionFO fo_object)
        {
            var query = $"FOBusinessUnit?paging=snapshot&$format=json&$filter=externalCode eq '{fo_object.externalCode}'";
            try
            {
                dynamic response = SFApi.Get(query).results[0];

                Assert.AreEqual(fo_object.cust_managementarea, response.cust_managementarea.Value, "cust_managementarea is not matching");
                //Assert.AreEqual(fo_object.description, response.description.Value, "description is not matching");
                Assert.AreEqual(fo_object.description_defaultValue, response.description_defaultValue.Value, "description_defaultValue is not matching");
                //Assert.AreEqual(fo_object.description_en_US, response.description_en_US.Value, "description_en_US is not matching");
                //Assert.AreEqual(fo_object.entityUUID, response.entityUUID.Value, "entityUUID is not matching");
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode is not matching");
                //Assert.AreEqual(fo_object.name, response.name.Value, "name is not matching");
                Assert.AreEqual(fo_object.name_defaultValue, response.name_defaultValue.Value, "name_defaultValue is not matching");
                //Assert.AreEqual(fo_object.name_en_US, response.name_en_US.Value, "name_en_US is not matching");
                Assert.AreEqual(fo_object._startDate, response.startDate.Value, "startDate is not matching");
                Assert.AreEqual(fo_object.status, response.status.Value, "status is not matching");

                fo_object.api_v_status = Constants.AVPass; Util.Updatelog("Check the values are as input data", "Data is matching", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail; Util.Updatelog("Check the values are as input data", "Data is NOT matching", State.APIFail);
                TestLog.Error($"No Result found! {e.Message} ");
            }
        }
    }
}
