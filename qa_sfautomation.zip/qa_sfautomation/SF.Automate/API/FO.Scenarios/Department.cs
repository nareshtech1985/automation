﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.FOEntities;
    using System;
    using System.Reflection;
    using LegalEntity = FOEntities.LegalEntity;

    public class Department
    {
        public static void Create(DepartmentFO fo_object)
        {
            fo_object.costCenter = CostCenter.GetExternalCode(fo_object.costCenter);
            ///fo_object.cust_codeblock = CodeBlock.GetExternalCode(fo_object.cust_codeblock); //this isid hence no need to get extn cod.
            fo_object.cust_establishmentid = Establishment.GetExternalCode(fo_object.cust_establishmentid);
            fo_object.cust_managerialcountry = ManagementCountry.GetExternalCode(fo_object.cust_managerialcountry);
            fo_object.cust_speciality = Speciality.GetExternalCode(fo_object.cust_speciality);
            fo_object.cust_toSSLProp = SubServiceLine.GetExternalCode(fo_object.cust_toSSLProp);
            fo_object.cust_toeylegalentityProp = LegalEntity.GetExternalCode(fo_object.cust_toeylegalentityProp);
            fo_object.cust_tomanagementregionProp = ManagementRegion.GetExternalCode(fo_object.cust_tomanagementregionProp);

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(fo_object, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for department", "data for department created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for department", "data for department not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {

        }

        public static void Validate(DepartmentFO fo_object)
        {
            var query = $"FODepartment?$filter=externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                /* remaining fields to be added during the script debugging */
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for department ", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for department ", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
        }

    }
}

