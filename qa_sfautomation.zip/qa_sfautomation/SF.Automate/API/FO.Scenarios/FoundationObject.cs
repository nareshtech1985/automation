﻿namespace SF.Automate.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using Pom;
    using SF.APICore;
    using System;
    /// <summary>
    /// Generic template to create and validate the foundation objects.
    /// Methods and the details need to updated once finalized
    /// This class is an experiemental check to reduce the code base for foundation object
    /// </summary>
    public class FoundationObject : SFComponent
    {
        public static void Create<T>(T foObject)
        {
            if (foObject == null)
            {
                throw new ArgumentNullException("Data not passed for creating test data");
            }

            try
            {
                var cls_name = typeof(T);
                var obj = Activator.CreateInstance(typeof(T));
                obj = foObject;
                /* passing the object read via data input to create the test data */
                var result = SFApi.Upsert(JsonConvert.SerializeObject(obj, new JsonSerializerSettings() { NullValueHandling = NullValueHandling.Ignore, Formatting = Formatting.Indented }));
                if (result.ToLower().Contains("success"))
                {
                    Util.Updatelog($"Create test data for {cls_name.FullName}", $"Test data successfully created for {cls_name.FullName}", State.APIPass);
                }
                else
                {
                    Util.Updatelog($"Create test data for {cls_name.FullName}", $"Unable to create test data for {cls_name.FullName}", State.APIFail);
                }
                obj.GetType().GetProperty("api_c_status").SetValue(obj, result);// settting the api call status value
            }
            catch (Exception e)
            {
                TestLog.Error($"Exception Occured {e.Message}");
            }
        }

        public static void Validate<T>(T foObject)
        {
            if (foObject == null)
            {
                throw new ArgumentNullException("Data not passed for validating test data");
            }


        }
    }
}
