﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    using System;
    using System.Reflection;

    public class CorporateAddress
    {
        public static void Create(CorporateAddressFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "FOCorporateAddressDEFLT"
                },
                fo_object.address1,
                fo_object.address2,
                fo_object.address3,
                fo_object.address4,
                fo_object.address5,
                fo_object.address6,
                fo_object.address8,
                fo_object.addressId,
                fo_object.city,
                fo_object.country,
                fo_object.county,
                fo_object.customLong1,
                fo_object.customString1,
                fo_object.customString2,
                fo_object.customString3,
                fo_object.customString4,
                fo_object.province,
                fo_object.startDate,
                fo_object.state,
                fo_object.zipCode,
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for corporate address", "data for corporate address created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for corporate address", "data for corporate address not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {

        }

        public static void Validate(CorporateAddressFO fo_object)
        {
            var query = $"FOCorporateAddressDEFLT?$filter=addressId eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                /* remaining fields to be added during the script debugging */
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for corporate address ", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for corporate address ", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
        }
    }
}

