﻿
namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.FO;
    using SF.FOEntities;
    using System;
    using System.Reflection;

    internal class EventReason : SFComponent
    {
        public static void Create(EventReasonFO fo_object)
        {
            fo_object.event_ = GetPicklistByLabel(PicklistId.___event, fo_object.event_).optionId;
            fo_object.emplStatus = GetPicklistByLabel(PicklistId.employee__status, fo_object.emplStatus).optionId;

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(fo_object, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for event reason", "data for event reason created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for event reason", "data for event reason not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public static void Validate(EventReasonFO fo_object)
        {
            var query = $"FOEventReason?$filter=externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                /* remaining fields to be added during the script debugging */
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for event reason", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for event reason", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
        }
    }
}
