﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    using System;
    using System.Reflection;

    public class ActivityType
    {
        public static void Create(ActivityTypeFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "cust_activity_type"
                },
                fo_object.effectiveStartDate,
                fo_object.externalCode,
                fo_object.mdfSystemStatus,
                fo_object.externalName_defaultValue,
                fo_object.externalName_en_US,
                fo_object.cust_Description_defaultValue,
                fo_object.cust_Description_en_US
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for activity type", "activity type created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for activity type", "activity type not created", State.APIFail);
            }
        }

        public static void Generate_ZoneA_Extract()
        {
        }

        public static void Validate(ActivityTypeFO fo_object)
        {
            var query = $"cust_activity_type?$filter=externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object._effectiveStartDate, response.effectiveStartDate.Value, "effectiveStartDate not matching");
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                Assert.AreEqual(fo_object.mdfSystemStatus, response.mdfSystemStatus.Value, "mdfSystemStatus not matching");
                Assert.AreEqual(fo_object.externalName_defaultValue, response.externalName_defaultValue.Value, "externalName_defaultValue not matching");
                Assert.AreEqual(fo_object.externalName_en_US, response.externalName_en_US.Value, "externalName_en_US not matching");
                Assert.AreEqual(fo_object.cust_Description_defaultValue, response.cust_Description_defaultValue.Value, "cust_Description_defaultValue not matching");
                Assert.AreEqual(fo_object.cust_Description_en_US, response.cust_Description_en_US.Value, "cust_Description_en_US not matching");
                fo_object.api_v_status = Constants.AVPass; Util.Updatelog("Validate the data for activity type ", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail; Util.Updatelog("Validate the data for activity type ", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
        }
    }
}