﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    using System;
    internal class ManagementCountry
    {
        public static void Create(ManagerialCountryFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "cust_Managerial_Country"
                },
                fo_object.effectiveStartDate,
                fo_object.externalCode,
                fo_object.mdfSystemStatus,
                fo_object.cust_Description_defaultValue,
                fo_object.cust_Description_en_US,
                fo_object.externalName_defaultValue,
                fo_object.externalName_en_GB
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for management unit", "data for management unit created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for management unit", "data for management unit not created", State.APIFail);
            }
        }

        internal static string GetExternalCode(string _name)
        {
            var query = $"cust_Managerial_Country?$filter=externalName_defaultValue eq '{_name}'&$format=json";
            return SFApi.Get(query).results[0].externalCode.Value;
        }

        public static void Generate_ZoneA_Extract()
        {
            /* script work in progress */
        }

        public static void Validate(ManagerialCountryFO fo_object)
        {
            var query = $"cust_Managerial_Country?paging=snapshot&$format=json&$filter=externalCode eq '{fo_object.externalCode}'";
            try
            {
                dynamic response = SFApi.Get(query).results[0];

                Assert.AreEqual(fo_object._effectiveStartDate, response.effectiveStartDate.Value, "effectiveStartDate not matching ");
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching ");
                Assert.AreEqual(fo_object.mdfSystemStatus, response.mdfSystemStatus.Value, "mdfSystemStatus not matching ");
                Assert.AreEqual(fo_object.cust_Description_defaultValue, response.cust_Description_defaultValue.Value, "cust_Description_defaultValue not matching ");
                Assert.AreEqual(fo_object.cust_Description_en_US, response.cust_Description_en_US.Value, "cust_Description_en_US not matching ");
                Assert.AreEqual(fo_object.externalName_defaultValue, response.externalName_defaultValue.Value, "externalName_defaultValue not matching ");
                Assert.AreEqual(fo_object.externalName_en_GB, response.externalName_en_GB.Value, "externalName_en_GB not matching ");

                fo_object.api_v_status = Constants.AVPass; Util.Updatelog("Check the values are as input data", "Data is matching", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail; Util.Updatelog("Check the values are as input data", "Data is NOT matching", State.APIFail);
                TestLog.Error($"No Result found! {e.Message} ");
            }
        }
    }
}
