﻿namespace SF.API.FO.Scenarios
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using Pom;
    using SF.APICore;
    using SF.Entity;
    using SF.FOEntities;
    using System;
    using System.Reflection;
    using System.Web;

    public class CostCenter
    {
        public static void Create(CostCenterFO fo_object)
        {
            var createquery = new
            {
                __metadata = new Metadata()
                {
                    Uri = "FOCostCenter"
                },
                fo_object.cust_WBS,
                fo_object.cust_comp,
                fo_object.cust_comp_desc,
                fo_object.cust_eco_location,
                fo_object.cust_eco_location_desc,
                fo_object.cust_merc_comp_code,
                fo_object.cust_merc_comp_code_desc,
                fo_object.cust_prof_centre,
                fo_object.cust_prof_centre_desc,
            };

            fo_object.api_c_status = SFApi.Upsert(JsonConvert.SerializeObject(createquery, Converter.Settings));
            if (fo_object.api_c_status.ToLower().Contains("success"))
            {
                Util.Updatelog("Create test data for Cost Center", "data for cost center created", State.APIPass);
            }
            else
            {
                Util.Updatelog("Create test data for Cost Center", "data for cost center not created", State.APIFail);
            }
        }

        internal static string GetExternalCode(string _name)
        {
            var encodev = HttpUtility.UrlEncode(_name);
            var query = $"FOCostCenter?$filter=name eq '{encodev}'&$format=json";
            return SFApi.Get(query).results[0].externalCode.Value;
        }

        public static void Generate_ZoneA_Extract()
        {

        }

        public static void Validate(CostCenterFO fo_object)
        {
            var query = $"FOCostCenter?$filter=externalCode eq '{fo_object.externalCode}'&$format=json";
            try
            {
                dynamic response = SFApi.Get(query).results[0];
                Assert.AreEqual(fo_object.externalCode, response.externalCode.Value, "externalCode not matching");
                /* remaining fields to be added during the script debugging */
                fo_object.api_v_status = Constants.AVPass;
                Util.Updatelog("Validate the data for cost center ", "Data is matching and valid", State.APIPass);
            }
            catch (Exception e)
            {
                fo_object.api_v_status = Constants.AVFail;
                Util.Updatelog("Validate the data for cost center ", "Data is not matching", State.APIFail);
                TestLog.Error($"Error in {MethodBase.GetCurrentMethod().Name}\t Message: {e.Message}");
            }
        }
    }
}

