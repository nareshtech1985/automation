﻿namespace DatabaseValidation
{
    using EY_Test.PageObjects;
    using NUnit.Framework;
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using Pom.PageObjects.DataModels;
    using SF.Model;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Threading;

    public class TDDHQA : MasterPage
    {

        #region New Validation
        public override void IntializePage()
        {
            Driver.Url = $@"{Util.DirectoryPath}\TDDH_Result.html";
        }

        public TDDHQA(IWebDriver Driver) : base(Driver)
        {

        }
        public static bool WaitFor_CoreHR_DataLoading(DateTime time)
        {
            bool dataloaded = false;
            var query = $"Select * from dbo.Job_Run_Master Where StartTimeStamp > '{time:yyyy-MM-dd HH:mm:ss}' and [Integration Type] = 'POSTEC' order by StartTimeStamp desc";
            TestLog.Info($"Query : {query}");
            //int ii = 0;
            do
            {
                var re = SQLConnect.ReadFromServer(query);
                if (re != null)
                {
                    if (re.Read())
                    {
                        int statusVal = Convert.ToInt32(re.GetString(3));
                        if (statusVal == 0)
                        {
                            var description = $"Job ID {re.GetInt64(0)} | Integration Start Time {re.GetDateTime(4)} | Job Not Completed......";
                            TestLog.Info(description);
                            re.Close();
                            Thread.Sleep(TimeSpan.FromMinutes(1));
                        }
                        else
                        {

                            if (statusVal != 1)
                            {
                                Util.Updatelog("Run Batch to Load data to TDDH", $"POST EC Completed with Status Code {statusVal}", State.APIFail);
                            }
                            else
                            {
                                Util.Updatelog("Run Batch to Load data to TDDH", "POST EC Completed with Status Code 1", State.Done);
                            }

                            var description = $"Job ID {re.GetInt64(0)} | Integration Start Time {re.GetDateTime(4)} | Job Completed, Invoking validation scripts......";
                            TestLog.Info(description);
                            re.Close();
                            break;
                        }
                    }
                    else
                    {
                        TestLog.Info("Post EC Process not invoked Yet!, Waiting for the Job to Invoke Post EC Process for 1 mintue");
                        Thread.Sleep(TimeSpan.FromMinutes(1));
                    }
                }
                else
                {
                    TestLog.Info("Post EC Process not invoked Yet!, Waiting for the Job to Invoke Post EC Process for 1 mintue");
                    Thread.Sleep(TimeSpan.FromMinutes(1));
                }
            } while (true);
            return dataloaded;
        }

        public static bool WaitFor_FO_DataLoading(DateTime time)
        {
            bool dataloaded = false;
            var query = $"Select * from dbo.Job_Run_Master where [Integration Type] = 'Foundation Data' and StartTimeStamp > '{time:yyyy-MM-dd HH:mm:ss}' order by StartTimeStamp desc";
            TestLog.Info($"Query : {query}");
            //int ii = 0;
            do
            {
                var re = SQLConnect.ReadFromServer(query);
                if (re != null)
                {
                    if (re.Read())
                    {
                        string InteType = re.GetString(1);
                        int statusVal = Convert.ToInt32(re.GetString(3));
                        if (statusVal == 0)
                        {
                            if (InteType.Contains("EC-FOLoader"))
                            {
                                var description = $"Job ID {re.GetInt64(0)} | Integration Start Time {re.GetDateTime(4)} | Job Not Completed......";
                                TestLog.Info(description);
                            }
                            else
                            {
                                var description = $"Job ID {re.GetInt64(0)} | Integration Start Time {re.GetDateTime(4)} | Job Not Completed......";
                                TestLog.Info(description);
                            }
                            re.Close();
                            Thread.Sleep(TimeSpan.FromMinutes(1));
                        }
                        if (InteType.Contains("EC-FOLoader"))
                        {
                            var description = $"Job ID {re.GetInt64(0)} | Integration Start Time {re.GetDateTime(4)} | Job Not Completed......";
                            TestLog.Info(description);
                            re.Close();
                            Thread.Sleep(TimeSpan.FromMinutes(1));
                        }
                        else
                        {
                            var description = $"Job ID {re.GetInt64(0)} | Integration Start Time {re.GetDateTime(4)} | Job Completed, Invoking validation scripts......";
                            TestLog.Info(description);
                            re.Close();
                            dataloaded = true;
                            Util.Updatelog("Run Batch to Load data to TDDH", $"Dataloading to FO objects seems completed", State.Done);
                            break;
                        }
                    }
                    else
                    {
                        TestLog.Info("FO Loading not yet invoked!, Waiting for the Job to Invoke FO Loading Process for 1 mintue");
                        Thread.Sleep(TimeSpan.FromMinutes(1));
                    }
                }
                else
                {
                    TestLog.Info("FO Loading not yet invoked!, Waiting for the Job to Invoke FO Loading Process for 1 mintue");
                    Thread.Sleep(TimeSpan.FromMinutes(1));
                }
            } while (true);
            return dataloaded;
        }


        public static void WaitForDataLoading(WorkFlowParameter param)
        {

            List<string> cpipackages = new List<string>();
            List<string> icpackages = new List<string>();

            List<FOMapping> fomaplist = TestData<FOMapping>.Data.ToList();
            List<FOMapping> currentmap = new List<FOMapping>();
            var uniquepackagename = param.FoObjectname.Distinct().ToList();

            /// -------------------------
            /// Filtering the object list
            /// -------------------------
            uniquepackagename.ForEach(p =>
            {
                var mp = fomaplist.Find(x => x.Enum_Values.ToLower().Equals(p.ToLower()));
                currentmap.Add(mp);

            });
            /* Wait for data loading if the Core HR Group is involved */
            if (currentmap.Any(x => x.FO_Group.Equals("JOB", StringComparison.InvariantCultureIgnoreCase) || x.FO_Group.Equals("timeoff", StringComparison.InvariantCultureIgnoreCase)))
            {
                WaitFor_CoreHR_DataLoading(Util.StartTime.ToUniversalTime());
            }
            /* Wait for data loading if the Core HR Group is involved */
            if (currentmap.Any(x => !x.FO_Group.Equals("JOB", StringComparison.InvariantCultureIgnoreCase) && !x.FO_Group.Equals("timeoff", StringComparison.InvariantCultureIgnoreCase)))
            {
                WaitFor_FO_DataLoading(Util.StartTime.ToUniversalTime());
            }

        }
        public void Validate_ClassChange(ClassChangeParameter data)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);

            var query = $"SELECT DISTINCT TOP 1 EMP.GUI,EMP.USERID,Convert(date,JOB.EFFECTIVESTARTDATE) as StartDate,JOB.EVENTREASONID,JOB.GPN,JOB.LPN,JOB.COUNTRY,FE.EventReasonTitle,ECLASS.LabelDefault AS EMPLOYEECLASS,ETYPE.LabelDefault AS EMPLOYEETYPE,Job.SequenceNumber FROM EC.CH_EMPLOYMENTINFO EMP WITH(NOLOCK) INNER JOIN  EC.CH_JOBINFO JOB With(nolock) ON EMP.EMPLOYMENTID = JOB.EMPLOYMENTID LEFT JOIN DBO.FO_EVENTREASON FE WITH(NOLOCK) ON FE.EVENTREASONID = JOB.EVENTREASONID AND FE.ISCURRENT = 1 LEFT JOIN FO_XLAT ECLASS WITH(NOLOCK) ON ECLASS.ExternalCode = JOB.EmployeeClassId and ECLASS.PicklistId = 'EMPLOYEECLASS' LEFT JOIN FO_XLAT ETYPE WITH(NOLOCK) ON ETYPE.ExternalCode = JOB.EmployeeTypeId and ETYPE.PicklistId = 'employmentType' Where  (Job.UserId = '{data.userId}' or Emp.GUI = '{data.personIdExternal}') and Job.EffectiveStartDate = '{data.startDate:yyyy-MM-dd}'  Order by StartDate Desc, Job.SequenceNumber desc;";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {

                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.Multiple(() =>
                        {
                            Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "GUI ID not matching");
                            Assert.AreEqual(data.userId, firstRow.ItemArray[1], "User  ID not matching");
                            Assert.AreEqual(data.startDate, firstRow.ItemArray[2], "Start/Effective Date not matching");
                            Assert.AreEqual(data.employeeClass, firstRow.ItemArray[8], "Employee Class not matching");
                            Assert.AreEqual(data.employmentType, firstRow.ItemArray[9], "Employement Type not matching");
                        });
                        Util.Updatelog($"Check Class change data is updated for the user {data.userId}", "Data is populated in TDDH", State.Pass);

                    }
                    else
                    {
                        Util.Updatelog($"Check Class change data is updated for the user {data.userId}", "Data is not populated in TDDH", State.Fail);
                    }
                }
                catch (Exception e)
                {
                    Util.Updatelog($"Check Class change data is updated for the user {data.userId}", $"Mistmatch in the data, {e.Message}", State.Fail);
                }
                SystemWait(2);
            }
        }


        public void Validate_DepartmentChange(DataChangeParameter data)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);

            var query = $"select distinct top 100 emp.gui,emp.userid,convert(date,job.effectivestartdate) as startdate,job.eventreasonid,job.gpn,job.lpn,job.country,fe.eventreasontitle,job.departmentid,dept.description,job.sequencenumber from ec.ch_employmentinfo emp with(nolock) inner join  ec.ch_jobinfo job with(nolock) on emp.employmentid = job.employmentid left join dbo.fo_eventreason fe with(nolock) on fe.eventreasonid = job.eventreasonid and fe.iscurrent = 1 left join fo_department dept with(nolock) on dept.departmentid = job.departmentid where (job.userid = '{data.userId}' or emp.gui = '{data.personIdExternal}') and job.effectivestartdate = '{data.startDate:yyyy-MM-dd}' order by startdate desc, job.sequencenumber desc";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);

            if (dataTable != null)
            {

                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.Multiple(() =>
                        {
                            Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "GUI ID not matching");
                            Assert.AreEqual(data.userId, firstRow.ItemArray[1], "User  ID not matching");
                            Assert.AreEqual(data.startDate, firstRow.ItemArray[2], "Start/Effective Date not matching");

                            if (!data.departmentid.ToLower().Equals("choose random"))
                            {
                                Assert.AreEqual(data.departmentid, firstRow.ItemArray[8], "Department id not matching with input");
                            }
                        });
                        Util.Updatelog($"Check department change data is updated for the user {data.userId}", "Data is populated in TDDH", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Check department change data is updated for the user {data.userId}", "Data is not populated in TDDH", State.Fail);
                    }
                }
                catch (Exception e)
                {
                    Util.Updatelog($"Check department change data is updated for the user {data.userId}", $"Mistmatch in the data, {e.Message}", State.Fail);
                }
                SystemWait(2);
            }

        }

        #endregion

    }
}