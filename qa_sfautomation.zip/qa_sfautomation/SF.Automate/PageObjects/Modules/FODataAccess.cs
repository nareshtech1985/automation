﻿namespace SF.Automate.PageObjects.Modules
{
    using NUnit.Framework;
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using SF.FOEntities;
    using System;
    using System.Data;

    public class FODataAccess : MasterPage
    {
        public FODataAccess(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {
        }

        #region TDDH Validation Scripts

        public void Validate_FO_ActivityType(ActivityTypeFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_ActivityType where ActivityTypeID = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.name, firstRow.ItemArray[1], "name value not matching");
                        //Assert.AreEqual(foObject.mdfSystemStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check ActivityType foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check ActivityType foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check ActivityType foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_Bank(BankFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_Bank where ExternalCode = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        Assert.AreEqual(foObject.cust_BankID, firstRow.ItemArray[1], "bank id value not matching");
                        Assert.AreEqual(foObject.bankName, firstRow.ItemArray[3], "bank name not matching");

                        Util.Updatelog($"Check Bank foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check Bank foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check Bank foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_BelgiumWeeklyHours(BelgiumWeeklyHoursFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_BelgiumWeeklyHours where WorkScheduleId = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check BelgiumWeeklyHours foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check BelgiumWeeklyHours foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check BelgiumWeeklyHours foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_BrazilCNPJ(BrazilCNPJFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_BrazilCNPJ where BrazilCNPJid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check BrazilCNPJ foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check BrazilCNPJ foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check BrazilCNPJ foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_CareerLevel(CareerLevelFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_CareerLevel where CareerLevelCode = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check CareerLevel foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check CareerLevel foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check CareerLevel foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_CodeBlock(CodeBlockFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_CodeBlock where CodeBlockid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check CodeBlock foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check CodeBlock foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check CodeBlock foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_CorporateAddress(CorporateAddressFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_CorporateAddress where CorporateAddressid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check CorporateAddress foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check CorporateAddress foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check CorporateAddress foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_CostCenter(CostCenterFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_CostCenter where CostCenterid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check CostCenter foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check CostCenter foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check CostCenter foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_CurrencyExchangeRate(CurrencyExchangeRateFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_CurrencyExchangeRate where ExchangeRateID = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check CurrencyExchangeRate foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check CurrencyExchangeRate foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check CurrencyExchangeRate foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_Department(DepartmentFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_Department where Departmentid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check Department foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check Department foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check Department foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                ////dataTable.TableName = foObject.GetType().Name;
                ////ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_Establishment(EstablishmentFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_Establishment where EstablishmentCodeID = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check Establishment foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check Establishment foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check Establishment foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_EventReason(EventReasonFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_EventReason where EventReasonid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check EventReason foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check EventReason foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check EventReason foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_Frequency(FrequencyFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_Frequency where Frequencyid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check Frequency foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check Frequency foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check Frequency foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_GeographicArea(GeographicAreaFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_GeographicArea where GeographicAreaid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check GeographicArea foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check GeographicArea foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check GeographicArea foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_GeographicRegion(GeographicRegionFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_GeographicRegion where GeographicRegionid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check GeographicRegion foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check GeographicRegion foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check GeographicRegion foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
                //dataTable.TableName = foObject.GetType().Name;
                //ExcelWorkBook.SaveFoundationOutput(dataTable);
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_GeoZone(GeoZoneFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_GeoZone where GeoZoneid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.status, firstRow.ItemArray[3], "status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check GeoZone foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check GeoZone foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check GeoZone foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_JobClassification(JobClassificationFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_JobClassification where JobCodeID = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check JobClassification foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check JobClassification foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check JobClassification foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_JobClassificationCS(JobClassificationCSFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_JobClassificationCS where JobClassificationCSid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check JobClassificationCS foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check JobClassificationCS foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check JobClassificationCS foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_JobFamily(JobFamilyFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_JobFamily where JobFamilyid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check JobFamily foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check JobFamily foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check JobFamily foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_JobFamilyGroup(JobFamilyGroupFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_JobFamilyGroup where JobFamilyGroupid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check JobFamilyGroup foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check JobFamilyGroup foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check JobFamilyGroup foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_JobFunction(JobFunctionFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_JobFunction where JobFunctionid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check JobFunction foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass);
                        foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check JobFunction foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                        foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check JobFunction foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail);
                    foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail;
                Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_JobRoleType(JobRoleTypeFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_JobRoleType where JobRoleTypeid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check JobRoleType foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check JobRoleType foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check JobRoleType foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_LegalEntity(LegalEntityFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_LegalEntity where LegalEntityID = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check LegalEntity foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check LegalEntity foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check LegalEntity foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_LegalEntityCS(LegalEntityFO foObject) // To be corrected or removed.
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_LegalEntityCS where LegalEntityCSid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check LegalEntityCS foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check LegalEntityCS foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check LegalEntityCS foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_Location(LocationFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_Location where Worklocationid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.status, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check Location foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check Location foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check Location foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_ManagementArea(ManagementAreaFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_ManagementArea where ManagementAreaid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check ManagementArea foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check ManagementArea foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check ManagementArea foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_ManagementRegion(ManagementRegionFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_ManagementRegion where ManagementRegionid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        Assert.AreEqual(foObject.name_defaultValue, firstRow.ItemArray[1], "name value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check ManagementRegion foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check ManagementRegion foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check ManagementRegion foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_ManagementUnit(ManagementUnitFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_ManagementUnit where ManagementUnitid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check ManagementUnit foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check ManagementUnit foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check ManagementUnit foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_ManagerialCountry(ManagerialCountryFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_ManagerialCountry where ManagerialCountryid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check ManagerialCountry foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check ManagerialCountry foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check ManagerialCountry foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_NameFormat(NameFormatFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_NameFormat where NameFormatCode = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check NameFormat foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check NameFormat foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check NameFormat foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_OperatingUnit(OperatingUnitFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_OperatingUnit where OperatingUnitid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check OperatingUnit foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check OperatingUnit foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check OperatingUnit foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_PayComponent(PayComponentFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_PayComponent where PayComponentid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check PayComponent foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check PayComponent foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check PayComponent foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_PayComponentGroup(PayComponentGroupFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_PayComponentGroup where PayComponentGroupid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check PayComponentGroup foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check PayComponentGroup foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check PayComponentGroup foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_PayGrade(PayGradeFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_PayGrade where PayGradeid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check PayGrade foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check PayGrade foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check PayGrade foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_PayGroup(PayGroupFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_PayGroup where PayGroupid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check PayGroup foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check PayGroup foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check PayGroup foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_PayRanges(PayRangesFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_PayRanges where PayRangeID = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check PayRanges foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check PayRanges foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check PayRanges foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_ProficiencyLevel(ProficiencyLevelFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_ProficiencyLevel where ProficiencyLevelid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check ProficiencyLevel foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check ProficiencyLevel foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check ProficiencyLevel foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_Rank(RankFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_Rank where Rankid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check Rank foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check Rank foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check Rank foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_RewardsDiversifier(RewardsDiversifierFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_RewardsDiversifier where RewardsDiversifierid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        Assert.AreEqual(foObject.cust_Description, firstRow.ItemArray[2], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check RewardsDiversifier foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check RewardsDiversifier foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check RewardsDiversifier foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_ServiceLine(ServiceLineFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_ServiceLine where ServiceLineid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        Assert.AreEqual(foObject.cust_description_defaultValue, firstRow.ItemArray[5], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check ServiceLine foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check ServiceLine foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check ServiceLine foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_ServiceType(ServiceTypeFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_ServiceType where ServiceTypeid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check ServiceType foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check ServiceType foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check ServiceType foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_Speciality(SpecialityFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_Speciality where Specialityid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.status, firstRow.ItemArray[3], "description value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check Speciality foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check Speciality foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check Speciality foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_SubManagementUnit(SubManagementUnitFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_SubManagementUnit where SubManagementUnitid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        Assert.AreEqual(foObject.cust_Description_defaultValue, firstRow.ItemArray[4], "description value not matching");
                        Assert.AreEqual(foObject.mdfSystemStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check SubManagementUnit foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check SubManagementUnit foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check SubManagementUnit foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_SubServiceLine(SubServiceLineFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_SubServiceLine where SubServiceLineid = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check SubServiceLine foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check SubServiceLine foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check SubServiceLine foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_WorkSchedule(WorkScheduleFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_WorkSchedule where ExternalCode = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check WorkSchedule foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check WorkSchedule foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check WorkSchedule foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        public void Validate_FO_BusinessUnit_Finance(BusinessUnit_FinanceFO foObject)
        {
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select * from FO_BusinessUnit_Finance where BusinessUnitID = '{foObject.externalCode}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(foObject.externalCode, firstRow.ItemArray[0], "external code value not matching");
                        //Assert.AreEqual(foObject.description, firstRow.ItemArray[4], "description value not matching");
                        //Assert.AreEqual(foObject.effectiveStatus, firstRow.ItemArray[3], "effective status value not matching");
                        //Assert.AreEqual(foObject._effectiveStartDate, firstRow.ItemArray[2], "description value not matching");
                        Util.Updatelog($"Check Business Unit Finance foundation data for external code {foObject.externalCode} ", "Data is available with key data", State.Pass); foObject.db_v_status = Constants.TVPass; foObject.api_v_status = Constants.AVPass; foObject.api_c_status = Constants.ACPass;
                    }
                    else
                    {
                        Util.Updatelog($"Check Business Unit Finance foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                    }
                }
                catch (Exception)
                {
                    Util.Updatelog($"Check Business Unit Finance foundation data for external code {foObject.externalCode} ", "Data is not available with key data", State.Fail); foObject.db_v_status = Constants.TVFail;
                }
            }
            else
            {
                foObject.db_v_status = Constants.TVFail; Util.Updatelog($"Select data for '{foObject.externalCode}' from db", "Data not available in the db.", State.Fail);
            }
        }

        #endregion TDDH Validation Scripts
    }
}