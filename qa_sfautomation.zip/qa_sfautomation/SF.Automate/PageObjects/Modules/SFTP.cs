﻿namespace EY_Test.PageObjects
{
    using cryptic;
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using System;
    using System.Collections.Generic;
    using System.IO;

    public class SFTP : MasterPage
    {

        private readonly string baseurl = "https://sftp012.successfactors.eu/";

        /* variables for decryption */
        private readonly Credential Credential = Util.TestConfiguration.Credentials.Find(x => x.Name.Equals("SFTP", StringComparison.InvariantCultureIgnoreCase));
        private readonly Cred CypherProgram = new Cred() { Publickey = Util.TestConfiguration.GetCustomKeyValue("publicKey") };
        private By username = By.Id("username");
        private By password = By.Id("password");
        private By loginBtn = By.Id("loginSubmit");

        public SFTP(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {

        }

        public void Login()
        {
            try
            {
                Driver.Url = baseurl;
                Clear(username);
                Clear(password);

                SetText(username, Credential.UserName);
                SetPasswordText(password, CypherProgram.Decrypt(Credential.Password));

                Click(loginBtn);

                Util.Updatelog("Login to SFTP server", "Login Success", State.Pass);
            }
            catch (Exception)
            {
                throw new FrameworkException("Login failure...");
            }
        }

        public void NavigateTo(string folder)
        {
            try
            {
                SystemWait(10);
                Driver.Navigate().GoToUrl($"{baseurl}{folder}");
                Util.Updatelog("Navigate to folder", $"Folder Opened {folder}", State.Pass);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Util.Updatelog("Navigate to folder", $"unable to navigate to folder {folder}", State.Pass);
            }
        }

        public string DownloadLatestFile()
        {
            By lastColumnHeader = By.XPath("//table//th[4]/div");
            WaitUntilElementDisplayed(lastColumnHeader);
            Click(lastColumnHeader);//First Click to select
            Click(lastColumnHeader);//Second Click to Sort in descending order
            By firstrowcheckbox = By.XPath("//table/tbody/tr[1]//input/..");
            By firstrow = By.XPath("//table/tbody/tr[1]");
            By firstrowfileName = By.XPath("//table/tbody/tr[1]/td[2]/span");
            var filename = GetText(firstrowfileName);
            if (filename.Contains(".pgp") || GetText(firstrowfileName).Contains(".xml"))
            {
                Click(firstrow);
                return WaitTillFileDownloads(filename);
            }
            else
            {
                throw new FrameworkException("File not generated! or the path is incorrect!");
            }
        }
        /// <summary>
        /// This method used to dowload all the latest files per the execution start time.
        /// </summary>
        /// <returns></returns>
        public List<string> DownloadLatestFiles()
        {
            List<string> filenames = new List<string>();
            By lastColumnHeader = By.XPath("//table//th[4]/div");
            WaitUntilElementDisplayed(lastColumnHeader);
            Click(lastColumnHeader);//First Click to select
            Click(lastColumnHeader);//Second Click to Sort in descending order
            By tablerows = By.XPath("//table/tbody/tr");
            foreach (IWebElement tableRowItem in Finds(tablerows))
            {
                MovetoElement(tableRowItem);
                string filename = tableRowItem.FindElement(By.XPath("./td[2]/span")).Text;
                DateTime filedate = Convert.ToDateTime(tableRowItem.FindElement(By.XPath("./td[4]")).Text);
                if (Util.StartTime.ToUniversalTime() < filedate)
                {
                    TestLog.Info($"Downloading the file ... {filename} to local temp folder");
                    Click(tableRowItem);
                    filenames.Add(filename);
                }
            }
            return filenames;
        }

        public string WaitTillFileDownloads(string filename, string filesize = "")
        {

            try
            {
                var filetodownload = $@"{Util.DownloadFolder}\{filename.Trim()}";
                var starttime = DateTime.Now;
                do
                {
                    SystemWait(1);

                    if (DateTime.Now.Subtract(starttime).TotalMinutes >= 3)
                    {
                        TestLog.Debug($"Waited for 3+ Min for the availability of file {filename}, File seems to be too large or not available in the temp folder; Continuing with rest of process.");
                        break;
                        //Temporary Logic to reduce the execution time
                        //throw new FrameworkException("File Size seems to be large, Hence skipping the rest of the execution");
                    }

                } while (!File.Exists(filetodownload));

                if (File.Exists(filetodownload))
                {
                    TestLog.Info($"File '{filename}' available in the temp folder");
                }

                return filetodownload;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return "No File";
            }
            //Once the file is downloade copy the same to the server folder where the job is configured.
        }
    }

    public class SFTPFile
    {
        public string FileName { get; set; }
        public string Size { get; set; }
        public DateTime Date { get; set; }
    }
}
