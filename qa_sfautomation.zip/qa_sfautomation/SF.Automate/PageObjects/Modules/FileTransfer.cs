﻿namespace EY_Test.PageObjects.Modules
{
    using cryptic;
    using Pom;
    using Renci.SshNet;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class FileTransfer
    {
        private static readonly Credential Credential = Util.TestConfiguration.Credentials.Find(x => x.Name.Equals("SFTP", StringComparison.InvariantCultureIgnoreCase));
        private static readonly string baseurl = Credential.URL;
        private static readonly Cred CypherProgram = new Cred() { Publickey = Util.TestConfiguration.GetCustomKeyValue("publicKey") };

        public static List<string> DownloadFiles(List<string> downloadFolder)
        {
            List<string> filenameList = new List<string>();
            try
            {
                using (SftpClient sftpclient = new SftpClient(baseurl, Credential.UserName, CypherProgram.Decrypt(Credential.Password)))
                {
                    var currentstartdate = Util.StartTime; //Convert.ToDateTime($"{DateTime.Now:yyyy-MM-dd}");

                    sftpclient.Connect();
                    downloadFolder.Distinct().ToList().ForEach(f =>
                    {
                        var files = sftpclient.ListDirectory(f);
                        var currentfiles = files.Where(x => x.LastWriteTime > currentstartdate);

                        if (currentfiles.Distinct().ToList().Count() == 0)
                        {
                            TestLog.Error("No file generated!");
                        }

                        currentfiles.Distinct().ToList().ToList().ForEach(fs =>
                        {
                            var ffilename = $@"{Util.DownloadFolder}\{fs.Name}";
                            try
                            {
                                using (Stream filen = File.OpenWrite(ffilename))
                                {
                                    TestLog.Info($"Downloading the file '{fs.Name}' started!");
                                    sftpclient.DownloadFile(fs.FullName, filen);
                                    filenameList.Add(ffilename);
                                    TestLog.Info($"File '{fs.Name}' download completed!");
                                }
                            }
                            catch (Exception e)
                            {
                                TestLog.Error($"Unable to download file from server, {e.Message}");
                            }
                        });

                    });
                }
            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
            }
            return filenameList;
        }

    }
}
