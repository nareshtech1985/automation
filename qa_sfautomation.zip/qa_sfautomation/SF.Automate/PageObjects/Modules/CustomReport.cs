﻿namespace EY_Test.PageObjects
{
    using Pom.PageObjects;
    using SF.Parameter;
    public class CustomReport
    {
        #region Report Creation
        public static void GenerateReport()
        {
            /* 01 */
            ExcelWorkBook.CreateExcelReport<AddressParameter>(CoreHRScenario.ADDRESS_CHANGE);
            /* 02 */
            ExcelWorkBook.CreateExcelReport<BankChangeParameter>(CoreHRScenario.BANK_ACCOUNT_CHANGE);
            /* 03 */
            ExcelWorkBook.CreateExcelReport<TimeOffParameter>(CoreHRScenario.PAID_LEAVE);
            /* 04 */
            ExcelWorkBook.CreateExcelReport<TimeOffParameter>(CoreHRScenario.UNPAID_LEAVE);
            /* 05 */
            ExcelWorkBook.CreateExcelReport<TimeOffParameter>(CoreHRScenario.RETURN_PAID_LEAVE);
            /* 06 */
            ExcelWorkBook.CreateExcelReport<TimeOffParameter>(CoreHRScenario.RETURN_UNPAID_LEAVE);
            /* 07 */
            ExcelWorkBook.CreateExcelReport<TimeOffParameter>(CoreHRScenario.LONG_TERM_DISABILITY);
            /* 08 */
            ExcelWorkBook.CreateExcelReport<RankParameter>(CoreHRScenario.RANK_CHANGE_PROMOTION);
            /* 09 */
            ExcelWorkBook.CreateExcelReport<RankParameter>(CoreHRScenario.RANK_CHANGE_DEMOTION);
            /* 10 */
            ExcelWorkBook.CreateExcelReport<DataChangeParameter>(CoreHRScenario.FTE_CHANGE);
            /* 11 */
            ExcelWorkBook.CreateExcelReport<DataChangeParameter>(CoreHRScenario.STD_HRS_CHANGE);
            /* 12 */
            ExcelWorkBook.CreateExcelReport<DataChangeParameter>(CoreHRScenario.DEPARTMENT_CHANGE);
            /* 13 */
            ExcelWorkBook.CreateExcelReport<DataChangeParameter>(CoreHRScenario.CLASS_CHANGE);
            /* 14 */
            ExcelWorkBook.CreateExcelReport<DataChangeParameter>(CoreHRScenario.CHANGE_COUNSELOR);
            /* 15 */
            ExcelWorkBook.CreateExcelReport<DataChangeParameter>(CoreHRScenario.MC_CHANGE);
            /* 16 */
            ExcelWorkBook.CreateExcelReport<DataChangeParameter>(CoreHRScenario.LEGAL_ENTITY_CHANGE);
            /* 17 */
            ExcelWorkBook.CreateExcelReport<TerminateParameter>(CoreHRScenario.TERMINATE_EMPLOYEE);
            /* 18 */
            ExcelWorkBook.CreateExcelReport<TerminateParameter>(CoreHRScenario.NO_SHOW);
            /* 19 */
            ExcelWorkBook.CreateExcelReport<BankChangeParameter>(CoreHRScenario.BANK_ACCOUNT_CHANGE);
            /* 20 */
            ExcelWorkBook.CreateExcelReport<DataChangeParameter>(CoreHRScenario.DOMESTIC_TRANSFER);
            /* 21 */
            ExcelWorkBook.CreateExcelReport<StartDateParameter>(CoreHRScenario.START_DATE_CHANGE);
            /* 22 */
            ExcelWorkBook.CreateExcelReport<DataChangeParameter>(CoreHRScenario.CREATE_CONCURRENT_ASSIGNMENT);
            /* 23 */
            ExcelWorkBook.CreateExcelReport<GlobalAssignmentParameter>(CoreHRScenario.EMP_GLOBAL_ASSIGNMENT);
            /* 24 */
            ExcelWorkBook.CreateExcelReport<GlobalAssignmentParameter>(CoreHRScenario.RETURN_FROM_GLOBAL_ASSIGNMENT);

        }

        #endregion
    }
}
