﻿namespace EY_Test.PageObjects
{
    using EY_Test.PageObjects.CPI_Portal;
    using EY_Test.PageObjects.Modules;
    using EY_Test.PageObjects.SuccessFactors.IntegrationCenter;
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects.DataModels;
    using SF.API.CoreHR.Scenarios;
    using SF.APICore;
    using SF.Helper;
    using SF.HelperLibrary.Mapping.Helper;
    using SF.Model;
    using SpreadsheetLight;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading;

    public class WorkFlow
    {
        public static void ReconfigureITSDEV1Jobs(WorkFlowParameter parameter)
        {
            List<string> downloadFolder = new List<string>();
            List<string> downloadfiles = new List<string>();
            List<string> cpipackages = new List<string>();
            List<string> icpackages = new List<string>();

            List<FOMapping> fomaplist = TestData<FOMapping>.Data.ToList();
            var uniquepackagename = parameter.FoObjectname.Distinct();

            /// -------------------------
            /// Filtering the object list
            /// -------------------------
            fomaplist.ForEach(x =>
            {
                if (uniquepackagename.Any(c => c.ToLower().Equals(x.Enum_Values.ToLower())))
                {
                    if (x.IsCPI) { cpipackages.Add(x.PackageName); }
                    if (x.IsSFIC) { icpackages.Add(x.PackageName); }
                }
            });

            if (icpackages.Distinct().ToList().Count > 0)
            {
                //Execute SF IC Workflow
                var sflogin = new LoginPage(parameter.Driver);
                var sfhome = sflogin.Login();
                var ichome = (IntegrationCenterHome)sfhome.NavigateToIntegrationCenter("Integration Center");
                var ics = ichome.NavigateToMyIntegrations();
                //icpackages.Distinct().ToList().ForEach(icPackageName =>
                foreach (var icPackageName in icpackages.Distinct().ToList())
                {
                    try
                    {
                        if (ics.SearchAndSelectPackage(icPackageName))
                        {
                            ics.ReconfigureSFTP_ForITSDEV1();
                        }
                    }
                    catch (Exception e)
                    {
                        TestLog.Error(e.Message);
                    }
                }
            }
        }

        public static DateTime ExtractFO(WorkFlowParameter parameter)
        {
            List<string> downloadFolder = new List<string>();
            List<string> downloadfiles = new List<string>();
            List<string> cpipackages = new List<string>();
            List<string> icpackages = new List<string>();

            List<FOMapping> fomaplist = TestData<FOMapping>.Data.ToList();
            var uniquepackagename = parameter.FoObjectname.Distinct();

            /// -------------------------
            /// Filtering the object list
            /// -------------------------
            fomaplist.ForEach(x =>
            {
                if (uniquepackagename.Any(c => c.ToLower().Equals(x.Enum_Values.ToLower())))
                {
                    if (x.IsCPI) { cpipackages.Add(x.PackageName); }
                    if (x.IsSFIC) { icpackages.Add(x.PackageName); }
                }
            });

            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            // Executing the job from Cloud Platform Integration Center
            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            if (cpipackages.Distinct().ToList().Count > 0)
            {
                //Execute CPI Work Flow
                var cpiconfig = Util.GetCpiPackageInfo().Cpi.Find(x => x.Environment.Equals(Util.TestConfiguration.Environment, StringComparison.OrdinalIgnoreCase));
                var cpihome = new CPIHome(parameter.Driver);
                cpihome.Login();
                //cpipackages.Distinct().ToList().ForEach(cpack =>
                foreach (var cpack in cpipackages.Distinct().ToList())
                {
                    TestLog.Info($"Extracting the data for {cpack}");
                    #region CPI FO Execution Flow
                    try
                    {
                        var packagename = cpiconfig.Packagename;
                        var artifactname = cpack;

                        var cpipakages = cpihome.NavigateToDesign();
                        cpipakages.SearchPackages(packagename);

                        var package = cpipakages.SelectFirstPackage(packagename);
                        package.ChooseTab(PackageTab.Artifacts);

                        var workflow = package.SearchandSelectArtifact(artifactname);
                        string serviceUrl = "";
                        if (workflow.IsRunning())
                        {
                            workflow.Configure();
                            serviceUrl = workflow.GetServiceUrl();
                            workflow.ChooseModalTab(ModalTab.Receiver);
                            downloadFolder.Add(workflow.GetSFTPLocation());
                            workflow.CloseModal();
                        }
                        else
                        {
                            workflow.Configure();
                            serviceUrl = workflow.GetServiceUrl();
                            workflow.ChooseModalTab(ModalTab.Receiver);
                            downloadFolder.Add(workflow.GetSFTPLocation());
                            workflow.ChooseModalTab(ModalTab.More);
                            var initialjobdata = workflow.CaptureValues();
                            workflow.SaveAndDeploy();

                        }
                        var deploye = workflow.GetDeploymentInfo();
                        serviceUrl = deploye.GetServiceURL(packagename, new IFlow.Integration() { Artifactname = cpack, Artifactshortname = "" });

                        // Perform the API Call to generate the test data file from ec to use in the file loading batch
                        CpiApi.PostCallAsync(serviceUrl);

                        deploye.SelectArtifact(artifactname);
                        /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                        //For FO Objects No Need to Undeploy unless deployed - To be updated only if Required
                        /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                        if (Util.TestConfiguration.Environment.ToLower().Equals("itsdev1"))
                        {
                            //workflow.UndoChanges(artifactname);
                        }
                        else if (Util.TestConfiguration.Environment.ToLower().Equals("uat1"))
                        {
                            //package = cpipakages.SelectFirstPackage(packagename);
                            //package.ChooseTab(PackageTab.Artifacts);
                            //workflow = package.SearchandSelectArtifact(artifactname);
                            //workflow.Configure();
                            //workflow.ChooseModalTab(ModalTab.More);
                            //workflow.SetCutOffDate(Convert.ToDateTime(initialjobdata.CutOffDate));
                            //workflow.SetEmployeeId(initialjobdata.EmployeeIDs);
                            //workflow.SetManualLastRun(Convert.ToDateTime(initialjobdata.ManualLastRunTime));
                        }
                    }
                    catch (Exception e)
                    {
                        TestLog.Error(e.Message);
                    }
                    #endregion
                }

            }

            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            // Executing the job from SF Integration Center
            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            if (icpackages.Distinct().ToList().Count > 0)
            {
                //Execute SF IC Workflow
                var sflogin = new LoginPage(parameter.Driver);
                var sfhome = sflogin.Login();
                var ichome = (IntegrationCenterHome)sfhome.NavigateToIntegrationCenter("Integration Center");
                var ics = ichome.NavigateToMyIntegrations();
                //icpackages.Distinct().ToList().ForEach(icPackageName =>
                foreach (var icPackageName in icpackages.Distinct().ToList())
                {
                    TestLog.Info($"Extracting the data for {icPackageName}");
                    try
                    {
                        if (ics.SearchAndSelectPackage(icPackageName))
                        {
                            var sftplocation = ics.ClickReviewandRun();
                            TestLog.Info($"SFTP File Generated @ {sftplocation}");
                            downloadFolder.Add(sftplocation);
                            Thread.Sleep(TimeSpan.FromSeconds(40));
                        }
                    }
                    catch (Exception e)
                    {
                        TestLog.Error(e.Message);
                    }
                }
            }

            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            // Download via Basic Auth onyl required in ITSDEV1. For UAT this will be covered by the batch script in the Server
            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            Thread.Sleep(TimeSpan.FromSeconds(59));
            downloadfiles = FileTransfer.DownloadFiles(downloadFolder);

            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            // Placing the file in the QA Server(s) for batch to pick up and process the files
            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            return Util.CopyFileToShare(downloadfiles);

            //downloadFolder.ForEach(x => TestLog.Info($"SFTP Path : {x}"));
        }

        public static DateTime Run(WorkFlowParameter parameter)
        {

            List<string> downloadFolder = new List<string>();
            List<string> downloadfiles = new List<string>();

            // Get Cpi Packages to be used for reading the data for the scenario
            var cpipackage = Util.GetCpiPackageInfo().Cpi.Find(x => x.
          Environment.Equals(Util.TestConfiguration.Environment, StringComparison.OrdinalIgnoreCase));
            string employee = "";

            switch (parameter.Type)
            {
                case WorkFlowType.EmployeeTimeOff:
                    employee = string.Join(",", TimeOff.parameters.Select(x => x.personIdExternal).ToArray());
                    break;
                case WorkFlowType.Termination:
                    employee = string.Join(",", TerminateEmployee.parameters.Select(x => x.personIdExternal).ToArray());
                    break;
                case WorkFlowType.NoShow:
                    employee = string.Join(",", TerminateEmployee.parameters.Select(x => x.personIdExternal).ToArray());
                    break;
                case WorkFlowType.ClassChange:
                    employee = string.Join(",", ClassChange.parameters.Select(x => x.personIdExternal).ToArray());
                    break;
                case WorkFlowType.GlobalAssignment:
                    //employee = string.Join(",", TimeOff.parameters.Select(x => x.personIdExternal).ToArray());
                    break;
                case WorkFlowType.DataChange:
                    employee = string.Join(",", DepartmentChange.parameters.Select(x => x.personIdExternal).ToArray());
                    break;
                case WorkFlowType.All:
                    employee = GetAllemployeeId(); break;
                default:

                    break;
            }

            var cpihome = new CPIHome(parameter.Driver);
            cpihome.Login();

            foreach (var item in cpipackage.Integrations)
            {
                try
                {
                    var packagename = cpipackage.Packagename;
                    var artifactname = item.Artifactname;

                    var cpipackages = cpihome.NavigateToDesign();
                    cpipackages.SearchPackages(packagename);

                    var package = cpipackages.SelectFirstPackage(packagename);
                    package.ChooseTab(PackageTab.Artifacts);

                    var workflow = package.SearchandSelectArtifact(artifactname);
                    workflow.Configure();

                    var serviceUrl = workflow.GetServiceUrl();

                    workflow.ChooseModalTab(ModalTab.Receiver);

                    downloadFolder.Add(workflow.GetSFTPLocation());

                    workflow.ChooseModalTab(ModalTab.More);
                    var initialjobdata = workflow.CaptureValues();

                    if (Util.TestConfiguration.Environment.ToLower().Equals("itsdev1"))
                    {
                        workflow.SetCutOffDate(DateTime.Now.AddDays(-15));
                        workflow.SetEmployeeId(employee);
                        workflow.SetManualLastRun(DateTime.Now);
                    }
                    else if (Util.TestConfiguration.Environment.ToLower().Equals("uat1"))
                    {
                        workflow.SetCutOffDate(DateTime.Now.AddDays(-15));
                        workflow.SetManualLastRun(DateTime.Now);
                    }

                    workflow.SaveAndDeploy();
                    var deploye = workflow.GetDeploymentInfo();
                    serviceUrl = deploye.GetServiceURL(packagename, item);
                    // Perform the API Call to generate the test data file from ec to use in the file loading batch
                    CpiApi.PostCallAsync(serviceUrl);

                    deploye.SelectArtifact(artifactname);

                    //Un Deploy the Job / revert to previous job parameters
                    if (Util.TestConfiguration.Environment.ToLower().Equals("itsdev1"))
                    {
                        workflow.UndoChanges(artifactname);
                    }
                    else if (Util.TestConfiguration.Environment.ToLower().Equals("uat1"))
                    {
                        package = cpipackages.SelectFirstPackage(packagename);
                        package.ChooseTab(PackageTab.Artifacts);
                        workflow = package.SearchandSelectArtifact(artifactname);
                        workflow.Configure();
                        workflow.ChooseModalTab(ModalTab.More);
                        workflow.SetCutOffDate(Convert.ToDateTime(initialjobdata.CutOffDate));
                        workflow.SetEmployeeId(initialjobdata.EmployeeIDs);
                        workflow.SetManualLastRun(Convert.ToDateTime(initialjobdata.ManualLastRunTime));
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            // Perform the file download for the created scenarios
            var sftp = new SFTP(parameter.Driver);
            sftp.Login();
            foreach (var foders in downloadFolder)
            {
                try
                {
                    sftp.NavigateTo(foders);
                    downloadfiles.Add(sftp.DownloadLatestFile());
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }

            // Copy the files from download folder to share folder
            return Util.CopyFileToShare(downloadfiles);

        }

        public static string GetAllemployeeId()
        {
            string employee = "";
            using (SLDocument doc = new SLDocument($@"{Util.DirectoryPath}\Data\excel_data\CoreHR.xlsx"))
            {
                List<string> sheetNames = doc.GetWorksheetNames();
                foreach (var sheet in sheetNames)
                {
                    string emp = "";
                    if (sheet.ToLower().Equals("master sheet")) { continue; }
                    doc.SelectWorksheet(sheet);
                    var prop = doc.GetWorksheetStatistics();
                    for (int i = 2; i <= prop.EndRowIndex; i++)
                    {
                        if (!doc.GetCellValueAsString($"A{i}").Equals(string.Empty))
                        {
                            if (sheet.ToLower().Equals("leave"))
                            {
                                emp = $"{emp}{doc.GetCellValueAsString($"A{i}").Trim()},";
                            }
                            else
                            {
                                emp = $"{emp}{doc.GetCellValueAsString($"A{i}").Trim()},{doc.GetCellValueAsString($"B{i}").Trim()},";
                            }
                        }
                    }
                    if (!emp.Equals(string.Empty))
                    { employee = $"{employee.Trim()}{emp.Substring(0, emp.Length - 1).Trim()},"; }
                }
            }

            //remove duplicate values
            var list = employee.Split(',').ToList();
            var finalList = $"{string.Join(",", list.Distinct().ToArray())}";
            return finalList.Substring(0, finalList.Length - 1);
        }

        public static void GenerateExtract(WorkFlowParameter parameter)
        {
            List<string> downloadFolder = new List<string>();
            List<string> downloadfiles = new List<string>();
            List<string> cpipackages = new List<string>();
            List<string> icpackages = new List<string>();

            List<FOMapping> fomaplist = TestData<FOMapping>.Data.ToList();
            var uniquepackagename = parameter.FoObjectname.Distinct();

            /// -------------------------
            /// Filtering the object list
            /// -------------------------
            fomaplist.ForEach(x =>
            {
                if (uniquepackagename.Any(c => c.ToLower().Equals(x.Enum_Values.ToLower())))
                {
                    if (x.IsCPI) { cpipackages.Add(x.PackageName); }
                    if (x.IsSFIC) { icpackages.Add(x.PackageName); }
                }
            });

            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            // Executing the job from Cloud Platform Integration Center
            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            if (cpipackages.Distinct().ToList().Count > 0)
            {
                //Execute CPI Work Flow
                var cpiconfig = Util.GetCpiPackageInfo().Cpi.Find(x => x.Environment.Equals(Util.TestConfiguration.Environment, StringComparison.OrdinalIgnoreCase));
                var cpihome = new CPIHome(parameter.Driver);
                cpihome.Login();
                //cpipackages.Distinct().ToList().ForEach(cpack =>
                foreach (var cpack in cpipackages.Distinct().ToList())
                {
                    TestLog.Info($"Extracting the data for {cpack}");
                    #region CPI Execution Flow
                    try
                    {
                        string packagename = cpiconfig.Packagename;
                        string artifactname = cpack;
                    basictrial:
                        CPIDesign cpipakages = cpihome.NavigateToDesign();
                        cpipakages.SearchPackages(packagename);

                        CPIPackage package = cpipakages.SelectFirstPackage(packagename);
                        package.ChooseTab(PackageTab.Artifacts);

                        CPIWorkflow workflow = package.SearchandSelectArtifact(artifactname);
                        if (workflow == null) goto basictrial;
                        string serviceUrl = "";

                        // If the type is 'Job','Time' Redirect the flow to Configure
                        FOMapping jobgroup = fomaplist.Find(x => x.PackageName.Equals(artifactname));
                        if (jobgroup.FO_Group.Equals("JOB", StringComparison.InvariantCultureIgnoreCase))
                        {
                            #region Perform Configuration and Extraction for JOB related 

                            // Collect the employee GUI values
                            string employee = GetAllemployeeId(); ;
                            // Create and Save Config
                            workflow.Configure();
                            serviceUrl = workflow.GetServiceUrl();
                            workflow.ChooseModalTab(ModalTab.Receiver);
                            downloadFolder.Add(workflow.GetSFTPLocation());
                            workflow.ChooseModalTab(ModalTab.More);
                            CPIJobInfo initialjobdata = workflow.CaptureValues();
                            if (Util.TestConfiguration.Environment.ToLower().Equals("itsdev1"))
                            {
                                workflow.SetCutOffDate(DateTime.Now.AddDays(-1));
                                workflow.SetEmployeeId(employee);
                                workflow.SetManualLastRun(DateTime.Now);
                            }
                            else if (Util.TestConfiguration.Environment.ToLower().Equals("uat1"))
                            {
                                workflow.SetCutOffDate(DateTime.Now.AddDays(-1));
                                workflow.SetManualLastRun(DateTime.Now);
                            }
                            workflow.SaveAndDeploy();
                            CPIIntegration integration = workflow.GetDeploymentInfo();
                            serviceUrl = integration.GetServiceURL(packagename, new IFlow.Integration() { Artifactname = cpack, Artifactshortname = "" });
                            // Perform the API Call to generate the test data file from ec to use in the
                            // file loading batch
                            CpiApi.PostCallAsync(serviceUrl);

                            //Select the artifact page
                            integration.SelectArtifact(artifactname);

                            //Un Deploy the Job / revert to previous job parameters
                            if (Util.TestConfiguration.Environment.ToLower().Equals("itsdev1"))
                            {
                                workflow.UndoChanges(artifactname);
                            }
                            else if (Util.TestConfiguration.Environment.ToLower().Equals("uat1"))
                            {
                            undeployretry:
                                package = cpipakages.SelectFirstPackage(packagename);
                                package.ChooseTab(PackageTab.Artifacts);
                                workflow = package.SearchandSelectArtifact(artifactname);
                                if (workflow == null) goto undeployretry;
                                workflow.Configure();
                                workflow.ChooseModalTab(ModalTab.More);
                                workflow.SetCutOffDate(Convert.ToDateTime(initialjobdata.CutOffDate));
                                workflow.SetEmployeeId(initialjobdata.EmployeeIDs);
                                workflow.SetManualLastRun(Convert.ToDateTime(initialjobdata.ManualLastRunTime));
                                workflow.SaveAndDeploy();
                            }

                            #endregion
                        }
                        else
                        {
                            #region Perform Extraction for foundation Objects
                            if (workflow.IsRunning())
                            {
                                workflow.Configure();
                                serviceUrl = workflow.GetServiceUrl();
                                workflow.ChooseModalTab(ModalTab.Receiver);
                                downloadFolder.Add(workflow.GetSFTPLocation());
                                workflow.CloseModal();
                            }
                            else
                            {
                                workflow.Configure();
                                serviceUrl = workflow.GetServiceUrl();
                                workflow.ChooseModalTab(ModalTab.Receiver);
                                downloadFolder.Add(workflow.GetSFTPLocation());
                                workflow.ChooseModalTab(ModalTab.More);
                                var initialjobdata = workflow.CaptureValues();
                                workflow.SaveAndDeploy();
                            }
                            var deploye = workflow.GetDeploymentInfo();
                            serviceUrl = deploye.GetServiceURL(packagename, new IFlow.Integration() { Artifactname = cpack, Artifactshortname = "" });

                            // Perform the API Call to generate the test data file from ec to use in the file loading batch
                            CpiApi.PostCallAsync(serviceUrl);

                            deploye.SelectArtifact(artifactname);
                            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                            //For FO Objects No Need to Undeploy unless deployed - To be updated only if Required
                            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                            if (Util.TestConfiguration.Environment.ToLower().Equals("itsdev1"))
                            {
                                //workflow.UndoChanges(artifactname);
                            }
                            else if (Util.TestConfiguration.Environment.ToLower().Equals("uat1"))
                            {
                                //package = cpipakages.SelectFirstPackage(packagename);
                                //package.ChooseTab(PackageTab.Artifacts);
                                //workflow = package.SearchandSelectArtifact(artifactname);
                                //workflow.Configure();
                                //workflow.ChooseModalTab(ModalTab.More);
                                //workflow.SetCutOffDate(Convert.ToDateTime(initialjobdata.CutOffDate));
                                //workflow.SetEmployeeId(initialjobdata.EmployeeIDs);
                                //workflow.SetManualLastRun(Convert.ToDateTime(initialjobdata.ManualLastRunTime));
                            }
                            #endregion
                        }
                    }
                    catch (Exception e)
                    {
                        TestLog.Error(e.Message);
                        cpihome = new CPIHome(parameter.Driver);
                        cpihome.Login();
                    }
                    #endregion
                }

            }

            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            // Executing the job from SF Integration Center
            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            if (icpackages.Distinct().ToList().Count > 0)
            {
                //Execute SF IC Workflow
                var sflogin = new LoginPage(parameter.Driver);
                var sfhome = sflogin.Login();
                var ichome = (IntegrationCenterHome)sfhome.NavigateToIntegrationCenter("Integration Center");

                var ics = ichome.NavigateToMyIntegrations();
                //icpackages.Distinct().ToList().ForEach(icPackageName =>
                foreach (var icPackageName in icpackages.Distinct().ToList())
                {
                    TestLog.Info($"Extracting the data for {icPackageName}");
                    try
                    {
                        if (ics.SearchAndSelectPackage(icPackageName))
                        {
                            var sftplocation = ics.ClickReviewandRun();
                            TestLog.Info($"SFTP File Generated @ {sftplocation}");
                            downloadFolder.Add(sftplocation);
                            Thread.Sleep(TimeSpan.FromSeconds(40));
                        }
                    }
                    catch (Exception e)
                    {
                        TestLog.Error(e.Message);
                    }
                }
            }

            if (Util.TestConfiguration.Environment.ToLower().Equals("itsdev1"))
            {
                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                // Download via Basic Auth onyl required in ITSDEV1. For UAT this will be covered by the batch script in the Server
                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                Thread.Sleep(TimeSpan.FromSeconds(59));
                downloadfiles = FileTransfer.DownloadFiles(downloadFolder);

                if (downloadfiles.Count == 0)
                {
                    #region Download file via UI of SFTP
                    // Perform the file download for the created scenarios via UI
                    var sftp = new SFTP(parameter.Driver);
                    sftp.Login();
                    foreach (var foders in downloadFolder.Distinct())
                    {
                        try
                        {
                            sftp.NavigateTo(foders);
                            downloadfiles.AddRange(sftp.DownloadLatestFiles());
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                    }

                    //after download confirm the files exists in the temp folder
                    foreach (var filn in downloadfiles)
                    {
                        sftp.WaitTillFileDownloads(filn);
                    }
                    #endregion
                }

                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                // Placing the file in the QA Server(s) for batch to pick up and process the files
                // If the machine is EY Laptop , VPN Connection is Required.
                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                parameter.Driver.Url = $@"{Util.DirectoryPath}\dataloading.html";
                Util.CopyFileToShare(downloadfiles);
            }

            //downloadFolder.ForEach(x => TestLog.Info($"SFTP Path : {x}"));
        }

        public static void GenerateExtract_New(WorkFlowParameter parameter)
        {
            List<string> corehrlist = new List<string>() { "time", "job", "jobcs", "timeoff", "job_country_specific" };
            List<string> downloadFolder = new List<string>();
            List<string> downloadfiles = new List<string>();
            List<string> cpipackages = new List<string>();
            List<string> icpackages = new List<string>();

            List<JobPackage> fomaplist = (!Util.TestConfiguration.Environment.Equals(Constants.TST1)) ? PackageInfoLoader.Load().Packs : PackageInfoLoader.Load(Constants.TST1).Packs;
            var uniquepackagename = parameter.FoObjectname.Distinct();

            /// -------------------------
            /// Filtering the object list
            /// -------------------------
            fomaplist.ForEach(x =>
            {
                if (uniquepackagename.Any(c => c.ToLower().Equals(x.Name.ToLower())))
                {
                    if (x.IsCPI) { cpipackages.Add(x.Package_Name); }
                    if (x.IsSFIC) { icpackages.Add(x.Package_Name); }
                }
            });

            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            // Executing the job from Cloud Platform Integration Center
            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            if (cpipackages.Distinct().ToList().Count > 0)
            {
                var batchdriver = Browser.GetBrowser(BrowserName.Chrome);
                try
                {
                    //Execute CPI Work Flow
                    var cpiconfig = Util.GetCpiPackageInfo().Cpi.Find(x => x.Environment.Equals(Util.TestConfiguration.Environment, StringComparison.OrdinalIgnoreCase));
                    var cpihome = new CPIHome(batchdriver);
                    cpihome.Login();
                    //cpipackages.Distinct().ToList().ForEach(cpack =>
                    foreach (var cpack in cpipackages.Distinct().ToList())
                    {
                        TestLog.Info($"Extracting the data for {cpack}");
                        #region CPI Execution Flow
                        try
                        {
                            string packagename = cpiconfig.Packagename;
                            string artifactname = cpack;
                        basictrial:
                            CPIDesign cpipakages = cpihome.NavigateToDesign();
                            cpipakages.SearchPackages(packagename);

                            CPIPackage package = cpipakages.SelectFirstPackage(packagename);
                            package.ChooseTab(PackageTab.Artifacts);

                            CPIWorkflow workflow = package.SearchandSelectArtifact(artifactname);
                            if (workflow == null) goto basictrial;
                            string serviceUrl = "";

                            // If the type is 'Job','Time' Redirect the flow to Configure
                            JobPackage jobgroup = fomaplist.Find(x => x.Package_Name.Equals(artifactname));

                            if (corehrlist.Any(x => x.Equals(jobgroup.Name, StringComparison.InvariantCultureIgnoreCase)))
                            {
                                #region Perform Configuration and Extraction for JOB related 

                                // Collect the employee GUI values
                                string employee = "NA";//GetAllemployeeId(); ;
                                                       // Create and Save Config
                                workflow.Configure();
                                serviceUrl = workflow.GetServiceUrl();
                                workflow.ChooseModalTab(ModalTab.Receiver);
                                downloadFolder.Add(workflow.GetSFTPLocation());
                                workflow.ChooseModalTab(ModalTab.More);
                                CPIJobInfo initialjobdata = workflow.CaptureValues();
                                if (Util.TestConfiguration.Environment.Equals(Constants.ITSDEV1, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    workflow.SetContingentWorker("NA");
                                    workflow.SetCutOffDate(DateTime.Now);
                                    workflow.SetEmployeeId(employee);
                                    workflow.SetManualLastRun(DateTime.Now);
                                }
                                else if (Util.TestConfiguration.Environment.Equals(Constants.TST1, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    workflow.SetContingentWorker("NA");
                                    workflow.SetCutOffDate(DateTime.Now);
                                    workflow.SetManualLastRun(DateTime.Now);
                                }
                                workflow.SaveAndDeploy();
                                CPIIntegration integration = workflow.GetDeploymentInfo();
                                serviceUrl = integration.GetServiceURL(packagename, new IFlow.Integration() { Artifactname = cpack, Artifactshortname = "" });
                                // Perform the API Call to generate the test data file from ec to use in the
                                // file loading batch
                                CpiApi.PostCallAsync(serviceUrl);

                                //Select the artifact page
                                integration.SelectArtifact(artifactname);

                                //Un Deploy the Job / revert to previous job parameters
                                if (Util.TestConfiguration.Environment.Equals(Constants.ITSDEV1, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    workflow.UndoChanges(artifactname);
                                }
                                else if (Util.TestConfiguration.Environment.Equals(Constants.TST1, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    try
                                    {
                                    undeployretry:
                                        cpipakages = cpihome.NavigateToDesign();
                                        cpipakages.SearchPackages(packagename);
                                        package = cpipakages.SelectFirstPackage(packagename);
                                        package.ChooseTab(PackageTab.Artifacts);
                                        workflow = package.SearchandSelectArtifact(artifactname);
                                        if (workflow == null) goto undeployretry;
                                        workflow.Configure();
                                        workflow.ChooseModalTab(ModalTab.More);
                                        workflow.SetCutOffDate(Convert.ToDateTime(initialjobdata.CutOffDate));
                                        workflow.SetEmployeeId(initialjobdata.EmployeeIDs);
                                        workflow.SetManualLastRun(Convert.ToDateTime(initialjobdata.ManualLastRunTime));
                                        workflow.SetContingentWorker(initialjobdata.ContingentWorker);
                                        workflow.SaveAndDeploy();
                                    }
                                    catch (Exception)
                                    {
                                        TestLog.Info("Unable to reset the cpi package, try manually");

                                    }
                                }

                                #endregion
                            }
                            else
                            {
                                #region Perform Extraction for foundation Objects
                                if (workflow.IsRunning())
                                {
                                    workflow.Configure();
                                    serviceUrl = workflow.GetServiceUrl();
                                    workflow.ChooseModalTab(ModalTab.Receiver);
                                    downloadFolder.Add(workflow.GetSFTPLocation());
                                    workflow.CloseModal();
                                }
                                else
                                {
                                    workflow.Configure();
                                    serviceUrl = workflow.GetServiceUrl();
                                    workflow.ChooseModalTab(ModalTab.Receiver);
                                    downloadFolder.Add(workflow.GetSFTPLocation());
                                    workflow.ChooseModalTab(ModalTab.More);
                                    var initialjobdata = workflow.CaptureValues();
                                    workflow.SaveAndDeploy();
                                }
                                var deploye = workflow.GetDeploymentInfo();
                                serviceUrl = deploye.GetServiceURL(packagename, new IFlow.Integration() { Artifactname = cpack, Artifactshortname = "" });

                                // Perform the API Call to generate the test data file from ec to use in the file loading batch
                                CpiApi.PostCallAsync(serviceUrl);

                                deploye.SelectArtifact(artifactname);
                                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                                //For FO Objects No Need to Undeploy unless deployed - To be updated only if Required
                                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                                if (Util.TestConfiguration.Environment.Equals(Constants.ITSDEV1, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    //workflow.UndoChanges(artifactname);
                                }
                                else if (Util.TestConfiguration.Environment.Equals(Constants.TST1, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    //package = cpipakages.SelectFirstPackage(packagename);
                                    //package.ChooseTab(PackageTab.Artifacts);
                                    //workflow = package.SearchandSelectArtifact(artifactname);
                                    //workflow.Configure();
                                    //workflow.ChooseModalTab(ModalTab.More);
                                    //workflow.SetCutOffDate(Convert.ToDateTime(initialjobdata.CutOffDate));
                                    //workflow.SetEmployeeId(initialjobdata.EmployeeIDs);
                                    //workflow.SetManualLastRun(Convert.ToDateTime(initialjobdata.ManualLastRunTime));
                                }
                                #endregion
                            }
                        }
                        catch (Exception e)
                        {
                            TestLog.Error(e.Message);
                            cpihome = new CPIHome(parameter.Driver);
                            cpihome.Login();
                        }
                        #endregion
                    }
                }
                catch (Exception)
                {
                    TestLog.Error("CPI - File Generate Intermittent Issue, Please try again!");
                    throw;
                }
                finally
                {
                    batchdriver.Close();
                }
            }

            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            // Executing the job from SF Integration Center
            /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
            if (icpackages.Distinct().ToList().Count > 0)
            {
                //Execute SF IC Workflow
                var sflogin = new LoginPage(parameter.Driver);
                var sfhome = sflogin.Login();
                var ichome = (IntegrationCenterHome)sfhome.NavigateToIntegrationCenter("Integration Center");

                var ics = ichome.NavigateToMyIntegrations();
                //icpackages.Distinct().ToList().ForEach(icPackageName =>
                foreach (var icPackageName in icpackages.Distinct().ToList())
                {
                    TestLog.Info($"Extracting the data for {icPackageName}");
                    try
                    {
                        if (ics.SearchAndSelectPackage(icPackageName))
                        {
                            var sftplocation = ics.ClickReviewandRun();
                            TestLog.Info($"SFTP File Generated @ {sftplocation}");
                            downloadFolder.Add(sftplocation);
                            Thread.Sleep(TimeSpan.FromSeconds(40));
                        }
                    }
                    catch (Exception e)
                    {
                        TestLog.Error(e.Message);
                    }
                }
            }

            #region Zone A Extraction Logic 
            if (Util.TestConfiguration.Environment.Equals(Constants.ITSDEV1, StringComparison.InvariantCultureIgnoreCase))
            {
                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                // Download via Basic Auth onyl required in ITSDEV1. For UAT this will be covered by the batch script in the Server
                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                Thread.Sleep(TimeSpan.FromSeconds(59));
                downloadfiles = FileTransfer.DownloadFiles(downloadFolder);

                if (downloadfiles.Count == 0)
                {
                    #region Download file via UI of SFTP
                    // Perform the file download for the created scenarios via UI
                    var sftp = new SFTP(parameter.Driver);
                    sftp.Login();
                    foreach (var foders in downloadFolder.Distinct())
                    {
                        try
                        {
                            sftp.NavigateTo(foders);
                            downloadfiles.AddRange(sftp.DownloadLatestFiles());
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine(e.Message);
                        }
                    }

                    //after download confirm the files exists in the temp folder
                    foreach (var filn in downloadfiles)
                    {
                        sftp.WaitTillFileDownloads(filn);
                    }
                    #endregion
                }

                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                // Placing the file in the QA Server(s) for batch to pick up and process the files
                // If the machine is EY Laptop , VPN Connection is Required.
                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                parameter.Driver.Url = $@"{Util.DirectoryPath}\dataloading.html";
                Util.CopyFileToShare(downloadfiles);
            }

            if (Util.TestConfiguration.Environment.Equals(Constants.TST1, StringComparison.InvariantCultureIgnoreCase))
            {
                List<JobPackage> _packs = new List<JobPackage>();
                List<string> _filecontent = new List<string>();
                List<string> _filenames = new List<string>();

                uniquepackagename.ToList().ForEach(it =>
                {
                    if (fomaplist.Any(f => f.Name.Equals(it, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        _packs.Add(fomaplist.Find(f => f.Name.Equals(it, StringComparison.InvariantCultureIgnoreCase)));
                    }
                });
                #region Dummy file creation
                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */
                /* Place dummy extraction file to execute the required batches to extract and run the zone a files and data load */
                /* -------------- *** -------------- *** -------------- *** -------------- *** -------------- *** -------------- */

                if (_packs.Any(x => x.Name.Equals("job", StringComparison.InvariantCultureIgnoreCase)))
                {
                    _filecontent.Add("ce");
                }

                if (_packs.Any(x => x.Name.Equals("job_country_specific", StringComparison.InvariantCultureIgnoreCase)))
                {
                    _filecontent.Add("csce");
                }

                if (_packs.Any(x => x.Name.Equals("timeoff", StringComparison.InvariantCultureIgnoreCase)))
                {
                    _filecontent.Add("employeetimeoff");
                }

                if (_packs.Any(x => x.Group.Contains("fo", StringComparison.InvariantCultureIgnoreCase) || x.Table_Name.Contains("FO", StringComparison.InvariantCultureIgnoreCase)))
                {
                    _filecontent.Add("fo");
                }

                if (_packs.Any(x => x.Group.Contains("talent", StringComparison.InvariantCultureIgnoreCase)))
                {
                    _filecontent.Add("talent");
                }

                _filecontent.ForEach(fname =>
                {
                    var xfilename = $@"{Util.DownloadFolder}\file_{fname}_.txt";
                    using (StreamWriter zfile = new StreamWriter(File.Create(xfilename)) { AutoFlush = true })
                    {
                        zfile.WriteLine(fname);
                    }
                    _filenames.Add(xfilename);
                });
                #endregion
                parameter.Driver.Url = $@"{Util.DirectoryPath}\dataloading.html";
                Util.CopyEnvironmentfile();
                Util.CopyFileToShare(_filenames);

            }
            #endregion
        }
    }

    public class WorkFlowParameter
    {
        public IWebDriver Driver { get; set; }
        public WorkFlowType Type { get; set; }
        public dynamic Prop { get; set; }
        public List<string> FoObjectname { get; set; } = new List<string>();
    }

    public enum WorkFlowType
    {
        All,
        EmployeeTimeOff,
        NoShow,
        Termination,
        ClassChange,
        GlobalAssignment,
        DataChange,
        AddressChange
    }
}
