﻿namespace Pom.PageObjects
{
    using NUnit.Framework;
    using OpenQA.Selenium;
    using Pom;
    using SF.Parameter;
    using System;
    using System.Data;
    /// <summary>
    /// This Class contains the database validations for the Core HR Scenarios. 
    /// Querys are dynamically generated based on the query template hardcoded to the scripts. 
    /// Enchancement can be made based on request or demand
    /// For most scenarios, the key data combinations are primarly validated while creating the dynamic query.
    /// </summary>
    public class DBValidations : MasterPage
    {
        public DBValidations(IWebDriver driver) : base(driver)
        {
        }

        public void Validate_TerminatedRecords(TerminateParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select JobInfo.UserId, JobInfo.EffectiveStartDate, EventReasonId, Employmentinfo.TerminationDate from  EC.CH_JobInfo as JobInfo INNER JOIN EC.CH_Employmentinfo as Employmentinfo On JobInfo.UserId = Employmentinfo.UserId Where Employmentinfo.TerminationReason IS NOT NULL and JobInfo.UserId = '{data.userId}' and Employmentinfo.TerminationDate >= '{data.startDate:yyyy-MM-dd}' Order by JobInfo.EffectiveStartDate desc, JobInfo.SequenceNumber desc ";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(data.userId, firstRow.ItemArray[0], "User ID not matching");
                        //Assert.AreEqual(data.startDate.AddDays(1), firstRow.ItemArray[1], "Effective Date not matching"); //effective day will +1 day
                        Assert.AreEqual(data.eventReason, firstRow.ItemArray[2], "Termination Reason not matching");
                        //Assert.AreEqual(data.TerminationDate, firstRow.ItemArray[3], "Termination Date not matching");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_StartDateChange(DataChangeParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select JobInfo.UserId,JobInfo.EffectiveStartDate,Employmentinfo.HireDate,Employmentinfo.OriginalStartDate from  EC.CH_JobInfo as JobInfo INNER JOIN EC.CH_Employmentinfo as Employmentinfo On JobInfo.UserId=Employmentinfo.UserId Where Employmentinfo.TerminationDate IS  NULL and JobInfo.DeleteFlag = 'N' and JobInfo.UserId = '{data.userId}'  and JobInfo.EffectiveStartDate >= '{data.startDate}'; ";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(firstRow.ItemArray[0], data.userId, "User ID not matching");
                        //Assert.AreEqual(firstRow.ItemArray[1], data.startDate, "Date not matching");
                        //Assert.AreEqual(firstRow.ItemArray[2], data.hireDate, "Termination Reason not matching");
                        //Assert.AreEqual(firstRow.ItemArray[3], data.originalStartDate, "Termination Date Reason not matching");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_LongTermDisability(TimeOffParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select jobinfo.userid,eventreason.description,timeoff.startdate  from ec.ch_jobinfo as jobinfo inner join ec.ch_employeetimeoff as timeoff on jobinfo.userid = timeoff.userid inner join dbo.fo_eventreason as eventreason on jobinfo.eventreasonid = eventreason.eventreasonid where jobinfo.userid = '{data.personIdExternal}' and jobinfo.deleteflag = 'n' and jobinfo.eventid = '10'and eventreason.eventreasontitle like '{data.LeaveTypeCode}%' and timeoff.loaactualreturndate is null and jobinfo.EffectiveStartDate = timeoff.StartDate and timeoff.startdate= '{data.startDate.AddDays(1):yyyy-MM-dd}';";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(firstRow.ItemArray[0], data.personIdExternal, "User ID not matching");
                        //Assert.AreEqual(firstRow.ItemArray[1], data.LeaveDescription, "Description not as Expected");
                        //Assert.AreEqual(firstRow.ItemArray[2], data.startDate, "Date not matching");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_UnPaidLeaveData(TimeOffParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select distinct jobinfo.userid,timeoff.startdate,timeoff.EndDate,eventreason.description,jobinfo.EventReasonId,jobinfo.LeaveOfAbsenceStartDate,timeoff.LoaActualReturnDate from ec.ch_jobinfo as jobinfo inner join ec.ch_employeetimeoff as timeoff on jobinfo.userid = timeoff.userid inner join dbo.fo_eventreason as eventreason on jobinfo.eventreasonid = eventreason.eventreasonid where jobinfo.userid = '{data.personIdExternal}' and jobinfo.deleteflag = 'n' and jobinfo.eventid = '10'and timeoff.TimeType like '%{data.LeaveTypeCode}%' and timeoff.loaactualreturndate is null and jobinfo.EffectiveStartDate = timeoff.StartDate and timeoff.startdate= '{data.startDate:yyyy-MM-dd}';";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "User ID not matching");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[1], "start Date not matching");
                        //Assert.AreEqual(data.endDate, firstRow.ItemArray[2], "end Date not matching");
                        //Assert.AreEqual(firstRow.ItemArray[3], data.RequestType, "Request Type not as Expected");
                        Assert.AreEqual(data.LeaveDescription, firstRow.ItemArray[3], "Leave Description not matching");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Vaidate_PaidLeaveData(TimeOffParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select distinct jobinfo.userid,timeoff.startdate,timeoff.EndDate,eventreason.description,jobinfo.EventReasonId,jobinfo.LeaveOfAbsenceStartDate,timeoff.LoaActualReturnDate from ec.ch_jobinfo as jobinfo inner join ec.ch_employeetimeoff as timeoff on jobinfo.userid = timeoff.userid inner join dbo.fo_eventreason as eventreason on jobinfo.eventreasonid = eventreason.eventreasonid where jobinfo.UserId = '{data.personIdExternal}' and jobinfo.deleteflag = 'n' and jobinfo.eventid = '10'and timeoff.TimeType like '%{data.LeaveTypeCode}%' and timeoff.loaactualreturndate is null and jobinfo.EffectiveStartDate = timeoff.StartDate and timeoff.startdate= '{data.startDate:yyyy-MM-dd}';";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "User ID not matching");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[1], "start Date not matching");
                        //Assert.AreEqual(data.endDate, firstRow.ItemArray[2], "end Date not matching");
                        //Assert.AreEqual(firstRow.ItemArray[3], data.RequestType, "Request Type not as Expected");
                        Assert.AreEqual(data.LeaveDescription, firstRow.ItemArray[3], "Leave Description not matching");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_ReturnFromPaidLeaveData(TimeOffParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select distinct jobinfo.userid,timeoff.startdate,timeoff.EndDate,eventreason.description,jobinfo.EventReasonId,jobinfo.LeaveOfAbsenceStartDate,timeoff.LoaActualReturnDate from ec.ch_jobinfo as jobinfo inner join ec.ch_employeetimeoff as timeoff on jobinfo.userid = timeoff.userid inner join dbo.fo_eventreason as eventreason on jobinfo.eventreasonid = eventreason.eventreasonid where jobinfo.UserId = '{data.personIdExternal}' and jobinfo.deleteflag = 'n' and jobinfo.eventid = '10'and timeoff.TimeType like '%{data.LeaveTypeCode}%' and timeoff.loaactualreturndate is not null and jobinfo.EffectiveStartDate = timeoff.StartDate and timeoff.startdate= '{data.startDate:yyyy-MM-dd}';";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "User ID not matching");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[1], "start Date not matching");
                        //Assert.AreEqual(data.endDate, firstRow.ItemArray[2], "end Date not matching");
                        //Assert.AreEqual(firstRow.ItemArray[3], data.RequestType, "Request Type not as Expected");
                        Assert.AreEqual(data.LeaveDescription.ToLower(), firstRow.ItemArray[3].ToString().ToLower(), "Leave Description not matching");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_ReturnFromUnPaidLeaveData(TimeOffParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            string query = $"select distinct jobinfo.userid,timeoff.startdate,timeoff.EndDate,eventreason.description,jobinfo.EventReasonId,jobinfo.LeaveOfAbsenceStartDate,timeoff.LoaActualReturnDate from ec.ch_jobinfo as jobinfo inner join ec.ch_employeetimeoff as timeoff on jobinfo.userid = timeoff.userid inner join dbo.fo_eventreason as eventreason on jobinfo.eventreasonid = eventreason.eventreasonid where jobinfo.userid = '{data.personIdExternal}' and jobinfo.deleteflag = 'n' and jobinfo.eventid = '10'and timeoff.TimeType like '%{data.LeaveTypeCode}%' and timeoff.loaactualreturndate is not null and jobinfo.EffectiveStartDate = timeoff.StartDate and timeoff.startdate= '{data.startDate:yyyy-MM-dd}';";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "User ID not matching");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[1], "start Date not matching");
                        //Assert.AreEqual(data.endDate, firstRow.ItemArray[2], "end Date not matching");
                        // Assert.AreEqual(firstRow.ItemArray[3], data.RequestType, "Request Type not as Expected");
                        Assert.AreEqual(data.LeaveDescription, firstRow.ItemArray[3], "Leave Description not matching");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public override void IntializePage()
        {
            Driver.Url = $@"{Util.DirectoryPath}\TDDH_Result.html";
        }

        public void Validate_AddressData(AddressParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            var query = $"select employmentinfo.userid,convert(date,addressinfo.startdate) as startdate,addressinfo.address1,addressinfo.address2,addressinfo.city,addressinfo.State,addressinfo.country,addressinfo.zipcode,c.Descr from ec.ch_employmentinfo as employmentinfo with(nolock) inner join ec.ch_addressinfo as addressinfo with(nolock) on employmentinfo.personid=addressinfo.personid left join Mapping_Country c with(nolock) on c.Country = addressinfo.Country where addressinfo.deleteflag='n' and employmentinfo.userid='{data.userId}' and addressinfo.addresstype = '{data.addressType}' and addressinfo.startdate >= '{data.startDate:yyyy-MM-dd}'";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(firstRow.ItemArray[0], data.userId, "UserId not matching..");
                        //Assert.AreEqual(firstRow.ItemArray[1], data.startDate, "Effective Date not matching..");
                        switch (firstRow.ItemArray[6])//if condition to check country then proceed with data validation
                        {
                            case "USA":
                                Assert.AreEqual(firstRow.ItemArray[2], data.address1, "Address line 1 not matching..");
                                Assert.AreEqual(firstRow.ItemArray[3], data.address2, "Address line 2 not matching..");
                                Assert.AreEqual(firstRow.ItemArray[4], data.city, "City not matching..");
                                //Assert.AreEqual(firstRow.ItemArray[5], data.state, "State not matching..");
                                Assert.AreEqual(firstRow.ItemArray[6], data.country, "Country not matching..");
                                Assert.AreEqual(firstRow.ItemArray[7], data.zipCode, "Zipcode not matching..");

                                break;

                            case "GBR"://Country Specific conditions to be added based on demand or request

                                break;

                            case " ":

                                break;

                            default:
                                Assert.AreEqual(firstRow.ItemArray[2], data.address1, "Address line 1 not matching..");
                                Assert.AreEqual(firstRow.ItemArray[3], data.address2, "Address line 2 not matching..");
                                Assert.AreEqual(firstRow.ItemArray[4], data.city, "City not matching..");
                                //Assert.AreEqual(firstRow.ItemArray[5], data.state, "State not matching..");
                                Assert.AreEqual(firstRow.ItemArray[6], data.country, "Country not matching..");
                                Assert.AreEqual(firstRow.ItemArray[7], data.zipCode, "Zipcode not matching..");
                                break;
                        }
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data is available with key data. SQL Query [{query}]", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }

        }

        public void Validate_BankDetails(BankChangeParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            var query = $"Select pay.userid,pay.effectivestartdate,pay.paytype,paymethod.eccode,countrymap.descr,bank.bankname,pay.accountnumber,pay.routingnumber,pay.paysequence from ec.ch_paymentdetails as pay inner join fo_bank as bank on bank.externalcode = pay.bank inner join mapping_paymentmethod as paymethod on paymethod.eccode = pay.paymentmethod inner join mapping_country as countrymap on countrymap.country = pay.bankcountry where pay.deleteflag = 'n' and pay.userid = '{data.userId}' and pay.effectivestartdate >= '{data.startDate:yyyy-MM-dd}' and pay.paytype = '{data.paymentType}';";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(data.userId, firstRow.ItemArray[0], "UserId not matching..");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[1], "Effective Date not matching..");
                        Assert.AreEqual(data.paymentType, firstRow.ItemArray[2], "payment Type not matching..");
                        Assert.AreEqual(data.paymentMethod, firstRow.ItemArray[3], "payment Method  not matching..");
                        Assert.AreEqual(data.country, firstRow.ItemArray[4], "country not matching..");
                        Assert.AreEqual(data.bankName, firstRow.ItemArray[5], "bank Name not matching..");
                        Assert.AreEqual(data.bankAccountNumber, firstRow.ItemArray[6], "bank Account Number Name not matching..");
                        Util.Updatelog($"Check payment data is populated for user {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", "Data is available as expected", State.Pass);
                        data.db_v_status = Constants.TVPass;
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_CounselorChangeData(DataChangeParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            var query = $"select distinct JobInfo.UserId,JobInfo.EffectiveStartDate,JobInfo.EventReasonId,jobinfo.Supervisor, JobInfo.SequenceNumber from Ec.CH_JobInfo as JobInfo Join FO_EventReason as EventReason ON EventReason.EventReasonID = JobInfo.EventReasonID Join EC.CH_PersonalInfo as PersonalInfo On PersonalInfo.GUI = JobInfo.Supervisor Where EventReason.EventReasonTitle = 'Change of Counselor' AND JobInfo.DeleteFlag = 'N'  AND JobInfo.UserId = '{data.userId}' AND JobInfo.EffectiveStartDate >= '{data.startDate:yyyy-MM-dd}' order by Jobinfo.EffectiveStartDate desc, JobInfo.SequenceNumber desc;";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(firstRow.ItemArray[0], data.userId, "UserId not matching..");
                        //Assert.AreEqual(firstRow.ItemArray[1], data.startDate, "Effective Date not matching..");
                        Assert.AreEqual(firstRow.ItemArray[2], data.eventReason, "Event reason Id not matching..");
                        Assert.AreEqual(firstRow.ItemArray[3], data.managerId, "Supervisor not matching..");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_DomesticTransferData(DataChangeParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            var query = $"select JobInfo.UserId,JobInfo.EffectiveStartDate,loc.WorkLocationID,EventReason.EventReasonTitle,Loc.WorkLocationTitle from Ec.CH_JobInfo as JobInfo Join FO_EventReason as EventReason ON EventReason.EventReasonID = JobInfo.EventReasonID Join FO_Location as Loc ON Loc.WorkLocationID = JobInfo.WorklocationId where JobInfo.DeleteFlag = 'N' AND EventReason.EventReasonTitle = 'Domestic Transfer' AND JobInfo.UserId = '{data.userId}' AND JobInfo.EffectiveStartDate >= '{data.startDate:yyyy-MM-dd}'AND Loc.IsCurrent='1' order by Jobinfo.EffectiveStartDate desc, JobInfo.SequenceNumber desc;";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(firstRow.ItemArray[0], data.userId, "UserId not matching..");
                        //Assert.AreEqual(firstRow.ItemArray[1], data.startDate, "Effective Date not matching..");
                        //  Assert.AreEqual(firstRow.ItemArray[2], data.eventReason, "Event reason Id not matching..");
                        Assert.AreEqual(firstRow.ItemArray[2], data.location, "Location Id not matching..");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_FTEChangeData(DataChangeParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            var query = $"select info.UserId,info.EffectiveStartDate, info.standardhours,info.ftehours,info.fte,reason.EventReasonTitle  from EC.CH_JobInfo as info  JOIN FO_EventReason as reason  ON reason.EventReasonID=info.EventReasonId  where info.EventReasonId='AAC' AND info.UserId='{data.userId}' AND info.EffectiveStartDate >='{data.startDate:yyyy-MM-dd}';";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(firstRow.ItemArray[0], data.userId, "UserId not matching..");
                        //Assert.AreEqual(firstRow.ItemArray[1], data.startDate, "Effective Date not matching..");
                        Assert.AreEqual(Convert.ToDouble($"{firstRow.ItemArray[2]}"), Convert.ToDouble($"{data.standardHours:0.00}"), "standard Hours not matching..");
                        Assert.AreEqual(Convert.ToDouble($"{firstRow.ItemArray[3]}"), Convert.ToDouble($"{data.ftehours:0.00}"), "fte hours not matching..");
                        Assert.AreEqual(Convert.ToDouble($"{firstRow.ItemArray[4]}"), Convert.ToDouble($"{data.fte:0.00}"), "fte not matching..");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_RankChange_Promotion(RankParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            var query = $"select distinct JobInfo.userId,JobInfo.EffectiveStartDate,JobInfo.RankId,JobInfo.JobClassificationId,EventReason.EventReasonTitle,JobInfo.SequenceNumber from EC.CH_JobInfo as JobInfo Join FO_EventReason as EventReason ON JobInfo.EventReasonId = EventReason.EventReasonID where JobInfo.DeleteFlag = 'N' AND JobInfo.UserId = '{data.userId}' AND JobInfo.EffectiveStartDate >= '{data.startDate:yyyy-MM-dd}' AND EventReason.EventReasonTitle = 'Demotion' order by Jobinfo.EffectiveStartDate desc, JobInfo.SequenceNumber desc";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(firstRow.ItemArray[0], data.userId, "UserId not matching..");
                        //Assert.AreEqual(firstRow.ItemArray[1], data.startDate, "Effective Date not matching..");
                        Assert.AreEqual(firstRow.ItemArray[2], data.rankId, "Rank Id not matching..");
                        Assert.AreEqual(firstRow.ItemArray[3], data.jobcode, "Job Classification Id not matching..");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_RankChange_Demotion(RankParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            var query = $"select distinct JobInfo.userId,JobInfo.EffectiveStartDate,JobInfo.RankId,JobInfo.JobClassificationId,EventReason.EventReasonTitle,JobInfo.SequenceNumber from EC.CH_JobInfo as JobInfo Join FO_EventReason as EventReason ON JobInfo.EventReasonId = EventReason.EventReasonID where JobInfo.DeleteFlag = 'N' AND JobInfo.UserId = '{data.userId}' AND JobInfo.EffectiveStartDate >= '{data.startDate:yyyy-MM-dd}' AND EventReason.EventReasonTitle = 'Promotion' order by Jobinfo.EffectiveStartDate desc, JobInfo.SequenceNumber desc";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];
                        Assert.AreEqual(firstRow.ItemArray[0], data.userId, "UserId not matching..");
                        //Assert.AreEqual(firstRow.ItemArray[1], data.startDate, "Effective Date not matching..");
                        Assert.AreEqual(firstRow.ItemArray[2], data.rankId, "Rank Id not matching..");
                        Assert.AreEqual(firstRow.ItemArray[3], data.jobcode, "Job Classification Id not matching..");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_StandardHourData(DataChangeParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            var query = $"select info.UserId,info.EffectiveStartDate, info.standardhours,info.ftehours,info.fte,reason.EventReasonTitle  from EC.CH_JobInfo as info  JOIN FO_EventReason as reason  ON reason.EventReasonID=info.EventReasonId  where info.EventReasonId='AAC' AND info.UserId='{data.userId}' AND info.EffectiveStartDate >= '{data.startDate:yyyy-MM-dd}';";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(data.userId, firstRow.ItemArray[0], "UserId not matching..");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[1], "Effective Date not matching..");
                        Assert.AreEqual(Convert.ToDouble(data.standardHours), Convert.ToDouble($"{firstRow.ItemArray[2]}"), "standard Hours not matching..");
                        Assert.AreEqual(Convert.ToDouble(data.ftehours), Convert.ToDouble($"{firstRow.ItemArray[3]}"), "fte hours not matching..");
                        Assert.AreEqual(Convert.ToDouble(data.fte), Convert.ToDouble($"{firstRow.ItemArray[4]}"), "fte not matching..");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_ClassChange(ClassChangeParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);

            var query = $"SELECT DISTINCT EMP.GUI,EMP.USERID,Convert(date,JOB.EFFECTIVESTARTDATE) as StartDate,JOB.EVENTREASONID,JOB.GPN,JOB.LPN,JOB.COUNTRY,FE.EventReasonTitle,ECLASS.LabelDefault AS EMPLOYEECLASS,ETYPE.LabelDefault AS EMPLOYEETYPE,Job.SequenceNumber FROM EC.CH_EMPLOYMENTINFO EMP WITH(NOLOCK) INNER JOIN  EC.CH_JOBINFO JOB With(nolock) ON EMP.EMPLOYMENTID = JOB.EMPLOYMENTID LEFT JOIN DBO.FO_EVENTREASON FE WITH(NOLOCK) ON FE.EVENTREASONID = JOB.EVENTREASONID AND FE.ISCURRENT = 1 LEFT JOIN FO_XLAT ECLASS WITH(NOLOCK) ON ECLASS.ExternalCode = JOB.EmployeeClassId and ECLASS.PicklistId = 'EMPLOYEECLASS' LEFT JOIN FO_XLAT ETYPE WITH(NOLOCK) ON ETYPE.ExternalCode = JOB.EmployeeTypeId and ETYPE.PicklistId = 'employmentType' Where  (Job.UserId = '{data.userId}' or Emp.GUI = '{data.personIdExternal}') and Job.EffectiveStartDate >= '{data.startDate:yyyy-MM-dd}'  Order by StartDate Desc, Job.SequenceNumber desc;";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "GUI ID not matching");
                        Assert.AreEqual(data.userId, firstRow.ItemArray[1], "User  ID not matching");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[2], "Start/Effective Date not matching");
                        Assert.AreEqual(data.employeeClass, firstRow.ItemArray[8], "Employee Class not matching");
                        Assert.AreEqual(data.employmentType, firstRow.ItemArray[9], "Employement Type not matching");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
                SystemWait(2);
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_Department_Change(DataChangeParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);

            var query = $"select distinct top 100 emp.gui,emp.userid,convert(date,job.effectivestartdate) as startdate,job.eventreasonid,job.gpn,job.lpn,job.country,fe.eventreasontitle,job.departmentid,dept.description,job.sequencenumber from ec.ch_employmentinfo emp with(nolock) inner join  ec.ch_jobinfo job with(nolock) on emp.employmentid = job.employmentid left join dbo.fo_eventreason fe with(nolock) on fe.eventreasonid = job.eventreasonid and fe.iscurrent = 1 left join fo_department dept with(nolock) on dept.departmentid = job.departmentid where (job.userid = '{data.userId}' or emp.gui = '{data.personIdExternal}') and job.effectivestartdate >= '{data.startDate:yyyy-MM-dd}' order by startdate desc, job.sequencenumber desc";
            var dataTable = SQLConnect.ReadFromServerAsTable(query);

            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        //Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "GUI ID not matching");
                        Assert.AreEqual(data.userId, firstRow.ItemArray[1], "User  ID not matching");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[2], "Start/Effective Date not matching");

                        if (!data.departmentid.ToLower().Equals("choose random"))
                        {
                            Assert.AreEqual(data.departmentid, firstRow.ItemArray[8], "Department id not matching with input");
                        }
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
                SystemWait(2);
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_MCChangeRecords(DataChangeParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);
            var query = $"select p.gui,j.userid,convert(date, j.EffectiveStartDate) as [startdate],j.EventReasonId,j.gpn,j.lpn,j.Country,fe.EventReasonTitle,j.SequenceNumber,j.ManagerialCountryId,j.ManagementRegionId,j.ManagementAreaId from ec.ch_jobinfo j with(nolock) inner join ec.CH_PersonalInfo p with(nolock) on p.PersonId = j.PersonId and p.gui = '{data.personIdExternal}' left join dbo.fo_eventreason fe with(nolock) on fe.eventreasonid = j.eventreasonid and fe.iscurrent = 1 order by j.EffectiveStartDate desc, j.SequenceNumber desc, convert(bigint, j.UserId) desc";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);
                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        //Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "GUI ID not matching");
                        Assert.AreEqual(data.userId, firstRow.ItemArray[1], "User  ID not matching");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[2], "Start/Effective Date not matching");
                        Assert.AreEqual(data.eventReason, firstRow.ItemArray[3], "Event Reason Not matching");
                        Assert.AreEqual(data.managementcountryid, firstRow.ItemArray[9], "Management Country Id not matching");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
                SystemWait(2);
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_ConcurrentAssignment(DataChangeParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);

            var query = $"select p.gui,j.userid,convert(date,j.EffectiveStartDate) as [startdate],j.EventReasonId,j.gpn,j.lpn,j.Country,fe.EventReasonTitle,j.SequenceNumber,j.ManagerialCountryId,j.ManagementRegionId,j.ManagementAreaId from ec.ch_jobinfo j with(nolock) inner join ec.CH_PersonalInfo p with(nolock) on p.PersonId = j.PersonId and p.gui = '{data.personIdExternal}' left join dbo.fo_eventreason fe with(nolock) on fe.eventreasonid = j.eventreasonid and fe.iscurrent = 1 order by j.EffectiveStartDate desc, j.SequenceNumber desc, convert(bigint,j.UserId) desc";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        //Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "GUI ID not matching");
                        Assert.AreEqual(data.userId, firstRow.ItemArray[1], "User  ID not matching");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[2], "Start/Effective Date not matching");
                        Assert.AreEqual(data.eventReason, firstRow.ItemArray[3], "Event Reason not matching");
                        //Assert.AreEqual(data.managementcountryid, firstRow.ItemArray[16], "Employee Class not matching");
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
                SystemWait(2);
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_GlobalAssignment(GlobalAssignmentParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);

            var query = $"select distinct emp.gui,emp.userid,convert(date,job.effectivestartdate) as startdate,job.eventreasonid,job.gpn,job.lpn,job.country,fe.eventreasontitle,job.sequencenumber,job.GeographicAreaId,job.GeographicRegionId,job.ManagementAreaId,job.ManagementRegionId,job.ServiceLineId,job.SubServiceLineId,job.DepartmentId,job.ManagerialCountryId from ec.ch_employmentinfo emp with(nolock) inner join ec.ch_jobinfo job with(nolock) on emp.employmentid = job.employmentid left join dbo.fo_eventreason fe with(nolock) on fe.eventreasonid = job.eventreasonid and fe.iscurrent = 1 where(job.userid = '{data.userId}' or emp.gui = '{data.personIdExternal}') order by startdate desc, job.sequencenumber desc; ";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        //Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "GUI ID not matching");
                        Assert.AreEqual(data.userId, firstRow.ItemArray[1], "User  ID not matching");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[2], "Start/Effective Date not matching");
                        //Assert.AreEqual(data.eventReason, firstRow.ItemArray[3], "Event reason not matching with first record");
                        //Assert.AreEqual(data.company, firstRow.ItemArray[16], "Legal entity id not matching"); // to be corrected
                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
                SystemWait(2);
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }

        public void Validate_EndGAAssignment(GlobalAssignmentParameter data)
        {
            data.db_v_status = Constants.TVFail;
            ResetResultView(out IWebElement queryObject, out IWebElement tableObject);

            var query = $"select distinct emp.gui,emp.userid,convert(date,job.effectivestartdate) as startdate,job.eventreasonid,job.gpn,job.lpn,job.country,fe.eventreasontitle,job.sequencenumber,job.GeographicAreaId,job.GeographicRegionId,job.ManagementAreaId,job.ManagementRegionId,job.ServiceLineId,job.SubServiceLineId,job.DepartmentId,job.ManagerialCountryId from ec.ch_employmentinfo emp with(nolock) inner join ec.ch_jobinfo job with(nolock) on emp.employmentid = job.employmentid left join dbo.fo_eventreason fe with(nolock) on fe.eventreasonid = job.eventreasonid and fe.iscurrent = 1 where(job.userid = '{data.userId}' or emp.gui = '{data.personIdExternal}') order by startdate desc, job.sequencenumber desc; ";

            var dataTable = SQLConnect.ReadFromServerAsTable(query);
            if (dataTable != null)
            {
                UpdateQueryView(queryObject, query);
                UpdateResultView(tableObject, dataTable);

                try
                {
                    if (dataTable.Rows.Count != 0)
                    {
                        DataRow firstRow = dataTable.Rows[0];

                        //Assert.AreEqual(data.personIdExternal, firstRow.ItemArray[0], "GUI ID not matching");
                        Assert.AreEqual(data.userId, firstRow.ItemArray[1], "User  ID not matching");
                        //Assert.AreEqual(data.startDate, firstRow.ItemArray[2], "Start/Effective Date not matching");
                        Assert.AreEqual(data.eventReason, firstRow.ItemArray[3], "Event reason not matching");

                        data.db_v_status = Constants.TVPass;
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data available.<br>SQL Query [{query}] ", State.Pass);
                    }
                    else
                    {
                        Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] ", State.Fail);
                    }
                }
                catch (Exception e) { Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data not available.<br>SQL Query [{query}] <br> Exception : {e.Message} ", State.Fail); }
                SystemWait(2);
            }
            else
            {
                Util.Updatelog($"Execute Query for : User - {data.userId} | Effective Date : {data.startDate:yyyy-MM-dd} ", $"Data Not available.<br>SQL Query [{query}] ", State.Fail);
            }
        }
    }
}