﻿namespace EY_Test.PageObjects.CPI_Portal
{
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using System;

    public enum ModalTab
    {
        Sender,
        Receiver,
        More
    }

    public class CPIWorkflow : MasterPage
    {
        private By configurebutton = By.XPath("//bdi[text()='Configure']/ancestor::button");
        private By deployebutton = By.XPath("//bdi[text()='Deploy']/ancestor::button");
        private By modal = By.XPath("//div[contains(@class,'sapMDialog') and contains(@style,'display')]");
        private By modal_More = By.XPath(".//div[@class='sapMITBHead']//span[text()='More']"); // to be used with modal element only

        private IWebElement modalwindow = null;

        public CPIWorkflow(IWebDriver driver) : base(driver)
        {

        }

        public override void IntializePage()
        {

        }

        public void Configure()
        {

            Click(configurebutton);
            WaitTillCPIPageLoaderCompletes(10);

            if (IsDisplayed(modal))
            {
                modalwindow = Find(modal);
                Util.Updatelog("Check if the configure modal is displayed", "Configure modal is displayed", State.Pass);
            }
            else
            {
                Util.Updatelog("Check if the configure modal is displayed", "Configure modal is not displayed", State.Fail);
            }
        }

        public void SetEmployeeId(string employee)
        {
            try
            {
                SetImplicitWait(2);
                By txt = By.XPath("//bdi[text()='Employee IDs']/ancestor::div[contains(@class,'sapUiSimpleForm')]//input");
                if (IsExists(txt))
                {
                    Clear(txt);
                    SetText(txt, employee, 3);
                }
                else
                {
                    Util.Updatelog("Enter employee id's", "Filed to add employee not availlable", State.Done);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
        public void SetCutOffDate(DateTime cutOffDate)
        {
            try
            {
                SetImplicitWait(2);
                By txt = By.XPath("//bdi[contains(text(),'CutOff-Date') or contains(text(),'Cut-Off Date')]/ancestor::div[contains(@class,'sapUiSimpleForm')]//input");
                if (IsDisplayed(txt))
                {
                    Clear(txt);
                    SetText(txt, $"{cutOffDate:yyyy-MM-dd}T00:00:00", 3);
                }
            }
            catch (Exception)
            {

            }
        }

        public void CloseModal()
        {
            Click(By.XPath("//bdi[text()='Close']/ancestor::button"));
        }

        public bool IsRunning() => Finds(By.XPath("//div[contains(text(),'Runtime Status: Started')]")).Count > 0;

        public void SetManualLastRun(DateTime cutOffDate)
        {
            try
            {
                SetImplicitWait(2);
                By txt = By.XPath("//bdi[contains(text(),'Manual Last Run Time')]/ancestor::div[contains(@class,'sapUiSimpleForm')]//input");
                if (IsExists(txt))
                {
                    Clear(txt);
                    SetText(txt, $"{cutOffDate:yyyy-MM-dd}T00:00:00", 3);
                }
            }
            catch (Exception)
            {

            }
        }

        /// <summary>
        /// This is to capture the previous job info, Only the field which are going to be edited will be captured here.
        /// </summary>
        public CPIJobInfo CaptureValues()
        {
            By cutoffpath = By.XPath("//bdi[contains(text(),'CutOff-Date') or contains(text(),'Cut-Off Date')]/ancestor::div[contains(@class,'sapUiSimpleForm')]//input");
            By manuallastruntime = By.XPath("//bdi[contains(text(),'Manual Last Run Time')]/ancestor::div[contains(@class,'sapUiSimpleForm')]//input");
            By employeeids = By.XPath("//bdi[contains(text(),'Employee')]/ancestor::div[contains(@class,'sapUiSimpleForm')]//input");
            By cwrworker = By.XPath("//bdi[contains(text(),'Contingent Worker')]/ancestor::div[contains(@class,'sapUiSimpleForm')]//input");
            CPIJobInfo jobdata = new CPIJobInfo
            {
                CutOffDate = IsExists(cutoffpath) ? GetAttribute(cutoffpath, "value") : $"{DateTime.Now:yyyy-MM-dd}T00:00:00",
                ManualLastRunTime = IsExists(manuallastruntime) ? GetAttribute(manuallastruntime, "value") : $"{DateTime.Now:yyyy-MM-dd}T00:00:00",
                EmployeeIDs = IsExists(employeeids) ? GetAttribute(employeeids, "value") : "NA",
                ContingentWorker = IsExists(cwrworker) ? GetAttribute(cwrworker, "value") : "NA"
            };

            TestLog.Info($"The Previous State of the Job is as Follows {jobdata}"); return jobdata;
        }

        public void UndoChanges(string artifactname)
        {
            By searchBox = By.XPath("//input[contains(@id,'_SEARCH')]");
            By artifactRow = By.XPath($"//span[contains(@title,'{artifactname}')]/ancestor::tr");
            By undeployButton = By.XPath("//bdi[contains(.,'Undeploy')]/..");
            By confrimDialog = By.XPath("//div[@role='dialog' and contains(@style,'block')]");
            By yesBtn = By.XPath("//div[@role='dialog' and contains(@style,'block')]//bdi[contains(text(),'Yes')]/..");

            // Logic to apply the undeployment of the Job.
            Driver.Navigate().Back();
            WaitTillPageLoadingCompletes();
            Clear(searchBox);
            SetText(searchBox, artifactname);

            WaitUntilElementDisplayed(artifactRow);
            Click(artifactRow);
            Click(undeployButton);

            WaitUntilElementDisplayed(confrimDialog);
            Click(yesBtn);
        }

        /// <summary>
        /// To be reworked base on time
        /// </summary>
        public void SaveAndDeploy()
        {
            SetImplicitWait(5);
            var deploybtn = modalwindow.FindElement(By.XPath(".//bdi[text()='Deploy']/ancestor::button"));
            var savebtn = modalwindow.FindElement(By.XPath(".//bdi[text()='Save']/ancestor::button"));
            By confirmationsave = By.XPath("//span[text()='Confirmation']/ancestor::div[@role='alertdialog']//bdi[text()='Save']/ancestor::button");
            By closeBtn = By.XPath("//span[contains(text(),'Messages')]/ancestor::div[@role='dialog']//bdi[text()='Close']/ancestor::button");
            //Save
            try
            {
                if (savebtn.Displayed)
                {
                    savebtn.Click();
                    WaitTillCPIPageLoaderCompletes(30);
                    Util.Updatelog("Save configuration for the package", "package saved", State.Done);
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Not Saved!");
            }

            try
            {
                if (IsDisplayed(closeBtn))
                {
                    Click(closeBtn);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            try
            {
                if (deploybtn.Displayed)
                {
                    deploybtn.Click();
                    var yesbutton = By.XPath("//bdi[text()='Yes']/ancestor::button");
                    var okbutton = By.XPath("//bdi[text()='OK']/ancestor::button");
                    if (IsExists(yesbutton)) Click(yesbutton, 10);
                    WaitTillCPIPageLoaderCompletes(35);
                    Util.Updatelog("Deploy", "Package Deployed", State.Pass);
                    if (IsExists(okbutton)) Click(okbutton, 10);
                }
                else
                {
                    Util.Updatelog("Deploy", "Unable to deploy", State.Fail);
                }
            }
            catch (Exception)
            {
                Util.Updatelog("Exception Occured in CPI Work flow", "Please Check", State.Skip);
            }
        }

        public string GetServiceUrl()
        {
            By endpoint_txt = By.XPath("//bdi[text()='Address']/ancestor::div[contains(@class,'endpoint')]//input");
            WaitUntilElementDisplayed(endpoint_txt);
            return Find(endpoint_txt).GetAttribute("value");
        }

        public string GetSFTPLocation()
        {
            By rec = By.XPath("//div[contains(@class,'endpointsCombo')]");
            By sftp_val = By.XPath("//li[contains(.,'SFTP')]");
            By endpoint_txt = By.XPath("//bdi[text()='Directory']/ancestor::div[contains(@class,'endpoint')]//input");

            WaitUntilElementDisplayed(rec);
            Click(rec);

            WaitUntilElementDisplayed(sftp_val);
            Click(sftp_val);

            WaitUntilElementDisplayed(endpoint_txt);
            Click(endpoint_txt);
            return Find(endpoint_txt).GetAttribute("value").Trim();
        }

        public void ChooseModalTab(ModalTab tab)
        {
            var btn = modalwindow.FindElement(By.XPath($".//span[text()='{tab}']"));
            Click(btn);
            Util.Updatelog("Choose the more tab", "Tab Selected", State.Pass);

        }

        public CPIIntegration GetDeploymentInfo()
        {
            By restorbtn = By.XPath("//span[contains(@id,'restore-btn')]/ancestor::button");
            By deploymenttab = By.XPath("//span[text()='Deployment Status']/ancestor::div[@class='sapMITBFilterWrapper']");
            By statusObject = By.XPath("//span[contains(@id,'deploymentStatus-ObjectStatus-text')]");

            By integrationRunlink = By.LinkText("Navigate to Manage Integration Content");

            if (IsDisplayed(restorbtn))
            {
                WaitTillCPIPageLoaderCompletes(15);
                Click(restorbtn);
                WaitTillCPIPageLoaderCompletes(15);
                Click(deploymenttab);
                WaitTillTheTextIs(statusObject, "Started");
                WaitUntilElementDisplayed(integrationRunlink, 20);
                SystemWait(15);
                //Click(integrationRunlink);
                //SwtichToNewTab();                
                return new CPIIntegration(Driver);
            }
            else
            {
                TestLog.Info("Restore button not visible");
                return new CPIIntegration(Driver);
            }
        }

        internal void SetContingentWorker(string contingentWorker)
        {
            try
            {
                SetImplicitWait(2);
                By txt = By.XPath("//bdi[contains(text(),'Contingent Worker')]/ancestor::div[contains(@class,'sapUiSimpleForm')]//input");
                if (IsExists(txt))
                {
                    Clear(txt);
                    SetText(txt, contingentWorker, 3);
                }
            }
            catch (Exception)
            {

            }
        }
    }

    public class CPIJobInfo
    {
        public string CutOffDate { get; set; }
        public string ManualLastRunTime { get; set; }
        public string EmployeeIDs { get; set; }
        public string ContingentWorker { get; set; }

        public override string ToString()
        {
            return $"| Cut off Date: {CutOffDate} \t | Manaual Last Run time: {ManualLastRunTime} \t | Employee ID: {EmployeeIDs}";
        }
    }
}