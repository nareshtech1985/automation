﻿namespace EY_Test.PageObjects.CPI_Portal
{
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;

    public class CPIPackage : MasterPage
    {

        public CPIPackage(IWebDriver driver) : base(driver)
        {

        }

        public override void IntializePage()
        {

        }

        public void ChooseTab(PackageTab tab)
        {
            By tb = By.XPath($"//bdi[contains(text(),'{tab}')]/ancestor::button");
            Click(tb, 30);
            WaitTillCPIPageLoaderCompletes(30);
            WaitTillArtifactPageLoadingCompletes(30);
        }

        public CPIWorkflow SearchandSelectArtifact(string artifactname)
        {
            TestLog.Info($"Initiating search for artifact {artifactname}");
            By filter = By.CssSelector("input[placeholder*='Filter Artifacts']");
            WaitTillCPIPageLoaderCompletes(30);
            if (IsExists(filter, 30))
            {
                Clear(filter);
                SetText(filter, artifactname, 3);
                var resultItem = By.XPath($"//bdi[text()='{artifactname}']/ancestor::tr");
                if (IsExists(resultItem))
                {
                    Click(resultItem);
                    WaitTillCPIPageLoaderCompletes(30);
                    WaitTillArtifactPageLoadingCompletes(30);
                    Util.Updatelog("Choose the package", $"Package {resultItem} selected", State.Pass);
                    return new CPIWorkflow(Driver);
                }
                else
                {
                    Util.Updatelog("Select artifact", "artifact not selectable", State.Fail);
                    return null;
                    //throw new FrameworkException("Artifact not selectable!");
                }
            }
            else
            {
                Util.Updatelog("Select artifact", "artifact not displayed", State.Fail);
                //throw new FrameworkException("Artifact filter option not displayed!");
                return null;
            }
        }

    }

    public enum PackageTab
    {
        Overview,
        Artifacts,
        Documents,
        Tags
    }
}