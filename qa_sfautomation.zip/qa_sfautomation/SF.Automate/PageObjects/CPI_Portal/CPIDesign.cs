﻿namespace EY_Test.PageObjects.CPI_Portal
{
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;

    public class CPIDesign : MasterPage
    {
        private By filtertxt = By.CssSelector("input[type='search'][placeholder='Filter']");
        private By listItems = By.CssSelector("tbody.sapMListItems tr");

        public CPIDesign(IWebDriver driver) : base(driver)
        {
        }

        public override void IntializePage()
        {
        }

        public void SearchPackages(string searchkey)
        {
            WaitTillCPIPageLoaderCompletes(5);
            Clear(filtertxt);
            SetText(filtertxt, searchkey, 4);
            WaitTillCPIPageLoaderCompletes(2);

            var items = Finds(listItems);

            if (items.Count >= 1)
            {
                Util.Updatelog($"Search by {searchkey}", "Result found", State.Pass);
            }
            else
            {
                throw new FrameworkException("Search yeilded no results");
            }
        }

        public CPIPackage SelectFirstPackage(string packagename)
        {
            By packageresult = By.XPath($"//span[@title='{packagename}']");

            if (!IsExists(packageresult, 30))
            {
                throw new FrameworkException("Expected Package not found in the result");
            }

            var items = Finds(listItems);

            if (items.Count >= 1)
            {
                Click(items[0]);
                WaitTillCPIPageLoaderCompletes(15);
                Util.Updatelog($"Select the first package", "package selected", State.Pass);
                return new CPIPackage(Driver);
            }
            else
            {
                throw new FrameworkException("Packagae not found");
            }
        }
    }
}