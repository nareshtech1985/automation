﻿/* Modified by QA Team */

namespace EY_Test.PageObjects.CPI_Portal
{
    using cryptic;
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using System;
    public class CPIHome : MasterPage
    {
        private By username = By.CssSelector("input#j_username");
        private By password = By.CssSelector("input#j_password");
        private By loginbutton = By.CssSelector("#logOnFormSubmit");


        /* variables for decryption */
        private readonly Credential Credential = Util.TestConfiguration.Credentials.Find(x => x.Name.Equals("IFlow", StringComparison.InvariantCultureIgnoreCase));
        private readonly Cred CypherProgram = new Cred() { Publickey = Util.TestConfiguration.GetCustomKeyValue("publicKey") };

        public CPIHome(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {
            Driver.Url = "https://e2133-tmn.hci.eu1.hana.ondemand.com/itspaces/shell/design";
        }

        public void Login()
        {
            try
            {
                WaitTillCPIPageLoaderCompletes(10);
                WaitUntilElementDisplayed(username);
                if (IsExists(username, 10))
                {
                    Clear(username, 3);
                    SetText(username, Credential.UserName);
                    Find(username).SendKeys(Keys.Enter);
                    Clear(password, 3);
                    SetPasswordText(password, CypherProgram.Decrypt(Credential.Password));
                    Click(loginbutton);
                }
            }
            catch (Exception e) { Console.WriteLine(e.Message); throw new FrameworkException("Unable to login to the CPI Portal"); }
        }

        public CPIDesign NavigateToDesign()
        {
            WaitTillCPIPageLoaderCompletes(30);
            Driver.Url = "https://e2133-tmn.hci.eu1.hana.ondemand.com/itspaces/shell/design";
            WaitTillCPIPageLoaderCompletes(30);
            return new CPIDesign(Driver);
        }
    }
}