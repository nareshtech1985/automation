﻿/***
 *  IFLOW Job Selection & Mapping
 *
 */
namespace IFlow
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using System.Collections.Generic;
    using System.Globalization;

    public partial class CpiPackageConfig
    {
        [JsonProperty("CPI", NullValueHandling = NullValueHandling.Ignore)]
        public List<Cpi> Cpi { get; set; }
    }

    public partial class Cpi
    {
        [JsonProperty("environment", NullValueHandling = NullValueHandling.Ignore)]
        public string Environment { get; set; }

        [JsonProperty("packagename", NullValueHandling = NullValueHandling.Ignore)]
        public string Packagename { get; set; }

        [JsonProperty("integrations", NullValueHandling = NullValueHandling.Ignore)]
        public List<Integration> Integrations { get; set; }
    }

    public partial class Integration
    {
        [JsonProperty("artifactshortname", NullValueHandling = NullValueHandling.Ignore)]
        public string Artifactshortname { get; set; }

        [JsonProperty("artifactname", NullValueHandling = NullValueHandling.Ignore)]
        public string Artifactname { get; set; }
    }

    public partial class CpiPackageConfig
    {
        public static CpiPackageConfig FromJson(string json) => JsonConvert.DeserializeObject<CpiPackageConfig>(json, IFlow.Converter.Settings);
    }

    public static class Serialize
    {
        public static string ToJson(this CpiPackageConfig self) => JsonConvert.SerializeObject(self, IFlow.Converter.Settings);
    }

    public static class Converter
    {
        public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
        {
            MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
            DateParseHandling = DateParseHandling.None,
            Converters =
            {
                new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
            },
        };
    }
}
