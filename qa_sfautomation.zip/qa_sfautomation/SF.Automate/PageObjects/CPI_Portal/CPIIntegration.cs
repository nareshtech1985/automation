﻿namespace EY_Test.PageObjects.CPI_Portal
{
    using OpenQA.Selenium;
    using Pom.PageObjects;


    public class CPIIntegration : MasterPage
    {

        public CPIIntegration(IWebDriver driver) : base(driver)
        {

        }

        public override void IntializePage()
        {
            Driver.Url = "https://e2133-tmn.hci.eu1.hana.ondemand.com/itspaces/shell/monitoring/Artifacts";
            WaitTillCPIPageLoaderCompletes(30);
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="packagename"></param>
        public void SelectArtifact(string packagename)
        {
            Driver.Url = "https://e2133-tmn.hci.eu1.hana.ondemand.com/itspaces/shell/monitoring/Artifacts";
            WaitTillArtifactPageLoadingCompletes(30);
            By myintegrationItem = By.XPath($"//span[text()='{packagename}' and contains(@id,'ART')]/ancestor::tr");
            By artifactdetails = By.XPath("//bdi[text()='Artifact Details']/ancestor::button");
            By messagelink = By.LinkText("Monitor Message Processing");
            By messageItem = By.XPath($"//span[text()='{packagename}' and contains(@id,'MESS')]");
            By messageItemStatus = By.XPath($"//span[text()='{packagename}' and contains(@id,'MESS')]/ancestor::tr//span[contains(@class,'sapMObjS')]");
            By refreshBtn = By.XPath("//button[@title='Update the page']");

            WaitTillCPIPageLoaderCompletes(15);
            Click(myintegrationItem);

            WaitUntilElementDisplayed(artifactdetails);
            Click(artifactdetails);
            WaitTillArtifactPageLoadingCompletes(30);
            //Check if link available
            WaitUntilElementDisplayed(messagelink);
            Click(messagelink);
            WaitTillCPIPageLoaderCompletes(30);

            Driver.Navigate().Refresh();

            WaitUntilElementDisplayed(messageItem);
            Click(messageItem);

            WaitTillTheTextIs(refreshBtn, messageItemStatus, "Completed");

            if (GetText(messageItemStatus).Trim().ToLower().Equals("completed"))
            {
                System.Console.WriteLine("CPI job is completed");
            }
            else
            {
                System.Console.WriteLine($"CPI job is {GetText(messageItemStatus)}");
            }
        }

        public string GetServiceURL(string packagename, IFlow.Integration item)
        {
            string serviceLink = "";
            By searchBox = By.XPath("//input[contains(@id,'_SEARCH')]");
            By artifactRow = By.XPath($"//span[text()='{item.Artifactname}']/ancestor::tr[1]");
            By serviceUrlLink = By.XPath("(//div[@id='endpoint_sub_id-innerGrid']//span[contains(@class,'itopweb')])");
            By packageNameelem = By.XPath($"//div[contains(@class,'PageHeaderContent')]//span[contains(text(),'{packagename}')]");
            ////span[text()='{item.Artifactname}']/ancestor::tr[1]
            ////span[contains(@title,'{item.Artifactname}')]/ancestor::tr

            Clear(searchBox);
            WaitTillCPIPageLoaderCompletes(15);
            SetText(searchBox, item.Artifactname);
            WaitTillCPIPageLoaderCompletes(15);
            WaitUntilElementDisplayed(artifactRow);
            Click(artifactRow);
            WaitTillArtifactPageLoadingCompletes(20);
            if (IsExists(packageNameelem))
            {
                MovetoElement(serviceUrlLink);
                serviceLink = GetText(serviceUrlLink);
            }
            return serviceLink;
        }
    }
}