﻿/// <summary>
/// This file will contains all the common methods used for the application under test
/// Author Samson Simon
/// Created Date : 21 MAY 2019
/// </summary>
namespace Pom.PageObjects
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.UI;
    using Pom;
    using SeleniumExtras.WaitHelpers;
    using System;
    using System.Collections.Generic;
    using System.Data;
    //using ExpectedConditions = ;

    public abstract class MasterPage : BaseScript
    {
        //protected TranslatedText Translations;
        protected WebDriverWait webwait;
        protected By datepickerwindow = ReadBy("DatePickerWindow");
        protected By _fgglobalsearch = By.Id("globalSearchInput");
        protected static Dictionary<string, string> tempdata = new Dictionary<string, string>();

        public MasterPage(IWebDriver Driver) : base(Driver)
        {
            webwait = new WebDriverWait(Driver, TimeSpan.FromSeconds(30));
            //if (Convert.ToBoolean(Util.Settings.GetCustomKeyValue("LoadTranslation")))
            //{ Translations = new TranslatedText(); }
            this.IntializePage();
            
        }

        public abstract void IntializePage();

        #region Common Methods

        protected static void KeyDownEnter()
        {
            //SendKeys.SendWait("{DOWN}");
            //SendKeys.SendWait("{ENTER}");
            TestLog.Error("Unable to select from the list opted for Keydown, But its disabled");
        }

        public void SelectDateRange(DateTime fromdate, DateTime todate)
        {
            if (IsExists(datepickerwindow))
            {
                //select the from year month then date
                PickDate(fromdate);

                //select the to year month then date
                PickDate(todate);
            }
            else
            {
                Util.Updatelog("Check calender displayed", "Calendar not displayed", State.Fail);
            }
        }

        private void PickDate(DateTime fromdate)
        {
            var monthyear = $"{fromdate:MMMM-yyyy}".Trim();
            var day = $"{fromdate: d}".Trim();
            do
            {
                var currentMonthYear = $"{GetText("DatePicker_CurrentMonth").Trim()}-{GetText("DatePicker_CurrentYear").Trim()}";
                if (currentMonthYear.ToLower().Equals(monthyear.ToLower()))
                {
                    var d = ReadBy("DatePicker_Date", day);
                    Find(d); Util.Updatelog("Select date ", State.Pass);
                    Click(d);
                    break;
                }
                else
                {
                    var d1 = fromdate;
                    var d2 = Convert.ToDateTime($"{day}-{GetText("DatePicker_CurrentMonth").Trim()}-{GetText("DatePicker_CurrentYear").Trim()}");

                    if (d1 < d2)
                    {
                        Click("DatePicker_Previous");
                        TestLog.Info("Clicking previus button on calender window");
                    }
                    else
                    {
                        Click("DatePicker_Next");
                        TestLog.Info("Clicking next button on calender window");
                    }
                }
            } while (true);
        }

        public void ClickSimilarItems(string objectname)
        {
            IList<IWebElement> elements = Finds(objectname);
            foreach (IWebElement a in elements)
            {
                if (a.Displayed)
                {
                    JSClick(a);
                    Util.Updatelog("Click Item ", " Item is present and clicked ", State.Pass);
                }
                else
                {
                    Util.Updatelog("Click Item ", " Item not present", State.Pass);
                }
            }
        }
        /*
        public void CompareSimilarTranslation(string objectname, bool nodeonly = false)
        {
            IList<IWebElement> elements = Finds(objectname);
            foreach (var a in elements)
            {
                string textfromui = a.Text;
                if (nodeonly) { textfromui = GetTextofNode(a); textfromui.Replace("\n", string.Empty); }
                var translation = Translations.GetTranslation(objectname);
                if (textfromui.Equals(translation))
                {
                    Util.Updatelog(string.Format("Verify the translation for the webelement {0} is '{1}' ", objectname, translation), string.Format("Translation is matching. '{0}' ", translation), Status.Pass);
                }
                else
                {
                    Util.Updatelog(string.Format("Verify the translation for the webelement {0} is '{1}' ", objectname, translation), string.Format("Translation is not matching. '{0}' ", translation), Status.Fail);
                }
            }
        }

        /// <summary>
        /// Use this function to compare the french translation
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="waittime"></param>
        public void CompareTranslation(string objectname, long waittime = 30, bool nodeonly = false, string replacechar = "")
        {
            string textfromui = GetText(objectname, waittime).Trim();
            if (nodeonly) { textfromui = GetTextofNode(objectname, waittime); textfromui.Replace("\n", string.Empty); }
            var translation = Translations.GetTranslation(objectname);
            translation = Regex.Replace(translation, "\n", " ").Trim();
            textfromui = Regex.Replace(textfromui, "\r\n", " ").Trim();
            translation = Regex.Replace(translation, "  ", " ").Trim();
            if (!replacechar.Equals(string.Empty)) { textfromui.Replace(replacechar, string.Empty); }
            Console.WriteLine(string.Format("Text from UI  : {0}", textfromui));
            Console.WriteLine(string.Format("Translation   : {0}", translation));
            if (textfromui.Trim().Equals(translation.Trim()))
            {
                Util.Updatelog(string.Format("Verify the translation for the webelement {0} is '{1}' ", objectname, translation), string.Format("Translation is matching. ' {0} ' ", translation), Status.Pass);
            }
            else
            {
                Util.Updatelog(string.Format("Verify the translation for the webelement {0} is '{1}' ", objectname, translation), string.Format("Translation is not matching. '{0}' ", translation), Status.Fail);
            }
        }

        /// <summary>
        /// Compare the Translation base on the attribute value
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="attribute"></param>
        /// <param name="waittime"></param>
        /// <param name="nodeonly"></param>
        /// <param name="replacechar"></param>
        public void CompareTranslation(string objectname, string attribute, long waittime = 30, string replacechar = "")
        {
            string textfromui = GetAttribute(objectname, attribute, waittime).Trim();
            var translation = Translations.GetTranslation(objectname);
            translation = Regex.Replace(translation, "\n", " ").Trim();
            textfromui = Regex.Replace(textfromui, "\r\n", " ").Trim();
            translation = Regex.Replace(translation, "  ", " ").Trim();
            if (!replacechar.Equals(string.Empty)) { textfromui.Replace(replacechar, string.Empty); }
            Console.WriteLine(string.Format("Text from UI  : {0}", textfromui));
            Console.WriteLine(string.Format("Translation   : {0}", translation));
            if (textfromui.Trim().Equals(translation.Trim()))
            {
                Util.Updatelog(string.Format("Verify the translation for the webelement {0} is '{1}' ", objectname, translation), string.Format("Translation is matching. ' {0} ' ", translation), Status.Pass);
            }
            else
            {
                Util.Updatelog(string.Format("Verify the translation for the webelement {0} is '{1}' ", objectname, translation), string.Format("Translation is not matching. '{0}' ", translation), Status.Fail);
            }
        }

        public void CompareTranslation(IWebElement elem, string objectname, bool nodeonly = false, string replacechar = "")
        {
            string textfromui = GetText(elem).Trim();
            if (nodeonly) { textfromui = GetTextofNode(elem); textfromui.Replace("\n", string.Empty); }
            var translation = Translations.GetTranslation(objectname);
            translation = Regex.Replace(translation, "\n", " ").Trim();
            textfromui = Regex.Replace(textfromui, "\r\n", " ").Trim();
            translation = Regex.Replace(translation, "  ", " ").Trim();
            if (!replacechar.Equals(string.Empty)) { textfromui = textfromui.Replace(replacechar, string.Empty).Trim(); }
            Console.WriteLine(string.Format("Text from UI  : {0}", textfromui));
            Console.WriteLine(string.Format("Translation   : {0}", translation));
            if (textfromui.Trim().Equals(translation.Trim()))
            {
                Util.Updatelog(string.Format("Verify the translation for the webelement {0} is '{1}' ", objectname, translation), string.Format("Translation is matching. '{0}' ", translation), Status.Pass);
            }
            else
            {
                Util.Updatelog(string.Format("Verify the translation for the webelement {0} is '{1}' ", objectname, translation), string.Format("Translation is not matching. '{0}' ", translation), Status.Fail);
            }
        }

        public void CompareTranslation(By by, string objectname, long waittime = 30, bool nodeonly = false, string replacechar = "")
        {
            string textfromui = GetText(by, waittime);
            if (nodeonly) { textfromui = GetTextofNode(by, waittime); textfromui.Replace("\n", string.Empty); }
            var translation = Translations.GetTranslation(objectname);
            translation = Regex.Replace(translation, "\n", " ").Trim();
            textfromui = Regex.Replace(textfromui, "\r\n", " ").Trim();
            translation = Regex.Replace(translation, "  ", " ").Trim();
            if (!replacechar.Equals(string.Empty)) { textfromui.Replace(replacechar, string.Empty); }
            Console.WriteLine(string.Format("Text from UI  : {0}", textfromui));
            Console.WriteLine(string.Format("Translation   : {0}", translation));
            if (textfromui.Trim().Equals(translation.Trim()))
            {
                Util.Updatelog(string.Format("Verify the translation for the webelement {0} is '{1}' ", objectname, translation), string.Format("Translation is matching. '{0}' ", translation), Status.Pass);
            }
            else
            {
                Util.Updatelog(string.Format("Verify the translation for the webelement {0} is '{1}' ", objectname, translation), string.Format("Translation is not matching. '{0}' ", translation), Status.Fail);
            }
        }
        */

        #endregion Common Methods

        #region Loader & Spinners

        /// <summary>
        /// Method used to wait till the loading symbol disappeares on a page loader
        /// </summary>
        /// <param name="waittime"></param>
        public void WaitTillLoadingCompletes(long waittime = 15)
        {
            try
            {
                By loader = ReadBy("loadingPane");
                if (waittime <= Timeout) { waittime = Timeout; }
                if (Driver.FindElements(loader).Count >= 1)
                {
                    WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime));
                    wait.Until(ExpectedConditions.InvisibilityOfElementLocated(loader));
                }
            }
            catch (Exception)
            {
                Console.WriteLine("loading pane closed");
            }
        }

        public void WaitTillCPIPageLoaderCompletes(long waittime = 15)
        {
            //sap-ui-blocklayer-popup
            try
            {//sap-ui-blocklayer-popup  
                By loader = By.Id("sap-ui-blocklayer-popup");
                if (waittime <= Timeout) { waittime = Timeout; }
                if (Driver.FindElements(loader).Count >= 1)
                {
                    WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime))
                    {
                        PollingInterval = TimeSpan.FromMilliseconds(10)
                    };
                    wait.Until(ExpectedConditions.InvisibilityOfElementLocated(loader));
                }

                loader = By.Id("sapUiBusyIndicator");

                if (Driver.FindElements(loader).Count >= 1)
                {
                    WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime))
                    {
                        PollingInterval = TimeSpan.FromMilliseconds(10),
                        Message = "Waiting till the busy indicator is invisible"
                    };
                    wait.Until(ExpectedConditions.InvisibilityOfElementLocated(loader));
                }

                loader = By.XPath("//div[contains(@class,'sapUiBlockLayer')]");

                if (Driver.FindElements(loader).Count >= 1)
                {
                    WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime))
                    {
                        PollingInterval = TimeSpan.FromMilliseconds(100),
                        Message = "Waiting till the UI Block layer is invisible"
                    };
                    wait.Until(ExpectedConditions.InvisibilityOfElementLocated(loader));
                }

            }
            catch (Exception e)
            {
                TestLog.Debug($"loading UI layer {e.Message}");
            }
        }
        public void WaitTillPageLoadingCompletes(long waittime = 15)
        {
            try
            {
                By loader = ReadBy("loadingPane2");
                if (waittime <= Timeout) { waittime = Timeout; }
                if (Driver.FindElements(loader).Count >= 1)
                {
                    WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime));
                    wait.Until(ExpectedConditions.InvisibilityOfElementLocated(loader));
                }
            }
            catch (Exception)
            {
                Console.WriteLine("loading pane closed");
            }
        }

        public void WaitTillArtifactPageLoadingCompletes(long waittime = 15)
        {
            try
            {
                By loader = By.XPath("//div[contians(@class,'sapUiBlockLayer')]");
                if (waittime <= Timeout) { waittime = Timeout; }
                if (Driver.FindElements(loader).Count >= 1)
                {
                    WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime));
                    wait.PollingInterval = TimeSpan.FromMilliseconds(100);
                    wait.Message = "Waiting till the UI Block layer is invisible";
                    wait.Until(ExpectedConditions.InvisibilityOfElementLocated(loader));
                }
            }
            catch (Exception)
            {
                Console.WriteLine("loading pane closed");
            }
        }
        /// <summary>
        /// Method used to wait till the loading symbol disappeares on a page loader
        /// </summary>
        /// <param name="waittime"></param>
        public void WaitUntilElementClickable(By by, long waittime = 15)
        {
            try
            {
                if (waittime <= Timeout) { waittime = Timeout; }
                WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime));
                wait.Until(ExpectedConditions.ElementToBeClickable(by));
            }
            catch (Exception)
            {
                TestLog.Debug($"Waiting failed for the clickability of the element ");
            }
        }

        /// <summary>
        /// Method used to wait till the loading symbol disappeares on a page loader
        /// </summary>
        /// <param name="waittime"></param>
        public void WaitUntilElementClickable(string objectname, long waittime = 15)
        {
            try
            {
                if (waittime <= Timeout) { waittime = Timeout; }
                WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime));
                wait.Until(ExpectedConditions.ElementToBeClickable(ReadBy(objectname)));
            }
            catch (Exception)
            {
                TestLog.Debug($"Waiting failed for visibility of element located by {ReadBy(objectname)}");
            }
        }

        /// <summary>
        /// Method used to wait till the loading symbol disappeares on a page loader
        /// </summary>
        /// <param name="waittime"></param>
        public void WaitUntilElementDisplayed(string objectname, long waittime = 15)
        {
            try
            {
                if (waittime <= Timeout) { waittime = Timeout; }
                WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime));
                wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(ReadBy(objectname)));
            }
            catch (Exception)
            {
                TestLog.Debug($"Waiting failed for visibility of element located by {ReadBy(objectname)}");
            }
        }

        /// <summary>
        /// Method used to wait till the loading symbol disappeares on a page loader
        /// </summary>
        /// <param name="waittime"></param>
        public void WaitUntilElementDisplayed(By by, long waittime = 15)
        {
            try
            {
                if (waittime <= Timeout) { waittime = Timeout; }
                WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime));
                wait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(by));
            }
            catch (Exception)
            {
                TestLog.Debug($"Waiting failed for visibility of element located by {by}");
            }
        }

        /// <summary>
        /// Method used to wait till the loading symbol disappeares on a page loader
        /// </summary>
        /// <param name="waittime"></param>
        public void WaitUntilElementInvisible(By by, long waittime = 15)
        {
            try
            {
                if (waittime <= Timeout) { waittime = Timeout; }
                WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime));
                wait.Until(ExpectedConditions.InvisibilityOfElementLocated(by));
            }
            catch (Exception)
            {
                TestLog.Debug($"Waiting failed for visibility of element located by {by}");
            }
        }

        /// <summary>
        /// Method used to wait till the loading symbol disappeares on a table loader
        /// </summary>
        /// <param name="waittime"></param>
        public void WaitTilTableLoadingCompletes(long waittime = 15)
        {
            try
            {
                By loader = ReadBy("tableLoader");
                if (waittime < Timeout) { waittime = Timeout; }
                if (Driver.FindElements(loader).Count >= 1)
                {
                    WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime));
                    wait.Until(ExpectedConditions.InvisibilityOfElementLocated(loader));
                }
            }
            catch (Exception)
            {
                Console.WriteLine("loading pane closed");
            }
        }

        #endregion Loader & Spinners

        #region CPI Related Methods
        //Wait for 4 mins till the text displayed in the page/element.
        protected void WaitTillTheTextIs(By statusObject, string expectedText)
        {
            // increase the limit to make time more 
            for (int i = 0; i < 30; i++)
            {
                try
                {
                    WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(10))
                    {
                        PollingInterval = TimeSpan.FromMilliseconds(100)
                    };// To be changed to 4 Min
                    wait.IgnoreExceptionTypes(typeof(NoSuchElementException), typeof(ElementNotVisibleException));
                    wait.Until(ExpectedConditions.TextToBePresentInElementLocated(statusObject, expectedText));
                    break;
                }
                catch (Exception e)
                {
                    TestLog.Debug($"Waiting for text to be changed to {expectedText}, exception : {e.Message}");
                }
            }
        }

        //Wait for 4 mins till the text displayed in the page/element.
        protected void WaitTillTheTextIs(By refreshbtn, By statusObject, string expectedText)
        {
            for (int i = 1; i <= 5; i++)
            {
                try
                {
                    WebDriverWait wait = new WebDriverWait(this.Driver, TimeSpan.FromMinutes(2));
                    wait.Until(ExpectedConditions.TextToBePresentInElementLocated(statusObject, expectedText));
                    break;
                }
                catch (Exception e)
                {
                    Click(refreshbtn);
                    TestLog.Debug($"Clicked refresh button, due to : {e.Message}");
                }
            }
        }

        protected void UpdateResultView(IWebElement tableObject, DataTable dataTable)
        {
            try
            {
                if (dataTable != null)
                {
                    var body = Util.PrintResult(dataTable);
                    ((IJavaScriptExecutor)Driver).ExecuteScript("arguments[0].innerHTML=arguments[1]", tableObject, body);
                }
            }
            catch (Exception e) { Console.WriteLine(e.Message); }
        }

        protected void UpdateQueryView(IWebElement queryObject, string query)
        {
            try
            {
                ((IJavaScriptExecutor)Driver).ExecuteScript($"arguments[0].innerHTML=\"{query.ToLower()}\"", queryObject);
            }
            catch (Exception) { }
        }

        protected void ResetResultView(out IWebElement queryObject, out IWebElement tableObject)
        {
            queryObject = Find(By.XPath("//p"));
            tableObject = Find(By.XPath("//table"));
            ((IJavaScriptExecutor)Driver).ExecuteScript("arguments[0].innerHTML=''", queryObject);
            ((IJavaScriptExecutor)Driver).ExecuteScript("arguments[0].innerHTML=''", tableObject);
        }
        #endregion

        #region FieldGlass Methods

        protected readonly By suggestionlistbox = By.XPath("//ul[contains(@class,'ui-menu') and not(contains(@style,'display:'))]");
        protected readonly By suggestionfirstItem = By.XPath("//ul[contains(@class,'ui-menu') and not(contains(@style,'display:'))]//li[@class='ui-menu-item'][1]");
        protected readonly By ContinueBtn = By.XPath("//input[@value='Continue']");
        protected readonly By SubmitBtn = By.XPath("//input[@value='Submit']");
        protected readonly By EditBtn = By.XPath("//input[@value='Edit']");

        protected void ClickCreate()
        {
            Click(By.XPath("//div[text()='Create']/ancestor::li[1]"));
            WaitUntilElementDisplayed(By.XPath("//div[@id='createMenu']"));
        }

        protected void _ProfileWorkerNav() => Click(By.XPath("//a[text()='Profile Worker']/ancestor::li[1]"));

        protected void _jobrequistionworker() => Click(By.XPath("//a[text()='Job Requisition for Worker']/ancestor::li[1]"));
       
        /// <summary>
        /// used to populate the value on a dropdown field
        /// </summary>
        /// <param name="labelName"></param>
        /// <param name="fieldvalue"></param>
        public void Select_FGDropdownValue(string labelName, string fieldvalue)
        {
            By controlContainer = By.XPath($"//label[contains(text(),'{labelName}')]/ancestor::div[2]");
            By controlTextbox = By.XPath($"//label[contains(text(),'{labelName}')]/ancestor::div[2]//input[@type='text' and not(@disabled)]");
            MovetoElement(controlContainer);
            Clear(controlTextbox);
            SetText(controlTextbox, fieldvalue);
            webwait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(suggestionfirstItem));
            Click(suggestionfirstItem);
                       
            //Util.Updatelog($"Search and Select {searchvalue} from the field {labelName}", $"Value selected", State.Pass);
        }
        /// <summary>
        /// used to populate the value on a text box field 
        /// </summary>
        /// <param name="labelName"></param>
        /// <param name="fieldvalue"></param>
        public void Set_FGTextboxValue(string labelName, string fieldvalue)
        {
            By controlContainer = By.XPath($"//label[contains(text(),'{labelName}')]/ancestor::div[2]");
            By controlTextbox = By.XPath($"//label[contains(text(),'{labelName}')]/ancestor::div[2]//input[@type='text']");
            MovetoElement(controlContainer);
            Clear(controlTextbox);
            SetText(controlTextbox, fieldvalue);            
        }

        

        public void Continue() => Click(ContinueBtn);

        public virtual void Submit() => Click(SubmitBtn);

        #endregion
    }
}