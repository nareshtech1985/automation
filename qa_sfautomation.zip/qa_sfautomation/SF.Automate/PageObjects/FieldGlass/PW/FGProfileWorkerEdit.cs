﻿namespace SF.Automate.PageObjects.FieldGlass.PW
{
    using OpenQA.Selenium;
    using Pom.PageObjects;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class FGProfileWorkerEdit : MasterPage
    {
        public FGProfileWorkerEdit(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {
            
        }
    }
}
