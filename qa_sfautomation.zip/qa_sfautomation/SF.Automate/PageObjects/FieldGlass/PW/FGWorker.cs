﻿/// <summary>
/// Test Cases for FG Profile Worker
/// Created By: Samson Simon
/// Created On: 09-05-2022
/// </summary>
namespace SF.Automate.PageObjects.FieldGlass
{
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using SF.Automate.PageObjects.FieldGlass.PW;
    using System;

    public enum ProfileWorkerAction
    {
        Edit_Profile_Worker,
        Edit_Worker_Name,
        Close_Profile_Worker
    }

    public class FGWorkerMaster : MasterPage
    {
        #region Labels
        private readonly By WorkerName = By.CssSelector("#profileWorkerBadge div.fgTitleStyle");
        private readonly By WorkerType = By.CssSelector("#profileWorkerBadge span.secFlag"); // P for Profile worker, T for Contract workers
        private readonly By WorkerStatus = By.XPath("//div[text()='Status']/ancestor::li//div[@class='values']");
        private readonly By NextStep = By.XPath("//div[text()='Next Step']/ancestor::li//div[@class='values']");
        private readonly By WorkerID = By.XPath("//div[text()='Profile Worker ID']/ancestor::li//div[@class='values']");
        private readonly By WorkerPeriod = By.XPath("//div[text()='Period']/ancestor::li//div[@class='values']");
        private readonly By WorkerSupplier = By.XPath("//div[text()='Supplier']/ancestor::li//div[@class='values']");
        #endregion

        #region Buttons
        private readonly By EditButton = By.XPath("//input[@value='Edit']");
        private readonly By ApproveButton = By.XPath("//input[@value='Approve']");
        private readonly By RejectButton = By.XPath("//input[@value='Reject']");
        private readonly By ActionButton = By.Id("actionMenuId");
        #endregion

        #region Containers
        private By Dialogpanel = By.CssSelector("div#dialogPanelFocus");
        private By DialogpanelApprove = By.CssSelector("div#dialogPanelFocus input[value='Approve']");
        private By DialogpanelReject = By.CssSelector("div#dialogPanelFocus input[value='Reject']");
        private By DialogpanelCancel = By.CssSelector("div#dialogPanelFocus input[value='Cancel']");
        private By DialogpanelComments = By.Id("comments");
        private By DialogpanelReason = By.Id("reasonId");
        #endregion

        #region Links
        private By IDTLink = By.Id("contextualTextExternalLink");
        #endregion

        public FGWorkerMaster(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {

        }

        #region Reading Values 
        public string GetWorkerName() => GetText(WorkerName);
        public string GetWorkerType() => GetText(WorkerType);
        public string GetWorkerStatus() => GetText(WorkerStatus);
        public string GetNextStep() => GetText(NextStep);
        public string GetWorkerID() => GetText(WorkerID);
        public string GetWorkerPeriod() => GetText(WorkerPeriod);
        public string GetWorkerSupplier() => GetText(WorkerSupplier);
        #endregion

        #region Worker Actions
        public void Approve()
        {
            Click(ApproveButton);
            WaitUntilElementDisplayed(Dialogpanel);
            if (IsDisplayed(Dialogpanel))
            {
                Util.Updatelog("Check the approve comments pop up is displayed", "Approve Profile worker popup is displayed", State.Pass);
                SetText(DialogpanelComments, "Approve the pw records");
                Click(DialogpanelApprove);
                WaitTillTheTextIs(WorkerStatus, "Open");
            }
            else
            {
                Util.Updatelog("Check the approve comments pop up is displayed", "Approve Profile worker popup is not displayed", State.Fail);
            }
        }

        public void Reject()
        {
            Click(RejectButton);
            WaitUntilElementDisplayed(Dialogpanel);
            if (IsDisplayed(Dialogpanel))
            {
                Util.Updatelog("Check the Reject comments pop up is displayed", "Reject Profile worker popup is displayed", State.Pass);
                SelectDropdownValueByText(DialogpanelReason, "Submitted in Error");
                SetText(DialogpanelComments, "Approve the pw records");
                Click(DialogpanelReject);
                WaitTillTheTextIs(WorkerStatus, "Rejected"); 
            }
            else
            {
                Util.Updatelog("Check the Reject comments pop up is displayed", "Reject Profile worker popup is not displayed", State.Fail);
            }
        }

        public void Edit()
        {
            Click(EditButton);
        }
        /*
        public object Action(ProfileWorkerAction workerAction)
        {
            By option = By.XPath($"//a[text()='{workerAction.ToString().Replace("_"," ")}']/..");
            Click(ActionButton);
            WaitUntilElementDisplayed(option);
            Click(option);
            switch (workerAction)
            {
                case ProfileWorkerAction.Edit_Profile_Worker:
                    return new FGProfileWorkerEdit(Driver);
                case ProfileWorkerAction.Edit_Worker_Name:
                    return new FGWorkNameUpdate(Driver);
                case ProfileWorkerAction.Close_Profile_Worker:
                    return new FGClosePofileWorker(Driver);
            }
        }
        */
        #endregion


    }
}
