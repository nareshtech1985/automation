﻿namespace SF.Automate.PageObjects.FieldGlass.PW
{
    using OpenQA.Selenium;
    using Pom.PageObjects;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public enum WorkerCloseReason
    {

    }
    public class FGClosePofileWorker : MasterPage
    {
        #region Containers
        private By Panel = By.Id("dialogPanelFocus");
        private By Reason = By.Id("reason_id");
        private By EndDate = By.Id("endDate");
        private By Comments = By.Id("comments");
        private By CloseProfileWorker = By.CssSelector("div#dialogPanelFocus input[value='Close Profile Worker']");
        private By Cancel = By.CssSelector("div#dialogPanelFocus input[value='Cancel']");
        
        
        #endregion

        public FGClosePofileWorker(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {
            
        }
    }
}
