﻿namespace SF.Automate.PageObjects.FieldGlass.PW
{
    using OpenQA.Selenium;
    using Pom.PageObjects;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class FGWorkNameUpdate : MasterPage
    {
        public FGWorkNameUpdate(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            
        }
    }
}
