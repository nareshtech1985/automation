﻿/// <summary>
/// Page Object Class for the 'Create Profile Worker'
/// Created By: Samson Simon
/// Created On: 09-05-2022
/// </summary>
namespace SF.Automate.PageObjects.FieldGlass
{
    using NUnit.Framework;
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using SF.Automate.Lib.DataHelpers;
    using System;

    public class FGCreateProfileWorker : MasterPage
    {
        #region dropdown elements
        private By Supplierdropdown = By.XPath("//label[text()='Supplier']/ancestor::div[2]//input[@type='text']");
        private By Ownerdropdown = By.XPath("//label[text()='Owner']/ancestor::div[2]//input[@type='text']");
        private By Legalentitydropdown = By.XPath("//label[text()='Legal Entity']/ancestor::div[2]//input[@type='text']");
        private By EYofficedropdown = By.XPath("//label[text()='EY Office']/ancestor::div[2]//input[@type='text']");
        private By HRdropdown = By.XPath("//label[text()='HR Department']/ancestor::div[2]//input[@type='text']");
        private By EmployeeTypedropdown = By.XPath("//label[text()='Employee Type']/ancestor::div[2]//input[@type='text']");
        private By CountryCodedropdown = By.XPath("//label[text()='Country/Region ISO Code']/ancestor::div[2]//input[@type='text']");
        private By Rankdropdown = By.XPath("//label[contains(text(),'Rank (')]/ancestor::span//input[@type='text']");
        private By JCDropdown = By.XPath("//label[text()='Job Classification']/ancestor::span//input[@type='text']");
        private By ActivityDropdown = By.XPath("//label[text()='Activity Type']/ancestor::div[2]//input[@type='text']");
        #endregion

        #region textbox elements
        private By FirstName = By.XPath("//label[text()='First Name']/ancestor::div[2]//input[@type='text']");
        private By LastName = By.XPath("//label[text()='Last Name']/ancestor::div[2]//input[@type='text']");
        private By Phonenumber = By.Id("phoneNumber");
        private By Email = By.XPath("//label[text()='Email']/ancestor::div[2]//input[@type='text']");
        private By SecurityID = By.XPath("//label[text()='Security ID']/ancestor::div[2]//input[@type='text']");
        private By ConfirmSecurityID = By.XPath("//label[text()='Confirm Security ID']/ancestor::div[2]//input[@type='text']");

        #endregion

        #region radio elements
        private By phone_email_confirm_yes = By.XPath("//label[contains(text(),'(required for first time log-in)')]/ancestor::div[2]//input[@value='Yes']");
        private By phone_email_confirm_no = By.XPath("//label[contains(text(),'(required for first time log-in)')]/ancestor::div[2]//input[@value='No']");
        #endregion

        #region link elements
        private By Dob_Link = By.XPath("//div[text()='Edit']");//04/04/2022
        private By Dob_field = By.XPath("//div[text()='Date of Birth']/ancestor::div[2]//input[@type='text']");
        private By Dob_updatelink = By.XPath("//div[text()='Update']");
        #endregion

        #region date elements
        private By StartDate = By.XPath("//label[text()='Start Date']/ancestor::div[2]//input");
        private By EndDate = By.XPath("//label[text()='End Date']/ancestor::div[2]//input");
        #endregion

        #region button elements
        //private By ContinueBtn = By.XPath("//input[@value='Continue']");
        //private By SubmitBtn = By.XPath("//input[@value='Submit']");
        #endregion

        #region other variables
        private string _firstname { get; set; }
        private string _lastname { get; set; }
        private string _securityid { get; set; }
        #endregion

        public FGCreateProfileWorker(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {
            Assert.IsTrue("Fieldglass: Create Profile Worker".Equals(WebDriver.Title), "Create profile worker page not displayed");
            _firstname = RandomNames.FirstName;
            _lastname = RandomNames.LastName;
            if (_firstname.Equals(_lastname)) _lastname = RandomNames.LastName;
            _securityid = $"{_firstname[..2].ToUpper()}{_lastname[..2].ToUpper()}{DateTime.Now.AddYears(-45):ddMM}1234";
        }

        public void SelectSupplier(string _value = "EY Default Profile Worker Supplier")
        {
            Clear(Supplierdropdown);
            SetText(Supplierdropdown, _value);
            Click(suggestionfirstItem);
        }

        public void SetFirstName() => SetText(FirstName, _firstname);
        public void SetLastName() => SetText(LastName, _lastname);
        public void SetPhone()
        {
            Clear(Phonenumber);
            SetText(Phonenumber, "+465 8575 27364");
        }
        public void SetEmail() => SetText(Email, $"{_firstname.ToLower()}.{_lastname.ToLower()}@gmail.com");
        public void SetLegalEntity(string _value = "US01")
        {
            Clear(Legalentitydropdown);
            SetText(Legalentitydropdown, _value);
            Click(suggestionfirstItem);
        }

        public void SetOffice(string _value= "Alpharetta-Global IT (US008)")
        {
            Clear(EYofficedropdown);
            SetText(EYofficedropdown, _value); 
            Click(suggestionfirstItem);
        }

        public void SetHRDepartment(string _value= "SRCR-US331-00000-00018-0316033 (USA00-100039)")
        {
            Clear(HRdropdown);
            SetText(HRdropdown, _value); 
            Click(suggestionfirstItem);
        }

        public void SetPhoneAndEmailConfirmation()
        {
            WaitUntilElementClickable(phone_email_confirm_yes);
            Click(phone_email_confirm_yes);
        }

        public void SetDateofbirth()
        {
            Click(Dob_Link);
            SetText(Dob_field, $"{DateTime.Now.AddYears(-45):MM/dd/yyyy}");
            Click(Dob_updatelink);
        }
        public void SelectEmployeeType(string _value = "Individual Contractor (UC)")
        {
            Clear(EmployeeTypedropdown);
            SetText(EmployeeTypedropdown, _value);
            Click(suggestionfirstItem);
        }

        public void SelectCountryISO(string _value= "USA")
        {
            Clear(CountryCodedropdown);
            SetText(CountryCodedropdown, _value);
            WaitUntilElementClickable(suggestionfirstItem);
            Click(suggestionfirstItem);
        }
        public void SelectRank(string _value = "Client Serving Contractor")
        {
            Clear(Rankdropdown);
            SetText(Rankdropdown, _value);
            Click(suggestionfirstItem);
        }
        public void SelectJobClassification(string _value = "Contractor CSP SN1(USA00-979184)")
        {
            Clear(JCDropdown);
            SetText(JCDropdown, _value);
            Click(suggestionfirstItem);
        }
        public void SelectActivityType(string _value = "SUPERVISING ASSOCIATE (AS3)")
        {
            Clear(ActivityDropdown);
            SetText(ActivityDropdown, _value);
            Click(suggestionfirstItem);
        }
        public void SetStartDate() => SetText(StartDate, $"{DateTime.Now.AddDays(1):MM/dd/yyyy}");
        public void SetEndDate() => SetText(EndDate, $"{DateTime.Now.AddMonths(5):MM/dd/yyyy}");
        public void SetSecurityID() => SetText(SecurityID, _securityid);
        public void SetConfirmSecurityID() => SetText(ConfirmSecurityID, _securityid);

        public FGWorkerMaster ContinueAndCreate()
        {
            Click(ContinueBtn);
            Click(SubmitBtn);
            if (WebDriver.Title.Contains("Fieldglass: Worker"))
            {
                Util.Updatelog("Check Worker", "Worker Page", State.Pass);
            }
            else
            {
                Util.Updatelog("Check Worker", "Worker Page", State.Pass);
            }
            return new FGWorkerMaster(Driver);
        }
    }
}
