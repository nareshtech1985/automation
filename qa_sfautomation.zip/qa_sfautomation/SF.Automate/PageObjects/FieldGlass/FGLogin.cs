﻿/// <summary>
/// Page Object Class for the 'Field Glass Login Page'
/// Created By: Samson Simon
/// Created On: 09-05-2022
/// </summary>
namespace SF.Automate.PageObjects.FieldGlass
{
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using SeleniumExtras.WaitHelpers;
    using System;

    public class FGLogin : MasterPage
    {
        public FGLogin(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            Driver.Url = "https://euxuat2.fgvms.eu/";
        }

        /** login form elements */
        private By loginwindow = By.Id("content_area_new");
        private By loginusername = By.Id("usernameId_new");
        private By loginpassword = By.Id("passwordId_new");
        private By loginbtn = By.CssSelector("div.entryLoginInput_button button");

        public FGHome Login(AuthRole authRole = AuthRole.FGPWR)
        {
            var c = Util.TestConfiguration.Credentials.Find(x => x.Name.Equals(authRole.ToString()));
            if (c != null)
            {
                Console.WriteLine(Util.CypherProgram.Decrypt(c.Password));
                WaitUntilElementDisplayed(loginwindow);
                Clear(loginusername);
                SetText(loginusername, c.UserName);
                Clear(loginpassword);
                SetPasswordText(loginpassword, Util.CypherProgram.Decrypt(c.Password));
                Click(loginbtn);
                return new FGHome(Driver);
            }
            else
            {
                throw new FrameworkException("Login user details not provided or unable to fetch it");
            }            
        }
    }

    public enum AuthRole
    {
        /// <summary>
        /// Talent Transaction Role
        /// </summary>
        FGPWR,
        /// <summary>
        /// Hiring Manager US Role
        /// </summary>
        FGHMUS,
        /// <summary>
        /// Hiring Manager DU Role
        /// </summary>
        FGHMDU,
        /// <summary>
        /// EWO Role
        /// </summary>
        FGEWO,
        /// <summary>
        /// Program Cordinator Role
        /// </summary>
        FGPGDU,
        /// <summary>
        /// Experience Manager
        /// </summary>
        FGEMUS,
        /// <summary>
        /// Supplier US
        /// </summary>
        FGSUPUS,
        /// <summary>
        /// Supplier DU
        /// </summary>
        FGSUPDU,
        /// <summary>
        /// Gignow User Role
        /// </summary>
        FGGIGNOW
    }
}
