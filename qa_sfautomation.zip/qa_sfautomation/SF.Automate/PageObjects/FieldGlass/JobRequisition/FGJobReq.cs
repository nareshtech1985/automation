namespace SF.Automate.PageObjects.FieldGlass.JobRequisition
{
    using OpenQA.Selenium;
    using Pom.PageObjects;
    using SeleniumExtras.WaitHelpers;
    using System;

    public class FGJobReq : MasterPage
    {
        #region Initial Elements
        private By Job_Requisition_Owner = By.Id("select_ownerId");
        private By Job_Billing_Currency = By.Id("currencyText");
        private By First_Template = By.CssSelector("tr.itemContainer:nth-child(1) td a");
        private By BreadCrumb = By.CssSelector("div.menuBreadCrumbWrapper");
        private By BreadAugment = By.XPath("//*[contains(@class,'menuBreadCrumbCurrent')]/span[text()='Augment']");
        private By BreadCrumbReview = By.XPath("//*[contains(@class,'menuBreadCrumbCurrent')]/span[text()='Review and Submit']");

        #endregion

        #region dropdown elements
        private By Supplierdropdown = By.XPath("//label[text()='Supplier']/ancestor::div[2]//input[@type='text']");
        private By Ownerdropdown = By.XPath("//label[text()='Owner']/ancestor::div[2]//input[@type='text']");
        private By Legalentitydropdown = By.XPath("//label[text()='Legal Entity']/ancestor::div[2]//input[@type='text']");
        private By EYofficedropdown = By.XPath("//label[text()='EY Office']/ancestor::div[2]//input[@type='text']");
        private By HRdropdown = By.XPath("//label[text()='HR Department']/ancestor::div[2]//input[@type='text']");
        private By EmployeeTypedropdown = By.XPath("//label[text()='Employee Type']/ancestor::div[2]//input[@type='text']");
        private By CountryCodedropdown = By.XPath("//label[text()='Country/Region ISO Code']/ancestor::div[2]//input[@type='text']");
        private By Rankdropdown = By.XPath("//label[contains(text(),'Rank (')]/ancestor::span//input[@type='text']");
        private By JCDropdown = By.XPath("//label[text()='Job Classification']/ancestor::span//input[@type='text']");
        private By ActivityDropdown = By.XPath("//label[text()='EY Billing Level Equivalent/Activity Type Code']/ancestor::div[2]//input[@type='text']");
        private By BusinessReason = By.XPath("//label[text()='Business Reason']/ancestor::*[contains(@class,'formLabel')]//input[@type='text']");
        private By NSRRate = By.XPath("//label[text()='Net Standard Revenue Rate (NSR Rate)']/ancestor::*[contains(@class,'formLabel')]//input[@type='text']");
        private By RelationShip = By.XPath("//label[text()='Relationship Type']/ancestor::*[contains(@class,'formLabel')]//input[@type='text']");
        private By Engagements = By.XPath("//label[text()='Engagement/Opportunity']/ancestor::*[contains(@class,'formLabel')]//select");
        private By SecurityClearance = By.XPath("//label[text()='Security Clearance Required?']/ancestor::div[2]//input[@type='text']");
        private By BusinessUnit = By.XPath("//label[text()='Business Unit Lead']/ancestor::div[2]//input[@type='text']");
        private By ExperienceManager = By.XPath("//label[text()='Experience Manager']/ancestor::div[2]//input[@type='text']");
        #endregion

        #region textbox elements
        private By FirstName = By.XPath("//label[text()='First Name']/ancestor::div[2]//input[@type='text']");
        private By LastName = By.XPath("//label[text()='Last Name']/ancestor::div[2]//input[@type='text']");
        private By PositionCount = By.Id("positionsAvailable");
        private By Phonenumber = By.Id("phoneNumber");
        private By Email = By.XPath("//label[text()='Email']/ancestor::div[2]//input[@type='text']");
        private By SecurityID = By.XPath("//label[text()='Security ID']/ancestor::div[2]//input[@type='text']");
        private By ConfirmSecurityID = By.XPath("//label[text()='Confirm Security ID']/ancestor::div[2]//input[@type='text']");
        private By MinimumRate = By.Id("minRates0");
        private By MaximumRate = By.Id("maxRates0");
        #endregion

        #region radio elements
        private By International_Transfer_yes = By.XPath("//label[contains(text(),'International Travel Required?')]/ancestor::div[2]//input[@value='Yes']");
        private By International_Transfer_no = By.XPath("//label[contains(text(),'International Travel Required?')]/ancestor::div[2]//input[@value='No']");
        private By Can_This_B_Remote_yes = By.XPath("//label[contains(text(),'Can this engagement be performed remotely ')]/ancestor::div[2]//input[@value='Yes']");
        private By Can_This_B_Remote_no = By.XPath("//label[contains(text(),'Can this engagement be performed remotely ')]/ancestor::div[2]//input[@value='No']");
        private By phone_email_confirm_yes = By.XPath("//label[contains(text(),'(required for first time log-in)')]/ancestor::div[2]//input[@value='Yes']");
        private By phone_email_confirm_no = By.XPath("//label[contains(text(),'(required for first time log-in)')]/ancestor::div[2]//input[@value='No']");
        private By AttestConfirmation_yes = By.XPath("//label[contains(text(),'I attest that I have read and agree with the statement above.')]/ancestor::div[2]//input[@value='Yes']");
        private By AttestConfirmation_no = By.XPath("//label[contains(text(),'I attest that I have read and agree with the statement above.')]/ancestor::div[2]//input[@value='No']");
        #endregion

        internal void AgreeWithStatements()
        {
            SystemWait(1);
            Click(AttestConfirmation_yes);
        }



        internal void SelectSecurityClearance()
        {
            SystemWait(2);
            Clear(SecurityClearance);
            SetText(SecurityClearance, "No");
            Click(suggestionfirstItem);
            webwait.Until(ExpectedConditions.ElementIsVisible(By.XPath("//div[contains(@id,'finalStringValue')]")));
        }

        internal int GetNumberOfPosition() => Convert.ToInt32(GetAttribute(PositionCount,"value"));

        internal void SetBusinessUnit()
        {
            Clear(BusinessUnit);
            SetText(BusinessUnit, "hmus_ey");
            if (!IsDisplayed(suggestionfirstItem)) Click(BusinessUnit);
            Click(suggestionfirstItem);
        }

        internal void SetExperienceManager()
        {
            Clear(ExperienceManager);
            SetText(ExperienceManager, "emus_ey");
            if (!IsDisplayed(suggestionfirstItem)) Click(ExperienceManager);
            Click(suggestionfirstItem);
        }




        #region link elements
        private By enddatelink = By.Id("endDateLink");
        private By Dob_Link = By.XPath("//div[text()='Edit']");//04/04/2022
        private By Dob_field = By.XPath("//div[text()='Date of Birth']/ancestor::div[2]//input[@type='text']");
        private By Dob_updatelink = By.XPath("//div[text()='Update']");
        #endregion

        #region date elements
        private By StartDate = By.XPath("//label[text()='Start Date']/ancestor::div[2]//input");
        private By EndDate = By.XPath("//label[text()='End Date']/ancestor::div[2]//input");
        #endregion

        private string ownername, billingcurrency, templatename;

        public FGJobReq(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            webwait.Until((d) => d.Title.Equals("Fieldglass: Create Job Requisition"));

            ownername = GetText(Job_Requisition_Owner);
            billingcurrency = GetText(Job_Billing_Currency);
            templatename = GetText(First_Template);
        }

        public string GetFirstTemplateName() => GetText(First_Template);

        public void SelectTemplate()
        {
            Click(First_Template);
            webwait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(BreadCrumb));

            if (IsExists(BreadCrumb))
            {
                Console.WriteLine($"{ownername} : {billingcurrency} : {templatename}");
            }
        }


        internal void SetNumberOfPositions()
        {
            Clear(PositionCount);
            SetText(PositionCount, "20");
            //WaitUntilFGLoaderDisappears();
        }

        internal void SelectEndDate()
        {
            if (!IsDisplayed(EndDate)) { Click(enddatelink); }
            webwait.Until(ExpectedConditions.ElementToBeClickable(EndDate));
            Clear(EndDate);
            SetText(EndDate, $"{DateTime.Now.AddMonths(10):MM/dd/yyyy}");
        }

        internal void SelectStartDate()
        {
            webwait.Until(ExpectedConditions.ElementToBeClickable(StartDate));
            Clear(StartDate);
            SetText(StartDate, $"{DateTime.Now.AddDays(2):MM/dd/yyyy}");
        }

        internal void SelectDepartmentAs(string departmentValue)
        {
            webwait.Until(ExpectedConditions.ElementToBeClickable(HRdropdown));
            Clear(HRdropdown);
            SetText(HRdropdown, departmentValue);
            if (!IsExists(suggestionfirstItem)) Click(HRdropdown);
            Click(suggestionfirstItem);
        }

        internal void ChooseInternalTransferRequiredAs(string v)
        {
            SystemWait(1);
            MovetoElement(International_Transfer_no);
            webwait.Until(ExpectedConditions.ElementToBeClickable(International_Transfer_no));
            if (v.ToLower().Equals("no"))
            {
                SystemWait(3);
                Click(International_Transfer_no);
            }
            else
            {
                SystemWait(3);
                Click(International_Transfer_yes);
            }
        }

        internal void SetNSR()
        {
            Clear(NSRRate);
            SetText(NSRRate, "10");
        }

        internal void SelectEngagementAs(string _engname = "FBF_ADV_SUT Nortel Study (E-20129466)")
        {
            SelectDropdownValueByText(Engagements, _engname);
        }

        internal FGJobRequisitionView ContinueandCreate()
        {
            Click(ContinueBtn);
            WaitUntilElementDisplayed(SubmitBtn);
            Click(SubmitBtn);
            return new FGJobRequisitionView(Driver);
        }

        internal void SelectRelationTypeAs(string value = "External: Client Facing")
        {
            Clear(RelationShip);
            SetText(RelationShip, value);
            Click(suggestionfirstItem);
        }

        internal void SelectBusinessReason(string value = "Client requirement")
        {
            Clear(BusinessReason); SetText(BusinessReason, value); Click(suggestionfirstItem);
        }

        internal void ChooseCanThisBeRemoteAs(string v)
        {
            SystemWait(1);
            MovetoElement(Can_This_B_Remote_no);
            webwait.Until(ExpectedConditions.ElementIsVisible(Can_This_B_Remote_no));
            if (v.ToLower().Equals("no"))
            {
                SystemWait(3);
                Click(Can_This_B_Remote_no);
            }
            else
            {
                SystemWait(3);
                Click(Can_This_B_Remote_yes);
            }
        }

        internal void SelectEyBilling(string value = "ADMINISTRATIVE")
        {
            MovetoElement(ActivityDropdown);
            SystemWait(2);
            Clear(ActivityDropdown);
            SetText(ActivityDropdown, value);
            SystemWait(2);
            Click(suggestionfirstItem);
        }

        internal void SelectEYOfficeAs(string value = "Akron")
        {
            MovetoElement(EYofficedropdown);

            Clear(EYofficedropdown);
            SetText(EYofficedropdown, value);
            SystemWait(2);
            webwait.Until(ExpectedConditions.ElementToBeClickable(suggestionfirstItem));
            Click(suggestionfirstItem); //WaitUntilFGLoaderDisappears();
            SystemWait(6);
        }

        internal void SelectLegalEntityAs(string value = "US01")
        {
            SystemWait(2);
            MovetoElement(Legalentitydropdown);
            Clear(Legalentitydropdown);
            SetText(Legalentitydropdown, value);
            Click(suggestionfirstItem);
            //WaitUntilFGLoaderDisappears();
        }

        internal void SetMaximumRate()
        {
            webwait.Until(ExpectedConditions.ElementToBeClickable(MaximumRate));
            Clear(MaximumRate);
            SystemWait(1);
            SetText(MaximumRate, "21");
        }

        internal void SetMinimumRate()
        {
            Clear(MinimumRate);
            SystemWait(1);
            SetText(MinimumRate, "20");
        }

        internal double GetMaximumRate() => Convert.ToDouble(GetAttribute(MaximumRate,"value"));
        internal double GetMinmumRate() => Convert.ToDouble(GetAttribute(MinimumRate, "value"));
    }
}
