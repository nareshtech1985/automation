﻿namespace SF.Automate.PageObjects.FieldGlass.JobRequisition
{
    using OpenQA.Selenium;
    using Pom.PageObjects;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class FGJobRequisitionView : MasterPage
    {

        private By JobReqStatus = By.XPath("//div[text()='Status']/ancestor::li/div[@class='values']");
        private By JobRequisitionNumber = By.XPath("//div[text()='Job Requisition ID']/ancestor::li/div[@class='values']");
        public FGJobRequisitionView(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            webwait.Until(d => d.Title.Contains("Fieldglass: Job Requisition"));
        }

        public string GetStatus() => GetText(JobReqStatus);
        public string GetJobRequistionNumber() => GetText(JobRequisitionNumber);
    }
}
