﻿namespace SF.Automate.PageObjects.FieldGlass.CW
{
    using OpenQA.Selenium;
    using Pom.PageObjects;
    using SeleniumExtras.WaitHelpers;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class JobSeekersView : MasterPage
    {
        private By pagetitle = By.CssSelector("h3#showTitle");
        private By cardview = By.Id("#js_cards_switch_btn");
        private By listview = By.Id("#js_list_switch_btn");

        


        public JobSeekersView(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            webwait.Until((d) => d.FindElement(pagetitle).Text.Contains("Job Seekers"));
            Click(cardview);
            webwait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(By.CssSelector("div.js-action-bar")));
        }

        public CreateWorkOrderPage Initiate_Worker_Hire(string workerid)
        {
            By hirebutton = By.XPath($"//div[@class='fieldValue' and text()='{workerid}']/ancestor::section//input[@type='button']");
            Click(hirebutton);
            return new CreateWorkOrderPage(Driver);
        }
    }
}
