﻿using OpenQA.Selenium;
using Pom.PageObjects;
using SeleniumExtras.WaitHelpers;
using SF.Automate.Lib.DataHelpers;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Text;
using System.Threading;
using WindowsInput;

namespace SF.Automate.PageObjects.FieldGlass.CW
{
    public class JobSeekerSubmit : MasterPage
    {
        #region dropdown elements
        private By CountryDropdown = By.XPath("//label[contains(text(),'Current Country')]/ancestor::div[2]//input[@type='text']");
        #endregion

        #region textbox elements
        private By FirstName = By.XPath("//label[text()='First Name']/ancestor::div[2]//input[@type='text']");
        private By LastName = By.XPath("//label[text()='Last Name']/ancestor::div[2]//input[@type='text']");
        private By Phonenumber = By.XPath("//label[contains(text(),'Current Phone Number')]/ancestor::div[2]//input[@type='text']");
        private By Email = By.XPath("//label[text()=\"Contractor's Email\"]/ancestor::div[2]//input[@type='text']");
        private By SecurityID = By.XPath("//label[text()='Security ID']/ancestor::div[2]//input[@type='text']");
        private By ConfirmSecurityID = By.XPath("//label[text()='Confirm Security ID']/ancestor::div[2]//input[@type='text']");

        private By SourcedfromGiginow = By.XPath("//label[contains(text(),'Sourced From Gig')]/ancestor::div[2]//input[@type='text']");
        private By ActualSupplier = By.XPath("//label[contains(text(),'Actual Supplier Name')]/ancestor::div[2]//input[@type='text']");
        private By CommittedSpend = By.XPath("//label[contains(text(),'Committed Spend')]/ancestor::div[2]//input[@type='text']");
        private By CurrentCity = By.XPath("//label[contains(text(),'Current City')]/ancestor::div[2]//input[@type='text']");
        private By CurrentState = By.XPath("//label[contains(text(),'Current State')]/ancestor::div[2]//input[@type='text']");
        private By SponsorShip = By.XPath("//label[contains(text(),'Sponsorship for Employment')]/ancestor::div[2]//input[@type='text']");


        #endregion

        #region radio elements
        private By phone_email_confirm_yes = By.XPath("//label[contains(text(),'(required for first time log-in)')]/ancestor::div[2]//input[@value='Yes']");
        private By phone_email_confirm_no = By.XPath("//label[contains(text(),'(required for first time log-in)')]/ancestor::div[2]//input[@value='No']");


        private By Has_WorkerIn_EY_Yes = By.XPath("//label[contains(text(),'Has the candidate ever worked for EY')]/ancestor::div[2]//input[@value='Yes']");
        private By Has_WorkerIn_EY_No = By.XPath("//label[contains(text(),'Has the candidate ever worked for EY')]/ancestor::div[2]//input[@value='No']");

        private By AuthorizedToWorkYes = By.XPath("//label[contains(text(),'legally authorized to work')]/ancestor::div[2]//input[@value='Yes']");
        private By AuthorizedToWorkNo = By.XPath("//label[contains(text(),'legally authorized to work')]/ancestor::div[2]//input[@value='No']");

        private By IndependenceYes = By.XPath("//label[contains(text(),'Independence Terms')]/ancestor::div[2]//input[@value='Yes']");
        private By IndependenceNo = By.XPath("//label[contains(text(),'Independence Terms')]/ancestor::div[2]//input[@value='No']");


        #endregion

        #region link elements
        private By Dob_Link = By.XPath("//div[text()='Edit']");//04/04/2022
        private By Dob_field = By.XPath("//div[text()='Date of Birth']/ancestor::div[2]//input[@type='text']");
        private By Dob_updatelink = By.XPath("//div[text()='Update']");
        #endregion

        #region date elements
        private By AvailableDate = By.XPath("//label[text()='Available Date']/ancestor::div[2]//input");
        private By EndDate = By.XPath("//label[text()='End Date']/ancestor::div[2]//input");
        #endregion

        #region other variables
        private string _firstname { get; set; }
        private string _lastname { get; set; }
        private string _securityid { get; set; }
        #endregion

        public JobSeekerSubmit(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {
            webwait.Until(d => d.Title.Contains("Submit Job Seeker"));
            _firstname = RandomNames.FirstName;
            _lastname = RandomNames.LastName;
            if (_firstname.Equals(_lastname)) _lastname = RandomNames.LastName;
            _securityid = $"{_firstname[..2].ToUpper()}{_lastname[..2].ToUpper()}{DateTime.Now.AddYears(-45):ddMM}1234";
        }

        internal void SetFirstName()
        {
            Clear(FirstName);
            SetText(FirstName, _firstname);
        }

        internal void SetLastName()
        {
            Clear(LastName);
            SetText(LastName, _lastname);
        }

        internal void SetSecurityId()
        {
            Clear(SecurityID);
            SetText(SecurityID, _securityid);
        }

        internal void SetConfirmSecurityID()
        {
            Clear(ConfirmSecurityID);
            SetText(ConfirmSecurityID, _securityid);
        }

        internal void SetAvailableDate()
        {
            Clear(AvailableDate);
            SetText(AvailableDate, $"{DateTime.Now:yyyy-MM-dd}");
        }

        internal void SetCandidateSourcedFromGignowAs(YesNo value = YesNo.Yes)
        {
            Clear(SourcedfromGiginow);
            SetText(SourcedfromGiginow, value.ToString());
        }

        internal void SetActualSupplierName()
        {
            Clear(ActualSupplier);
            SetText(ActualSupplier, "Test Supplier");
        }

        internal void SetCommittedSpend()
        {
            Clear(CommittedSpend);
            SetText(CommittedSpend, "120");
        }

        internal void SetContractorEmail()
        {
            Clear(Email);
            SetText(Email, $"{_firstname}.{_lastname}@gmail.com");
        }

        internal void SetContractorCity(string value = "Camden and Aboy")
        {
            Clear(CurrentCity);
            SetText(CurrentCity, value);
        }

        internal void SetContractorState(string value= "New Jersy")
        {
            Clear(CurrentState);
            SetText(CurrentState, value);
        }

        internal void SelectContractorCountry(string value = "USA")
        {
            Clear(CountryDropdown);
            SetText(CountryDropdown, value);
            Click(suggestionfirstItem);
        }

        internal void SetContractorPhone()
        {
            var r = new Random();
            Clear(Phonenumber);
            SetText(Phonenumber, $"{r.Next(100, 999)}-{r.Next(1000, 9990)}-{r.Next(1000, 9999)}1");
        }

        internal void HasCandidateWorkerForEYAs(YesNo value=YesNo.No)
        {
            SystemWait(1);
            switch (value)
            {
                case YesNo.Yes: Click(Has_WorkerIn_EY_Yes); break;
                case YesNo.No: Click(Has_WorkerIn_EY_No); break;
            }
        }

        internal void IsCandidateAuthorisedtoWorkAs(YesNo value = YesNo.Yes)
        {
            SystemWait(1);
            MovetoElement(AuthorizedToWorkNo);
            switch (value)
            {
                case YesNo.Yes: Click(AuthorizedToWorkYes); break;
                case YesNo.No: Click(AuthorizedToWorkNo); break;
            }
        }

        internal void SetIndependenceFlag(YesNo value=YesNo.No)
        {
            webwait.Until(ExpectedConditions.InvisibilityOfElementLocated(By.XPath("//div[contains(@class,'jqmOverlay')]")));
            SystemWait(1);
            MovetoElement(IndependenceNo);
            switch (value)
            {
                case YesNo.Yes: Click(IndependenceYes); break;
                case YesNo.No: Click(IndependenceNo); break;
            }
        }

        internal JobPostingView SubmitandCreate()
        {
            Click(SubmitBtn);
            return new JobPostingView(Driver);
        }

        internal void SetSponsershipForEmployment()
        {
            Clear(SponsorShip);
            SetText(SponsorShip, "Yes");
        }

        internal void AttachResume()
        {
            By attachpopup = By.Id("dialogPanelFocus");
            By choosefile = By.XPath("//input[@value='Choose Files']");
            By attachBtn = By.XPath("//input[contains(@id,'resume_form_button')]");
            var filepath = @"C:\Automation\Test_John Doe.docx";
            MovetoElement(attachBtn);
            Click(attachBtn);
            SystemWait(2);
            WaitUntilElementDisplayed(attachpopup);
            retry:
            try
            {
                
                Click(choosefile);
                SystemWait(3);
                InputSimulator keys = new InputSimulator();
                SystemWait(3);
                keys.Keyboard.TextEntry(filepath);
                SystemWait(1);
                keys.Keyboard.KeyPress(WindowsInput.Native.VirtualKeyCode.RETURN);
                SystemWait(2);
                By attachbtn = By.Id("noProfilePicName");
                webwait.Until(ExpectedConditions.ElementIsVisible(attachbtn)).Click();
            }
            catch (Exception)
            {
                goto retry;
            }

        }

        public string GetFirstName() => GetAttribute(FirstName,"value");
        public string GetLastName() => GetAttribute(LastName, "value");
        public string GetEmailId() => GetAttribute(Email, "value");
        public string GetPhoneNumber() => GetAttribute(Phonenumber, "value");
        public string GetSecurityId()=> GetAttribute(SecurityID, "value");
        public string GetAvailableDate() => GetAttribute(AvailableDate, "value");
    }
}
