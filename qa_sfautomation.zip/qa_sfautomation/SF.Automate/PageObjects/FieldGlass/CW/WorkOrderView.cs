﻿namespace SF.Automate.PageObjects.FieldGlass.CW
{
    using OpenQA.Selenium;
    using Pom.PageObjects;
    using SeleniumExtras.WaitHelpers;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class WorkOrderView : MasterPage
    {
        private By WorkerOrderID = By.XPath("//div[text()='Work Order ID']/ancestor::li/div[@class='values']");
        private By Status = By.XPath("//div[text()='Status']/ancestor::li/div[@class='values']");
        private By NextStep = By.XPath("//div[text()='Next Step']/ancestor::li/div[@class='values']");

        public WorkOrderView(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            webwait.Until(ExpectedConditions.TitleContains("Work Order"));
        }

        public string GetWorkOrderId() => GetText(WorkerOrderID);
        public string GetStatus() => GetText(Status);

        public CreateWorkOrderPage EditWorkOrder()
        {
            Click(EditBtn);
            return new CreateWorkOrderPage(Driver);
        }
    }
}
