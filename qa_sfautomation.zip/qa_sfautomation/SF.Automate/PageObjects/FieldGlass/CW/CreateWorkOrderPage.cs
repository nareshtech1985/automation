﻿namespace SF.Automate.PageObjects.FieldGlass.CW
{
    using OpenQA.Selenium;
    using Pom.PageObjects;
    using SeleniumExtras.WaitHelpers;
    using System;
    using System.Collections.Generic;
    using System.Text;

    public class CreateWorkOrderPage : MasterPage
    {
        #region Label Values
        private By jobseekerid = By.XPath("//div[text()='Job Seeker']/ancestor::li//div[@class='values']");
        #endregion

        #region Dropdown Controls

        #endregion

        #region Textbox Controls

        #endregion

        #region Date Controls

        #endregion



        public CreateWorkOrderPage(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            webwait.Until(ExpectedConditions.TitleContains("Create Work Order"));          
        }


        public void Select_WorkerTypeAs(string _value = "Individual Contractor") => Select_FGDropdownValue("Worker Type", _value);
        public void Select_CountryCodeAs(string _value="USA") => Select_FGDropdownValue("Country ISO Code", _value);
        public void Select_RankAs(string _value) => Select_FGDropdownValue("Rank", _value);
        public void Select_JobClassificationAs(string _value) => Select_FGDropdownValue("Job Classification", _value);
        public void Select_EyBillingLevelAs(string _value= "ENT") => Select_FGDropdownValue("EY Billing Level Equivalent", _value);
        public void Select_BridgeRequestTypeAs(string _value= "Manual BRIDGE") => Select_FGDropdownValue("BRIDGE Request Type", _value);
        public void Select_StandardIndependeceTermsAs(string _value) => Select_FGDropdownValue("Standard Independence Terms", _value);
        public void Set_CandidateSourceFromGignowAs(string _value) => Set_FGTextboxValue("GigNow", _value);
        public void Set_ActualSupplierNameAs(string _value) => Set_FGTextboxValue("Actual Supplier Name", _value);
        public void Set_CommittedSpendAs(string _value) => Set_FGTextboxValue("Committed Spend", _value);

        public WorkOrderView SubmitAndCreate()
        {
            Click(SubmitBtn);
            return new WorkOrderView(Driver);
        }
    }
}
