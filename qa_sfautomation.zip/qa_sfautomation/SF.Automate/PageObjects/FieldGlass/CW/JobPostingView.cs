﻿

namespace SF.Automate.PageObjects.FieldGlass.CW
{
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class JobPostingView : MasterPage
    {
        private By _jobseeker_tab = By.CssSelector("a#tab_responses");
        private By _submittedSeekersList = By.CssSelector("table#job_posting_job_seeker_supplier_list tbody tr");
        
        public JobPostingView(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {
            webwait.Until(d => d.Title.Contains("Job Requisition"));
        }

        internal JobSeekerSubmit SubmitSeeker()
        {
            By submit = By.Id("jobPostingMenu_2_submitJobSeeker");
            Click(submit);
            return new JobSeekerSubmit(Driver);
        }

        public int GetSubmittedSeekersCount() => Finds(_submittedSeekersList).Count;

        public JobSeekerView GotoSubmittedJobSeeker()
        {
            Click(_jobseeker_tab);
            var items = Finds(_submittedSeekersList);
            if (items.Count >= 1)
            {
                var elem = items[items.Count - 1];
                By nameLink = By.XPath(".//td[@class='archiveLink']");
                string name = elem.FindElement(nameLink).Text;
                Console.WriteLine($"Job Seeker Name: {name}");
                elem.FindElement(nameLink).Click();
                return new JobSeekerView(Driver);
            }
            else
            {
                throw new FrameworkException("No Job Seeker available to navigate!");
            }
        }
        public JobSeekersView GotoJobSeekersView()
        {
            Click(_jobseeker_tab);
            return new JobSeekersView(Driver);
        }

    }
}
