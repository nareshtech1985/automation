﻿namespace SF.Automate.PageObjects.FieldGlass 
{
    using OpenQA.Selenium;
    using Pom.PageObjects;
    using System;
    using System.Collections.Generic;
    using System.Text;
    public class JobSeekerView : MasterPage
    {
        private By Status = By.XPath("//div[text()='Status']/ancestor::li/div[@class='values']");
        private By NextStep = By.XPath("//div[text()='Next Step']/ancestor::li/div[@class='values']");
        private By JobSeekerId = By.XPath("//div[text()='Job Seeker ID']/ancestor::li/div[@class='values']");
        
        public JobSeekerView(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            webwait.Until(d => d.Title.Contains("Job Seeker"));
        }

        public string GetJobSeekerID() => GetText(JobSeekerId);
        public string GetJobSeekerStatus() => GetText(Status);
    }
}
