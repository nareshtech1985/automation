﻿/// <summary>
/// Page Object Class for the 'Field Glass Home Page'
/// Created By: Samson Simon
/// Created On: 09-05-2022
/// </summary>
namespace SF.Automate.PageObjects.FieldGlass
{
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using SeleniumExtras.WaitHelpers;
    using SF.Automate.PageObjects.FieldGlass.CW;
    using SF.Automate.PageObjects.FieldGlass.JobRequisition;
    using System;

    public class FGHome : MasterPage
    {

        

        public FGHome(IWebDriver Driver) : base(Driver)
        {
        }

        public FGLogin Logout()
        {
            By accountOpener = By.CssSelector("div#accountOpener");
            By signOut = By.Id("signOut");
            Click(accountOpener);
            webwait.Until(ExpectedConditions.VisibilityOfAllElementsLocatedBy(signOut));
            Click(signOut);
            return new FGLogin(Driver);
        }

        public override void IntializePage()
        {
            if(WebDriver.Title.Equals("Fieldglass: Home"))
            {
                Util.Updatelog("Login to FG", "Logged into FieldGlass", State.Pass);
            }
            else
            {
                Util.Updatelog("Login to FG", "Logged into FieldGlass failed, Title not expected", State.Fail);
            }
        }

        public FGCreateProfileWorker NavigateToCreateProfileWorker()
        {
            ClickCreate();
            _ProfileWorkerNav();
            return new FGCreateProfileWorker(Driver);
        }

        public FGJobReq NavigateToCreateJobRequsistion()
        {
            ClickCreate();
            _jobrequistionworker();
            return new FGJobReq(Driver);
        }

        internal FGWorkerMaster Search(string serachtext)
        {
            Clear(_fgglobalsearch);
            SetText(_fgglobalsearch, serachtext);
            SetText(_fgglobalsearch, Keys.Enter);
            return new FGWorkerMaster(Driver);
        }


        internal JobPostingView SearchJobPosting(string searchvalue)
        {
            By search = By.Id("globalSearchInput");
            Clear(search);
            SetText(search,searchvalue);
            SetText(search,Keys.Enter);
            return new JobPostingView(Driver);
        }

        internal WorkOrderView SearchWorkOrder(string searchvalue)
        {
            By search = By.Id("globalSearchInput");
            Clear(search);
            SetText(search, searchvalue);
            SetText(search, Keys.Enter);
            return new WorkOrderView(Driver);
        }
    }
}
