﻿namespace EY_Test.PageObjects.SuccessFactors.Onboarding
{
    using OpenQA.Selenium;
    using System;


    public class USWorkflow : WorkFlowMaster
    {
        private int indexNumber = 0;


        public void UpdateJobClassification()
        {
            SelectDropdownValueByValue(activityType, "AI1");
        }

        public void AddCompensation()
        {
            SelectDropdownValueByText(paygroup, "USA Bi-weekly Pay Group");
            SelectDropdownValueByText(paycomponent, "Salary");
            SelectDropdownValueByText(payfrequency, "Biweekly");
            Clear(payamount); SetText(payamount, "2500");
        }

        public void AddNationalID()
        {
            var random = new Random();
            SelectDropdownValueByText(nidCountry, "United States", 10);
            SelectDropdownValueByText(nidType, "ssn", 10);
            SetText(nidNumber, $"{random.Next(0, 999):000}-{random.Next(0, 99):00}-{random.Next(0, 9999):0000}");
            SelectDropdownValueByText(isPrimary, "Yes");
            Click(nomore);
        }

        public void AddTime()
        {
            SetText(stdHrs, "45");
            SelectDropdownValueByText(fulltime, "Yes");
        }

        public void AddEmploymentDetails()
        {
            SelectDropdownValueByText(regular, "Regular");
            SelectDropdownValueByText(employeeClass, "Employee");
            SelectDropdownValueByText(employeeType, "Permanent Contract");
        }

        public (string FirstName, string LastName) AddNameInformation()
        {
            LastName = $"{LastName}_USA";
            SetText(firstName, $"{FirstName}", 10);
            SetText(lastName, $"{LastName}", 10);
            SetText(pre_firstName, $"{FirstName}", 10);
            SetText(pre_lastName, $"{LastName}", 10);

            SetText(dateofbirth, $"{DateTime.Now.AddYears(-25):MM/dd/yyyy}");
            SelectDropdownValueByValue(gender, "M");

            return (FirstName, LastName);
        }

        public void AddNewJoinerInfo()
        {
            SetText(hiredate, $"{DateTime.Now.AddDays(-75):MM/dd/yyyy}");
            SetText(country, "United States", 10);
            WaitUntilElementDisplayed(comboListItem1);
            Click(comboListItem1);
            SetText(legalentity, "000686", 10);
            WaitUntilElementDisplayed(comboListItem1);
            Click(comboListItem1);
            SetText(department, "USA00-100695", 10);
            WaitUntilElementDisplayed(comboListItem1);
            Click(comboListItem1);
            SetText(workLocation, "Global IT", 10);
            WaitUntilElementDisplayed(comboListItem1);
            Click(comboListItem1);
            SetText(jobCode, "Intern (Client", 10);
            WaitUntilElementDisplayed(comboListItem1);
            Click(comboListItem1);
        }
        public USWorkflow(IWebDriver Driver) : base(Driver)
        {
            SetNames();
        }

        public override void IntializePage()
        {
            indexNumber = new Random().Next(999);
            WaitUntilElementDisplayed(workflowFrame);
            if (IsExists(workflowFrame))
            {
                Driver.SwitchTo().Frame(Find(workflowFrame));
            }
        }

        public void Step1()
        {
            SetText(hiredate, $"{DateTime.Now.AddDays(-180):MM/dd/yyyy}", 10);
            SetText(country, "United States", 10);
            Click(comboListItem1);
            SetText(legalentity, "000686", 10);
            Click(comboListItem1);
            SetText(department, "00", 10);
            Click(comboListItem1);
            SelectDropdownValueByText(experience, "Experienced", 10);
            Click(finishBtn);
        }

        /**
         * Step 1 New Hire Set-up Information
         */
        public void PerformStepx()
        {
            SetText(firstName, $"{FirstName}", 10);
            SetText(lastName, $"{LastName}", 10);
            SetText(pre_firstName, $"{FirstName}", 10);
            SetText(pre_lastName, $"{LastName}", 10);
            SelectDropdownValueByValue(gender, "M", 10);
            SetText(hiredate, $"{DateTime.Now.AddDays(-180):MM/dd/yyyy}", 10);

            SetText(persemail, "Ernst@ey.com", 10);
            SetText(confirmPersemail, "Ernst@ey.com", 10);

            SetText(country, "United States", 10);
            Click(comboListItem1);
            SetText(legalentity, "000686", 10);
            Click(comboListItem1);
            SetText(department, "00", 10);
            Click(comboListItem1);
            SelectDropdownValueByText(experience, "Experienced", 10);
            Click(finishBtn);
        }
    }
}
