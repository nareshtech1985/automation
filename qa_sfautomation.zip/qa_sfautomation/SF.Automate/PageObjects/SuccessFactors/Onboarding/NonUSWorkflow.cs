﻿namespace EY_Test.PageObjects.SuccessFactors.Onboarding
{
    using EY_Test.TestScripts.InputObjects;
    using Fare;
    using OpenQA.Selenium;
    using Pom;
    using SF.ConstandDataModel;
    using System;


    public class NonUSWorkflow : WorkFlowMaster
    {
        private int indexNumber = 0;

        public NonUSWorkflow(IWebDriver Driver) : base(Driver)
        {
            SetNames();
        }

        public NonUSWorkflow(IWebDriver Driver, InputTestData inputdata) : base(Driver, inputdata)
        {
            SetNames();
        }

        public override void IntializePage()
        {
            indexNumber = new Random().Next(999);
            WaitUntilElementDisplayed(workflowFrame);
            if (IsExists(workflowFrame))
            {
                Driver.SwitchTo().Frame(Find(workflowFrame));
            }
        }

        public void PerformStepx()
        {

        }

        public void Step1()
        {
            SetText(hiredate, $"{DateTime.Now.AddDays(-180):MM/dd/yyyy}", 10);
            SetText(country, "United States", 10);
            Click(comboListItem1);
            SetText(legalentity, "000686", 10);
            Click(comboListItem1);
            SetText(department, "00", 10);
            Click(comboListItem1);
            SelectDropdownValueByText(experience, "Experienced", 10);
            Click(finishBtn);
        }

        /**
         * Step 1 New Hire Set-up Information
         */
        public void AddEmployeeClassandType()
        {
            var cls = _inputdata.EmployeeClass.Equals(string.Empty) || _inputdata.EmployeeClass.Equals("Any", StringComparison.InvariantCultureIgnoreCase) ? "Employee" : _inputdata.EmployeeClass;
            var emptype = _inputdata.EmploymentType.Equals(string.Empty) || _inputdata.EmploymentType.Equals("Any", StringComparison.InvariantCultureIgnoreCase) ? "Permanent Contract" : _inputdata.EmploymentType;

            SelectDropdownValueByText(employeeClass, cls, 10);
            SelectDropdownValueByText(employeeType, emptype, 10);
        }

        public void AddHireInformation()
        {

            var dept = _inputdata.departmentid.ToLower().Contains("any") ? "00" : _inputdata.departmentid;
            var le = _inputdata.legalEntityId.ToLower().Contains("any") ? "0" : _inputdata.legalEntityId;


            SetText(country, _inputdata.country, 10);
            WaitUntilElementDisplayed(comboListItem1);
            Click(comboListItem1);
            SetText(legalentity, le, 10);
            WaitUntilElementDisplayed(comboListItem1);
            Click(comboListItem1);
            SetText(department, dept, 10);
            WaitUntilElementDisplayed(comboListItem1);
            Click(comboListItem1);
            SelectDropdownValueByText(experience, "Experienced", 10);
        }

        public void AddNationalID()
        {
        SelectNID:
            try
            {

                NIDFormat iDFormat = new NIDFormat();
                var nidvalue = GenerateNID(out iDFormat);
                SelectDropdownValueByText(nidCountry, iDFormat.Country, 10);
                SelectDropdownValueByText(nidType, iDFormat.National_ID_Desc.Trim(), 10);
                SetText(nidNumber, nidvalue);
                SelectDropdownValueByText(isPrimary, "Yes");
                Click(nomore);
            }
            catch (Exception e)
            {
                TestLog.Debug($"Selecting NID : {e.Message}");
                goto SelectNID;
            }
        }

        private string GenerateNID(out NIDFormat iDFormat)
        {
            iDFormat = new NIDFormat();
            var random = new Random();
            var nidlist = NIDList.Load().Prop.FindAll(x => x.Country.ToLower().Equals(_inputdata.country.ToLower()));
            if (nidlist.Count > 1)
            {
                iDFormat = nidlist[random.Next(nidlist.Count)];
            }
            else if (nidlist.Count == 1)
            {
                iDFormat = nidlist[0];
            }
            else
            {
                iDFormat = new NIDFormat() { Country = "India", National_ID_Type = "Aadhaar Card No", Regular_Expression = @"[\d]{4}-[\d]{4}-[\d]{4}" };
            }

            iDFormat.Regular_Expression = iDFormat.Regular_Expression.Replace("\\d", "0-9");
            iDFormat.Regular_Expression = iDFormat.Regular_Expression.Replace("\\s", " ");
            iDFormat.Regular_Expression = iDFormat.Regular_Expression.Replace(".", @"\.");


            Xeger xeger = new Xeger(iDFormat.Regular_Expression, new Random());
            national_id = xeger.Generate();
            TestLog.Info($"National ID Type : {iDFormat.National_ID_Desc} | National ID Value : {national_id}");
            return national_id;
        }

        public void AddOrgInformation()
        {
            var jobcode = _inputdata.jobcode.ToLower().Contains("any") ? "IT" : _inputdata.jobcode;
            var nidlist = NIDList.Load().Prop.FindAll(x => x.Country.ToLower().Equals(_inputdata.country.ToLower()));
            string locationstring = $"{_inputdata.country.Substring(0, 1)}";
            if (nidlist.Count >= 1)
            {
                locationstring = $"{nidlist[0].Country_Code.Substring(0, 2)}";
            }
            Clear(workLocation);
            SetText(workLocation, locationstring, 10);
            WaitUntilElementDisplayed(comboListItem1);
            Click(comboListItem1);
            Clear(jobCode);
            SetText(jobCode, jobcode, 10);
            WaitUntilElementDisplayed(comboListItem1);
            Click(comboListItem1);
        }

        public void AddOtherJobInformations()
        {
            SelectDropdownValueByText(overtime, "Regular Pay, No Overtime");
            SelectDropdownValueByText(regular, "Regular");
            SelectDropdownValueByText(fulltime, "No");
        }

        public void AddPersonalEmail()
        {
            SetText(persemail, $"{FirstName}.{LastName}@outlook.com", 10);
            SetText(confirmPersemail, $"{FirstName}.{LastName}@outlook.com", 10);
        }
        public (string FirstName, string LastName) AddPersonalInformation()
        {
            SetText(firstName, $"{FirstName}", 10);
            SetText(lastName, $"{LastName}", 10);
            SetText(pre_firstName, $"{FirstName}", 10);
            SetText(pre_lastName, $"{LastName}", 10);
            SelectDropdownValueByValue(gender, "M", 10);
            Clear(dateofbirth);
            SetText(dateofbirth, $"{DateTime.Now.AddYears(-27):MM/dd/yyyy}");
            return (FirstName, LastName);

        }

        public void AddStandardHours()
        {
            SetText(stdHrs, "40");
        }

        public void AddStartDate()
        {
            var datevalue = _inputdata.HireDate.Equals(DateTime.MinValue) ? DateTime.Now.AddDays(-250) : _inputdata.HireDate;
            SetText(hiredate, $"{datevalue:MM/dd/yyyy}", 10);
        }

    }
}
