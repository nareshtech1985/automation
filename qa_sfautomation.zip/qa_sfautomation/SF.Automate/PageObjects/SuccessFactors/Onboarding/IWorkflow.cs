﻿namespace EY_Test.PageObjects.SuccessFactors.Onboarding
{
    public interface IWorkflow
    {
        void AddJobInfo();
        void AddHireDate();
        void AddPersonalInfo();
        void AddJobClassification();
        void AddEmploymentDetails();
        void AddTimeProfile();
        void AddCompensationInfo();
        void AddNationalID();
        void AddIDTData();
        void PerformIDTVerification();
        void AddPersonalEmail();
        void AddHireInformaiton();
    }
}
