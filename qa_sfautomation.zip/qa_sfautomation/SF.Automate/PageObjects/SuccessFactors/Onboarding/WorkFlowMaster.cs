﻿
namespace EY_Test.PageObjects.SuccessFactors.Onboarding
{
    using EY_Test.API.Parameters.IDT;
    using EY_Test.API.Parameters.IDT.GUISearch;
    using EY_Test.TestScripts.InputObjects;
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using SF.APICore;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text.RegularExpressions;

    public class WorkFlowMaster : MasterPage
    {
        protected InputTestData _inputdata;
        protected string national_id = "";
        protected string FirstName { get; set; }
        protected string LastName { get; set; }

        protected Dictionary<string, string> Countries = new Dictionary<string, string> {
        {"India","IND"},{"United States","USA"},{"China","CHN"},{"United Kingdom","GBR"},{"Germany","DEU"},{"Japan","JPN"},{"Philippines","PHL"},{"Australia","AUS"},{"Canada","CAN"},{"France","FRA"},{"Brazil","BRA"},{"Italy","ITA"},{"Netherlands","NLD"},{"Spain","ESP"},{"Poland","POL"},{"Malaysia","MYS"},{"Singapore","SGP"},{"Russian Federation","RUS"},{"South Africa","ZAF"},{"Argentina","ARG"}
        };

        public WorkFlowMaster(IWebDriver Driver) : base(Driver)
        {

        }

        public WorkFlowMaster(IWebDriver Driver, InputTestData inputdata) : base(Driver)
        {
            _inputdata = inputdata;
        }

        public override void IntializePage()
        {

        }

        protected void SetNames()
        {
            var r = new Random();
            FirstName = $"{FirstNames[r.Next(FirstNames.Count)]}";
            LastName = $"{LastNames[r.Next(LastNames.Count)]}";
        }

        public void Next()
        {
            Click(nextBtn);
            WaitTillPageLoadingCompletes();
        }

        private (string gui, string lpn, string gpn) FetchIDTValues(string hrefValue)
        {
            TestLog.Info("Retriving the IDT Values via IDT API");
            (string gui, string lpn, string gpn) idtoolvalue;
            var itemlst = Regex.Split(hrefValue.Substring(hrefValue.IndexOf('?')), "&").ToList();
            var searchresult = IDToolApi.SearchReservedIdentifiersAsync(new IDTSearchInput() { fName = FirstName, lName = LastName, nationalId = national_id });
            if (searchresult.GUIs.Count() == 0)
            {
                #region field mapping
                string fn = itemlst.Find(x => x.Contains("fn=")).Replace("fn=", string.Empty);
                string ln = itemlst.Find(x => x.Contains("ln=")).Replace("ln=", string.Empty);
                string gender = itemlst.Find(x => x.Contains("gender=")).Replace("gender=", string.Empty);
                string dob = itemlst.Find(x => x.Contains("dob=")).Replace("dob=", string.Empty);
                string ctxId = itemlst.Find(x => x.Contains("ctxId=")).Replace("ctxId=", string.Empty);
                string sln = itemlst.Find(x => x.Contains("sln=")).Replace("sln=", string.Empty);
                string nIc = itemlst.Find(x => x.Contains("nIc=")).Replace("nIc=", string.Empty);
                string nId = itemlst.Find(x => x.Contains("nId=")).Replace("nId=", string.Empty);
                string ec = itemlst.Find(x => x.Contains("ec=")).Replace("ec=", string.Empty);
                string et = itemlst.Find(x => x.Contains("et=")).Replace("et=", string.Empty);
                string le = itemlst.Find(x => x.Contains("le=")).Replace("le=", string.Empty);
                string mc = itemlst.Find(x => x.Contains("mc=")).Replace("mc=", string.Empty);
                string doh = itemlst.Find(x => x.Contains("doh=")).Replace("doh=", string.Empty);
                string mr = itemlst.Find(x => x.Contains("mr=")).Replace("mr=", string.Empty);
                string ctxSoR = itemlst.Find(x => x.Contains("ctxSoR=")).Replace("ctxSoR=", string.Empty);
                string ctxSrc = itemlst.Find(x => x.Contains("ctxSrc=")).Replace("ctxSrc=", string.Empty);
                string gc = itemlst.Find(x => x.Contains("gc=")).Replace("gc=", string.Empty);
                #endregion
                var values = IDToolApi.GenerateIdentifierAsync(new IDTInputParameter()
                {
                    contextId = ctxId,
                    firstName = fn,
                    lastName = ln,
                    gender = gender,
                    dob = $"{Convert.ToDateTime(dob):yyyy-MM-dd}",
                    ecCode = ec,
                    etCode = et,
                    leCode = le,
                    mcCode = mc,
                    doh = $"{Convert.ToDateTime(doh):yyyy-MM-dd}",
                    mrCode = mr,
                    contextSoR = ctxSoR,
                    contextSrc = ctxSrc,
                    gcCode = gc,
                    isBoomerang = true,
                    mode = "AM",
                    providedGUI = ""
                });
                idtoolvalue.gui = values.Gui;
                idtoolvalue.lpn = values.Lpn;
                idtoolvalue.gpn = values.Gpn;
            }
            else
            {
                idtoolvalue.gui = searchresult.GUIs.Last().GUI_CODE;
                idtoolvalue.lpn = searchresult.GUIs.Last().LPN_CODE;
                idtoolvalue.gpn = searchresult.GUIs.Last().GPN_CODE;
            }
            TestLog.Info($"IDT Values GUI : {idtoolvalue.gui}\tGPN : {idtoolvalue.gpn}\tLPN : {idtoolvalue.lpn}");
            return idtoolvalue;
        }

        public (string gui, string lpn, string gpn) PerformIDTSearchAndUpdateInfo()
        {
            By link = By.XPath("//a[contains(text(),'Identifier Tool')]");
            var hrefValue = GetAttribute(link, "href");
            (string gui, string lpn, string gpn) idtoolvalue = FetchIDTValues(hrefValue);
            Clear(GUIField); SetText(GUIField, idtoolvalue.gui);
            Clear(LPNField); SetText(LPNField, idtoolvalue.lpn);
            Clear(GPNField); SetText(GPNField, idtoolvalue.gpn);
            return idtoolvalue;

        }

        public void PerformPreverification()
        {
            SelectDropdownValueByText(EventReason, "New Hire");
            SelectDropdownValueByText(Verified, "Yes");
        }

        public override void Submit()
        {
            Click(finishBtn);
            Driver.SwitchTo().DefaultContent();
            WaitUntilElementDisplayed(iframe1);
            if (IsExists(iframe1))
            {
                Driver.SwitchTo().Frame(Find(iframe1));
            }
        }


        public bool VerifySystemValidationStatus()
        {
            By sysval = By.XPath("//label[contains(text(),'Validation')]/ancestor::tr[1]//option[@selected]");
            bool exportsuccess = false;
            if (GetText(sysval).ToLower().Contains("success"))
            {
                exportsuccess = true;
            }
            return exportsuccess;
        }

        public bool VerifyTDDHExportStatus()
        {
            bool exportsuccess = false;
            if (GetText(TDDHExportStatus).ToLower().Contains("success"))
            {
                exportsuccess = true;
            }
            return exportsuccess;
        }

        public void Cancel()
        {
            By cancel = By.XPath("//input[@value='Cancel']");
            By nosave = By.XPath("//button[contains(text(),'Close without Saving')]");
            Click(cancel, 10);
            Driver.SwitchTo().DefaultContent();
            WaitUntilElementDisplayed(iframe1);
            if (IsExists(iframe1))
            {
                Driver.SwitchTo().Frame(Find(iframe1));
            }
            Click(nosave, 10);
        }

        #region Common Fields
        protected By comboListItem1 = By.XPath("//div[@class='ddcombo_results' and not(contains(@style,'display: none'))]//li[2]");
        protected By finishBtn = By.XPath("//input[@value='Finish']");
        protected By nextBtn = By.XPath("//input[@value='Next']");
        protected By iframe1 = By.Id("iframeForKMS");
        protected By workflowFrame = By.XPath("//iframe[@name='frmContent']");
        #endregion

        #region Fields
        protected By firstName = By.XPath("(//label[contains(text(),'First Name')])[1]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By lastName = By.XPath("(//label[contains(text(),'Last Name')])[1]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By pre_firstName = By.XPath("(//label[contains(text(),'Preferred First Name')])[1]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By pre_lastName = By.XPath("(//label[contains(text(),'Preferred Last Name')])[1]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By gender = By.XPath("(//label[contains(text(),'Gender')])[1]/ancestor::tr[1]//select");
        protected By dateofbirth = By.XPath("(//span[contains(text(),'Birth')])[1]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By hiredate = By.XPath("//span[contains(text(),'Hire Date')]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By persemail = By.XPath("//label[contains(text(),'Please enter')]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By confirmPersemail = By.XPath("//label[contains(text(),'Re-enter')]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By country = By.XPath("//span[contains(text(),'Country')]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By legalentity = By.XPath("//span[contains(text(),'EY Legal Entity')]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By department = By.XPath("//span[contains(text(),'Department')]/ancestor::tr[1]//input[not(@type='hidden')]");
        //protected By experience = By.XPath("//span[contains(text(),'Experience Type')]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By experience = By.XPath("//label[contains(text(),'Experience Type')]/ancestor::tr[1]//select");        //
        protected By employeeClass = By.XPath("//span[contains(text(),'Employee Class')]/ancestor::tr[1]//select");
        protected By employeeType = By.XPath("//span[contains(text(),'Employee Type')]/ancestor::tr[1]//select");
        protected By nidCountry = By.XPath("//span[contains(text(),'Country')]/ancestor::tr[1]//select");
        protected By nidType = By.XPath("//span[contains(text(),'Type')]/ancestor::tr[1]//select");
        protected By nidNumber = By.XPath("//label[contains(text(),'Number')]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By isPrimary = By.XPath("//label[contains(text(),'Primary')]/ancestor::tr[1]//select");
        protected By nomore = By.XPath("//label[contains(@for,'rbtnAddMoreNo')]");//By.XPath("//input[@value='rbtnAddMoreNo']");
        protected By workLocation = By.XPath("//span[contains(text(),'Work Location')]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By jobCode = By.XPath("//span[contains(text(),'Job')]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By stdHrs = By.XPath("//label[contains(text(),'Hours')]/ancestor::tr[1]//input[not(@type='hidden')]");
        protected By overtime = By.XPath("//span[contains(text(),'Overtime ')]/ancestor::tr[1]//select");
        protected By regular = By.XPath("//span[contains(text(),'Regular')]/ancestor::tr[1]//select");
        protected By fulltime = By.XPath("//*[contains(text(),'Full Time') or contains(text(),'Fulltime')]/ancestor::tr[1]//select");
        protected By GUIField = By.XPath("//label[text()='GUI']/ancestor::tr[1]//input[@type='text']");
        protected By GPNField = By.XPath("//label[text()='GPN']/ancestor::tr[1]//input[@type='text']");
        protected By LPNField = By.XPath("//label[text()='LPN']/ancestor::tr[1]//input[@type='text']");
        protected By EventReason = By.XPath("//label[contains(text(),'Event Reason')]/ancestor::tr[1]//select");
        protected By Verified = By.XPath("//label[contains(text(),'Verified')]/ancestor::tr[1]//select");
        protected By TDDHExportStatus = By.XPath("//label[contains(text(),'Export to TDDH Status')]/ancestor::tr[1]//option[@selected]");
        protected By activityType = By.XPath("(//span[contains(text(),'Activity Type')])[1]/ancestor::tr[1]//select");
        protected By paygroup = By.XPath("//label[contains(text(),'Pay Group')]/ancestor::tr[1]//select");
        protected By paycomponent = By.XPath("//label[contains(text(),'Pay Component')]/ancestor::tr[1]//select");
        protected By payfrequency = By.XPath("//span[contains(text(),'Pay Frequency')]/ancestor::tr[1]//select");
        protected By payamount = By.XPath("//label[contains(text(),'Pay Amount')]/ancestor::tr[1]//input[@type='text']");
        #endregion

        private List<string> FirstNames
        {
            get
            {
                var names = Regex.Split(File.ReadAllText($@"{Util.DirectoryPath}\Data\text_data\fnames.txt"), "\r\n").ToList();
                return names;
            }
        }

        private List<string> LastNames
        {
            get
            {
                var names = Regex.Split(File.ReadAllText($@"{Util.DirectoryPath}\Data\text_data\lnames.txt"), "\r\n").ToList();
                return names;
            }
        }
    }
}
