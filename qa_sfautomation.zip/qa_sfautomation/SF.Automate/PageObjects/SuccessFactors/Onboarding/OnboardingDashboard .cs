﻿namespace EY_Test.PageObjects.SuccessFactors.Onboarding
{
    using EY_Test.TestScripts.InputObjects;
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;


    public class OnboardingDashboard : MasterPage
    {
        #region Variables
        private By onboardingIframe = By.Id("iframeForKMS");
        private By startButton = By.XPath("//bdi[text()='Create New Task']");
        private By start_usworkflowbtn = By.XPath("//*[contains(text(),'US Workflow')]/ancestor::button");
        private By start_nonusworkflowbtn = By.XPath("//*[contains(text(),'Global Workflow')]/ancestor::button");
        private By startcenterButton = By.XPath("//input[contains(@id,'_btnStart')]");
        private By workflowFrame = By.XPath("//iframe[@name='frmContent']");
        #endregion

        public OnboardingDashboard(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            WaitUntilElementDisplayed(onboardingIframe, 30);
            if (IsExists(onboardingIframe))
            {
                Driver.SwitchTo().Frame(Find(onboardingIframe));
                Util.Updatelog("Switch to onboarding frame", "Switch Success", State.Pass);
            }
            else
            {
                throw new FrameworkException("Unable to switch to onboarding frame!");
            }
        }

        public USWorkflow InitiateUSWorkflow()
        {
            Click(startButton);
            Click(start_usworkflowbtn);
            WaitUntilElementDisplayed(startcenterButton);
            Click(startcenterButton);
            return new USWorkflow(Driver);
        }

        public NonUSWorkflow InitiateNonUSWorkflow(InputTestData data)
        {
            Click(startButton);
            Click(start_nonusworkflowbtn);
            WaitUntilElementDisplayed(startcenterButton);
            Click(startcenterButton);
            return new NonUSWorkflow(Driver, data);
        }

        public object SelectProcess(string workflowtype, string rowidentifier)
        {
            By identiferRow = By.XPath($"//a[contains(text(),'{rowidentifier}')]");
            By workflowListitem = By.XPath($"//span[text()='{workflowtype}']/ancestor::li");
            Click(workflowListitem);
            WaitUntilElementDisplayed(identiferRow, 20);
            Click(identiferRow);
            //Click(By.XPath("//tbody[contains(@id,'activityTable')]/tr"));//Select First Row Item in the List (per script there should be only 1)
            if (workflowtype.ToLower().Contains("global"))
            {
                Driver.SwitchTo().Frame(Find(workflowFrame));
            }
            else
            {
                Driver.SwitchTo().Frame(Find(workflowFrame));//Change the id if the US frame is different
            }
            /*if (workflowtype.ToLower().Contains("global"))
            {
                return new NonUSWorkflow(Driver);
            }
            else
            {
                return new USWorkflow(Driver);
            }*/
            return null;
        }

        public void Exit()
        {
            Driver.SwitchTo().DefaultContent();
        }
    }
}
