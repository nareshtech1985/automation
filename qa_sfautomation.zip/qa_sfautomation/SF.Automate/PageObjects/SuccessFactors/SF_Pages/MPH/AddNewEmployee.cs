﻿namespace EY_Test.PageObjects.SuccessFactors.SF_Pages.MPH
{
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;

    public class AddNewEmployee : MasterPage
    {


        public AddNewEmployee(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {

        }

        public override void Submit()
        {
            By submitButton = By.XPath("//footer//bdi[text()='Submit']/ancestor::button");
            By okButton = By.XPath("//footer//bdi[text()='OK']/ancestor::button");
            WaitUntilElementDisplayed(submitButton, 30);
            Click(submitButton);

            WaitUntilElementDisplayed(okButton, 30);
        }
        public void UpdateJobinformationData()
        {
            By showitem = By.XPath("//span[contains(.,'Job Information') and contains(@id,'title')]//ancestor::div[3]//bdi[contains(.,'more')]");
            if (IsExists(showitem))
            {
                foreach (var item in Finds(showitem))
                {
                    MovetoElement(item);
                    Click(item);
                    TestLog.Info("Expanding the fields");
                }
            }

            By counselor = By.XPath("//bdi[text()='Counselor']/ancestor::div[2]//input");
            SelectValueFromSFDropdown(counselor, "No Manager");

            //new logic
            SelectValueFromSFDropdown_AD("Work Location", "00");
            CloseWarning();
            SelectValueFromSFDropdown_AD("Benefit Program", "No Benefits");


        }

        private void CloseWarning()
        {
            By warningOkbutton = By.XPath("//span[.='Warning']/ancestor::div[4]//button[.='OK']");
            if (IsDisplayed(warningOkbutton))
            {
                Click(warningOkbutton); WaitTillPageLoadingCompletes();
            }
        }

        public void UpdateTimeProfile()
        {
            By timeprofileinput = By.XPath("//bdi[text()='Time Profile']/ancestor::div[2]//input");
            By listitem = By.XPath("//li[2]");
            By defaultitem = By.XPath("//li[1]");

            SelectValueFromSFDropdown_AD("Time Profile", "TIME_PROFILE");

            //Clear(timeprofileinput);
            //SetText(timeprofileinput, "TIME_PROFILE");
            /*
            if (IsExists(listitem, 20) && IsDisplayed(listitem))
            {
                Click(listitem);
            }
            else if (IsExists(defaultitem, 20))
            {
                Click(defaultitem);
            }*/
        }


        public void UpdateEmailAddress(string emailid = "somebody@eyey.com")
        {
            By email = By.XPath("//bdi[text()='Email Address']/ancestor::div[2]//input[not(@role)]");
            if (IsExists(email))
            {
                Clear(email);
                SetText(email, emailid);
            }
        }

        public void UpdateAddress()
        {
            By fathersName = By.XPath("//bdi[text()=\"Father's Name\"]/ancestor::div[2]//input");
            if (IsExists(fathersName))
            {
                Clear(fathersName);
                SetText(fathersName, "Great Father");
            }
            By deleteIcon = By.XPath("//*[text()='Addresses']/ancestor::div[2]//span[contains(@class,'sapUiIcon')]/..");

            if (IsExists(deleteIcon)) Click(deleteIcon);



            UpdateGlobalInfo();
        }

        private void UpdateGlobalInfo()
        {

            By showitem = By.XPath("//span[contains(.,'Global Information') and contains(@id,'title')]//ancestor::div[3]//bdi[contains(.,'Show')]");
            if (IsExists(showitem))
            {
                Click(showitem);
            }

            SetImplicitWait(3);
            By Aboriginal_Peoples = By.XPath("//bdi[contains(text(),'Aboriginal')]/ancestor::div[2]//input");
            By Visible_Minority = By.XPath("//bdi[contains(text(),'Visible')]/ancestor::div[2]//input");
            By Persons_with_Disabilities = By.XPath("//bdi[contains(text(),'Disabilities')]/ancestor::div[2]//input");
            By Group_Membership = By.XPath("//bdi[contains(text(),'Membership')]/ancestor::div[2]//input");
            By Religious_Affiliation = By.XPath("//bdi[contains(text(),'Religious')]/ancestor::div[2]//input");
            By Landed_Immigrant = By.XPath("//bdi[contains(text(),'Immigrant')]/ancestor::div[2]//input");
            By Military_Service = By.XPath("//bdi[contains(text(),'Military')]/ancestor::div[2]//input");
            By Care_giving_Responsibilities_C = By.XPath("//bdi[contains(text(),'Responsibilities (Ch')]/ancestor::div[2]//input");
            By Care_giving_Responsibilities_A = By.XPath("//bdi[contains(text(),'Responsibilities (A')]/ancestor::div[2]//input");
            By Participation = By.XPath("//bdi[contains(text(),'Participation')]/ancestor::div[2]//input");


            SelectValueFromSFDropdown(Aboriginal_Peoples);
            SelectValueFromSFDropdown(Visible_Minority);
            SelectValueFromSFDropdown(Persons_with_Disabilities);
            SelectValueFromSFDropdown(Group_Membership);
            SelectValueFromSFDropdown(Religious_Affiliation);
            SelectValueFromSFDropdown(Landed_Immigrant);
            SelectValueFromSFDropdown(Military_Service);
            SelectValueFromSFDropdown(Care_giving_Responsibilities_C);
            SelectValueFromSFDropdown(Care_giving_Responsibilities_A);
            SelectValueFromSFDropdown(Participation, "No");
            SetImplicitWait();
        }

        private void SelectValueFromSFDropdown(By selectelement, string textvalue = "Prefer")
        {
            if (IsExists(selectelement))
            {
                By listitem = By.XPath($"//div[contains(@id,'-popup') and contains(@style,'visible')]//li[contains(.,'{textvalue}')]");
                By listitem2 = By.XPath($"//em[contains(.,'{textvalue}')]/ancestor::td");
                Click(selectelement); Clear(selectelement); SystemWait(2);
                SetText(selectelement, textvalue); SystemWait(2);
                if (IsExists(listitem, 3)) { WaitUntilElementDisplayed(listitem); Click(listitem); }
                if (IsExists(listitem2, 3)) { WaitUntilElementDisplayed(listitem2); Click(listitem2); }
                Util.Updatelog($"Select the value in select dropdown", "value selected", State.Pass);
            }
        }

        private void SelectValueFromSFDropdown_AD(string labelname, string textvalue = "No")
        {
            By selectelement = By.XPath($"//bdi[text()='{labelname}']/ancestor::div[2]//input");
            if (IsExists(selectelement))
            {
                By listitem = By.XPath($"//div[contains(@id,'-popup') and contains(@style,'visible')]//li[contains(.,'{textvalue}')]");
                Click(selectelement); Clear(selectelement); SystemWait(2);
                SetText(selectelement, textvalue); SystemWait(2);
                WaitUntilElementDisplayed(listitem); Click(listitem);
                Util.Updatelog($"Select the value in field {labelname}", "value selected", State.Pass);
                WaitTillPageLoadingCompletes();
            }
        }

        public void ClickContinue(Section section)
        {
            By continuebutton = By.XPath($"//bdi[text()='Continue']/ancestor::button[contains(@class,'{section}')]");
            Click(continuebutton);
            SystemWait(5);
            WaitUntilElementInvisible(By.XPath("//div[@id='sap-ui-blocklayer-popup']"), 50);
        }

    }
    public enum Section { IDENTITY, PERSONAL, JOB, COMPENSATION }
}
