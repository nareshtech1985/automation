﻿namespace EY_Test.PageObjects.SuccessFactors.SF_Pages.MPH
{
    using OpenQA.Selenium;
    using Pom.PageObjects;
    public class ManagePendingHireList : MasterPage
    {
        private string _fname, _lname;
        public ManagePendingHireList(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {
            _fname = "";
            _lname = "";
        }

        public void ChoosePage()
        {
            By ddtext = By.XPath("//div[contains(@class,'sapFDynamicPageTitleMainInner')]//div[contains(@id,'select0') and not(@role)]");
            By onbitem = By.XPath("//li[contains(.,'Onboarding 1.0 ')]");
            Click(ddtext);
            Click(onbitem);
        }

        public void ApplyFilter(string firstname, string lastname)
        {
            WaitUntilElementInvisible(By.XPath("//div[contains(@class,'sapUiBlockLayer')]"), 30);
            SystemWait(20);
            _fname = firstname;
            _lname = lastname;

            By fname = By.XPath("//span[contains(.,'First Name')]/ancestor::div[contains(@class,'inputContainer')]//input");
            By lname = By.XPath("//span[contains(.,'Last Name')]/ancestor::div[contains(@class,'inputContainer')]//input");
            By applybutton = By.XPath("(//bdi[text()='Apply']/ancestor::button)[2]");

            WaitTillLoadingCompletes();

            Clear(fname);
            Clear(lname);

            SetText(fname, firstname);
            SetText(lname, lastname);

            Click(applybutton);
        }

        public AddNewEmployee SelectFirstRecord()
        {
            WaitUntilElementInvisible(By.XPath("//div[contains(@class,'sapUiBlockLayer')]"), 30);
            SystemWait(20);
            By firstrowItems = By.XPath($"(//a[text()='{_fname}']|//span[text()='{_lname}'])/ancestor::tr//a");
            SystemWait(1);
            if (IsExists(firstrowItems))
            {
                JSClick(firstrowItems);
                return new AddNewEmployee(Driver);
            }
            else
            {
                return null;
            }
        }


    }
}
