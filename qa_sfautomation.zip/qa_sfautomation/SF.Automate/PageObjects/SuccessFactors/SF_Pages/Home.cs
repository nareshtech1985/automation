﻿namespace EY_Test.PageObjects.SuccessFactors
{
    using EY_Test.PageObjects.SuccessFactors.IntegrationCenter;
    using EY_Test.PageObjects.SuccessFactors.Onboarding;
    using EY_Test.PageObjects.SuccessFactors.SF_Pages.MPH;
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;


    public enum HomePageMenu { Home, Onboarding, AdminCenter, IntegrationCenter }

    public class Home : MasterPage
    {
        private By homePageContent = By.XPath("//section[@id='sapUshellDashboardPage-cont']");
        private By searchBox = By.XPath("//input[@id='bizXSearchField-I']");
        private By selectfirstResult = By.XPath("//ul[contains(@class,'sapMSelectList')]/li");

        public Home(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            WaitUntilElementDisplayed(homePageContent, 30);
            Util.Updatelog("Check home page is displayed", "Home Page is displayed", State.Pass);
        }

        /// <summary>
        /// This will select the user from the list displayed
        /// </summary>
        /// <param name="gui"></param>
        public EmployeeFile SearchGui(string gui)
        {
            Clear(searchBox, 4);
            SystemWait(2);
            SetText(searchBox, gui, 6);
            SystemWait(2);
            if (IsExists(selectfirstResult, 4))
            {
                Click(selectfirstResult, 10);
                Util.Updatelog($"Search for GUI {gui}", "Selected", State.Done);
                return new EmployeeFile(Driver);
            }
            else
            {
                //Util.Updatelog($"Search for GUI {gui}", "User not listed", Status.Fail);
                throw new FrameworkException("User not Listed to select");
            }
        }

        #region Navigation
        public object NavigateTo(HomePageMenu menu)
        {
            WaitUntilElementDisplayed(By.CssSelector("#customHeaderModulePickerBtn-inner"));
            Click(By.CssSelector("#customHeaderModulePickerBtn-inner"));
            switch (menu)
            {
                case HomePageMenu.Home: return null;
                case HomePageMenu.Onboarding:
                    Click(By.XPath("//a[contains(text(),'Onboarding 1.0')]"));
                    return new OnboardingDashboard(Driver);
                case HomePageMenu.AdminCenter: return null;
            }
            return null;
        }


        public object NavigateToManagePendingHires(string searchtext)
        {
            Clear(searchBox, 4);
            SystemWait(2);
            SetText(searchBox, searchtext, 6);
            SystemWait(2);

            var elem = By.XPath($"//li[.='{searchtext}']");

            if (IsExists(elem, 4))
            {
                Click(elem, 10);
                Util.Updatelog($"Search for {searchtext}", "Selected", State.Done);
                return new ManagePendingHireList(Driver);
            }
            else
            {
                Util.Updatelog($"Search for {searchtext}", "User not listed", State.Fail);
                //throw new FrameworkException("User not Listed to select");
                return null;
            }
        }

        public object NavigateToIntegrationCenter(string searchtext)
        {
            Clear(searchBox, 4);
            SystemWait(2);
            SetText(searchBox, searchtext, 6);
            SystemWait(2);

            var elem = By.XPath($"//li[.='{searchtext}']");

            if (IsExists(elem, 4))
            {
                SystemWait(2);
                Click(elem, 10);
                Util.Updatelog($"Search for {searchtext}", "Selected", State.Done);
                return new IntegrationCenterHome(Driver);
            }
            else
            {
                //Util.Updatelog($"Search for {searchtext}", "User not listed", State.Fail);
                //throw new FrameworkException("User not Listed to select");
                return new IntegrationCenterHome(Driver, true);
            }
        }

        #endregion


    }
}
