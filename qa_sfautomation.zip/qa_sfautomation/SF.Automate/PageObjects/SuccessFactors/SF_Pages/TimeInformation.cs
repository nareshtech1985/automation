﻿namespace EY_Test.PageObjects.SuccessFactors
{
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using SF.Parameter;
    using System;


    public class TimeInformation : MasterPage
    {
        private readonly By timeRecordSection = By.XPath("//span[contains(text(),'Time Records')]/ancestor::div[contains(@class,'sapUiVlt ')]");

        public TimeInformation(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {
            WaitUntilElementDisplayed(timeRecordSection);
            Util.Updatelog("Check time information page is displayed", "Time information is displayed", State.Pass);
        }

        public void ValidateTimeOffData(TimeOffParameter parameters)
        {
            By row = By.XPath($"//span[text()='{parameters.LeaveDescription}']/ancestor::tr");
            if (IsExists(row))
            {
                Click(row);
                SystemWait(5);
                Util.Updatelog("Check the leave record is displayed", "Leave record displayed", State.Pass);

                By actualstatusValue = By.XPath("//span[contains(text(),'Actual Return')]/ancestor::tr/td[2]");
                if (GetText(actualstatusValue).Equals("-"))
                {
                    Console.WriteLine("Pass!");
                }

            }
            else
            {
                Util.Updatelog("Check the leave record is displayed", "Data not displayed", State.Fail);
            }

            By Ok = By.XPath("//BDI[contains(text(),'OK')]/ancestor::button");
            if (IsExists(Ok)) { Click(Ok); } else { Driver.Navigate().Refresh(); WaitTillPageLoadingCompletes(); }

        }

        public void ValidateReturnFromLeave(TimeOffParameter time)
        {
            By row = By.XPath($"//span[text()='{time.LeaveDescription}']/ancestor::tr");
            if (IsExists(row))
            {
                Click(row);
                SystemWait(5);
                Util.Updatelog("Check the leave record is displayed", "Leave record displayed", State.Pass);

                By actualstatusValue = By.XPath("//span[contains(text(),'Actual Return')]/ancestor::tr/td[2]");
                if (!GetText(actualstatusValue).Equals("-"))
                {
                    Util.Updatelog("Check Return date is updated", "Return date is updated", State.Pass);
                }
                else
                {
                    Util.Updatelog("Check Return date is updated", "Return date is updated", State.Fail);
                }

            }
            else
            {
                Util.Updatelog("Check the leave record is displayed", "Data not displayed", State.Fail);
            }

            By Ok = By.XPath("//BDI[contains(text(),'OK')]/ancestor::button");
            if (IsExists(Ok)) { Click(Ok); } else { Driver.Navigate().Refresh(); WaitTillPageLoadingCompletes(); }

        }
    }


}
