﻿namespace EY_Test.PageObjects.SuccessFactors
{
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;

    public class EmployeeFile : MasterPage
    {
        private By menubar = By.XPath("//div[@id='__xmlview0--objectPage-anchBar']");
        public EmployeeFile(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            WaitTillPageLoadingCompletes(20);
            WaitUntilElementDisplayed(menubar, 10);
            Util.Updatelog("Check Employee file is displayed", "Employee file displayed", State.Pass);
            By personalInfoLink = By.XPath("//bdi[contains(text(),'Personal Information')]/ancestor::button");
            if (IsExists(personalInfoLink))
            {
                Click(personalInfoLink);
                WaitTillLoadingCompletes();
            }
            else
            {

            }
        }

        public void NavigateToEmploymentInfo()
        {
            SystemWait(5);
            By employmentinfoLink = By.XPath("//bdi[contains(text(),'Employment Information')]/ancestor::button");
            if (IsExists(employmentinfoLink))
            {
                Click(employmentinfoLink);
                WaitTillLoadingCompletes();
            }
            else
            {
                throw new FrameworkException($"Unable to click button with Locator : {employmentinfoLink}");
            }
        }

        public void CheckEmployeeStatusIs(string v)
        {
            By employeeStatus = By.XPath("//span[contains(text(),'Employee Sta')]/../../td[2]");

            if (GetText(employeeStatus).Trim().Equals(v))
            {
                Util.Updatelog($"Check the employee status is displayed as {v}", "Status is expected", State.Pass);
            }
            else
            {
                Util.Updatelog($"Check the employee status is displayed as {v}", $"Status is not as expected, {GetText(employeeStatus)}", State.Fail);
            }
        }

        public void NavigateToTimeOff()
        {
            SystemWait(5);
            By timeOffLink = By.XPath("//bdi[contains(text(),'Time Off')]/ancestor::button");
            if (IsExists(timeOffLink))
            {
                Click(timeOffLink);
                WaitTillLoadingCompletes();
            }
            else
            {
                throw new FrameworkException($"Unable to click button with Locator : {timeOffLink}");
            }

            //Check the Timeoff Section is displayed
            By timeOffBox = By.XPath("//div[contains(@class,'timeOffUpcomingTimeOffLTR')]");
            if (IsExists(timeOffBox))
            {
                Util.Updatelog("Check the time off seciton displayed", "Upcoming Time off section displayed", State.Pass);
            }
        }

        public TimeInformation AdministerTimeOff()
        {
            By link = By.XPath("//a[contains(text(),'Administer Time')]");
            if (IsExists(link))
            {
                Click(link);
                return new TimeInformation(Driver);
            }
            else
            {
                throw new FrameworkException("Administer Time linke not displayed");
            }
        }
    }
}
