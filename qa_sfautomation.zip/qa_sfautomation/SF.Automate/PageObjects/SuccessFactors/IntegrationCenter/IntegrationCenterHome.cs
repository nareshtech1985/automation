﻿namespace EY_Test.PageObjects.SuccessFactors.IntegrationCenter
{
    using OpenQA.Selenium;


    using Pom.PageObjects;
    public class IntegrationCenterHome : MasterPage
    {
        public IntegrationCenterHome(IWebDriver Driver, bool forceload = false) : base(Driver)
        {
            if (forceload)
            {
                Driver.Url = @"https://hcm12preview.sapsf.eu/xi/ui/integrationbuilder/pages/index.xhtml";
                WaitUntilElementDisplayed("icheader");
            }
        }

        public override void IntializePage()
        {
            WaitUntilElementDisplayed("icheader");
        }

        public MyIntegrationPage NavigateToMyIntegrations()
        {
            WaitTillPageLoadingCompletes();
            WaitUntilElementClickable("ic_myintegration_tile");
            Click("ic_myintegration_tile");
            WaitTillPageLoadingCompletes();
            return new MyIntegrationPage(Driver);
        }
    }
}
