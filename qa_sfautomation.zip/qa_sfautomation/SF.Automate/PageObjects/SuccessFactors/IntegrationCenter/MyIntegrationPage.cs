﻿namespace EY_Test.PageObjects.SuccessFactors.IntegrationCenter
{
    using cryptic;
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using System;

    public class MyIntegrationPage : MasterPage
    {
        public MyIntegrationPage(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {

        }

        public bool SearchAndSelectPackage(string searchtext = "")
        {
            WaitTillPageLoadingCompletes();
            Clear("ic_search", 20);
            SetText("ic_search", searchtext, 20);
            if (Finds(ReadBy("ic_package_select", searchtext)).Count > 0)
            {
                Util.Updatelog($"Search for {searchtext}", "Integration package available", State.Pass);
                Click(ReadBy("ic_package_select", searchtext));
                WaitTillPageLoadingCompletes();
                return true;
            }
            else
            {
                Util.Updatelog($"Search for {searchtext}", "Integration package not available", State.Fail);
                return false;
            }
        }

        public string ClickReviewandRun()
        {
            WaitTillPageLoadingCompletes();

            string integrationname = "";
            string sftpfilelocation = "";
            string sftppath = "";

            integrationname = GetAttribute("ic_name", "value", 20);

            WaitUntilElementDisplayed("ic_reviewandrun_block");
            Click("ic_reviewandrun_block");

            sftpfilelocation = GetText("ic_fileLocation");
            sftppath = GetText("ic_sftppath");

            if (Util.TestConfiguration.Environment.ToLower().Equals("itsdev1"))
            {
                if (sftpfilelocation.ToLower().Contains("prod") || !sftppath.ToLower().Contains("sftp012.successfactors.eu"))
                {
                    TestLog.Debug("Configuration is Prod exiting the execution");
                    throw new FrameworkException("Prod configuration for the IC Job");
                }
            }


            WaitUntilElementDisplayed("ic_runnow_button", 30);
            Click("ic_runnow_button");

            WaitUntilElementDisplayed("bdi_OkButton", 50);
            Click("bdi_OkButton");

            WaitUntilElementDisplayed("bdi_CancelButton", 10);
            Click("bdi_CancelButton");

            WaitUntilElementDisplayed("ic_search", 30);

            return sftpfilelocation;
        }

        public void ReconfigureSFTP_ForITSDEV1()
        {
            Credential Credential = Util.TestConfiguration.Credentials.Find(x => x.Name.Equals("SFTP", StringComparison.InvariantCultureIgnoreCase));
            Cred CypherProgram = new Cred() { Publickey = Util.TestConfiguration.GetCustomKeyValue("publicKey") };
            try
            {
                WaitTillPageLoadingCompletes();
                Click("ic_dest_header");

                WaitTillPageLoadingCompletes();
                SystemWait(1);

                Clear("ic_dest_hostaddress");
                SetText("ic_dest_hostaddress", Credential.URL);

                Click("ic_dest_authtype");
                Click("ic_dest_basicauth");

                SystemWait(3);


                Clear("ic_dest_password");
                SetPasswordText(ReadBy("ic_dest_password"), CypherProgram.Decrypt(Credential.Password));

                Clear("ic_dest_username");
                SetText("ic_dest_username", Credential.UserName);

                Clear("ic_dest_filefolder");
                SetText("ic_dest_filefolder", "/int/outbound/FoundationObjects_Dev");
                SystemWait(3);

                Click("ic_next");
                SystemWait(2);
                Click("ic_sche_occur");
                WaitUntilElementDisplayed("ic_sche_notscheduled");
                Click("ic_sche_notscheduled");

                Click("ic_save_icon");

                WaitUntilElementDisplayed("ic_save_btn", 10);
                Click("ic_save_btn");

                WaitUntilElementDisplayed("ic_save_confirm", 10);
                Click("ic_save_confirm");

                WaitUntilElementDisplayed("ic_con_ok", 10);
                Click("ic_con_ok");

                WaitUntilElementDisplayed("bdi_CancelButton", 10);
                Click("bdi_CancelButton");

            }
            catch (Exception e)
            {
                TestLog.Error($"Unable to reconfigure IC Job {e.Message}");
            }
            //int/outbound/FoundationObjects_Dev
        }
    }
}