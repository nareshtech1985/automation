﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EY_Test.PageObjects.SuccessFactors.IntegrationCenter
{
    public class fomapper
    {
        public List<FoMap> Data { get; set; }
    }

    public class FoMap
    {
        public string FOObject { get; set; }
        public bool IsCPI { get; set; }
        public bool IsSFIC { get; set; }
        public string PackageName { get; set; }
    }

}
