﻿namespace EY_Test.PageObjects.SuccessFactors.IDT
{
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using System;


    public class IDTool : MasterPage
    {
        private By SearchButton = By.XPath("//button[.='Search']");
        private By GenerateButton = By.XPath("//button[.='Generate/Confirm IDs']");
        private By GenerateGUIYesButton = By.XPath("//button[.='YES']");
        private By GUIText = By.XPath("//bdi[.='GUI:']/ancestor::div[2]//input");
        private By GPNText = By.XPath("//bdi[.='GPN:']/ancestor::div[2]//input");
        private By LPNText = By.XPath("//bdi[.='LPN:']/ancestor::div[2]//input");
        private By CloseButton = By.XPath("//footer//button[.='Close']");
        private By _CloseButton = By.XPath("//button[@title='Close']");
        private By ExistingIDPanel = By.XPath("//div[contains(@class,'sapMPanelBGTransparent')]");
        private By EGUIText = By.XPath("//span[contains(.,'GUI [New]')]/ancestor::div[2]//span[@data-sap-ui='__text1']");
        private By ELPNText = By.XPath("//span[contains(.,'LPN [New]')]/ancestor::div[2]//span[@data-sap-ui='__text2']");
        private By EGPNText = By.XPath("//span[contains(.,'GPN [New]')]/ancestor::div[2]//span[@data-sap-ui='__text3']");
        private By NAGUI = By.XPath("//span[contains(.,'GUI [NA')]/ancestor::div[2]//span[@data-sap-ui='__text1']");

        public IDTool(IWebDriver Driver) : base(Driver)
        {

        }

        public override void IntializePage()
        {
            SwtichToNewTab();
            Driver.Manage().Window.Maximize();

        }

        public (string gui, string lpn, string gpn) SearchandGenerateValues()
        {
            string gui = "";
            string gpn = "";
            string lpn = "";

            Click(SearchButton); WaitTillPageLoadingCompletes(); if (IsDisplayed(_CloseButton)) Click(_CloseButton);
            Click(SearchButton); WaitTillPageLoadingCompletes(); if (IsDisplayed(_CloseButton)) Click(_CloseButton);

            if (IsExists(ExistingIDPanel) && !GetText(NAGUI).ToLower().Equals("na"))
            {
                gui = GetText(EGUIText);
                lpn = GetText(ELPNText);
                gpn = GetText(EGPNText);
            }

            Click(GenerateButton);
            WaitTillPageLoadingCompletes();
            WaitUntilElementDisplayed(GenerateGUIYesButton);
            Click(GenerateGUIYesButton);
            try
            {
                WaitTillPageLoadingCompletes();
                WaitUntilElementDisplayed(CloseButton);

                if (IsDisplayed(CloseButton))
                {
                    gui = GetAttribute(GUIText, "value");
                    lpn = GetAttribute(LPNText, "value");
                    gpn = GetAttribute(GPNText, "value");
                }
                SystemWait(3);
                if (IsExists(CloseButton)) { Click(CloseButton); }

            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
                throw;
            }
            finally
            {

            }

            return (gui, lpn, gpn);
        }

    }
}
