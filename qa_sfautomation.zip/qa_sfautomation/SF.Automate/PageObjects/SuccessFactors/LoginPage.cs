﻿namespace EY_Test.PageObjects
{
    using cryptic;
    using EY_Test.PageObjects.SuccessFactors;
    using OpenQA.Selenium;
    using Pom;
    using Pom.PageObjects;
    using System;

    public class LoginPage : MasterPage
    {
        private readonly By loginButton = By.XPath("//bdi[text()='Log in']/ancestor::button");
        private readonly By loginContent = By.XPath("//section[@id='login-cont']");
        private readonly By password = By.XPath("//input[@id='__input2-inner']");
        private readonly By userName = By.XPath("//input[@id='__input1-inner']");
        public LoginPage(IWebDriver Driver) : base(Driver)
        {
        }

        public override void IntializePage()
        {
            if (Util.TestConfiguration.Environment.Equals(Constants.ITSDEV1, StringComparison.InvariantCultureIgnoreCase))
            {
                Driver.Url = "https://hcm12preview.sapsf.eu/login?company=EYITSDEV1#/login";
            }
            else if (Util.TestConfiguration.Environment.Equals(Constants.TST1, StringComparison.InvariantCultureIgnoreCase))
            {
                Driver.Url = Util.TestConfiguration.Credentials.Find(x => x.Name.Equals("SF")).URL;
            }
            else
            {
                Driver.Url = Util.TestConfiguration.Credentials.Find(x => x.Name.Equals("SF")).URL;
            }

            //
            WaitTillPageLoadingCompletes();
            WaitUntilElementDisplayed(loginContent, 30);
            if (IsExists(loginContent))
            {
                Util.Updatelog("Check Sign In page is displayed", "Sign in page is displayed", State.Pass);
            }
            else
            {
                Util.Updatelog("Login Page not found", State.Done);
            }
        }

        public Home Login()
        {
            if (IsExists(loginContent))
            {
                /* Only appplicable to ITSDEV1 environment */
                Clear(userName);
                Clear(password);
                Cred CypherProgram = new Cred() { Publickey = Util.TestConfiguration.GetCustomKeyValue("publicKey") };
                var cred = Util.TestConfiguration.Credentials.Find(x => x.Name.Equals("SF"));
                SetText(userName, cred.UserName);
                SetPasswordText(password, CypherProgram.Decrypt(cred.Password));
                SetPasswordText(password, Keys.Enter);
                //Click(loginButton);
                WaitTillLoadingCompletes(20);
            }
            else
            {
                Util.Updatelog("Login", "SSO Enabled Login", State.Done);
            }
            return new Home(Driver);
        }
    }
}