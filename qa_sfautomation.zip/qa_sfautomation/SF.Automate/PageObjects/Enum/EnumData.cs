﻿public enum YesNo
{
    Yes,No
}