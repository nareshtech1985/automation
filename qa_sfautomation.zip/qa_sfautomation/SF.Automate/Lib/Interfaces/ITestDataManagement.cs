﻿namespace Pom
{
    using System.Collections.Generic;

    public interface ITestDataManagement
    {
        string GetData(string key, string value, string filename);

        string GetData(string key, string filename);

        Dictionary<string, string> GetDataDictionary(string Key, string filename);

        Dictionary<string, Dictionary<string, string>> GetDataDictionary(string filename);

        bool IsKeyValuePresentInTestData(string key, string value1, string filename);

        void WritetoTestData(string key, string value, string data, string filename);
    }
}