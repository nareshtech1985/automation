namespace Pom
{
    using DocumentFormat.OpenXml.Packaging;
    using DocumentFormat.OpenXml.Spreadsheet;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;


    public class XLRW : IDisposable
    {
        private SpreadsheetDocument mybook;
        private Sheet thecurrentsheet;
        private Worksheet thecurrentwsheet;
        private WorkbookPart workbookPart;
        private WorksheetPart wspart;
        private SheetData thesheetdata;
        public XLRW(string filename)
        {
            mybook = SpreadsheetDocument.Open($@"{Util.DirectoryPath}\{filename}", false);
        }

        /// <summary>
        /// This is list down all of the sheets available in the workbook
        /// </summary>
        /// <returns></returns>
        public List<string> GetSheets()
        {
            List<string> xlSheets = new List<string>();
            workbookPart = mybook.WorkbookPart;
            Sheets thesheetcollection = workbookPart.Workbook.GetFirstChild<Sheets>();
            StringBuilder excelResult = new StringBuilder();

            //using for each loop to get the sheet from the sheetcollection  
            foreach (Sheet thesheet in thesheetcollection)
            {
                xlSheets.Add(thesheet.Name);
            }
            return xlSheets;
        }

        /// <summary>
        /// This is set the current sheet pointer to the specified sheet, by default the sheet1 is considered when name is not provided.
        /// </summary>
        /// <param name="sheetname"></param>
        public void SetSheet(string sheetname = "Sheet1")
        {
            try
            {
                thecurrentsheet = workbookPart.Workbook.Descendants<Sheet>().Where(x => x.Name == sheetname).FirstOrDefault();
                thecurrentwsheet = ((WorksheetPart)workbookPart.GetPartById(thecurrentsheet.Id)).Worksheet;
                Console.WriteLine($"Sheet selected is {sheetname}");
            }
            catch (Exception)
            {
                thecurrentsheet = workbookPart.Workbook.Descendants<Sheet>().FirstOrDefault();
                thecurrentwsheet = ((WorksheetPart)workbookPart.GetPartById(thecurrentsheet.Id)).Worksheet;
                Console.WriteLine($"Unable to select the mentioned sheet or sheet name is incorrect!. Name : {sheetname}\nDefault Sheet is selected.Name :{thecurrentsheet.Name}");
            }
        }

        /// <summary>
        /// this will read the cell value based on the refernece passed. data value will be returned in a seriazlied format which need to be convereted.
        /// </summary>
        /// <param name="cellreference"></param>
        /// <returns></returns>
        public string GetCellValues(string cellreference)
        {
            string cellvalue = string.Empty;
            wspart = (WorksheetPart)workbookPart.GetPartById(thecurrentsheet.Id);
            Cell thecell = wspart.Worksheet.Descendants<Cell>().Where(x => x.CellReference == cellreference).FirstOrDefault();
            if (thecell != null)
            {
                if (thecell.CellValue != null && thecell.CellValue.InnerText != null)
                {
                    cellvalue = thecell.CellValue.InnerText;

                    if (thecell.DataType != null)
                    {
                        switch (thecell.DataType.Value)
                        {
                            case CellValues.SharedString:
                                var stringtbl = workbookPart.GetPartsOfType<SharedStringTablePart>().FirstOrDefault();
                                if (stringtbl != null)
                                {
                                    cellvalue = stringtbl.SharedStringTable.ElementAt(int.Parse(cellvalue)).InnerText;
                                }
                                break;
                            case CellValues.Boolean:
                                switch (cellvalue)
                                {
                                    case "0":
                                        cellvalue = "FALSE";
                                        break;
                                    default:
                                        cellvalue = "TRUE";
                                        break;
                                }
                                break;
                            case CellValues.String:
                                cellvalue = thecell.CellValue.InnerText;
                                break;
                        }
                    }
                }
            }
            return cellvalue;
        }

        /// <summary>
        /// This should be called to close the file, so that memory is not wasted.
        /// </summary>
        public void CloseFile()
        {
            mybook.Save();
            //mybook.SaveAs("Output.xlsx") ;
            mybook.Close();
        }

        /// <summary>
        /// This will return the number of rows in the sheet selected
        /// </summary>
        /// <returns></returns>
        public int GetRowCount()
        {
            thesheetdata = thecurrentwsheet.GetFirstChild<SheetData>();
            return thesheetdata.Count();
        }

        /// <summary>
        /// This will return the number of columns based on the first row
        /// </summary>
        /// <returns></returns>
        public int GetColumnCount()
        {
            Row row = thesheetdata.Descendants<Row>().First();

            return row.Count();
        }

        public static void ReadExcelFile()
        {
            try
            {
                //Lets open the existing excel file and read through its content . Open the excel using openxml sdk
                using (SpreadsheetDocument doc = SpreadsheetDocument.Open("RSDFile.xlsx", false))
                {
                    //create the object for workbook part  
                    WorkbookPart workbookPart = doc.WorkbookPart;
                    Sheets thesheetcollection = workbookPart.Workbook.GetFirstChild<Sheets>();
                    StringBuilder excelResult = new StringBuilder();

                    //using for each loop to get the sheet from the sheetcollection  
                    foreach (Sheet thesheet in thesheetcollection)
                    {
                        excelResult.AppendLine("Excel Sheet Name : " + thesheet.Name);
                        excelResult.AppendLine("----------------------------------------------- ");
                        //statement to get the worksheet object by using the sheet id  
                        Worksheet theWorksheet = ((WorksheetPart)workbookPart.GetPartById(thesheet.Id)).Worksheet;

                        SheetData thesheetdata = theWorksheet.GetFirstChild<SheetData>();
                        foreach (Row thecurrentrow in thesheetdata)
                        {
                            foreach (Cell thecurrentcell in thecurrentrow)
                            {
                                //statement to take the integer value  
                                string currentcellvalue = string.Empty;
                                if (thecurrentcell.DataType != null)
                                {
                                    if (thecurrentcell.DataType == CellValues.SharedString)
                                    {
                                        int id;
                                        if (Int32.TryParse(thecurrentcell.InnerText, out id))
                                        {
                                            SharedStringItem item = workbookPart.SharedStringTablePart.SharedStringTable.Elements<SharedStringItem>().ElementAt(id);
                                            if (item.Text != null)
                                            {
                                                //code to take the string value  
                                                excelResult.Append(item.Text.Text + " ");
                                            }
                                            else if (item.InnerText != null)
                                            {
                                                currentcellvalue = item.InnerText;
                                            }
                                            else if (item.InnerXml != null)
                                            {
                                                currentcellvalue = item.InnerXml;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    excelResult.Append(thecurrentcell.InnerText + " ");
                                }
                            }
                            excelResult.AppendLine();
                        }
                        excelResult.Append("");
                        Console.WriteLine(excelResult.ToString());
                        Console.ReadLine();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        internal void SetCellValue(string cellreference, string value)
        {
            var cr = ConvertToRowandColumn(cellreference);
            var xy = Int32.Parse(Regex.Replace(cellreference, "[^0-9]*", string.Empty));
            wspart = (WorksheetPart)workbookPart.GetPartById(thecurrentsheet.Id);
            var r = wspart.Worksheet.Descendants<Row>().Where(x => Int32.Parse(x.RowIndex.InnerText) == xy).FirstOrDefault();
            var cel = r.Descendants<Cell>().Any(x => x.CellReference.Equals(cellreference.ToUpper()));
            if (!cel)
            {
                for (int i = r.ChildElements.Count; i < (cr[1] - 1); i++)
                {
                    r.Append(new Cell());
                }
                Cell c = new Cell()
                {
                    CellReference = cellreference,
                    DataType = CellValues.SharedString,
                };
                r.Append(c);
            }
        }
        private int[] ConvertToRowandColumn(string range)
        {
            string pattern = "(?<=[a-zA-Z])(?=[0-9])";// |((?<=[0-9])(?=[a-zA-Z]))
            string Column = Regex.Split(range, pattern)[0];
            string Row = Regex.Split(range, pattern)[1];

            char[] colLetters = Column.ToCharArray();
            int[] cell = new int[2];
            cell[0] = Convert.ToInt32(Row);
            if (colLetters.Length == 1)
            {
                cell[1] = 26 - ('Z' - colLetters[0]);
            }
            else if (colLetters.Length == 2)
            {
                int[] colChar = new int[Column.Length];
                colChar[0] = 26 - ('Z' - colLetters[0]);
                colChar[1] = 26 - ('Z' - colLetters[1]);
                cell[1] = (26 * colChar[0]) + colChar[1];
            }
            else if (colLetters.Length == 3)
            {
                int[] colChar = new int[Column.Length];
                colChar[0] = 26 - ('Z' - colLetters[0]);
                colChar[1] = 26 - ('Z' - colLetters[1]);
                colChar[2] = 26 - ('Z' - colLetters[2]);
                cell[1] = (676 * colChar[0]) + (26 * colChar[1]) + colChar[2];
            }
            return cell;
        }

        public void Dispose()
        {
            mybook.Close();
            mybook.Dispose();
        }
    }
}