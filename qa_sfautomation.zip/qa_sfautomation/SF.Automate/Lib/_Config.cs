﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;

    public static class Converter
    {
        public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
        {
            MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
            DateParseHandling = DateParseHandling.None,
            Converters =
            {
                new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
            },
            Formatting = Formatting.Indented,
            NullValueHandling = NullValueHandling.Ignore
        };
    }

    public static class Serialize
    {
        public static string ToJson(this Config self) => JsonConvert.SerializeObject(self, Converter.Settings);
    }

    public partial class Credential
    {
        [JsonProperty("Application")]
        public string Application { get; set; }

        [JsonProperty("Url")]
        public string Url { get; set; }

        [JsonProperty("Domain")]
        public string Domain { get; set; }

        [JsonProperty("UserName")]
        public string UserName { get; set; }

        [JsonProperty("Password")]
        public string Password { get; set; }

        [JsonProperty("PrivateKey", NullValueHandling = NullValueHandling.Ignore)]
        public string PrivateKey { get; set; }
    }

    public partial class CustomKey
    {
        [JsonProperty("Key")]
        public string Key { get; set; }

        [JsonProperty("Value")]
        public string Value { get; set; }
    }

    public partial class Config
    {
        [JsonProperty("AUT")]
        public string Aut { get; set; }

        [JsonProperty("TimeOut")]
        public long TimeOut { get; set; }

        [JsonProperty("Browser")]
        public string Browser { get; set; }
        
        [JsonProperty("Headless")]
        public bool Headless { get; set; }

        [JsonProperty("ExeRegion")]
        public string ExeRegion { get; set; }

        [JsonProperty("APIAuthetication")]
        public List<Apiauthentication> APIAuthetication { get; set; }

        [JsonProperty("Credentials")]
        public List<Credential> Credentials { get; set; }

        [JsonProperty("RegionData")]
        public List<RegionData> RegionData { get; set; }

        [JsonProperty("CustomKeys")]
        public List<CustomKey> CustomKeys { get; set; }


        public class Apiauthentication
        {
            [JsonProperty("api")]
            public string API { get; set; }
            [JsonProperty("authentication")]
            public string Authentication { get; set; }
            [JsonProperty("baseurl")]
            public string BaseUrl { get; set; }
        }

        public string GetCustomKeyValue(string key)
        {
            var a = this.CustomKeys.Find(x => x.Key.ToLower().Equals(key.ToLower()));
            return a.Value;
        }

        public RegionData GetRegion()
        {
            var a = this.RegionData.Find(x => x.Region.Equals(this.ExeRegion));
            return a;
        }

        /// <summary>
        /// Returns the application url
        /// </summary>
        /// <returns></returns>
        public string GetURL()
        {
            var a = this.RegionData.Find(x => x.Region.Equals(this.ExeRegion) && x.Aut.ToLower().Equals(this.Aut.ToLower()));
            return a.Url.ToString();
        }

        /// <summary>
        /// Returns the User Name
        /// </summary>
        /// <returns></returns>
        public Credential GetUserName()
        {
            var a = this.Credentials.Find(x => x.Application.ToLower().Equals(this.Aut.ToLower()));
            return a;
        }

        /// <summary>
        /// Returns the Connection String
        /// </summary>
        /// <returns></returns>
        public string GetConnectionString()
        {
            var a = this.RegionData.Find(x => x.Region.Equals(this.ExeRegion) && x.Aut.ToLower().Equals(this.Aut.ToLower()));
            return a.CS.ToString();
        }
    }

    public partial class Config
    {
        public static Config FromJson(string json) => JsonConvert.DeserializeObject<Config>(json, Pom.Converter.Settings);

        public static T FromAnyJson<T>(string json) where T:class => JsonConvert.DeserializeObject<T>(json, Pom.Converter.Settings);
    }

    public partial class RegionData
    {
        [JsonProperty("Region")]
        public string Region { get; set; }

        [JsonProperty("AUT")]
        public string Aut { get; set; }

        [JsonProperty("URL")]
        public Uri Url { get; set; }

        [JsonProperty("CS")]
        public Uri CS { get; set; }
    }
}