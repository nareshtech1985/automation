﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace EyFramework
{ using Pom; using Newtonsoft.Json;
    using System.Collections.Generic;

    public partial class Translation
    {
        [JsonProperty("Id")]
        public string Id { get; set; }

        [JsonProperty("Lang")]
        public string Lang { get; set; }

        [JsonProperty("Text")]
        public string Text { get; set; }
    }

    public partial class Translation
    {
        public static List<Translation> FromJson(string json)
        {
            return JsonConvert.DeserializeObject<List<Translation>>(json, POMFramework.Converter.Settings);
        }
    }
}