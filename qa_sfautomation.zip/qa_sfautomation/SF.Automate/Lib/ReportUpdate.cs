﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{
    using HtmlAgilityPack;
    using System;
    using System.IO;
    using System.Text.RegularExpressions;

    public class ReportUpdate
    {
        /// <summary>
        /// This method will correct the image displayed in the extent report, this works only if the report is generated
        /// </summary>
        /// <param name="filepath"></param>
        public static void AddImagePositionScriptsinReportHtml(string filepath)
        {
            if (File.Exists(filepath))
            {
                var htmlDoc = new HtmlDocument();
                htmlDoc.Load(filepath);
                var linkNodes = htmlDoc.DocumentNode.SelectNodes(".//a[@data-featherlight='image']");
                if (linkNodes != null)
                {
                    foreach (var linkNode in linkNodes)
                    {
                        var parentNode = linkNode.ParentNode;
                        var base64String = linkNode.Attributes["href"].Value;
                        var node = HtmlNode.CreateNode($"<div><img src=\"{base64String}\" style=\"width: 600px; height: auto;\"/></div>");
                        parentNode.RemoveChild(linkNode);
                        parentNode.AppendChild(node);
                    }

                }

                // get the header text for dashboard
                var headers = htmlDoc.DocumentNode.SelectNodes("//div[@class='left panel-name']/text()");
                var testHeader = headers[0] as HtmlTextNode;
                var stepHeader = headers[1] as HtmlTextNode;
                //Replace headers with Features and Scenarios
                testHeader.Text = testHeader.InnerText.Replace(testHeader.InnerText, "Features");
                stepHeader.Text = stepHeader.InnerText.Replace(stepHeader.InnerText, "Scenarios");
                //replace Test to Features in pass count
                var testPassed = htmlDoc.DocumentNode.SelectSingleNode("//div[@id='test-view-charts']//span[contains(.,'test')]/text()") as HtmlTextNode;
                testPassed.Text = testPassed.InnerText.Replace(testPassed.InnerText, " feature(s) passed");
                //replace Step to Scenarios in pass count
                var stepPassed = htmlDoc.DocumentNode.SelectSingleNode("//div[@id='test-view-charts']//span[contains(.,'step')]/text()") as HtmlTextNode;
                stepPassed.Text = stepPassed.InnerText.Replace(stepPassed.InnerText, " scenario(s) passed");
                //Get the Execution Count 
                var executionCount = htmlDoc.DocumentNode.SelectNodes("//div[@class='col s12 m6 l6 np-h']//span[@class='strong']/text()");
                //Set Pass count for Scenarios
                var passcount = executionCount[4] as HtmlTextNode;
                int passedScenarios;
                try
                {
                    passedScenarios = htmlDoc.DocumentNode.SelectNodes("//li[@class='node level-1  pass']").Count;
                }
                catch (Exception)
                {
                    passedScenarios = 0;
                }

                passcount.Text = passedScenarios.ToString();
                //Set Fail count for Scenarios
                var failcount = executionCount[5] as HtmlTextNode;
                int failedScenarios;
                try
                {
                    failedScenarios = htmlDoc.DocumentNode.SelectNodes("//li[@class='node level-1  fail']").Count;
                }
                catch (Exception)
                {
                    failedScenarios = 0;
                }
                failcount.Text = failedScenarios.ToString();

                //Set skip count for Scenarios
                var skipcount = executionCount[6] as HtmlTextNode;
                int skippedScenarios;
                try
                {
                    skippedScenarios = htmlDoc.DocumentNode.SelectNodes("//li[@class='node level-1  skip']").Count;
                }
                catch (Exception)
                {
                    skippedScenarios = 0;
                }

                skipcount.Text = skippedScenarios.ToString();

                int totalCount = passedScenarios + failedScenarios + skippedScenarios;
                //update Dashboard Page

                var dashboardTest = htmlDoc.DocumentNode.SelectSingleNode("//div[@id='dashboard-view']//div[contains(text(),'Tests')]/text()") as HtmlTextNode;
                dashboardTest.Text = dashboardTest.InnerText.Replace(dashboardTest.InnerText, " Features");

                var dashboardScenarioCount = htmlDoc.DocumentNode.SelectSingleNode("//div[@id='dashboard-view']//div[contains(text(),'Steps')]/div/text()") as HtmlTextNode;
                dashboardScenarioCount.Text = totalCount.ToString();

                var dashboardScenario = htmlDoc.DocumentNode.SelectSingleNode("//div[@id='dashboard-view']//div[contains(text(),'Steps')]/text()") as HtmlTextNode;
                dashboardScenario.Text = dashboardScenario.InnerText.Replace(dashboardScenario.InnerText, " Scenarios");

                // update chart
                var script = htmlDoc.DocumentNode.SelectNodes("//script");

                string scriptcontent = script[1].InnerText;
                script[1].Remove();
                string[] chartValues = { "childCount", "passChild", "failChild", "skipChild", "exceptionsChild" };

                int[] ExecutionCount = { totalCount, passedScenarios, failedScenarios, skippedScenarios, failedScenarios + skippedScenarios };

                for (int i = 0; i < ExecutionCount.Length; i++)
                {
                    string value = Regex.Match(scriptcontent, chartValues[i] + ":.*?,").ToString();
                    scriptcontent = scriptcontent.Replace(value, chartValues[i] + ":" + ExecutionCount[i] + ",");
                }

                var bodyNode = htmlDoc.DocumentNode.SelectSingleNode("//body");
                bodyNode.PrependChild(HtmlNode.CreateNode("<script>" + scriptcontent + "</script>"));

                // update percentage
                decimal Pass_percent = (passedScenarios / (decimal)totalCount) * 100;
                Pass_percent = Math.Truncate(Pass_percent * 100) / 100;
                decimal fail_percent = (failedScenarios / (decimal)totalCount) * 100;
                fail_percent = Math.Truncate(fail_percent * 100) / 100;
                decimal skip_percent = (skippedScenarios / (decimal)totalCount) * 100;
                skip_percent = Math.Truncate(skip_percent * 100) / 100;
                var scripts = htmlDoc.DocumentNode.SelectNodes("//span[@class='tooltipped']");
                scripts[4].Attributes["data-tooltip"].Value = Pass_percent + "%";
                scripts[5].Attributes["data-tooltip"].Value = fail_percent + "%";
                scripts[6].Attributes["data-tooltip"].Value = skip_percent + "%";
                htmlDoc.Save(filepath);

                htmlDoc.Save(filepath);
            }
        }
    }
}