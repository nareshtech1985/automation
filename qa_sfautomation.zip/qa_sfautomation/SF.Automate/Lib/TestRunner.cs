﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{
    using EY_Test.API.Framework;
    using EY_Test.PageObjects;
    using NLog;
    using NUnit.Framework;
    using NUnit.Framework.Internal;
    using OpenQA.Selenium;
    using Pom.DataHelpers;
    using Pom.PageObjects;
    using SF.Automate.PageObjects.Modules;
    using System;
    using System.Collections.Generic;
    using System.Text.RegularExpressions;

    /// <summary>
    /// Summary description for TestTemplate
    /// </summary>
    [SetUpFixture]
    public class TestRunner
    {
        #region Framwork Variables
        private IWebDriver _driver;
        private string _testName { get; set; }
        protected Dictionary<string, Dictionary<string, string>> data;
        protected IWebDriver Driver { get => _driver; set => _driver = value; }
        public string TestName { get => _testName; set => _testName = value; }
        public static IWebDriver WebDriver { get; set; }
        #endregion

        #region Project Related Variable Only
        /* SF API Automation Related Changes */
        //protected DBValidations db;
        protected string _objectname = "";
        protected static string currentCategory = string.Empty;
        protected static FODataAccess dataaccess;
        protected static WorkFlowParameter workflowparam = new WorkFlowParameter()
        {
            Driver = WebDriver
        };
        /* SF API Automation Related Changes */
        #endregion

        #region Framwork Setup and Tear Down Methods

        [OneTimeSetUp]
        public void StartTesting()
        {
            Util.FetchSettings(); // reading configuration
            Util.StartTime = DateTime.Now;
            Util.CleanSession(); // cleaning temp folder or existing browsers
            //Util.SetConsoleOutPut();
            Util.SetLogger(); // initiate logger
            TestLog.Info(string.Format("Automated Testing Started @ {0} ", Util.StartTime));
            Util.SetApiAuths(); // setting api auths
            Util.CreateDownloadFolder(); // creating download folder for chrome and edgechrome if not available
            //Util.SetCredentials(); // setting the windows credentials
            Util.LoadObjectRepository(); // loading object repository
            Util.StartReporting(TestContext.CurrentContext.Test.Name);
            LaunchBrowser();
            MailHtml.Testreports.Clear(); //Clear mail log before each suite
        }



        [OneTimeTearDown]
        public void StopTesting()
        {
            Util.EndTime = DateTime.Now;
            Util.FlushExtentReport();
            TestLog.Info(string.Format("Testing Stopped @ {0} ", DateTime.Now));
            if (Driver != null)
            {
                Driver.Quit();
            }
            Util.CleanSession();

            var ts = new TestSuite()
            {
                UserName = Environment.UserName,
                MachineName = Environment.MachineName,
                Environment = Util.TestConfiguration.Application.Environment,
                ExecutionTime = Util.EndTime.Subtract(Util.StartTime),
                Tests = MailHtml.Testreports
            };

            Util.SendEmailReport(ts);
            Util.CreateAndSaveEmailReport(ts);

            LogManager.Shutdown();

            TestContext.AddTestAttachment(Report.TestReport, "Test Report");
            TestContext.AddTestAttachment($@"{Util.ResultPath}\TestLog.log");
        }

        [SetUp]
        public void Setup()
        {
            _testName = TestContext.CurrentContext.Test.MethodName.Replace("_", " ");
            var attribute = TestContext.CurrentContext.Test.Arguments.Length > 0 ? TestContext.CurrentContext.Test.Arguments[0] : null;
            if (attribute != null)
            {
                //try
                //{
                //    _testName = $"{_testName} {attribute.GetType().GetProperty("userId").GetValue(attribute)}";
                //}
                //catch (Exception)
                //{ }
            }
            TestLog.Info("".PadLeft(100, '-'));
            TestLog.Info($"Starting Test Execution for the Test:{_testName}");
            TestLog.Info("".PadLeft(100, '-'));
            TestLog.Info($"Execution Started @ {DateTime.Now} ");
            Util.AddTest(_testName);
            //Util.FetchYamlData();
            HTMLReport.Driver = Driver;

            #region sf api automation sepcific setup 

            _objectname = CleanName(TestContext.CurrentContext.Test.Name);
            var path = Util.DirectoryPath;
            currentCategory = (string)TestContext.CurrentContext.Test.Properties.Get("Category");
            switch (currentCategory)
            {
                case "01_CoreHR":
                    Driver.Url = $@"{path}\apistatus.html";
                    HTMLReport.Driver = Driver;
                    HTMLReport.CallHistory.Clear();
                    HTMLReport.TestName = TestContext.CurrentContext.Test.Name.Replace("_", " ");
                    HTMLReport.UpdateStatusView();
                    workflowparam.FoObjectname.Add((_objectname.Contains("leave", StringComparison.InvariantCultureIgnoreCase) ? "timeoff" : "job"));
                    break;
                case "03_CoreHR": Driver.Url = $@"{path}\TDDH_Result.html"; break;

                case "01_Foundation":
                    Driver.Url = $@"{path}\apistatus.html";
                    HTMLReport.Driver = Driver;
                    HTMLReport.CallHistory.Clear();
                    HTMLReport.TestName = TestContext.CurrentContext.Test.Name.Replace("_", " ");
                    HTMLReport.UpdateStatusView();
                    workflowparam.FoObjectname.Add(Regex.Replace(_objectname, @"(?:[Vv]alidate_)|(?:[Cc]reate_)", string.Empty));
                    HTMLReport.UserDetails = _objectname;
                    break;

                case "03_Foundation": Driver.Url = $@"{path}\TDDH_Result.html"; break;

                case "Step 02 Data Extraction":
                    Driver.Url = $@"about:blank";

                    break;
            }

            #endregion

        }
        [TearDown]
        public void TearDown()
        {
            switch (currentCategory)
            {
                case "01_CoreHR":
                    HTMLReport.SaveReport();
                    JsonHelper.SaveAsJson(CoreHRExecution._paramobject, _objectname);
                    ExcelWorkBook.SavePayLoadInfoasExcelReport(CoreHRExecution.ExecutionStatuses, _objectname);
                    ExcelWorkBook.CreateExcelReportFromRuntimeData(Util.TestConfiguration.GetCustomKeyValue("CoreHROutput"), _objectname, CoreHRExecution._paramobject);
                    break;

                case "03_CoreHR":
                    JsonHelper.SaveAsJson(CoreHRExecution._paramobject, _objectname);
                    ExcelWorkBook.CreateExcelReportFromRuntimeData(Util.TestConfiguration.GetCustomKeyValue("CoreHROutput"), _objectname, CoreHRExecution._paramobject);
                    CoreHRExecution.ClearList();
                    break;

                case "01_Foundation":
                    HTMLReport.SaveReport();
                    JsonHelper.SaveAsJson(FoundationExecution.ExecutionStatuses, _objectname);
                    ExcelWorkBook.SavePayLoadInfoasExcelReport(FoundationExecution.ExecutionStatuses, _objectname);
                    ExcelWorkBook.CreateExcelReport(ExecutionStatus._paramobject, _objectname, Util.TestConfiguration.GetCustomKeyValue("FOOutput"));
                    //MailHtml.AddTestResultToCollection(FoundationExecution.ExecutionStatuses.Count);
                    break;

                case "03_Foundation":
                    JsonHelper.SaveAsJson(FoundationExecution.ExecutionStatuses, _objectname);
                    //MailHtml.AddTestResultToCollection(FoundationExecution.ExecutionStatuses.Count);
                    ExcelWorkBook.CreateExcelReport(FoundationExecution._paramobject, _objectname, Util.TestConfiguration.GetCustomKeyValue("FODBOutput"));
                    FoundationExecution.ClearList();
                    break;

                case "02_Data_Extraction":
                    MailHtml.AddTestResultToCollection(1, TestContext.CurrentContext.Result.Outcome.ToString(), "Zone A Extraction and TDDH Data Load");
                    break;
                case null:
                case "":
                    MailHtml.AddTestResultToCollection(1, TestContext.CurrentContext.Result.Outcome.ToString(), TestContext.CurrentContext.Result.Message);
                    break;
                default:
                    MailHtml.AddTestResultToCollection(1, TestContext.CurrentContext.Result.Outcome.ToString(), $"{TestContext.CurrentContext.Result.Message}<br>Test Case Not Categorized!");
                    break;
            }
            TestLog.Info(string.Format("Execution Completed @ {0} ", DateTime.Now));
            TestLog.Info("".PadLeft(100, '-'));
            TestLog.Info($"Completed Test Execution for the Test:{_testName}");
            TestLog.Info("".PadLeft(100, '-'));
        }
        private void LaunchBrowser()
        {
            Enum.TryParse(Util.TestConfiguration.Browser.Name, out BrowserName browsername);
            Driver = Browser.GetBrowser(browsername);
        }
        private string CleanName(string name)
        {
            var cleanedName = Regex.Replace(name, @"(?:TC[CEV0-9]+_)|(?:[Cc]reate_)|(?:FO_)|(?:_[Cc]reate_)|(?:_[Ii]n_TDDH_DB)|(?:_[Vv]alidate_)|(?:[Vv]alidate_)", string.Empty);
            TestLog.Info($"Name : {cleanedName}");
            return cleanedName;
        }
        #endregion
    }
}