﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{
using cryptic;
    using IFlow;
    using Newtonsoft.Json;
    using NLog;
    using OpenQA.Selenium;
    using OpenQA.Selenium.Remote;
    using RestSharp;
    using SF.APICore;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Reflection;
    using System.Text.RegularExpressions;

    public class Util
    {
        #region Private Variables

        private static Config settings;
        private static ObjectRepo objects;
        private static string resultPath = null;

        #endregion Private Variables

        #region Properties
        public static ObjectRepo Objects { get => objects; set => objects = value; }
        public static DateTime StartTime { get; set; }
        public static DateTime EndTime { get; set; }
        public static Config TestConfiguration
        {
            get
            {
                if (settings == null)
                {
                    FetchSettings();
                }
                return settings;
            }
            set => settings = value;
        }
        public static string ResultPath
        {
            get
            {
                if (resultPath == null)
                {
                    resultPath = $@"{Regex.Replace(DirectoryPath, pattern: @"\\bin\\[^\s]*", string.Empty)}\Test_Results\Run_{StartTime:yyyy MM dd hh mm ss}";
                }
                return resultPath;
            }
        }

        public static Cred CypherProgram = new Cred() { Publickey = TestConfiguration.GetCustomKeyValue("publicKey") };

        //public static List<Translation> Translations { get => translations; set => translations = value; }
        #endregion Properties

        #region ExternReport Functions

        /// <summary>
        /// This is to add test node to the result
        /// </summary>
        /// <param name="testName"></param>
        public static void AddTest(string testName)
        {
            Report.AddTest(testName);
        }

        /// <summary>
        /// This is to initialze the test report
        /// </summary>
        /// <param name="className"></param>
        public static void StartReporting(string className)
        {
            Report.Initialize(className);
        }

        /// <summary>
        /// Updates the test log with step action and expected states
        /// </summary>
        /// <param name="action">Provide the action </param>
        /// <param name="expected">Provide the expected result</param>
        /// <param name="status">Provide the outcome as pass or fail </param>
        public static void Updatelog(string action, string expected, State status)
        {
            Report.UpdateLog(action, expected, status);
            TestLog.Info($"Action : {action:-50} | Actual : {expected:-50} | Status : {status}");
        }

        /// <summary>
        /// Updates the test log with step action and expected states
        /// </summary>
        /// <param name="action">Provide the action </param>
        /// <param name="expected">Provide the expected result</param>
        /// <param name="status">Provide the outcome as pass or fail </param>
        public static void Updatelog(string message, State status)
        {
            Report.UpdateLog("Action", message, status);
            TestLog.Info($"Action : {" - ":-50} | Actual : {message:-50} | Status : {status}");
        }

        public static void FlushExtentReport()
        {
            Report.ShutDown();
        }

        #endregion ExternReport Functions

        #region NLog Helpers
        public static void SetLogger()
        {
            GlobalDiagnosticsContext.Set("resultpath", ResultPath);

            /*var config = new LoggingConfiguration();
            var logfile = new FileTarget("logfile") { FileName = $@"{ResultPath()}\Test_Log.log", AutoFlush = true, DeleteOldFileOnStartup = false };
            var errorfile = new FileTarget("errorfile") { FileName = $@"{ResultPath()}\Error_Log.log", AutoFlush = true };

            config.AddRule(NLog.LogLevel.Debug, NLog.LogLevel.Info, logfile);
            config.AddRule(NLog.LogLevel.Error, NLog.LogLevel.Fatal, errorfile);
            //LayoutRenderer.Register("PomLoc", (x) => $"{x.CallerMemberName:-50} | {x.Message} ");
            LogManager.Configuration = config;
            */
        }

        #endregion

        #region Core Helper Functions

        /// <summary>
        /// To Create folder for the path provided
        /// </summary>
        /// <param name="reportpath"></param>
        public static void CreatedFolder(string reportpath)
        {
            if (!Directory.Exists(reportpath))
            {
                Directory.CreateDirectory(reportpath);
            }
        }
        /// <summary>
        /// Create the download folder for the files to be downloaded. Works on Chrome & EdgeChrome
        /// </summary>
        public static void CreateDownloadFolder()
        {
            var directory = Path.Combine(DirectoryPath, TestConfiguration.Browser.DownloadFolder);
            if (!Directory.Exists(directory)) { Directory.CreateDirectory(directory); }
            var apidirectory = $@"{ResultPath}\api_call_log";
            if (!Directory.Exists(apidirectory)) { Directory.CreateDirectory(apidirectory); }
        }
        /// <summary>
        /// Get Current directory of the assembly
        /// </summary>
        public static string SolutionPath => Regex.Replace(DirectoryPath, @"(?:[\w.]+\\bin[\\\s\d\w.]*)", string.Empty);
        /// <summary>
        /// Get Current directory of the assembly
        /// </summary>
        public static string DirectoryPath => Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        /// <summary>
        /// Get the current location of download folder created
        /// </summary>
        public static string DownloadFolder => $@"{DirectoryPath}\{TestConfiguration.Browser.DownloadFolder}";
        /// <summary>
        /// Set Windows Credentials for application
        /// </summary>
        public static void SetCredentials()
        {
            //CredentialManager.RemoveCredentials(settings);
            //CredentialManager.SetCredentials(CredentialManagement.PersistanceType.Enterprise, settings);
        }
        /// <summary>
        /// Get Browser Name
        /// </summary>
        /// <param name="Driver"></param>
        /// <returns></returns>
        public static string GetBrowser(IWebDriver Driver)
        {
            ICapabilities cap = ((RemoteWebDriver)Driver).Capabilities;
            return cap.GetCapability(CapabilityType.BrowserName).ToString();
        }
        /// <summary>
        /// Load Setting file
        /// </summary>
        public static void FetchSettings()
        {
            //string path = string.Format(@"{0}\Config.json", DirectoryPath);
            //TestConfiguration = //Config.FromJson(File.ReadAllText(path));
            TestConfiguration = ConfigurationLoader.Load();
            //VerifyEncryption();
        }
        private static void VerifyEncryption()
        {
            bool changed = false;
            try
            {
                var listofcrd = TestConfiguration.Credentials;
                foreach (var item in listofcrd)
                {
                    if (!item.UserName.ToLower().Equals("encrypted"))
                    {
                        ////Encrypt the value
                        //Crypto c = new Crypto(encryptionkey);
                        //var a = c.EncryptData($"{item.UserName}_{item.Password}_eyframework_");

                        ////Replace the value
                        //item.UserName = "encrypted";
                        //item.Password = a;
                        //changed = true;
                    }
                }
            }
            catch (Exception e)
            {
                TestLog.Info($"Encryption is not successfull {e.Message}");
            }
            finally
            {
                if (changed)
                {
                    File.WriteAllText($@"{DirectoryPath}\Config.json", TestConfiguration.ToJson());
                    string path = DirectoryPath.Replace("\\bin\\Debug", string.Empty);
                    path = path.Replace("\\bin\\Release", string.Empty);
                    File.Copy($@"{DirectoryPath}\Config.json", $@"{path}\Config.json", true);
                }
            }
        }
        /// <summary>
        /// Load Object Repository
        /// </summary>
        public static void LoadObjectRepository()
        {
            string path = string.Format(@"{0}\OR.json", DirectoryPath);
            Objects = ObjectRepo.FromJson(File.ReadAllText(path));

            DirectoryInfo directory = new DirectoryInfo($@"{DirectoryPath}\ObjectRepo");
            foreach (var item in directory.GetFiles().ToList<FileInfo>().FindAll(x => x.Name.EndsWith(".json")))
            {
                var pageelements = ObjectRepo.FromJson(File.ReadAllText(item.FullName));
                objects.Objects.AddRange(pageelements.Objects);
            }
        }
        /// <summary>
        /// This will return file information from the directory path inside the run folder
        /// </summary>
        /// <param name="directorypath"></param>
        public static FileInfo GetLatestFileInfo(string directorypath = "Downloads")
        {
            var filepath = $@"{DirectoryPath}\{directorypath}";
            DirectoryInfo downloaddirectory = new DirectoryInfo(filepath);
            if (downloaddirectory.GetFiles().Count<FileInfo>() == 0)
            {
                return null;
                //throw new FrameworkException($"Path {filepath} doesn't contains the files");
            }
            else
            {
                return downloaddirectory.GetFiles().OrderByDescending(x => x.CreationTimeUtc).First();
            }
        }
        /// <summary>
        /// This closes, the excel, webdrivers such as chrome, IE before starting the suite
        /// </summary>
        /// <summary>
        /// This closes, the excel, webdrivers such as chrome, IE before starting the suite
        /// </summary>
        public static void CleanSession()
        {
            var processes = from p in Process.GetProcesses()
                            select p;

            foreach (var process in processes)
            {
                try
                {
                    /*if (process.MainWindowTitle.Contains(" - Excel"))
                    {
                        TestLog.Info($"Terminating Process Name : {process.ProcessName} | Title Name : {process.MainWindowTitle}");
                        process.Kill(); process.WaitForExit();
                    }*/
                    if (process.ProcessName.Contains("chromedriver") || process.ProcessName.Contains("chrome"))
                    {
                        TestLog.Info($"Terminating Process Name : {process.ProcessName} | Title Name : {process.MainWindowTitle}");
                        process.Kill(); process.WaitForExit();
                    }
                    if (process.ProcessName.Contains("msedgedriver"))
                    {
                        TestLog.Info($"Terminating Process Name : {process.ProcessName} | Title Name : {process.MainWindowTitle}");
                        process.Kill(); process.WaitForExit();
                    }
                    if (process.ProcessName.Contains("msegde"))
                    {
                        TestLog.Info($"Terminating Process Name : {process.ProcessName} | Title Name : {process.MainWindowTitle}");
                        process.Kill(); process.WaitForExit();
                    }
                }
                catch (Exception e)
                {
                    TestLog.Debug(e);
                }
            }
        }

        #endregion 

        #region SF API Automation Specific Helper Functions

        /// <summary>
        /// SF Api Automation Specific
        /// </summary>
        public static void SetApiAuths()
        {
            SFApi.Apiauth = TestConfiguration.API_Credentials.Find(x => x.api.Equals("SF", StringComparison.InvariantCultureIgnoreCase)).authentication;
            //CpiApi.Apiauth = TestConfiguration.API_Credentials.Find(x => x.api.Equals("IFLOW", StringComparison.InvariantCultureIgnoreCase)).authentication;
            IDToolApi.IDToolAuth = TestConfiguration.API_Credentials.Find(x => x.api.Equals("IDT", StringComparison.InvariantCultureIgnoreCase)).authentication;
        }

        /// <summary>
        /// This is specific to the SF API Automation - This is used for copying the file from the download folder to the share folder.
        /// The list of files can be provided, as there might be cases where multiple file would be required.
        /// </summary>
        /// <param name="files"></param>
        public static DateTime CopyFileToShare(List<string> files)
        {
            TestLog.Info("".PadLeft(100, '-'));
            TestLog.Info("File Copy Process!");
            TestLog.Info("".PadLeft(100, '-'));
            try
            {
                var sharefolder = Util.TestConfiguration.GetCustomKeyValue("APIAutomationFolder");
                foreach (var file in files)
                {
                    var f = new FileInfo(file);
                    var nf = $@"{sharefolder}\{f.Name}";
                    if (File.Exists(file))
                    {
                        File.Copy(file, nf); TestLog.Info($"File '{f.Name}' Copied to '{sharefolder}' ");
                        //File.Delete(file);
                    }
                    else { TestLog.Debug($"File not found {nf}"); }
                }
                return DateTime.UtcNow.AddHours(2);
            }
            catch (Exception e)
            {
                TestLog.Error($"Error in file copy : {e.Message}");
                return DateTime.UtcNow.AddHours(2);
            }

        }

        /// <summary>
        /// This is to load the CPI Packages to be configured and executed
        /// </summary>
        /// <returns></returns>
        public static CpiPackageConfig GetCpiPackageInfo() =>
             CpiPackageConfig.FromJson(File.ReadAllText($@"{DirectoryPath}\Data\json_data\cpi_mapping_new.json"));
        /// <summary>
        /// The data table content will be displayed as HTML Table output (Basic)
        /// </summary>
        /// <param name="datatable"></param>
        /// <returns></returns>
        public static string PrintResult(DataTable datatable)
        {
            string columnHeadTxt = "";
            foreach (DataColumn column in datatable.Columns)
            {
                columnHeadTxt += $"<td>{column.ColumnName}</td> ";
            }
            string columnBodyTxt = "";
            foreach (DataRow row in datatable.Rows)
            {
                string cr = "";
                foreach (var r in row.ItemArray)
                {
                    cr += $"<td><div> {r} <div></td>";
                }
                columnBodyTxt += $"<tr>{cr}</tr>";
            }
            return $"<thead><tr>{columnHeadTxt}</tr></thead> <tbody>{columnBodyTxt}</tbody>";
        }

        #endregion

        #region Email Report
        public static void SendEmailReport(TestSuite suite)
        {
            var jsoncontent = PrepareEmail(suite);
            var baseurl = "https://prod-253.westeurope.logic.azure.com:443/workflows/08602b7955964d46a666d86d18edb4ec/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=7GQmAzXAl_711Nwf_FeJXq9etLAkfC5fjBS3gwNeeSs";
            dynamic seriliazedString = "";
            var client = new RestClient();
            var request = new RestRequest(baseurl, Method.Post);
            request.AddHeader("Accept", "*/*");
            request.AddHeader("Accept-Encoding", "gzip, deflate, br");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("Content-Type", "application/json");
            request.AddStringBody(jsoncontent, DataFormat.Json);
            try
            {
                DateTime start = DateTime.Now;
                RestResponse response = client.ExecuteAsync(request, Method.Post).Result;
                TimeSpan span = DateTime.Now - start;
                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    Console.WriteLine("Failed Invoke!");
                }
                else if (response.StatusCode == HttpStatusCode.Accepted)
                {
                    Console.WriteLine("Success Invoke!");
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static string PrepareEmail(TestSuite suite)
        {
            EmailObject emailBody = Util.TestConfiguration.MailConfig;
            emailBody.Body = MailHtml.PrepareHtmlBody(suite);
            emailBody.Attachment = GetAttachments(suite);
            string desc = "Note: Following documents are attached as part of this executions:"; emailBody.Attachment.ToList().ForEach(x => desc += $"<br>{x.Name} - {x.Description}");
            emailBody.Body = emailBody.Body.Replace($"$attachmentdesc", desc);
            return JsonConvert.SerializeObject(emailBody, Converter.Settings);
        }

        private static Attachment[] GetAttachments(TestSuite suite)
        {
            List<Attachment> attachments = new List<Attachment>();

            List<AttachModel> attachModels = new List<AttachModel>
            {
                /** Basic HTML Report */
                new AttachModel(){ ContentType = "text/html",FileName = "Index.html",FilePath= Report.TestReport,Description= "Default HTML execution report" }, 
                /** Completed Log File */
                new AttachModel(){ ContentType = "text/text",FileName = "TestLog.log",FilePath= ResultPath,Description= "Execution log file for analysis & debugging"  },
                /** Run Time Data Files (json) */
                new AttachModel(){ ContentType = "*/*",FileName = "Runtimedata.zip",FilePath= $@"{DirectoryPath}\RuntimeParameterValues",Description= "Runtime data for each scenario's or objects used"},
            };

            if (suite.Tests.Any(x => x.TestModule.Equals("CoreHR", StringComparison.InvariantCultureIgnoreCase)))
            {
                attachModels.Add(new AttachModel()
                { ContentType = "*/*", FileName = TestConfiguration.GetCustomKeyValue("CoreHROutput"), FilePath = ResultPath, Description = "Core HR Output data captured during the execution for further reference" }); //Core HR Output Excel 1
                attachModels.Add(new AttachModel()
                { ContentType = "*/*", FileName = TestConfiguration.GetCustomKeyValue("CoreHRDBOutput"), FilePath = ResultPath, Description = "Core HR Data base Output data captured during the execution for further reference" }); //Core HR Output Excel 2
            }

            if (suite.Tests.Any(x => x.TestModule.Equals("Foundation", StringComparison.InvariantCultureIgnoreCase)))
            {
                //FO Output Excel   
                attachModels.Add(new AttachModel() { ContentType = "*/*", FileName = TestConfiguration.GetCustomKeyValue("FOOutput"), FilePath = ResultPath, Description = "Foundation Output data captured during the execution for further reference" });
                //Payload-wise Excel
                attachModels.Add(new AttachModel() { ContentType = "*/*", FileName = TestConfiguration.GetCustomKeyValue("Payload"), FilePath = ResultPath, Description = "Basic execution info for foundation data and the payload log for reference" });
                //DB Result Excel
                attachModels.Add(new AttachModel() { ContentType = "*/*", FileName = TestConfiguration.GetCustomKeyValue("FODBOutput"), FilePath = ResultPath, Description = "Foundation Output data captured during the execution for further reference when performing tddh validations" });
            }

            /** Converting all required attachments to the their byte form */
            foreach (AttachModel md in attachModels)
            {
                try
                {
                    var fname = $@"{md.FilePath.Replace(md.FileName, string.Empty)}\{md.FileName}";
                    if (File.Exists(fname))
                    {
                        var at = new Attachment()
                        {
                            Name = md.FileName,
                            ContentBytes = new Content()
                            {
                                contenttype = md.ContentType,
                                content = Convert.ToBase64String(File.ReadAllBytes(fname)),
                            },
                            Description = md.Description
                        };
                        attachments.Add(at);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine($"Unable to select the attachment {md.FileName} from {md.FilePath}; Error {e.Message}");
                }
            }

            return attachments.ToArray();
        }

        public static void CreateAndSaveEmailReport(TestSuite testSuite)
        {
            using (StreamWriter s = new StreamWriter(File.Create($@"{Util.ResultPath}\EmailReport.html")))
            {
                s.WriteLine(MailHtml.PrepareHtmlBody(testSuite));
            };
        }

        internal static void CopyEnvironmentfile()
        {
            var envfile = $@"{Util.TestConfiguration.GetCustomKeyValue("APIAutomationFolder")}\FileTran\env.txt";
            using (StreamWriter s = new StreamWriter(File.Create(envfile)))
            {
                s.AutoFlush = true;
                s.Write(TestConfiguration.Environment.Equals("ITSDEV1", StringComparison.InvariantCultureIgnoreCase) ? "itsdev1" : "uat1");//to be changed later along with tddh loader
            }
        }


        #endregion

    }

    public class AttachModel
    {
        public string FileName { get; set; }
        public string ContentType { get; set; }
        public string FilePath { get; set; }
        public string Description { get; set; }
    }
}