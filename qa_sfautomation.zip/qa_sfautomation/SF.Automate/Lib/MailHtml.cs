﻿namespace Pom
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text.RegularExpressions;

    public class TestSuite
    {
        public string MachineName { get; internal set; }
        public string Environment { get; set; }
        public string Path { get; set; }
        public TimeSpan ExecutionTime { get; set; }
        public List<TestReport> Tests { get; set; }
        public string UserName { get; internal set; }
    }

    public class TestReport
    {
        public string TestModule { get; set; }
        public string TestCaseId { get; set; }
        public string TestCaseName { get; set; }
        public int TestDataCount { get; set; }
        public string TestCaseResult { get; set; }
        public string Message { get; set; }
    }

    public class MailHtml
    {

        public static List<TestReport> Testreports = new List<TestReport>();

        public static void AddTestResultToCollection(int _DataCount, string resultstring = "No Run!", string _message = "")
        {
            var modulename = "Test Suite";
            var e = (string)TestContext.CurrentContext.Test.Properties.Get("Category");
            if (e != null)
            {
                modulename = Regex.Replace(e, "(?:[0-9]+_)", string.Empty);
            }
            if (_message == null) _message = "";
            Testreports.Add(new TestReport
            {
                TestModule = modulename,
                TestCaseId = Regex.Match(TestContext.CurrentContext.Test.Name, @"TC[CEV0-9]+").Value.Trim(),
                TestCaseName = Regex.Replace(TestContext.CurrentContext.Test.Name, @"(?:TC[CEV0-9]+_)|(?:[_]+)|(?:#)", " ").Trim(),
                TestCaseResult = resultstring,//TestContext.CurrentContext.Result.Outcome.ToString(),
                Message = _message.Equals(string.Empty) ? TestContext.CurrentContext.Result.Message : _message,
                TestDataCount = _DataCount
            }); ;

        }

        public static string PrepareHtmlBody(TestSuite suite)
        {
            string strHtml = "";
            string bodyTemplate = ReadHtmlTemplate();

            List<TestReport> sortedTestResults = (from s in suite.Tests
                                                  orderby s.TestModule, s.TestCaseId
                                                  select s).ToList();

            foreach (TestReport executionResult in sortedTestResults)
            {
                strHtml += "<tr>";
                strHtml += $"<td>{executionResult.TestModule}</td>";
                strHtml += $"<td>{executionResult.TestCaseName}</td>";
                strHtml += $"<td>{executionResult.TestDataCount}</td>";
                strHtml += $"<td>{executionResult.TestCaseResult}</td>";
                strHtml += $"<td>{executionResult.Message}</td>";
                strHtml += "</tr>";
            }
            bodyTemplate = bodyTemplate.Replace("$environment", suite.Environment);
            bodyTemplate = bodyTemplate.Replace("$time", $@"{suite.ExecutionTime:hh\:mm\:ss}");
            bodyTemplate = bodyTemplate.Replace("$numberofTCs", sortedTestResults.Count.ToString());
            bodyTemplate = bodyTemplate.Replace("$numberofTCPassed", $"{sortedTestResults.FindAll(x => x.TestCaseResult.Equals("passed", StringComparison.InvariantCultureIgnoreCase)).Count}");
            bodyTemplate = bodyTemplate.Replace("$numberofTCFailed", $"{sortedTestResults.FindAll(x => !x.TestCaseResult.Equals("passed", StringComparison.InvariantCultureIgnoreCase)).Count}");
            bodyTemplate = bodyTemplate.Replace("$machine", suite.MachineName);
            //bodyTemplate = bodyTemplate.Replace("$attachmentdesc", string.Empty);
            bodyTemplate = bodyTemplate.Replace("$ResultTable", strHtml);


            return bodyTemplate;
        }

        public static string PrepareHtmlBody(List<TestReport> testResultSets)
        {
            string strHtml = "";
            string bodyTemplate = ReadHtmlTemplate();
            int numberOfTestCasesFailed = 0;
            int numberOfTestCasesPassed = 0;

            strHtml += "<table style=\"width:100%;border:solid;border-width:thin;\">";
            strHtml += " <tr class=\"ResultTableHeader\">";
            strHtml += "<td style=\"width:12%\">TC Module</td><td style=\"width:40%\">TC Name</td><td style=\"width:8%\"># TC Data</td><td style=\"width:10%\">Test Result</td><td style=\"width:20%\">Comments</td>";
            strHtml += "</tr>";

            List<TestReport> sortedTestResults = testResultSets.OrderBy(executionResult => executionResult.TestCaseId).ToList();
            foreach (TestReport executionResult in sortedTestResults)
            {
                strHtml += "<tr>";
                strHtml += $"<td>{executionResult.TestModule}</td>";
                strHtml += $"<td>{executionResult.TestCaseName}</td>";
                strHtml += $"<td>{executionResult.TestDataCount}</td>";
                strHtml += $"<td>{executionResult.TestCaseResult}</td>";
                strHtml += $"<td>{executionResult.Message}</td>";
                strHtml += "</tr>";
            }
            strHtml += "</table>";
            bodyTemplate = bodyTemplate.Replace("$numberofTCs", sortedTestResults.Count.ToString());
            bodyTemplate = bodyTemplate.Replace("$numberofTCPassed", numberOfTestCasesPassed.ToString());
            bodyTemplate = bodyTemplate.Replace("$numberofTCFailed", numberOfTestCasesFailed.ToString());
            bodyTemplate = bodyTemplate.Replace("$ResultTable", strHtml);

            return bodyTemplate;
        }

        public static string ReadHtmlTemplate()
        {
            string strHTML = File.ReadAllText($@"{Util.DirectoryPath}\Data\html_data\mailtemplate.html");
            return strHTML;
        }
    }

    public class EmailObject
    {
        public string To { get; set; }
        public string CC { get; set; }
        public string BCC { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        public Attachment[] Attachment { get; set; }
    }

    public class Attachment
    {
        public string Name { get; set; }
        public Content ContentBytes { get; set; }
        [JsonIgnore]
        public string Description { get; set; }
    }

    public class Content
    {
        [JsonProperty("$content-type")]
        public string contenttype { get; set; }
        [JsonProperty("$content")]
        public string content { get; set; }
    }
}
