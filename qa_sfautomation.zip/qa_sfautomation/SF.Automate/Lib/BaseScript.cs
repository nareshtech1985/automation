﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{
    using OpenQA.Selenium;
    using OpenQA.Selenium.Support.UI;
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;

    public enum Element
    {
        Clickable,
        Visible,
        Presence
    }

    public abstract class BaseScript
    {

        /// Object for storing the default timeout value
        protected static long Timeout = Util.TestConfiguration.Browser.TimeOut;

        // Dictionary for the testdata
        protected static Dictionary<string, string> _testdata = TestData.Testdata;

        // Main Driver Object for the execution
        protected IWebDriver Driver;
        private static IWebDriver _driver;
        public static IWebDriver WebDriver => _driver;

        protected BaseScript(IWebDriver Driver)
        {
            this.Driver = Driver;
            _driver = Driver;
        }

        // Object for storing Current window handle
        protected static string CurrentWindow { get; set; }

        /// <summary>
        /// This will read the OR file data to a by object
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="placeholder"></param>
        /// <returns></returns>
        protected static By ReadBy(string objectname, string placeholder = "")
        {
            By by;
            var webobject = Util.Objects.GetElementInfo(objectname);
            var weblocator = webobject.Value;

            if (!placeholder.Equals(string.Empty))
            {
                weblocator = string.Format(webobject.Value, placeholder);
            }

            switch (webobject.By.ToLower())
            {
                case "id": by = By.Id(weblocator); break;
                case "xpath": by = By.XPath(weblocator); break;
                case "css": by = By.CssSelector(weblocator); break;
                case "tag": by = By.TagName(weblocator); break;
                case "class": by = By.ClassName(weblocator); break;
                case "link": by = By.LinkText(weblocator); break;
                case "plink": by = By.PartialLinkText(weblocator); break;
                default:
                    throw new FrameworkException($"Error in Object Repository | OR Id : {objectname} | Invalid By Provided");
            }

            return by;
        }

        /// <summary>
        /// Used to clear the text value from test box
        /// </summary>
        /// <param name="v"></param>
        protected void Clear(string v, long waittime = 15)
        {
            Find(v, waittime).Clear();
            TestLog.Info($"Object identified using OR {v} is cleared");
        }

        /// <summary>
        /// Used to clear the text value from test box
        /// </summary>
        /// <param name="v"></param>
        protected void Clear(By by, long waittime = 15)
        {
            Find(by, waittime, Element.Presence).Clear();
            TestLog.Info($"Object identified using OR {by} is cleared");
        }

        /// <summary>
        /// Highlight the particular element
        /// </summary>
        /// <param name="context"></param>
        protected void ClearHighlight(IWebElement context)
        {
            var _Driver = ((IJavaScriptExecutor)Driver);
            var clear = @"arguments[0].style.cssText = ""border-width: 0px; border-style: solid; border-color: red""; ";
            _Driver.ExecuteScript(clear, context);
            TestLog.Info("Object is cleared of highlighting ");
        }

        /// <summary>
        /// Highlight the particular element
        /// </summary>
        /// <param name="context"></param>
        protected void ClearHighlight(string objectname)
        {
            var context = Find(objectname);
            var _Driver = ((IJavaScriptExecutor)Driver);
            var clear = @"arguments[0].style.cssText = ""border-width: 0px; border-style: solid; border-color: red""; ";
            _Driver.ExecuteScript(clear, context);
        }

        /// <summary>
        /// Highlight the particular element
        /// </summary>
        /// <param name="context"></param>
        protected void ClearHighlight(By objectname)
        {
            var context = Find(objectname);
            var _Driver = ((IJavaScriptExecutor)Driver);
            var clear = @"arguments[0].style.cssText = ""border-width: 0px; border-style: solid; border-color: red""; ";
            _Driver.ExecuteScript(clear, context);
        }

        /// <summary>
        /// This will click the element using the selenium click statement
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="waittime"></param>
        protected void Click(string objectname, long waittime = 50)
        {
            Click(ReadBy(objectname), waittime);
        }

        /// <summary>
        /// This will click the element using the selenium click statement
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="waittime"></param>
        protected void Click(IWebElement elem)
        {
            elem.Click();
        }

        /// <summary>
        /// This will click the element using the selenium click statement
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        protected void Click(By by, long waittime = 30)
        {
            try
            {
                Find(by, waittime, Element.Clickable).Click();
            }
            catch (Exception ex)
            {
                TestLog.Debug(ex, $"Unable to click button {by} ");
                throw;
            }
        }

        /// <summary>
        /// This will find the element matching the locator passed as teh By object
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime">Default value 10 Sec</param>
        /// <param name="ele">Default value presence</param>
        /// <returns></returns>
        protected IWebElement Find(By by, long waittime = 10, Element ele = Element.Presence)
        {
            if (waittime != Timeout) { waittime = Timeout; }
            IWebElement Elem = null;
            var i = 0;
            do
            {
                try
                {
                    WebDriverWait Wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime))
                    {
                        PollingInterval = TimeSpan.FromMilliseconds(10)
                    };
                    switch (ele)
                    {
                        case Element.Clickable:
                            Elem = Wait.Until(ExpectedConditions.ElementToBeClickable(by));
                            break;

                        case Element.Visible:
                            Elem = Wait.Until(ExpectedConditions.ElementIsVisible(by));
                            break;

                        case Element.Presence:
                            Elem = Wait.Until(ExpectedConditions.ElementExists(by));
                            break;
                    }
                    if (Elem != null)
                    {
                        TestLog.Info($"Webelement located : {by} ");
                        break;
                    }
                }
                catch (Exception e)
                {
                    TestLog.Debug(e, $"Try {(i + 1)} : Element not found using By : {by}");
                }
            } while (i++ < 2);

            //Elem = Wait.Until(drv => drv.FindElement(by));
            return Elem;
        }

        /// <summary>
        /// This will find the element matching the locator, mentioned in the OR File
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected IWebElement Find(string objectname, long waittime = 10, Element ele = Element.Presence)
        {
            By by = ReadBy(objectname);
            if (by != null)
            {
                return Find(by, waittime, ele);
            }
            else
            {
                throw new FrameworkException(string.Format("Error in Object Repository | Object : {0} | By is null", objectname));
            }
        }

        /// <summary>
        /// This will find the elements matching the locator, mentioned in the OR File
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected IList<IWebElement> Finds(string objectname, long waittime = 10)
        {
            By by = ReadBy(objectname);
            if (by != null)
            {
                return Finds(by, waittime);
            }
            else
            {
                throw new FrameworkException(string.Format("Error in Object Repository | Object : {0} | By is null", objectname));
            }
        }

        /// <summary>
        /// This will find the all elements matching the locators, mentioned in the OR File
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime">Default value 10 Sec</param>
        /// <returns></returns>
        protected IList<IWebElement> Finds(By by, long waittime = 10)
        {
            if (waittime <= Timeout) { waittime = Timeout; }
            IList<IWebElement> Elems = null;
            WebDriverWait Wait = new WebDriverWait(this.Driver, TimeSpan.FromSeconds(waittime));
            Elems = Wait.Until(drv => drv.FindElements(by));
            return Elems;
        }

        /// <summary>
        /// This will read the attribute values of a element
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="attribute"></param>
        /// <param name="waittime">Optional parameter</param>
        /// <returns></returns>
        protected string GetAttribute(string objectname, string attribute, long waittime = 10)
        {
            return Find(objectname, waittime).GetAttribute(attribute);
        }

        /// <summary>
        /// This will read the attribute values of a element
        /// </summary>
        /// <param name="by"></param>
        /// <param name="attribute"></param>
        /// <param name="waittime">Optional parameter</param>
        /// <returns></returns>
        protected string GetAttribute(By by, string attribute, long waittime = 10)
        {
            return Find(by, waittime).GetAttribute(attribute);
        }

        /// <summary>
        /// This will read the attribute values of a element
        /// </summary>
        /// <param name="elem">Element </param>
        /// <param name="attribute">Look Up Attribute</param>
        /// <param name="waittime">Optional parameter</param>
        /// <returns></returns>
        protected string GetAttribute(IWebElement elem, string attribute, long waittime = 10) => elem.GetAttribute(attribute);

        /// <summary>
        /// This will read the text value of a webelement identified using by object
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected string GetText(By by, long waittime = 10)
        {
            return Find(by, waittime).Text;
        }

        protected void CloseCurrentTabAndSwitchTo(string window = "")
        {
            if (Driver != null)
            {
                Driver.Close();
                if (!window.Equals(string.Empty))
                {
                    Driver.SwitchTo().Window(window);
                }
                else
                {
                    Driver.SwitchTo().Window(CurrentWindow);
                }
                Util.Updatelog("Switch back to default Tab", "Switched to default tab", State.Done);
            }
            else
            {
                Console.WriteLine("Driver is null");
            }

        }

        /// <summary>
        /// This will read the selected text value of dropdown element
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected string GetSelectedValue(By by, long waittime = 10)
        {
            return new SelectElement(Find(by)).SelectedOption.Text;
        }

        /// <summary>
        /// This will read the selected text value of dropdown element
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected string GetSelectedValue(string objectname, long waittime = 10)
        {
            return new SelectElement(Find(objectname)).SelectedOption.Text;
        }

        /// <summary>
        /// This will read the selected text value of dropdown element
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected string GetSelectedValue(IWebElement elem, long waittime = 10)
        {
            return new SelectElement(elem).SelectedOption.Text;
        }

        /// <summary>
        /// This will read the text value of a webelement identified using value mentioned in OR file
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected string GetText(string objectname, long waittime = 50)
        {
            return Find(objectname, waittime).Text;
        }

        /// <summary>
        /// This will read the text value of a webelement identified using webelement
        /// </summary>
        /// <param name="elem"></param>
        /// <returns></returns>
        protected string GetText(IWebElement elem)
        {
            return elem.Text;
        }

        /// <summary>
        /// This will read the text value of a webelement identified using value mentioned in the OR file and only the text of a node, other child node values will be omitted
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected string GetTextofNode(string objectname, long waittime = 10)
        {
            IWebElement e = Find(objectname, waittime);
            string text = e.Text.Trim();
            IList<IWebElement> children = e.FindElements(By.XPath("./*"));
            foreach (IWebElement child in children)
            {
                text = text.Replace(child.Text, string.Empty).Trim();
            }
            return text;
        }

        /// <summary>
        /// This will read the text value of a webelement identified using by object and only the text of a node, other child node values will be omitted
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected string GetTextofNode(By by, long waittime = 10)
        {
            IWebElement e = Find(by, waittime);
            string text = e.Text.Trim();
            IList<IWebElement> children = e.FindElements(By.XPath("./*"));
            foreach (IWebElement child in children)
            {
                text = text.Replace(child.Text, string.Empty).Trim();
            }
            return text;
        }

        /// <summary>
        /// This will read the text value of a webelement identified using webelement and only the text of a node, other child node values will be omitted
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        protected string GetTextofNode(IWebElement element)
        {
            string text = element.Text.Trim();
            IList<IWebElement> children = element.FindElements(By.XPath("./*"));
            foreach (IWebElement child in children)
            {
                text = text.Replace(child.Text, string.Empty).Trim();
            }
            return text;
        }

        /// <summary>
        /// Highlight the particular element
        /// </summary>
        /// <param name="context"></param>
        protected void Highlight(IWebElement context)
        {
            var _Driver = ((IJavaScriptExecutor)Driver);
            var script = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color: red""; ";
            _Driver.ExecuteScript(script, context);
        }

        /// <summary>
        /// Highlight the particular element
        /// </summary>
        /// <param name="context"></param>
        protected void Highlight(string objectname)
        {
            var context = Find(objectname);
            var _Driver = ((IJavaScriptExecutor)Driver);
            var script = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color: red""; ";
            _Driver.ExecuteScript(script, context);
        }

        /// <summary>
        /// Highlight the particular element
        /// </summary>
        /// <param name="context"></param>
        protected void Highlight(By objectname)
        {
            var context = Find(objectname);
            var _Driver = ((IJavaScriptExecutor)Driver);
            var script = @"arguments[0].style.cssText = ""border-width: 2px; border-style: solid; border-color: red""; ";
            _Driver.ExecuteScript(script, context);
        }

        /// <summary>
        /// Check for the provided element is visible
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected bool IsEnabled(By by, long waittime = 3) => Find(by, waittime, Element.Visible).Enabled;

        /// <summary>
        /// Check for the provided element is visible
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected bool IsKendoEnabled(By by, long waittime = 3) => !Find(by, waittime, Element.Visible).GetAttribute("class").Contains("k-state-disabled");

        /// <summary>
        /// Check for the provided element is visible
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected bool IsDisplayed(string objectname, long waittime = 3) => Find(objectname, waittime, Element.Visible).Displayed;

        /// <summary>
        /// Check for the provided element is visible
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected bool IsDisplayed(By by, long waittime = 3) => Find(by, waittime, Element.Visible).Displayed;

        /// <summary>
        /// Check for the provided element is visible
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected bool IsEnabled(string objectname, long waittime = 3) => Find(objectname, waittime, Element.Visible).Enabled;

        /// <summary>
        /// This will check the element is available or not
        /// </summary>
        /// <param name="by"></param>
        /// <returns></returns>
        protected bool IsExists(string objectname, long waittime = 3)
        {
            By by = ReadBy(objectname);
            if (Driver.FindElements(by).Count >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        /// <summary>
        /// This will check the element is available or not
        /// </summary>
        /// <param name="elem"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected bool IsExists(IWebElement elem, long waittime = 3)
        {
            if (elem != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// This will check the element is available or not
        /// </summary>
        /// <param name="by"></param>
        /// <returns></returns>
        protected bool IsExists(By by, long waittime = 3)
        {
            if (Driver.FindElements(by).Count >= 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Check if the element is selected or not
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected bool IsSelected(By by, long waittime = 3) => Find(by, waittime, Element.Clickable).Selected;

        /// <summary>
        /// Check if the element is selected or not
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected bool IsSelected(IWebElement elem) => elem.Selected;

        /// <summary>
        /// Check if the element is selected or not
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected bool IsSelected(string objectname, long waittime = 3) => Find(objectname, waittime, Element.Clickable).Selected;

        /// <summary>
        /// This will click the element via javascript
        /// </summary>
        /// <param name="elem"></param>
        protected void JSClick(IWebElement elem)
        {
            ((IJavaScriptExecutor)Driver).ExecuteScript("arguments[0].click();", elem);
        }

        /// <summary>
        /// This will click the element via javascript
        /// </summary>
        /// <param name="by"></param>
        protected void JSClick(By by)
        {
            ((IJavaScriptExecutor)Driver).ExecuteScript("arguments[0].click();", Find(by));
        }

        /// <summary>
        /// This will click the element via javascript
        /// </summary>
        /// <param name="objectname"></param>
        protected void JSClick(string objectname)
        {
            ((IJavaScriptExecutor)Driver).ExecuteScript("arguments[0].click();", Find(objectname));
        }

        /// <summary>
        /// Page will be scrolled to the particular view
        /// </summary>
        /// <param name="elem"></param>
        protected void MovetoElement(IWebElement elem)
        {
            ((IJavaScriptExecutor)Driver).ExecuteScript("arguments[0].scrollIntoView();", elem);
        }

        /// <summary>
        /// Page will be scrolled to the particular view
        /// </summary>
        /// <param name="by"></param>
        protected void MovetoElement(By by)
        {
            IWebElement elem = Find(by);
            ((IJavaScriptExecutor)Driver).ExecuteScript("arguments[0].scrollIntoView();", elem);
        }

        /// <summary>
        /// Page will be scrolled to the particular view
        /// </summary>
        /// <param name="by"></param>
        protected void MovetoElement(string objectname, long waittime = 15)
        {
            IWebElement elem = Find(objectname, waittime);
            ((IJavaScriptExecutor)Driver).ExecuteScript("arguments[0].scrollIntoView();", elem);
        }

        /// <summary>
        /// This function will open a new tab , switch to tab & load the url passed
        /// </summary>
        protected void OpenAndSwitchTab(string url)
        {
            OpenNewTab();
            CurrentWindow = Driver.CurrentWindowHandle;
            foreach (var window in Driver.WindowHandles)
            {
                Driver.SwitchTo().Window(window);
            }

            Driver.Url = url;
        }

        /// <summary>
        /// This will open a new blank tab in the current window
        /// </summary>
        protected void OpenNewTab()
        {
            ((IJavaScriptExecutor)Driver).ExecuteScript("window.open()");
        }

        /// <summary>
        /// This will load the application URL mentioned in the Setting Files
        /// </summary>
        protected void OpenURL()
        {
            Driver.Url = Util.TestConfiguration.GetURL();
            Util.Updatelog("Application Launch", $"Application Lauched with Title : {Driver.Title} ", State.Pass);
        }

        /// <summary>
        /// Method used for selecting values from the text value as per the input.
        /// This mthod cab be used only if the dropdown element is a select
        /// </summary>
        /// <param name="objectname">name of the object repository element</param>
        /// <param name="value">value to be selected from the dropdown</param>
        /// <param name="waittime">wait value to be given to identify the webelement</param>
        protected void SelectDropdownValueByText(string objectname, string value, long waittime = 10)
        {
            SelectElement element = new SelectElement(Find(objectname, waittime));
            element.SelectByText(value);
        }

        /// <summary>
        /// Method used for selecting values from the text value as per the input.
        /// This mthod cab be used only if the dropdown element is a select
        /// </summary>
        /// <param name="by">by element</param>
        /// <param name="value">value to be selected from the dropdown</param>
        /// <param name="waittime">wait value to be given to identify the webelement</param>
        protected void SelectDropdownValueByText(By by, string value, long waittime = 10)
        {
            SelectElement element = new SelectElement(Find(by, waittime));
            element.SelectByText(value);
        }

        /// <summary>
        /// Method used to fetch the select value from the select dropdown. (for custom dropdown this is not recommended)
        /// </summary>
        /// <param name="by"></param>
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected string GetSelectedTextFromDropdown(By by, long waittime = 10)
        {
            SelectElement element = new SelectElement(Find(by, waittime));
            return element.SelectedOption.Text.Trim();
        }

        /// <summary>
        /// Method used to fetch the select value from the select dropdown. (for custom dropdown this is not recommended)
        /// </summary>
        /// <param name="objectname"></param>        
        /// <param name="waittime"></param>
        /// <returns></returns>
        protected string GetSelectedTextFromDropdown(string objectname, long waittime = 10)
        {
            SelectElement element = new SelectElement(Find(objectname, waittime));
            return element.SelectedOption.Text.Trim();
        }
        /// <summary>
        /// Method used for selecting values from the text value as per the input.
        /// This mthod cab be used only if the dropdown element is a select
        /// </summary>
        /// <param name="objectname">name of the object repository element</param>
        /// <param name="value">value to be selected from the dropdown</param>
        /// <param name="waittime">wait value to be given to identify the webelement</param>
        protected void SelectDropdownValueByValue(string objectname, string value, long waittime = 10)
        {
            SelectElement element = new SelectElement(Find(objectname, waittime));
            element.SelectByValue(value);
        }

        /// <summary>
        /// Method used for selecting values from the text value as per the input.
        /// This mthod cab be used only if the dropdown element is a select
        /// </summary>
        /// <param name="by">name of the object repository element</param>
        /// <param name="value">value to be selected from the dropdown</param>
        /// <param name="waittime">wait value to be given to identify the webelement</param>
        protected void SelectDropdownValueByValue(By by, string value, long waittime = 10)
        {
            SelectElement element = new SelectElement(Find(by, waittime));
            element.SelectByValue(value);
        }

        /// <summary>
        /// Method used for selecting random values from the dropdown
        /// This mthod cab be used only if the dropdown element is a select
        /// </summary>
        /// <param name="elem"></param>
        protected void SelectRandomDropdownValue(IWebElement elem)
        {
            SelectElement element = new SelectElement(elem);
            var ind = new Random().Next(element.Options.Count - 1);
            if (ind == 0) { ind = 1; }
            element.SelectByIndex(ind);
        }

        /// <summary>
        /// Method used for selecting random values from the dropdown
        /// This mthod cab be used only if the dropdown element is a select
        /// </summary>
        /// <param name="elem"></param>
        protected void SelectRandomDropdownValue(By by)
        {
            SelectElement element = new SelectElement(Find(by));
            var ind = new Random().Next(element.Options.Count - 1);
            if (ind == 0) { ind = 1; }
            element.SelectByIndex(ind);
        }

        /// <summary>
        /// Method used for selecting random values from the dropdown
        /// This mthod cab be used only if the dropdown element is a select
        /// </summary>
        /// <param name="elem"></param>
        protected void SelectRandomDropdownValue(string objectname)
        {
            SelectElement element = new SelectElement(Find(objectname));
            var ind = new Random().Next(element.Options.Count - 1);
            if (ind == 0) { ind = 1; }
            element.SelectByIndex(ind);
        }

        /// <summary>
        /// This will set the implicit wait time
        /// </summary>
        /// <param name="timeinseconds"></param>
        protected void SetImplicitWait(int timeinseconds = 40)
        {
            Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(timeinseconds);
        }

        /// <summary>
        /// This will input text into the element, applicable webelement textbox, textarea
        /// </summary>
        /// <param name="by"></param>
        /// <param name="value"></param>
        /// <param name="waittime"></param>
        protected void SetText(By by, string value, long waittime = 10)
        {
            try
            {
                Find(by, waittime).SendKeys(value);
                Util.Updatelog($"Set Text Value: {value}", "Value Entered", State.Done);
            }
            catch (Exception e)
            {
                TestLog.Error(e, $"unable to set text value for the element {by}");
            }
        }

        /// <summary>
        /// This will input text into the element, applicable webelement textbox, textarea
        /// </summary>
        /// <param name="by"></param>
        /// <param name="value"></param>
        /// <param name="waittime"></param>
        protected void SetPasswordText(By by, string value, long waittime = 10)
        {
            try
            {
                Find(by, waittime).SendKeys(value);
                Util.Updatelog($"Set Password Value: {new string('*', value.Length)}", "Value Entered", State.Done);
            }
            catch (Exception e)
            {
                TestLog.Error(e, $"unable to set text value for the element {by}");
            }
        }

        /// <summary>
        /// This will input text into the element, applicable webelement textbox, textarea
        /// </summary>
        protected void SetText(string objectname, string value, long waittime = 10)
        {
            try
            {
                Find(objectname, waittime).SendKeys(value);
                Util.Updatelog($"Set Text Value: {value}", "Value Entered", State.Done);
            }
            catch (Exception e)
            {
                TestLog.Error(e, $"unable to set text value for the element {objectname}");
            }
        }

        /// <summary>
        /// This will input text into the element, applicable webelement textbox, textarea
        /// </summary>
        protected void SetText(IWebElement element, string value)
        {
            try
            {
                element.SendKeys(value);
                Util.Updatelog($"Set Text Value: {value}", "Value Entered", State.Done);
            }
            catch (Exception e)
            {
                TestLog.Error(e, $"unable to set text value for the element ");
            }
        }

        /// <summary>
        /// This function will switch to new tab
        /// </summary>
        protected void SwtichToNewTab()
        {
            CurrentWindow = Driver.CurrentWindowHandle;
            foreach (var window in Driver.WindowHandles)
            {
                Driver.SwitchTo().Window(window);
            }
        }

        /// <summary>
        /// Make the system wait for a period of time in seconds
        /// </summary>
        /// <param name="seconds"></param>
        protected void SystemWait(int seconds)
        {
            Thread.Sleep(TimeSpan.FromSeconds(seconds));
        }

        #region Common Methods

        public string GetData(string key) => TestData.Get(key);

        protected void AddTestData(string key, string value)
        {
            TestData.Add(key, value);
        }
        /// <summary>
        /// Make the check box element to select or unselect base on check value, by default it will unselect
        /// </summary>
        /// <param name="by"></param>
        /// <param name="check"></param>
        /// <param name="checkboxName"></param>
        protected void SelectCheckBox(By by, bool check = false, string checkboxName = "")
        {
            if (check)
            {
                if (!IsSelected(by))
                {
                    Click(by);
                    Util.Updatelog($"Select checkbox {checkboxName} ", "Checkbox selected", State.Done);
                }
                else
                {
                    Util.Updatelog($"Select checkbox {checkboxName} ", "Checkbox selected already", State.Done);
                }
            }
            else
            {
                if (IsSelected(by))
                {
                    Click(by);
                    Util.Updatelog($"Unselect checkbox {checkboxName} ", "Checkbox de-selected", State.Done);
                }
                else
                {
                    Util.Updatelog($"Unselect checkbox {checkboxName} ", "Checkbox de-selected already", State.Done);
                }
            }
        }
        /// <summary>
        /// Make the check box element to select or unselect base on check value, by default it will unselect
        /// </summary>
        /// <param name="objectname"></param>
        /// <param name="check"></param>
        /// <param name="checkboxName"></param>
        protected void SelectCheckBox(string objectname, bool check = false, string checkboxName = "")
        {
            SelectCheckBox(ReadBy(objectname), check, checkboxName);
        }

        /// <summary>
        /// Enters the data value in the UI 5 date picker with current date/passed date value in default format
        /// MM/dd/yyyy
        /// </summary>
        /// <param name="by"></param>
        /// <param name="date"></param>
        protected void Select_UI5_Date(By by, DateTime date)
        {

            ((IJavaScriptExecutor)Driver).ExecuteScript($"arguments[0].document.getElementsByTagName('ui5-date-picker')[1].arguments[0].shadowRoot.firstElementChild.getElementsByClassName('ui5-date-picker-input')[0].shadowRoot.firstElementChild.getElementsByTagName('input')[0].innerHTML = '{date:MM/dd/yyyy}';", Find(by));
        }

        /// <summary>
        /// Enters the data value in the UI 5 date picker with current date/passed date value in default format
        /// MM/dd/yyyy
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="date"></param>
        protected void Select_UI5_Date(string obj, DateTime date)
        {

            ((IJavaScriptExecutor)Driver).ExecuteScript($"arguments[0].document.getElementsByTagName('ui5-date-picker')[1].arguments[0].shadowRoot.firstElementChild.getElementsByClassName('ui5-date-picker-input')[0].shadowRoot.firstElementChild.getElementsByTagName('input')[0].innerHTML = '{date:MM/dd/yyyy}';", Find(obj));
        }

        /// <summary>
        /// Enters the data value in the UI 5 date picker with current date/passed date value in default format
        /// MM/dd/yyyy
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="date"></param>
        protected void Select_UI5_Date(IWebElement elem, DateTime date)
        {

            ((IJavaScriptExecutor)Driver).ExecuteScript($"arguments[0].document.getElementsByTagName('ui5-date-picker')[1].arguments[0].shadowRoot.firstElementChild.getElementsByClassName('ui5-date-picker-input')[0].shadowRoot.firstElementChild.getElementsByTagName('input')[0].innerHTML = '{date:MM/dd/yyyy}';", elem);
        }

        #endregion Common Methods
    }
}