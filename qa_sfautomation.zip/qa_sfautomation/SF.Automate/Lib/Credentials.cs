﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{ using Pom; using CredentialManagement;
    using cryptic;

    using System;


    public class CredentialManager
    {
        public static string Key { private get; set; } = Util.Settings.GetCustomKeyValue("publicKey");
        private static Program CypherProgram = new Program() { Publickey = Key };
        public static UserPass GetCredential(string URL)
        {
            var uri = new Uri(URL);
            
            Credential cm = new Credential { Target = uri.Host };
            if (!cm.Load())
            {
                return null;
            }

            //UserPass is just a class with two string properties for user and pass
            return new UserPass(cm.Username, cm.Password);
        }

        public static bool SetCredentials(string URL, string username, string password, PersistanceType persistenceType)
        {
            var uri = new Uri(URL);

            return new Credential
            {
                Type = CredentialType.DomainPassword,
                Target = uri.Host,
                Username = username,
                Password = password,
                PersistanceType = persistenceType
            }.Save();
        }

        public static void SetCredentials(PersistanceType persistenceType, Config settings)
        {
            
            Console.WriteLine($"{Constants._Char10} Adding authentication info {Constants._Char10}");
            foreach (var a in settings.Credentials)
            {
                Credential credential = new Credential
                {
                    Type = CredentialType.DomainPassword,
                    Target = new Uri(a.Url).Host,
                    Username = (a.Domain.Equals(string.Empty))? a.UserName : $@"{a.Domain}\{a.UserName}",
                    Password = CypherProgram.Decrypt(a.Password),
                    PersistanceType = persistenceType
                };
                bool c = credential.Save();
                Console.WriteLine($"Auth info for {a.Url} { (c? "added":"not added") }");
            }
            Console.WriteLine($"{Constants._Char10} Adding authentication info completed {Constants._Char10}");
        }

        public static void RemoveCredentials(Config settings)
        {
            Console.WriteLine($"{Constants._Char10} Clearing authentication info in the system {Constants._Char10}");
            foreach (var a in settings.Credentials)
            {
                var uri = new Uri(a.Url);
                Credential credential = new Credential { Target = uri.Host, Type = CredentialType.DomainPassword };
                Console.WriteLine(string.Format("Clearing for URL: {0} : {1}", a.Url, credential.Delete()));
            }
            Console.WriteLine($"{Constants._Char10} Clearing authentication completed {Constants._Char10}");
        }
    }

    public class UserPass
    {
        private string Username { get; set; }
        private string Password { get; set; }

        public UserPass(string username, string password)
        {
            Username = username;
            Password = password;
        }
    }
}