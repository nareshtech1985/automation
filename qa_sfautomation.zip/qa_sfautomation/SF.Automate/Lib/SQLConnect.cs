﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{
    using System;

    using System.Data;
    using System.Data.SqlClient;

    public class SQLConnect
    {
        private static SqlConnection myConn;
        private static SqlCommand myCmd;
        private static SqlDataAdapter myAdapter;

        private static void OpenSqlConnection()
        {
            try
            {
                if (myConn == null)
                {
                    myConn = new SqlConnection(Util.TestConfiguration.GetDefaultConnectionString().CS);
                    myConn.Open();
                    TestLog.Info("Opening db connection");
                }

                if (myConn.State == ConnectionState.Closed)
                {
                    myConn = new SqlConnection(Util.TestConfiguration.GetDefaultConnectionString().CS);
                    myConn.Open();
                    TestLog.Info("Opening db connection");
                }
            }
            catch (Exception e)
            {
                TestLog.Error(e, "Db Connection Not Established");
            }
        }
        /*
        private static bool IsConnectionActive()
        {
            if (myConn.State == System.Data.ConnectionState.Open)
                return true;
            else
                return false;
        }*/

        public static SqlDataReader ReadFromServer(string sql)
        {
            try
            {
                if (myConn == null)
                    OpenSqlConnection();

                if (myConn.State != System.Data.ConnectionState.Open)
                    myConn.Open();

                myCmd = myConn.CreateCommand();
                myCmd.CommandText = sql;
                TestLog.Info($"Executing the Query : {sql}");
                return myCmd.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (Exception e)
            {
                myConn = null;
                myCmd = null;
                TestLog.Error(e, "Unable to read data");
                return null/* TODO Change to default(_) if this is not a reference type */;
            }
        }

        public static DataTable ReadFromServerAsTable(string sql)
        {
            TestLog.Debug($"Query : [ {sql} ]");
            try
            {
                if (myConn != null)
                {
                    if (myConn.State != ConnectionState.Closed)
                    {
                        CloseSqlConnection();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            try
            {
                if (myConn == null)
                    OpenSqlConnection();

                if (myConn.State != System.Data.ConnectionState.Open)
                    OpenSqlConnection();

                myCmd = myConn.CreateCommand();
                myCmd.CommandText = sql;
                DataTable table = new DataTable("result");
                SqlDataReader myReader;
                myReader = myCmd.ExecuteReader();
                if (myReader.HasRows)
                {
                    TestLog.Info("Data retrived from db.");
                    table.Load(myReader);
                }
                else
                {
                    TestLog.Info("No data retrived for the input query");
                    table = null;
                }
                myReader.Close();
                CloseSqlConnection();
                return table;
            }
            // Return myReader
            catch (Exception e)
            {
                myConn = null;
                myCmd = null;
                TestLog.Error(e, "Unable to read data");
                return null;
            }
        }

        private static void CloseSqlConnection()
        {
            try
            {
                if (myConn.State == System.Data.ConnectionState.Open)
                    myConn.Close();
            }
            catch (Exception e)
            {
                myConn = null;
                myCmd = null;
                TestLog.Error(e, "Error in close connection");
            }
        }

        public static bool UpdateServerViaAdapator(string sqlquery)
        {
            bool value = false;
            try
            {
                if (myConn.State == ConnectionState.Closed)
                    OpenSqlConnection();

                if (sqlquery.StartsWith("Insert"))
                {
                    myAdapter = new SqlDataAdapter()
                    {
                        InsertCommand = new SqlCommand(sqlquery, myConn)
                    };
                    int affectedrows = myAdapter.InsertCommand.ExecuteNonQuery();
                    value = true;
                }
                else if (sqlquery.StartsWith("Update"))
                {
                    myAdapter = new SqlDataAdapter()
                    {
                        UpdateCommand = new SqlCommand(sqlquery, myConn)
                    };
                    int affectedrows = myAdapter.UpdateCommand.ExecuteNonQuery();

                    value = true;
                }
                else if (sqlquery.StartsWith("Delete"))
                {
                    myAdapter = new SqlDataAdapter()
                    {
                        DeleteCommand = new SqlCommand(sqlquery, myConn)
                    };
                    int affectedrows = myAdapter.DeleteCommand.ExecuteNonQuery();

                    value = true;
                }
            }
            catch (Exception e)
            {
                value = false;
                TestLog.Error(e, "error in db update");
            }
            return value;
        }
    }
}