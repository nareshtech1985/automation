﻿namespace POMFramework.Lib.Log
{
    using System;

    public class TestLog
    {

        public static readonly NLog.Logger log = NLog.LogManager.GetCurrentClassLogger();
        public static void Debug(Exception ex, string message)
        {
            log.Debug(ex, message);
        }

        public static void Debug(string message)
        {
            log.Debug(message);
        }

        public static void Error(Exception ex, string message)
        {
            log.Error(ex, message);
        }

        public static void Error(string message)
        {
            log.Error(message);
        }

        public static void Info(Exception ex, string message)
        {
            log.Info(ex, message);
        }

        public static void Info(string message)
        {
            log.Info(message);
        }

        public static void Trace(Exception ex, string message)
        {
            log.Debug(ex, message);
        }

        public static void Trace(string message)
        {
            log.Trace(message);
        }

        public static void Warning(Exception ex, string message)
        {
            log.Warn(ex, message);
        }

        public static void Warning(string message)
        {
            log.Warn(message);
        }

        public static void Debug(Exception e)
        {
            log.Debug(e);
        }
    }
}
