﻿namespace Pom
{
    using Microsoft.Extensions.Configuration;
    using System.Globalization;
    using System.IO;
    public class ConfigurationLoader
    {
        private const string DefaultSettingsFile = "./Configs/Config.json";

        /// <summary>
        /// Loads the configuration for the given environment and tenant.
        /// If no environment or tenant is provided, then the default local config is loaded.
        /// </summary>
        /// <param name="environment">The environment to point to.</param>
        /// <returns>The relevant configuration for .</returns>
        public static Config Load()
        {
            string environment = File.ReadAllText("./env.txt");
            string targetJsonFile = DefaultSettingsFile;

            if (!string.IsNullOrWhiteSpace(environment))
            {
                // Override default config with environment specific config
                environment = FormatEnvironment(environment);
                targetJsonFile = $"./Configs/Config.{environment}.json";
            }
            TestLog.Info($"Loading the configuration for the environment : {targetJsonFile}");
            // Loads the default config, then overrides matching keys 
            // with the environment specific version
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile(DefaultSettingsFile)
                .AddJsonFile(targetJsonFile)
                .Build();

            var runconfig = new Config();

            // Deserialises the config into the HostsConfiguration object
            configuration.GetSection("Config").Bind(runconfig);

            return runconfig;
        }


        /// <summary>
        /// Loads the configuration for the given environment and tenant.
        /// If no environment or tenant is provided, then the default local config is loaded.
        /// </summary>
        /// <param name="environment">The environment to point to.</param>
        /// <returns>The relevant configuration for .</returns>
        public static Config Load(string environment = "")
        {
            string targetJsonFile = DefaultSettingsFile;

            if (!string.IsNullOrWhiteSpace(environment))
            {
                // Override default config with environment specific config
                environment = FormatEnvironment(environment);
                targetJsonFile = $"./Configs/Config.{environment}.json";
            }

            // Loads the default config, then overrides matching keys 
            // with the environment specific version
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile(DefaultSettingsFile)
                .AddJsonFile(targetJsonFile)
                .Build();

            var gitHubConfiguration = new Config();

            // Deserialises the config into the HostsConfiguration object
            configuration.GetSection("Config").Bind(gitHubConfiguration);

            return gitHubConfiguration;
        }

        private static string FormatEnvironment(string environment)
        {
            return CultureInfo.CurrentCulture.TextInfo.ToTitleCase(environment);
        }
    }
}
