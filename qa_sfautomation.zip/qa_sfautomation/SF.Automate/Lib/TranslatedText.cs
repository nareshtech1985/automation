﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{
    public class TranslatedText
    {
        //private static List<Translation> translations;

        public TranslatedText()
        {
            // translations = Util.Translations;
        }

        public string GetTranslation(string key)
        {
            //var translation = translations.Find(x => x.Id.ToLower().Equals(key.Trim().ToLower()));
            //if (translation == null)
            //{
            //    translation = new Translation
            //    {
            //        Text = string.Format("no value for key : {0} ", key)
            //    };
            //}
            return "";//translation.Text;
        }
    }
}