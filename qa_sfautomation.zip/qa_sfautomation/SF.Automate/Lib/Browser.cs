﻿/* Modified by QA Team */

namespace Pom
{    
    using OpenQA.Selenium;
    using OpenQA.Selenium.Chrome;
    using OpenQA.Selenium.Edge;
    using OpenQA.Selenium.Firefox;
    using OpenQA.Selenium.IE;
    using System;
    using System.IO;
    using WebDriverManager;
    using WebDriverManager.DriverConfigs.Impl;

    public enum BrowserName { Chrome, InternetExplorer, Firefox, EdgeChrome, Edge };

    public class Browser
    {
        public static IWebDriver WebDriver { get; set; }
        public static IWebDriver GetBrowser(BrowserName browser)
        {
            string AppRoot = Util.DirectoryPath;
            string Driverpath = Path.Combine(AppRoot, @"");
            var downloadDirectory = $@"{Util.DirectoryPath}\{Util.TestConfiguration.Browser.DownloadFolder}";
            string _userName = Util.TestConfiguration.User;
            IWebDriver Driver = null;
            var i = 0;
            do
            {
                try
                {
                    switch (browser)
                    {
                        case BrowserName.Chrome:
                            new DriverManager().SetUpDriver(new ChromeConfig(), "Latest");
                            //Please uncomment the commented steps if you have faced any login issue due to ADFS Policy
                            _userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name.Replace(@"US\", string.Empty);
                            var _profile = string.Format(@"--user-data-dir=C:\Users\{0}\AppData\Local\Google\Chrome\User Data", _userName);
                            ChromeOptions option = new ChromeOptions
                            {
                                PageLoadStrategy = PageLoadStrategy.Eager
                            };
                            if (Util.TestConfiguration.Browser.Headless) { option.AddArgument("--headless"); option.AddArgument("window-size=1920x1080"); }
                            option.AddArgument("no-sandbox");
                            option.AddArgument("disable-infobars");
                            option.AddArgument("--noerrdialogs");
                            option.AddArgument("--ignore-certificate-errors");
                            option.AddArgument("--start-maximized");
                            option.AddArgument(_profile);
                            option.AddArgument("--profile-directory=Default");
                            option.AddUserProfilePreference("download.default_directory", downloadDirectory);
                            Driver = new ChromeDriver(Driverpath, option);
                            break;

                        case BrowserName.InternetExplorer:
                            new DriverManager().SetUpDriver(new InternetExplorerConfig(), "Latest");
                            InternetExplorerOptions options = new InternetExplorerOptions
                            {
                                IntroduceInstabilityByIgnoringProtectedModeSettings = true,
                                IgnoreZoomLevel = true,
                                UnhandledPromptBehavior = UnhandledPromptBehavior.Ignore,
                                EnablePersistentHover = false,
                                EnsureCleanSession = true,
                                RequireWindowFocus = false,
                                PageLoadStrategy = PageLoadStrategy.Normal
                            };
                            Driver = new InternetExplorerDriver(Driverpath, options);
                            Driver.Manage().Window.Maximize();
                            break;

                        case BrowserName.Firefox:
                            new DriverManager().SetUpDriver(new FirefoxConfig(), "Latest");
                            Driver = new FirefoxDriver();
                            /**
                             * As of now Firefox is not included, as our primary requirment were only IE & Chrome
                             */
                            break;

                        case BrowserName.EdgeChrome:
                            new DriverManager().SetUpDriver(new EdgeConfig(), "Latest");
                            /* This is the new edge browser */
                            //var userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name.Replace(@"US\", string.Empty);
                            //var userName = "WG753KC.US";
                            var profile = string.Format(@"user-data-dir=C:\Users\{0}\AppData\Local\Microsoft\Edge\User Data", _userName);
                            var _option = new EdgeOptions
                            {                               
                                PageLoadStrategy = PageLoadStrategy.Eager
                            };
                            if (Util.TestConfiguration.Browser.Headless) { _option.AddArgument("--headless"); _option.AddArgument("window-size=1920x1080"); }
                            _option.AddArgument(profile);
                            _option.AddArgument("profile-directory=Default");
                            _option.AddArgument("--ignore-certificate-errors");
                            _option.AddArgument("--start-maximized");
                            _option.AddUserProfilePreference("download.default_directory", downloadDirectory);
                            Driver = new EdgeDriver(_option);
                            break;

                        case BrowserName.Edge:
                            new DriverManager().SetUpDriver(new EdgeConfig(), "Latest");
                            var edgeoption = new EdgeOptions
                            {
                                AcceptInsecureCertificates = true,
                                PageLoadStrategy = PageLoadStrategy.Eager
                            };
                            Driver = new EdgeDriver(Driverpath, edgeoption);
                            break;

                        default:
                            new DriverManager().SetUpDriver(new ChromeConfig(), "Latest");
                            ChromeOptions opt = new ChromeOptions
                            {
                                PageLoadStrategy = PageLoadStrategy.Eager
                            };
                            if (Util.TestConfiguration.Browser.Headless) { opt.AddArgument("--headless"); opt.AddArgument("window-size=1920x1080"); }
                            opt.AddArgument("--disable-infobars");
                            opt.AddArgument("--noerrdialogs");
                            opt.AddArgument("--ignore-certificate-errors");
                            opt.AddArgument("--start-maximized");
                            opt.AddUserProfilePreference("download.default_directory", downloadDirectory);
                            Driver = new ChromeDriver(Driverpath, opt);
                            break;
                    }
                    Console.WriteLine($"Execution Browser : {browser}");
                    Driver.Manage().Timeouts().PageLoad = TimeSpan.FromMinutes(1);
                    Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
                    Driver.Manage().Timeouts().AsynchronousJavaScript = TimeSpan.FromSeconds(50);
                    break;
                }
                catch (Exception e)
                {
                    TestLog.Debug(e, $"Browser launch failed on try # : {++i} , Exception : {e.Message}");
                    if (Driver != null) Driver.Quit();
                    Util.CleanSession();
                }
            } while (i < 3);

            if (Driver == null)
            {
                throw new FrameworkException("Browser launch issue, unable to continue please try again!");
            }

            i = 0;
            do
            {
                try
                {
                    Driver.Url = Util.TestConfiguration.GetURL();
                    break;
                }
                catch (Exception e)
                {
                    TestLog.Debug(e, $" URL launch failed on try # : {++i} ");
                }
            } while (i < 3);
            WebDriver = Driver;
            return Driver;
        }
    }
}