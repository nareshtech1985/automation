﻿namespace Pom
{
    using NUnit.Framework;
    using System;
    using System.Collections.Generic;

    public class TestData
    {
        public static Dictionary<string, string> Testdata { get; set; }

        public static void LoadTestData(string key = "")
        {
            var cls = TestContext.CurrentContext.Test.ClassName.ToString().Split('.');
            string clsname = cls[cls.Length - 1];
            string tc = TestContext.CurrentContext.Test.MethodName;
            try
            {
                if (!key.Equals(string.Empty)) { tc = key; }
                var k = new YamlHelper().GetDataDictionary(clsname);
                Testdata = k[tc];
                TestLog.Info($"Data reading for Suite : {clsname} TC : {tc}");
            }
            catch (Exception ex)
            {
                TestLog.Debug(ex.Message);
            }
        }

        public static void Add(string key, string value)
        {
            if (Testdata.ContainsKey(key))
            {
                Testdata.Remove(key);
            }
            Testdata.Add(key, value);

        }

        public static string Get(string key)
        {
            var value = "";
            if (Testdata.ContainsKey(key))
            { value = Testdata[key]; }
            else { TestLog.Debug($"{key} not present in the input data"); return string.Empty; }

            if (value.ToLower().Contains("currentdate"))
            {

                var x = value.Split('+');
                var y = x.Length > 1 ? Convert.ToInt32(x[1]) : 10;
                value = DateTime.Now.Add(TimeSpan.FromDays(y)).ToString("MM-dd-yyyy");
            }

            return value;
        }
    }
}