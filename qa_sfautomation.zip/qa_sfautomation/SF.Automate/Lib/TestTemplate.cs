﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{ using Pom; using NUnit.Framework;
    using NUnit.Framework.Internal;
    using OpenQA.Selenium;
    
    using System;

    using System.Collections.Generic;

    /// <summary>
    /// Summary description for TestTemplate
    /// </summary>
    [TestFixture]
    public class TestTemplate
    {
        protected static readonly NLog.Logger Logger = NLog.LogManager.GetCurrentClassLogger();
        private Report _report;
        private IWebDriver _driver;
        private string _testName;
        protected Dictionary<string, Dictionary<string, string>> data;
        protected IWebDriver Driver { get => _driver; set => _driver = value; }
        public Report XReport { get => _report; set => _report = value; }

        //OneTimeSetUpAttribute
        [OneTimeSetUp]
        public void StartTesting()
        {
            Util.StartTime = DateTime.Now;
            Util.CleanSession();
            //Util.SetConsoleOutPut();
            Util.SetLogger();
            Logger.Info(string.Format("Testing Started @ {0} ", Util.StartTime));
            Util.FetchSettings();
            Util.CreateDownloadFolder();
            Util.SetCredentials();
            Util.LoadObjectRepository();
            Util.LoadTranslation();
            _report = new Report();
        }

        [OneTimeTearDown]
        public void StopTesting()
        {
            Util.EndTime = DateTime.Now;
            XReport.Close();
            Logger.Info(string.Format("Testing Stopped @ {0} ", DateTime.Now));
            //Util.ResetConsoleOutPut();
            NLog.LogManager.Shutdown();
            Util.CleanSession();
        }

        [SetUp]
        public void Setup()
        {
            _testName = TestContext.CurrentContext.Test.Name.Replace("_", " ");            
            Logger.Info("".PadLeft(100, '-'));
            Logger.Info($"Starting Test Execution for the Test:{_testName}");
            Logger.Info("".PadLeft(100, '-'));
            Logger.Info($"Execution Started @ {DateTime.Now} ");
            XReport.AddTest(_testName);
            TestData.LoadTestData(TestContext.CurrentContext.Test.Name);
            Enum.TryParse(Util.Settings.Browser, out BrowserName browsername);
            Driver = Browser.GetBrowser(browsername);
            XReport.Driver = Driver;
            Util.SetReport(XReport);
            //Util.FetchYamlData();
        }

        [TearDown]
        public void TearDown()
        {
            if (Driver != null)
            {
                Driver.Quit();
            }
            Logger.Info(string.Format("Execution Completed @ {0} ", DateTime.Now));
            Logger.Info("".PadLeft(100, '-'));
            Logger.Info($"Completed Test Execution for the Test:{_testName}");
            Logger.Info("".PadLeft(100, '-'));
        }               
    }
}