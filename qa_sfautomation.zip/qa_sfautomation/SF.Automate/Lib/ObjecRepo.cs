﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;

    public partial class ObjectRepo
    {
        [JsonProperty("Objects")]
        public List<WebObject> Objects { get; set; }

        public WebObject GetElementInfo(string elementname)
        {
            try
            {
                var a = Objects.Find(x => x.Name.ToLower().Equals(elementname.ToLower()));

                if (a == null)
                {
                    throw new FrameworkException(string.Format("Object '{0}' not found in the Object Repository", elementname));
                }
                else
                {
                    return a;
                }
            }
            catch (Exception e)
            {
                TestLog.Error(e, "Error in Object Repository");
                throw new FrameworkException("Error in Object Repository", e);
            }
        }
    }

    public partial class WebObject
    {
        [JsonProperty("Name")]
        public string Name { get; set; }

        [JsonProperty("By")]
        public string By { get; set; }

        [JsonProperty("Value")]
        public string Value { get; set; }

        [JsonProperty("DisplayName", NullValueHandling = NullValueHandling.Ignore)]
        public string DisplayName { get; set; } = "";

        [JsonProperty("ParentObj", NullValueHandling = NullValueHandling.Ignore)]
        public string ParentObj { get; set; } = "";
    }

    public partial class ObjectRepo
    {
        public static ObjectRepo FromJson(string json) => JsonConvert.DeserializeObject<ObjectRepo>(json, Converter.Settings);
    }
}