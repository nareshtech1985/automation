﻿/// <summary>
/// This is core file please donot make changes unless necessary
/// Author Samson Simon
/// Created Date : 01 JUL 2019
/// </summary>
namespace Pom
{
    using AventStack.ExtentReports;
    using AventStack.ExtentReports.Reporter;
    using Newtonsoft.Json;
    using NUnit.Framework;
    using OpenQA.Selenium;
    using SF.Parameter;
    using System;
    using System.Collections.Generic;

    public class Report : ExtentReports
    {
        private static ExtentTest xTest;
        private static int counter = 0;
        private static ExtentHtmlReporter htmlreport;
        private static ExtentReports report;
        private static string reportpath;
        private static string CurrentTestClass;
        public static string TestReport { get => $@"{Util.ResultPath}\{CurrentTestClass}\Index.html"; }

        //public IWebDriver Driver { get => _driver; set => _driver = value; }

        public static void Initialize(string className)
        {
            CurrentTestClass = className;
            reportpath = $@"{Util.ResultPath}\{CurrentTestClass}";
            Util.CreatedFolder(reportpath);
            htmlreport = new ExtentHtmlReporter($@"{reportpath}\index.html");
            report = new ExtentReports();
            report.AttachReporter(htmlreport);
            report.AddSystemInfo("Host Name", string.Format("Machine {0}", Environment.MachineName));
            report.AddSystemInfo("AUT URL", $"<a href=\"{Util.TestConfiguration.GetURL()}\" />");
            report.AddSystemInfo("AUT Name", Util.TestConfiguration.Application.Name);
            report.AddSystemInfo("Execution Browser", Util.TestConfiguration.Browser.Name);
            report.AnalysisStrategy = AnalysisStrategy.Test;
        }

        public static void UpdateLog(string action, string expected, State status)
        {
            if (xTest == null) { AddTest("Test Setup"); }
            if (action.Equals(string.Empty)) { action = "Verify"; }
            var _node = xTest.CreateNode($"Step {++counter} - {action}");
            switch (status)
            {
                case State.Pass:
                    _node.Log(AventStack.ExtentReports.Status.Pass, expected);
                    _node.AddScreenCaptureFromBase64String(TakeScreenShot());
                    break;
                case State.Done:
                    _node.Log(AventStack.ExtentReports.Status.Pass, expected);
                    break;
                case State.Fail:
                    _node.Log(AventStack.ExtentReports.Status.Fail, expected);
                    _node.AddScreenCaptureFromBase64String(TakeScreenShot());
                    try { Assert.Fail(expected); } catch (Exception) { }
                    break;
                case State.Skip:
                    _node.Log(AventStack.ExtentReports.Status.Skip, expected);
                    _node.AddScreenCaptureFromBase64String(TakeScreenShot());
                    break;
                case State.APIPass:
                    _node.Log(AventStack.ExtentReports.Status.Pass, expected);
                    break;
                case State.APIFail:
                    _node.Log(AventStack.ExtentReports.Status.Fail, expected);
                    try { Assert.Fail(expected); } catch (Exception) { }
                    break;
                default:
                    _node.Log(AventStack.ExtentReports.Status.Error, expected);
                    _node.AddScreenCaptureFromBase64String(TakeScreenShot());
                    try { Assert.Fail(expected); } catch (Exception) { }
                    break;
            }
        }

        public static void AddTest(string testName)
        {
            xTest = report.CreateTest(testName);
            counter = 0;
        }

        public static void ShutDown()
        {
            try
            {
                report.Flush();
                //ReportUpdate.AddImagePositionScriptsinReportHtml(reportpath);
            }
            catch (Exception e)
            {
                TestLog.Info($"Error {e.Message}");
            }
        }

        private static string TakeScreenShot()
        {
            if (BaseScript.WebDriver != null)
            {
                try
                {
                    ITakesScreenshot takeScreenshot = (ITakesScreenshot)BaseScript.WebDriver;
                    Screenshot screenshot = takeScreenshot.GetScreenshot();
                    return screenshot.AsBase64EncodedString;
                }
                catch (Exception)
                {
                    return "Unable to capture screen!";
                }
            }
            else
            {
                return string.Empty;
            }
            //return fileName;
        }
    }

    public enum State
    {
        Pass, Fail, Skip, Error, DataIssue, Done, APIPass, APIFail
    }

    public class ExecutionStatus
    {
        #region Common Parameter for FO
        [ColumnHeader(0, "TCID")] public string TCID { get; set; }
        [ColumnHeader(6, "API Data Creation")] public string APIDataCreation { get; set; }
        [ColumnHeader(7, "API Data Validation")] public string APIDataValidation { get; set; }
        [ColumnHeader(8, "TDDH DB Validation")] public string DBDataValidation { get; set; }
        [ColumnHeader(9, "API Payload")] public object Parameter { get; set; }
        #endregion

        [JsonIgnore]
        public static List<object> _paramobject { get; set; }
        protected static string GetValue(object item, List<string> names)
        {
            foreach (var x in names)
            {
                try
                {
                    var nam = item.GetType().GetProperty(x).GetValue(item);
                    if (nam != null)
                    {
                        return nam.ToString();
                    }
                }
                catch (Exception)
                {
                    TestLog.Debug($"property {x} not available, hence moving to next property");
                }
            }
            return string.Empty;
        }
        public bool IsExecutionPass()
        {
            if (DBDataValidation.Contains(Constants.NoRun))
            {
                return APIDataValidation.Equals(Constants.AVPass);
            }
            else
            {
                return DBDataValidation.Equals(Constants.TVPass);
            }
        }

        public static void AddStatus()
        {

        }
    }

    public class CoreHRExecution : ExecutionStatus
    {
        [ColumnHeader(1, "GUI")] public string personIdExternal { get; set; }
        [ColumnHeader(2, "User ID")] public string userId { get; set; }
        [ColumnHeader(3, "Effective Start Date")] public string startDate { get; set; }
        private static List<CoreHRExecution> executionStatuses = new List<CoreHRExecution>();
        public static void ClearList() => executionStatuses.Clear();
        public static List<CoreHRExecution> ExecutionStatuses => executionStatuses;
        public static void AddStatus<T>(List<T> _item) where T : class
        {
            List<object> _it = new List<object>();
            _item.ForEach(x => _it.Add(x));
            _paramobject = _it;
            foreach (object item in _item)
            {
                var enhancedParam = new CoreHRExecution()
                {
                    TCID = TestContext.CurrentContext.Test.Name,
                    APIDataCreation = item.GetType().GetProperty("api_c_status").GetValue(item).ToString(),
                    APIDataValidation = item.GetType().GetProperty("api_v_status").GetValue(item).ToString(),
                    DBDataValidation = item.GetType().GetProperty("db_v_status").GetValue(item).ToString(),
                    personIdExternal = item.GetType().GetProperty("personIdExternal").GetValue(item).ToString(),
                    userId = item.GetType().GetProperty("userId").GetValue(item).ToString(),
                    startDate = item.GetType().GetProperty("startDate").GetValue(item).ToString(),
                    Parameter = item
                };

                executionStatuses.Add(enhancedParam);
            }
            string _message = "";
            string _resultstring = "Run Incomplete";
            if (_paramobject.Count > 1)
            {
                _message = $"{executionStatuses.FindAll(x => x.TCID.Equals(TestContext.CurrentContext.Test.Name) && x.IsExecutionPass()).Count} Passed; {executionStatuses.FindAll(x => x.TCID.Equals(TestContext.CurrentContext.Test.Name) && !x.IsExecutionPass()).Count} Failed";
            }

            _resultstring = executionStatuses.FindAll(x => x.TCID.Equals(TestContext.CurrentContext.Test.Name) && x.IsExecutionPass()).Count == _paramobject.Count ? "Passed" : "Failed";

            MailHtml.AddTestResultToCollection(_paramobject.Count, _resultstring, _message);
        }

    }

    public class FoundationExecution : ExecutionStatus
    {
        [ColumnHeader(1, "External Code")] public string ExternalCode { get; set; }
        [ColumnHeader(2, "Start Date")] public string StartDate { get; set; }
        [ColumnHeader(3, "Name")] public string Name { get; set; }
        [ColumnHeader(4, "Description")] public string Description { get; set; }
        [ColumnHeader(5, "Status")] public string Status { get; set; }
        private static List<FoundationExecution> executionStatuses = new List<FoundationExecution>();
        public static void ClearList() { executionStatuses.Clear(); _paramobject.Clear(); }
        public static List<FoundationExecution> ExecutionStatuses => executionStatuses;
        public static void AddStatus(List<object> _item)
        {
            _paramobject = _item;
            foreach (object item in _item)
            {
                var enhancedParam = new FoundationExecution()
                {
                    TCID = TestContext.CurrentContext.Test.Name,
                    APIDataCreation = item.GetType().GetProperty("api_c_status").GetValue(item).ToString(),
                    APIDataValidation = item.GetType().GetProperty("api_v_status").GetValue(item).ToString(),
                    DBDataValidation = item.GetType().GetProperty("db_v_status").GetValue(item).ToString(),
                    ExternalCode = item.GetType().GetProperty("externalCode").GetValue(item).ToString(),
                    Parameter = item
                };

                //List<string> Dates = new List<string> { "_effectiveStartDate", "_startDate" };
                List<string> Names = new List<string> { "name", "externalName", "externalName_defaultValue", "name_defaultValue" };
                List<string> Descs = new List<string> { "description", "description_defaultValue", "cust_Description_defaultValue", "cust_description_defaultValue" };
                List<string> Stats = new List<string> { "effectiveStatus", "status", "mdfSystemStatus" };

                #region Date Fix
                /* Date Fix */
                var _startdate = (DateTime)item.GetType().GetProperty("_effectiveStartDate").GetValue(item);
                if (_startdate.Equals(DateTime.MinValue))
                {
                    _startdate = (DateTime)item.GetType().GetProperty("_startDate").GetValue(item);
                }
                enhancedParam.StartDate = _startdate.ToString();
                #endregion
                #region Name Description and Status            
                enhancedParam.Name = GetValue(item, Names);
                enhancedParam.Description = GetValue(item, Descs);
                enhancedParam.Status = GetValue(item, Stats);
                #endregion

                executionStatuses.Add(enhancedParam);
            }
            string _resultstring = executionStatuses.FindAll(x => x.TCID.Equals(TestContext.CurrentContext.Test.Name) && x.IsExecutionPass()).Count == _paramobject.Count ? "Passed" : "Failed";
            string _message = "";
            if (_paramobject.Count > 1)
            {
                _message = $"{executionStatuses.FindAll(x => x.TCID.Equals(TestContext.CurrentContext.Test.Name) && x.IsExecutionPass()).Count} Passed; {executionStatuses.FindAll(x => x.TCID.Equals(TestContext.CurrentContext.Test.Name) && !x.IsExecutionPass()).Count} Failed";
            }
            else if (_paramobject.Count == 0)
            {
                Util.Updatelog("Check input data countr", "Input data missing or not provided", State.Error);
                _resultstring = "Failed";
            }
            MailHtml.AddTestResultToCollection(_paramobject.Count, _resultstring, _message);
        }
        public static void AddStatus<T>(List<T> _item) where T : class
        {
            List<object> _it = new List<object>();
            _item.ForEach(x => _it.Add(x));
            _paramobject = _it;
            foreach (object item in _item)
            {
                var enhancedParam = new FoundationExecution()
                {
                    APIDataCreation = item.GetType().GetProperty("api_c_status").GetValue(item).ToString(),
                    APIDataValidation = item.GetType().GetProperty("api_v_status").GetValue(item).ToString(),
                    DBDataValidation = item.GetType().GetProperty("db_v_status").GetValue(item).ToString(),
                    ExternalCode = item.GetType().GetProperty("externalCode").GetValue(item).ToString(),
                    Parameter = item
                };

                //List<string> Dates = new List<string> { "_effectiveStartDate", "_startDate" };
                List<string> Names = new List<string> { "name", "externalName", "externalName_defaultValue", "name_defaultValue" };
                List<string> Descs = new List<string> { "description", "description_defaultValue", "cust_Description_defaultValue" };
                List<string> Stats = new List<string> { "effectiveStatus", "status", "mdfSystemStatus" };

                #region Date Fix
                /* Date Fix */
                var _startdate = (DateTime)item.GetType().GetProperty("_effectiveStartDate").GetValue(item);
                if (_startdate.Equals(DateTime.MinValue))
                {
                    _startdate = (DateTime)item.GetType().GetProperty("_startDate").GetValue(item);
                }
                enhancedParam.StartDate = _startdate.ToString();
                #endregion
                #region Name Description and Status            
                enhancedParam.Name = GetValue(item, Names);
                enhancedParam.Description = GetValue(item, Descs);
                enhancedParam.Status = GetValue(item, Stats);
                #endregion

                executionStatuses.Add(enhancedParam);
            }
            string _message = "";
            if (_paramobject.Count > 1)
            {
                _message = $"{executionStatuses.FindAll(x => x.TCID.Equals(TestContext.CurrentContext.Test.Name) && x.IsExecutionPass()).Count} Passed; {executionStatuses.FindAll(x => x.TCID.Equals(TestContext.CurrentContext.Test.Name) && !x.IsExecutionPass()).Count} Failed";
            }
            var _resultstring = executionStatuses.FindAll(x => x.TCID.Equals(TestContext.CurrentContext.Test.Name) && x.IsExecutionPass()).Count == _paramobject.Count ? "Passed" : "Failed";
            MailHtml.AddTestResultToCollection(_paramobject.Count, _resultstring, _message);
        }
    }
}