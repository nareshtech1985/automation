﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;

namespace Pom
{
    public static class Converter
    {
        public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
        {
            MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
            DateFormatString = "yyyy-MM-dd",
            Formatting = Formatting.Indented,
            NullValueHandling = NullValueHandling.Ignore
        };

        public static readonly JsonSerializerSettings SaveSettings = new JsonSerializerSettings
        {
            MetadataPropertyHandling = MetadataPropertyHandling.Default,
            DateFormatString = "yyyy-MM-dd",
            NullValueHandling = NullValueHandling.Ignore,
            Formatting = Formatting.Indented
            //DateParseHandling = DateParseHandling.DateTime,
            //Converters = { new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }},
        };
    }
    public static class Serialize
    {
        public static string ToJson(this Config self) => JsonConvert.SerializeObject(self, Converter.Settings);
    }

    public class Config
    {
        public Application Application { get; set; }
        public string User { get; set; }
        public BrowserConfig Browser { get; set; }
        public List<Credential> Credentials { get; set; }
        public List<APICredentials> API_Credentials { get; set; }
        public List<Database> Database { get; set; }
        public List<Customkey> CustomKeys { get; set; }
        public List<ReportConfig> Reports { get; set; }
        public EmailObject MailConfig { get; set; }

        public string GetCustomKeyValue(string key)
        {
            var a = this.CustomKeys.Find(x => x.Key.ToLower().Equals(key.ToLower()));
            return a.Value;
        }

        public string Environment => this.Application.Environment;

        /// <summary>
        /// Returns the application url
        /// </summary>
        /// <returns></returns>
        public string GetURL() => this.Application.URL;

        /// <summary>
        /// Returns the User Name
        /// </summary>
        /// <returns></returns>
        public Credential GetCredentials()
        {
            var a = this.Credentials.Find(x => x.Name.ToLower().Equals(this.Application.AppKey));
            return a;
        }

        /// <summary>
        /// Returns the Connection String
        /// </summary>
        /// <returns></returns>
        public Database GetConnectionString(string dbname = "TDDH")
        {
            var a = this.Database.Find(x => x.Name.Equals(dbname));
            return a;
        }

        public Database GetDefaultConnectionString()
        {
            var a = this.Database.FindAll(x => x.Default).FirstOrDefault();
            return a;
        }

        public static Config FromJson(string json) => JsonConvert.DeserializeObject<Config>(json, Converter.Settings);

        public static T FromAnyJson<T>(string json) where T : class => JsonConvert.DeserializeObject<T>(json, Converter.Settings);
    }

    public class Application
    {
        public string Environment { get; set; }
        public string Name { get; set; }
        public string URL { get; set; }
        public string AppKey { get; set; }
    }

    public class BrowserConfig
    {
        public string Name { get; set; }
        public string Version { get; set; }
        public bool Headless { get; set; }
        public string DownloadFolder { get; set; }
        public long TimeOut { get; set; }
    }

    public class Credential
    {
        public string Name { get; set; }
        public string URL { get; set; }
        public string Domain { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string PrivateKey { get; set; }
    }

    public class APICredentials
    {
        public string api { get; set; }
        public string authentication { get; set; }
        public string baseurl { get; set; }
    }

    public class Database
    {
        public bool Default { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Key { get; set; }
        public string CS { get; set; }
    }

    public class Customkey
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }

    public class ReportConfig
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string FileName { get; set; }
    }

}
