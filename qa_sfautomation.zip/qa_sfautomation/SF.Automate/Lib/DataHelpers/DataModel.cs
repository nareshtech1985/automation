﻿namespace Pom.PageObjects.DataModels
{
    using Newtonsoft.Json;
    using Pom;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class TestData<T>
    {

        [JsonProperty("Data", NullValueHandling = NullValueHandling.Ignore)]
        public static IEnumerable<T> Data { get; set; } = Instance.GetType().GetProperty("Data").GetValue(Instance, null) as IEnumerable<T>;
        public static TestData<T> FromJson(string json) => JsonConvert.DeserializeObject<TestData<T>>(json, Converter.Settings);
        public static string ToJson(T self) => JsonConvert.SerializeObject(self, Converter.Settings);
        public static TestData<T> Instance
        {
            get
            {
                if (Data != null) { TestLog.Info("Reloading data.."); }
                try
                {
                    var filename = $"{typeof(T).Name}.json";
                    var directory = $@"{Util.DirectoryPath}\Data\json_data";
                    List<string> files = Directory.EnumerateFiles(directory).ToList();
                    string xs = files.Find(x => x.Contains(filename));
                    if (xs == null)
                    {
                        foreach (var dir in Directory.EnumerateDirectories(directory))
                        {
                            files = Directory.EnumerateFiles(dir).ToList();
                            xs = files.Find(x => x.Contains(filename));
                            if (!xs.Equals(string.Empty)) break;
                        }
                    }

                    return FromJson(File.ReadAllText(xs));
                }
                catch (Exception e)
                {
                    //throw new FrameworkException($@"Error of {typeof(T).Name}.json | Exception : {e.Message}");
                    Console.WriteLine(e.Message);
                    return null;
                }
            }
        }

        public static T Random => Data.ToList()[new Random().Next(Data.Count())];

    }
}
