﻿/// <summary>
/// This is a core file please do not make any changes unless necessary
/// Author : Samson Simon
/// Created Date : 26 Aug 2019
/// </summary>

namespace Pom.DataHelpers
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using Pom;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Xml.Serialization;
    using JsonConvert = Newtonsoft.Json.JsonConvert;

    public class JsonHelper : ITestDataManagement
    {
        private static dynamic TestData;
        private Dictionary<string, JValue> fields;

        public IEnumerable<KeyValuePair<string, JValue>> GetAllFields() => fields;

        /// <summary>
        /// Return the test data from the Json file "
        /// </summary>
        /// <param name="testdatafile"></param>
        /// <returns></returns>
        public string GetData(string key, string value, string testdatafile)
        {
            string data = "";
            if (key != "" && value != "")
            {
                string file = $@"{Util.DirectoryPath}Data\json_data\{testdatafile}.json";
                TestData = JsonConvert.DeserializeObject<dynamic>(File.ReadAllText(file));
                data = TestData[key][value];
                return data;
            }

            if (string.IsNullOrEmpty(data))
            {
                throw new Exception("No data present in " + testdatafile + " Json file for the given key");
            }
            else
            {
                throw new Exception("Error in reading data.Check the key/values provided");
            }
        }

        public void WritetoTestData(string key, string value, string data, string fileName)
        {
            string file = string.Format(@"{0}\{1}", Util.DirectoryPath, @"Data\json_data\" + fileName + ".json");
            string json = File.ReadAllText(file);
            JObject jsonObj = JObject.Parse(json);
            bool _keyPresent = jsonObj.ContainsKey(key);
            if (_keyPresent)
            {
                jsonObj[key][value] = data;
            }
            else
            {
                string _jsonString = "{\"" + value + "\":\"" + data + "\"}";
                jsonObj.Add(key, JObject.Parse(_jsonString));
            }

            string output = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
            File.WriteAllText(file, output);
        }

        /// <summary>
        /// Get the json based on token
        /// </summary>
        /// <param name="tokenName"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static JToken SelectToken(string tokenName, string fileName)
        {
            string file = string.Format(@"{0}\{1}", Util.DirectoryPath, @"Data\json_data\" + fileName + ".json");
            string json = File.ReadAllText(file);
            JObject jsonObj = JObject.Parse(json);
            return jsonObj.SelectToken(tokenName);
        }

        /// <summary>
        /// Convert the Json to Dictionary based on token
        /// </summary>
        /// <param name="tokenName"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public Dictionary<string, string> GetDataDictionary(string tokenName, string fileName)
        {
            JObject data = (JObject)SelectToken(tokenName, fileName);
            Dictionary<string, object> jsonDic = JsonConvert.DeserializeObject<Dictionary<string, object>>(data.ToString());

            var dataDictionary = jsonDic.ToDictionary(
                x => x.Key,
                x => x.Value.ToString()
            );
            return dataDictionary;
        }

        /// <summary>
        /// Verify the key and value is present in json
        /// </summary>
        /// <param name="json"></param>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public Boolean IsKeyValuePresentInTestData(String json, string key, string value)
        {
            JToken jToken = JToken.Parse(json);
            JsonHelper jsonHelper = new JsonHelper();
            Dictionary<string, JValue> jsonDictionary = jsonHelper.JsonFieldsCollector(jToken);
            foreach (KeyValuePair<string, JValue> keyValue in jsonDictionary)
            {
                if (keyValue.Key.Contains("." + key))
                {
                    if (keyValue.Value.ToString().Equals(value))
                        return true;
                }
            }
            return false;
        }

        public Dictionary<string, JValue> JsonFieldsCollector(JToken token)
        {
            fields = new Dictionary<string, JValue>();
            CollectFields(token);
            return fields;
        }

        /// <summary>
        /// Generic Recurrsive Method to parse through token types Object,Array
        /// </summary>
        /// <param name="jToken"></param>
        private void CollectFields(JToken jToken)
        {
            switch (jToken.Type)
            {
                case JTokenType.Object:
                    foreach (var child in jToken.Children<JProperty>())
                        CollectFields(child);
                    break;

                case JTokenType.Array:
                    foreach (var child in jToken.Children())
                        CollectFields(child);
                    break;

                case JTokenType.Property:
                    CollectFields(((JProperty)jToken).Value);
                    break;

                default:
                    fields.Add(jToken.Path, (JValue)jToken);
                    break;
            }
        }

        //Pass JArray read from DB to this method
        public IList<string> GetListfromJArray(JArray data, string columnName)
        {
            IList<string> list = new List<string>();

            if (data.Children<JObject>().Properties().Where(p => p.Name == columnName).Count() == 0)
            {
                list.Add("");
                return list;
            }

            foreach (JProperty prop in data.Children<JObject>().Properties().Where(p => p.Name == columnName))
            {
                string tempValue = prop.Value.ToString();
                list.Add(tempValue);
            }

            return list;
        }

        //Return value from given path
        // path can be like Manufacturers[0].Name or Products.name
        public string GetTokenfromJObject(string response, string path)
        {
            JObject jObject = JObject.Parse(response);
            return jObject.SelectToken(path).ToString();
        }

        public Dictionary<string, Dictionary<string, string>> GetDataDictionary(string filename)
        {
            return null;
        }

        public string GetData(string key, string filename)
        {
            return null;/* script work in progress */
        }

        private static string ToJson(IEnumerable<object> ts) => JsonConvert.SerializeObject(ts, Converter.SaveSettings);

        public static void SaveAsJson(IEnumerable<object> ts, string filename)
        {
            var path = $@"{Util.DirectoryPath}\RuntimeParameterValues";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            var jsonContent = ToJson(ts);
            var file = $@"{path}\{filename.ToLower()}.json";
            if (File.Exists(file)) File.Delete(file);
            using (StreamWriter e = new StreamWriter(new FileStream(file, FileMode.OpenOrCreate)))
            {
                e.WriteLine(jsonContent);
            }
        }

        public static void SaveAsXML(IEnumerable<object> ts, string filename)
        {
            var path = $@"{Util.DirectoryPath}\RuntimeParameterValues";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            if (ts.Count() > 0)
            {
                var e1 = ts.First();
                XmlSerializer inst = new XmlSerializer(ts.GetType());
                var file = $@"{path}\{filename.ToLower()}.xml";
                if (File.Exists(file)) File.Delete(file);
                using (StreamWriter e = new StreamWriter(new FileStream(file, FileMode.OpenOrCreate)))
                {
                    inst.Serialize(e, ts);
                }
            }
        }

        public static IEnumerable<T> ReadOutputData<T>(string filename) where T : class
        {
            var fname = filename.ToLower();
            try
            {
                var fileName = $@"{Util.DirectoryPath}\RuntimeParameterValues\{fname}.json";
                if (!File.Exists(fileName))
                {
                    return new List<T>();
                }
                return FromJson<T>(File.ReadAllText(fileName));
            }
            catch (Exception e)
            {
                throw new FrameworkException($@"Runtime error occured {e.Message}");
            }
        }

        private static IEnumerable<T> FromJson<T>(string json) where T : class => JsonConvert.DeserializeObject<IEnumerable<T>>(json, Converter.Settings);
    }
}