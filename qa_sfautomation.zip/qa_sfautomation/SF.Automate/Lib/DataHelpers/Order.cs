﻿namespace Test.Lib.DataHelpers
{
    using System;

    using System.Collections.Generic;

    public class Order : Attribute
    {
        private int _index;
        public int Index { get => _index; }
        public Order(int index)
        {
            _index = index;
        }

        public static List<string> OrderedItems<T>(T t)
        {
            var props = t.GetType().GetProperties();
            foreach (var p in props)
            {
                var v = p.Attributes.GetType().GetProperty("Index").GetValue(p);
                Console.WriteLine($" Value { p}");
            }
            return null;
        }
    }
}
