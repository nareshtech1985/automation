﻿/// <summary>
/// Generates Random First Name & Last Name Values for testing
/// </summary>
namespace SF.Automate.Lib.DataHelpers
{
    using Pom;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Text.RegularExpressions;
    internal class RandomNames
    {
        private static Random _rand = new Random();
        /// <summary>
        /// Returns a random first name value
        /// </summary>
        public static string FirstName
        {
            get
            {
                var names = Regex.Split(File.ReadAllText($@"{Util.DirectoryPath}\Data\text_data\fnames.txt"), "\r\n").ToList();
                return names.ElementAt(_rand.Next(names.Count));
            }
        }
        /// <summary>
        /// Returns a random last name value
        /// </summary>
        public static string LastName
        {
            get
            {
                var names = Regex.Split(File.ReadAllText($@"{Util.DirectoryPath}\Data\text_data\lnames.txt"), "\r\n").ToList();
                return names.ElementAt(_rand.Next(names.Count));
            }
        }
    }
}
