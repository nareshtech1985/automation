﻿namespace EY_Test.Lib.DataHelpers
{
    using Newtonsoft.Json;
    using Pom;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class RunTimeData<T> where T : class
    {
        private static readonly object sysLock = new object();

        public static List<T> ReadOutputData(string _objectname)
        {
            var fname = _objectname.ToString().ToLower();
            try
            {
                var fileName = $@"{Util.DirectoryPath}\RuntimeParameterValues\{fname}.json";
                if (!File.Exists(fileName))
                {
                    return new List<T>();
                }
                var list = FromJson(File.ReadAllText(fileName));
                if (list.Count == 0)
                {
                    //read input data
                    //list = ExcelWorkBook.ReadInputData<T>()
                }
                return list;
            }
            catch (Exception e)
            {
                throw new FrameworkException($@"Runtime error occured {e.Message}");
            }
        }

        public static List<T> ReadOutputData(CoreHRScenario hRScenarios)
        {
            var fname = hRScenarios.ToString().ToLower();
            try
            {
                var fileName = $@"{Util.DirectoryPath}\RuntimeParameterValues\{fname}.json";
                if (!File.Exists(fileName))
                {
                    return new List<T>();
                }
                return FromJson(File.ReadAllText(fileName));
            }
            catch (Exception e)
            {
                throw new FrameworkException($@"Runtime error occured {e.Message}");
            }
        }

        public static T[] ReadOutputDataAsArray(CoreHRScenario hRScenarios)
        {
            var fname = hRScenarios.ToString().ToLower();
            try
            {
                var fileName = $@"{Util.DirectoryPath}\RuntimeParameterValues\{fname}.json";
                if (!File.Exists(fileName))
                {
                    return new T[] { };
                }
                return AsJsonAray(File.ReadAllText(fileName));
            }
            catch (Exception e)
            {
                throw new FrameworkException($@"Runtime error occured {e.Message}");
            }
        }

        private static List<T> FromJson(string json) => JsonConvert.DeserializeObject<List<T>>(json, Converter.Settings);

        private static T[] AsJsonAray(string json) => JsonConvert.DeserializeObject<T[]>(json, Converter.Settings);

        private static string ToJson(IEnumerable<T> ts) => JsonConvert.SerializeObject(ts, Converter.Settings);

        public static void Save(IEnumerable<T> ts, CoreHRScenario hRScenarios)
        {
            var path = $@"{Util.DirectoryPath}\RuntimeParameterValues";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            var jsonContent = ToJson(ts);
            var filename = hRScenarios.ToString().ToLower();
            var file = $@"{path}\{filename}.json";
            if (File.Exists(file)) File.Delete(file);
            using (StreamWriter e = new StreamWriter(new FileStream(file, FileMode.OpenOrCreate)))
            {
                e.WriteLine(jsonContent);
            }
        }

        public static void SaveData(IEnumerable<T> ts, string filename)
        {
            var path = $@"{Util.DirectoryPath}\RuntimeParameterValues";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            var jsonContent = ToJson(ts);
            var file = $@"{path}\{filename.ToLower()}.json";
            if (File.Exists(file)) File.Delete(file);
            using (StreamWriter e = new StreamWriter(new FileStream(file, FileMode.OpenOrCreate)))
            {
                e.WriteLine(jsonContent);
            }
        }

        public static void MergeList(ref List<T> parameterList, T parameter)
        {
            try
            {
                var itemrow = parameterList.ToList().Find(x => x.GetType().GetProperty("rowKey").GetValue(x).Equals(parameter.GetType().GetProperty("rowKey").GetValue(parameter)));
                if (itemrow != null) { itemrow = parameter; }
                else
                {
                    int index = parameterList.Count + 1;
                    parameter.GetType().GetProperty("rowKey").SetValue(parameter, index);
                    parameterList.Add(parameter);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public static void MergeListAndSave(ref List<T> parameterList, T parameter, CoreHRScenario scenario)
        {
            lock (sysLock)
            {
                try
                {
                    if (parameterList == null)
                    {
                        parameterList = new List<T>();
                    }
                    // Mergin the List Items
                    var itemrow = parameterList.ToList().Find(x => x.GetType().GetProperty("rowKey").GetValue(x).Equals(parameter.GetType().GetProperty("rowKey").GetValue(parameter)));
                    if (itemrow != null)
                    {
                        parameterList.Remove(itemrow);
                        parameterList.Add(parameter);
                    }
                    else
                    {
                        int index = parameterList.Count + 1;
                        parameter.GetType().GetProperty("rowKey").SetValue(parameter, index);
                        parameterList.Add(parameter);
                    }

                    //Saving to Json
                    var path = $@"{Util.DirectoryPath}\RuntimeParameterValues";
                    if (!Directory.Exists(path)) Directory.CreateDirectory(path);
                    var jsonContent = ToJson(parameterList);
                    var filename = $"{scenario}".ToLower();
                    var file = $@"{path}\{filename}.json";
                    if (File.Exists(file)) File.Delete(file);
                    using (StreamWriter e = new StreamWriter(new FileStream(file, FileMode.OpenOrCreate)))
                    {
                        e.WriteLine(jsonContent);
                    }
                    TestLog.Debug($"Merged and Saved the file {file}");
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}