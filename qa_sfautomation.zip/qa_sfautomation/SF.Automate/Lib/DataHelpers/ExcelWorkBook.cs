﻿namespace Pom.PageObjects
{
    using EY_Test.Lib.DataHelpers;
    using EY_Test.TestScripts.InputObjects;
    using Newtonsoft.Json;
    using Pom;
    using SF.APICore;
    using SF.FO.Foundation;
    using SF.Helper;
    using SF.HelperLibrary.Mapping.Helper;
    using SF.Parameter;
    using SpreadsheetLight;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.IO;
    using System.Linq;
    using System.Threading;

    public class ExcelWorkBook
    {
        public static int ParameterCount { get; set; } = 0;

        private static string _CoreHRReport = $@"{Util.TestConfiguration.GetCustomKeyValue("CoreHROutput")}";
        private static string _FOReport = $@"{Util.TestConfiguration.GetCustomKeyValue("FOOutput")}";
        private static string _CoreHRDBReport = $@"{Util.TestConfiguration.GetCustomKeyValue("CoreHRDBOutput")}";
        private static string _FODBReport = $@"{Util.TestConfiguration.GetCustomKeyValue("FODBOutput")}";

        public static List<JobPackage> fomaplist;//= TestData<FOMapping>.Data.ToList();

        /// <summary>
        /// This method will read test data based on the paramater class input
        /// </summary>
        /// <typeparam name="T">specify the type of parameter required to read data from</typeparam>
        /// <param name="hRScenario">type of scenario which refere/the data sheet name from the input excel</param>
        /// <returns></returns>
        public static List<object> ReadTestData<T>(CoreHRScenario hRScenario, string workbookname = "DataSheet") where T : class
        {
            var paramList = new List<object>();
            using (SLDocument doc = new SLDocument($@"{Util.DirectoryPath}\Data\excel_data\{workbookname}.xlsx"))
            {
                TestLog.Info($"Select the worksheet {hRScenario}");
                doc.SelectWorksheet(hRScenario.ToString().ToLower());
                int columnEndIndex = doc.GetWorksheetStatistics().EndColumnIndex;
                int rowEndIndex = doc.GetWorksheetStatistics().EndRowIndex;
                ParameterCount = rowEndIndex;
                Dictionary<string, int> columnIndexer = new Dictionary<string, int>();

                // Iterate over columns
                for (int columnIndex = 1; columnIndex <= columnEndIndex; columnIndex++)
                {
                    string columnName = doc.GetCellValueAsString(1, columnIndex);
                    if (!columnName.Trim().Equals(string.Empty))
                    {
                        columnIndexer.Add(columnName, columnIndex);
                    }
                }
                var classType = typeof(T);
                var o = Activator.CreateInstance(classType);
                var propList = o.GetType().GetProperties();
                var fullClassName = o.GetType().FullName;
                // Iterate over rows
                for (int row = 2; row <= rowEndIndex; row++)
                {
                    try
                    {
                        // Add condition to skip the empty rows if the key columns are blank or empty
                        var p = Activator.CreateInstance(classType);
                        foreach (var prop in propList)
                        {
                            var propName = prop.Name;
                            ColumnHeader columnName = (ColumnHeader)(prop.GetCustomAttributes(false).Length != 0 ? prop.GetCustomAttributes(false)[0] : new ColumnHeader());
                            var propDatatype = prop.PropertyType.Name;
                            var dict = columnIndexer.ToList().Find(x => x.Key.ToLower().Equals(propName.ToLower()) || x.Key.ToLower().Equals(columnName.ColumnName.ToLower()));
                            if (dict.Key != null)
                            {
                                int columnIndex = dict.Value;
                                switch (propDatatype.ToLower())
                                {
                                    case "int32": p.GetType().GetProperty(propName).SetValue(p, doc.GetCellValueAsDouble(row, columnIndex)); break;
                                    case "string": p.GetType().GetProperty(propName).SetValue(p, doc.GetCellValueAsString(row, columnIndex).Trim()); break;
                                    case "datetime": p.GetType().GetProperty(propName).SetValue(p, doc.GetCellValueAsDateTime(row, columnIndex)); break;
                                }
                            }
                        }

                        #region Automation Specific Logic
                        /* ------------------------------------------------------------------ */
                        /*  Automation Specific Logic */
                        /* ------------------------------------------------------------------ */
                        var gui = p.GetType().GetProperty("personIdExternal").GetValue(p);
                        var userid = p.GetType().GetProperty("userId").GetValue(p);

                        if (gui.ToString().Equals(string.Empty) && userid.ToString().Equals(string.Empty))
                        {
                            TestLog.Debug($"Key Columns valus missing for the row number {row} in work sheet {hRScenario}");
                            goto OuterLoop;
                        }

                        p.GetType().GetProperty("ClassName").SetValue(p, fullClassName);

                        #endregion
                        paramList.Add((T)p);
                    }
                    catch (Exception e)
                    {
                        TestLog.Error(e.Message);
                    }
                OuterLoop:
                    continue;
                }
            }
            return paramList;
        }
        public static void SaveFoundationOutput(DataTable dataTable)
        {
            try
            {
                string filename = $@"{Util.ResultPath}\{_FODBReport}";
                SLDocument doc;
                if (!File.Exists(filename))
                {
                    doc = new SLDocument();
                    doc.SaveAs(filename);
                }
                doc = new SLDocument(filename);
                string sheetname = dataTable.TableName;
                if (doc.GetWorksheetNames().Any(x => x.Equals(sheetname)))
                {
                    doc.SelectWorksheet(sheetname);
                }
                else
                {
                    doc.AddWorksheet(sheetname);
                }

                doc.ImportDataTable("B2", dataTable, true);
                doc.Save();
                //doc.SaveAs(filename);
            }
            catch (Exception e)
            {
                TestLog.Error(e.Message);
            }


        }

        public static void SaveFoundationDataInExcel(List<FoundationExecution> executionStatuses, string _sheetname)
        {
            string filename = $@"{Util.ResultPath}\{Util.TestConfiguration.GetCustomKeyValue("Payload")}";
            SLDocument doc;
            if (!File.Exists(filename))
            {
                doc = new SLDocument();
                doc.SaveAs(filename);
            }
            doc = new SLDocument(filename);

            if (doc.GetWorksheetNames().Any(x => x.Equals(_sheetname.ToLower())))
            {
                doc.SelectWorksheet(_sheetname);
            }
            else
            {
                doc.AddWorksheet(_sheetname);
            }
            int rowid = 1, columnid = 1;
            var headerList = ColumnHeader.OrderHeaderList(executionStatuses.FirstOrDefault()).OrderBy(x => x.Key);
            var valueList = ColumnHeader.OrderFieldist(executionStatuses.FirstOrDefault()).OrderBy(x => x.Key);


            foreach (var _header in headerList)
            {
                doc.SetCellValue(rowid, columnid++, _header.Value);
            }
            rowid = 2;
            columnid = 1;
            var style = new SLStyle(); style.SetWrapText(true);
            foreach (var item in executionStatuses.FindAll(x => x.TCID.Contains(_sheetname)))
            {
                doc.SetCellValue(rowid, columnid, item.TCID);
                doc.SetCellValue(rowid, columnid + 1, item.ExternalCode);
                doc.SetCellValue(rowid, columnid + 2, item.StartDate);
                doc.SetCellValue(rowid, columnid + 3, item.Name);
                doc.SetCellValue(rowid, columnid + 4, item.Description);
                doc.SetCellValue(rowid, columnid + 5, item.Status);
                doc.SetCellValue(rowid, columnid + 6, item.APIDataCreation);
                doc.SetCellValue(rowid, columnid + 7, item.APIDataValidation);
                doc.SetCellValue(rowid, columnid + 8, item.DBDataValidation);
                doc.SetCellValue(rowid, columnid + 9, JsonConvert.SerializeObject(item.Parameter, Converter.Settings));
                rowid++;
            }
            doc.AutoFitColumn(1, 8);
            doc.SetColumnWidth(9, 50);
            doc.AutoFitRow(1, rowid++);
            doc.Save();
        }

        internal static void CreateExcelReportFromRuntimeData<T>(string filename, string _sheetname, List<T> t) where T : class
        {
            TestLog.Info($"Sheet Name :{_sheetname}");
            filename = $@"{Util.ResultPath}\CoreHRDB.xlsx";
            SLDocument doc;
            if (!File.Exists(filename))
            {
                doc = new SLDocument();
                doc.SaveAs(filename);
            }
            doc = new SLDocument(filename);
            int rowid = 1, columnid = 1;
            int endrowid = 1, endcolumnid = 1;
            if (doc.GetWorksheetNames().Any(x => x.Equals(_sheetname.ToLower())))
            {
                doc.SelectWorksheet(_sheetname);
                endrowid = doc.GetWorksheetStatistics().EndRowIndex;
                endcolumnid = doc.GetWorksheetStatistics().EndColumnIndex;
                doc.DeleteColumn(columnid, endcolumnid + 1);
            }
            else
            {
                doc.AddWorksheet(_sheetname);
            }

            if (t.Count != 0)
            {
                var classType = t[0].GetType();
                var o = Activator.CreateInstance(classType);

                var headerList = ColumnHeader.OrderHeaderList(o).OrderBy(x => x.Key);
                var valueList = ColumnHeader.OrderFieldist(o).OrderBy(x => x.Key);

                foreach (var _header in headerList)
                {
                    doc.SetCellValue(rowid, columnid++, _header.Value);
                }
                rowid++;
                columnid = 1;
                foreach (T param in t)
                {
                    foreach (var header in valueList)
                    {
                        var v = param.GetType().GetProperty(header.Value).GetValue(param);
                        doc.SetCellValue(rowid, columnid++, (v == null) ? "" : v.ToString());
                    }
                    rowid++;
                    columnid = 1;
                }
                columnid = doc.GetWorksheetStatistics().EndColumnIndex;
                doc.SetCellStyle(1, 1, rowid++, columnid++, new SLStyle()
                {
                    Alignment = new SLAlignment()
                    {
                        Horizontal = DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Center,
                        Vertical = DocumentFormat.OpenXml.Spreadsheet.VerticalAlignmentValues.Center
                    },
                    Font = new SLFont()
                    {
                        FontName = "Calibri",
                        FontSize = 8
                    }
                });
            }
            else
            {
                doc.SetCellValue(2, 2, "run time parameter file missing; please re-excute the script in the order => Create via API --> Extract Zone A --> Perform TDDH Validation ");
            }

            doc.AutoFitColumn(1, columnid);
            doc.AutoFitRow(1, rowid);
            doc.Save();
        }

        /// <summary>
        /// Save the basic key and Payload Informations for the Foundation Scenario's
        /// </summary>
        /// <param name="executionStatuses"></param>
        /// <param name="_sheetname"></param>
        public static void SavePayLoadInfoasExcelReport(List<FoundationExecution> executionStatuses, string _sheetname)
        {
            string filename = $@"{Util.ResultPath}\{Util.TestConfiguration.GetCustomKeyValue("Payload")}";
            SLDocument doc;
            if (!File.Exists(filename))
            {
                doc = new SLDocument();
                doc.SaveAs(filename);
            }
            doc = new SLDocument(filename);

            if (doc.GetWorksheetNames().Any(x => x.Equals(_sheetname.ToLower())))
            {
                doc.SelectWorksheet(_sheetname);
            }
            else
            {
                doc.AddWorksheet(_sheetname);
            }
            int rowid = 1, columnid = 1;
            var headerList = ColumnHeader.OrderHeaderList(executionStatuses.FirstOrDefault()).OrderBy(x => x.Key);
            var valueList = ColumnHeader.OrderFieldist(executionStatuses.FirstOrDefault()).OrderBy(x => x.Key);


            foreach (var _header in headerList)
            {
                doc.SetCellValue(rowid, columnid++, _header.Value);
            }
            rowid = 2;
            columnid = 1;
            var style = new SLStyle(); style.SetWrapText(true);
            foreach (var item in executionStatuses.FindAll(x => x.TCID.Contains(_sheetname)))
            {
                doc.SetCellValue(rowid, columnid, item.TCID);
                doc.SetCellValue(rowid, columnid + 1, item.ExternalCode);
                doc.SetCellValue(rowid, columnid + 2, item.StartDate);
                doc.SetCellValue(rowid, columnid + 3, item.Name);
                doc.SetCellValue(rowid, columnid + 4, item.Description);
                doc.SetCellValue(rowid, columnid + 5, item.Status);
                doc.SetCellValue(rowid, columnid + 6, item.APIDataCreation);
                doc.SetCellValue(rowid, columnid + 7, item.APIDataValidation);
                doc.SetCellValue(rowid, columnid + 8, item.DBDataValidation);
                doc.SetCellValue(rowid, columnid + 9, JsonConvert.SerializeObject(item.Parameter, Converter.Settings));
                rowid++;
            }
            doc.AutoFitColumn(1, 8);
            doc.SetColumnWidth(9, 50);
            doc.AutoFitRow(1, rowid++);
            doc.Save();
        }

        /// <summary>
        /// Save the basic key and Payload Informations for Core HR Scenarios
        /// </summary>
        /// <param name="executionStatuses"></param>
        /// <param name="_sheetname"></param>
        public static void SavePayLoadInfoasExcelReport(List<CoreHRExecution> executionStatuses, string _sheetname)
        {
            string filename = $@"{Util.ResultPath}\{Util.TestConfiguration.GetCustomKeyValue("Payload")}";
            SLDocument doc;
            if (!File.Exists(filename))
            {
                doc = new SLDocument();
                doc.SaveAs(filename);
            }
            doc = new SLDocument(filename);

            if (doc.GetWorksheetNames().Any(x => x.Equals(_sheetname.ToLower())))
            {
                doc.SelectWorksheet(_sheetname);
            }
            else
            {
                doc.AddWorksheet(_sheetname);
            }
            int rowid = 1, columnid = 1;
            var headerList = ColumnHeader.OrderHeaderList(executionStatuses.FirstOrDefault()).OrderBy(x => x.Key);
            var valueList = ColumnHeader.OrderFieldist(executionStatuses.FirstOrDefault()).OrderBy(x => x.Key);


            foreach (var _header in headerList)
            {
                doc.SetCellValue(rowid, columnid++, _header.Value);
            }
            rowid = 2;
            columnid = 1;
            var style = new SLStyle(); style.SetWrapText(true);
            foreach (var item in executionStatuses)
            {
                doc.SetCellValue(rowid, columnid, item.TCID);
                doc.SetCellValue(rowid, columnid + 1, item.personIdExternal);
                doc.SetCellValue(rowid, columnid + 2, item.userId);
                doc.SetCellValue(rowid, columnid + 3, item.startDate);
                doc.SetCellValue(rowid, columnid + 4, item.APIDataCreation);
                doc.SetCellValue(rowid, columnid + 5, item.APIDataValidation);
                doc.SetCellValue(rowid, columnid + 6, item.DBDataValidation);
                doc.SetCellValue(rowid, columnid + 7, JsonConvert.SerializeObject(item.Parameter, Converter.Settings));
                doc.SetCellStyle(2, 1, rowid, 8, style);
                rowid++;
            }
            doc.AutoFitColumn(1,8);
            doc.SetColumnWidth(9, 50);
            doc.AutoFitRow(1,rowid++);
            doc.Save();
        }

        public static List<object> ReadFoundationData<T>(FOType foscenario) where T : class
        {
            if (fomaplist is null)
            {
                fomaplist = (!Util.TestConfiguration.Environment.Equals(Constants.TST1)) ? PackageInfoLoader.Load().Packs : PackageInfoLoader.Load(Constants.TST1).Packs;
                //TestData<FOMapping>.Data.ToList();
            }
            var paramList = new List<object>();
            using (SLDocument doc = new SLDocument($@"{Util.DirectoryPath}\Data\excel_data\Foundation.xlsx"))
            {
                TestLog.Info($"Select the worksheet {foscenario}");
                doc.SelectWorksheet(foscenario.ToString().ToLower());
                int columnEndIndex = doc.GetWorksheetStatistics().EndColumnIndex;
                int rowEndIndex = doc.GetWorksheetStatistics().EndRowIndex;
                ParameterCount = rowEndIndex;
                Dictionary<string, int> columnIndexer = new Dictionary<string, int>();

                // Iterate over columns
                for (int columnIndex = 1; columnIndex <= columnEndIndex; columnIndex++)
                {
                    string columnName = doc.GetCellValueAsString(1, columnIndex);
                    if (!columnName.Trim().Equals(string.Empty))
                    {
                        columnIndexer.Add(columnName, columnIndex);
                    }
                }
                var classType = typeof(T);
                var o = Activator.CreateInstance(classType);
                var propList = o.GetType().GetProperties();
                var fullClassName = o.GetType().FullName;
                // Iterate over rows
                for (int row = 2; row <= rowEndIndex; row++)
                {
                    try
                    {
                        var p = Activator.CreateInstance(classType);
                        foreach (var prop in propList)
                        {
                            var propName = prop.Name;
                            ColumnHeader columnName = null;
                            if (prop.GetCustomAttributes(false).Length > 0)
                            {
                                columnName = (ColumnHeader)prop.GetCustomAttributes(false).ToList().Find(x => x.ToString().Contains(nameof(ColumnHeader), StringComparison.InvariantCultureIgnoreCase));
                            }
                            if (columnName is null) columnName = new ColumnHeader();
                            var propDatatype = prop.PropertyType.Name;
                            var dict = columnIndexer.ToList().Find(x => x.Key.ToLower().Equals(propName.ToLower()) || x.Key.ToLower().Equals(columnName.ColumnName.ToLower()));
                            if (dict.Key != null)
                            {
                                int columnIndex = dict.Value;
                                #region read data based on datatype
                                switch (propDatatype.ToLower())
                                {
                                    case "boolean":
                                        bool cellvalue = false;
                                        var bvalue = doc.GetCellValueAsString(row, columnIndex).Trim().ToLower();
                                        if (bvalue.Equals("true") || bvalue.Equals("false")) { cellvalue = Convert.ToBoolean(bvalue); }
                                        if (bvalue.Equals("yes") || bvalue.Equals("no")) { cellvalue = bvalue.Equals("yes"); }
                                        if (bvalue.Length > 0) p.GetType().GetProperty(propName).SetValue(p, cellvalue);
                                        break;
                                    case "int32":
                                        p.GetType().GetProperty(propName).SetValue(p, doc.GetCellValueAsDouble(row, columnIndex));
                                        break;
                                    case "string":
                                        var cvalue = doc.GetCellValueAsString(row, columnIndex).Trim();
                                        p.GetType().GetProperty(propName).SetValue(p, (cvalue != null && !cvalue.Equals(string.Empty)) ? cvalue : null);
                                        break;
                                    case "datetime":
                                        p.GetType().GetProperty(propName).SetValue(p, doc.GetCellValueAsDateTime(row, columnIndex));
                                        break;
                                }
                                #endregion

                                #region resolve the country id value
                                // if the field is country field, set the country column value based on the key.
                                try
                                {
                                    if (columnName.ColumnName.ToLower().Equals("country"))
                                    {
                                        var cv = doc.GetCellValueAsString(row, columnIndex).Trim();
                                        if (cv.Length > 3)
                                        {
                                            TestLog.Info($"Identifying the country value for {cv}");
                                            var countryVal = SFComponent.CountryCode(cv);
                                            p.GetType().GetProperty(propName).SetValue(p, countryVal);
                                        }
                                    }
                                }
                                catch (Exception)
                                {
                                    throw new FrameworkException($"Unable to identify the country value, Input data {foscenario} has invalid country data. Refer the valid country name is master sheet!");
                                }
                                #endregion
                            }
                        }
                        #region skip null rows
                        var chk = p.GetType().GetProperty("externalCode").GetValue(p);
                        if (chk == null) { continue; }
                        #endregion

                        #region adding metadata info
                        var metainfo = fomaplist.Find(x => x.Name.Equals(foscenario.ToString(), StringComparison.InvariantCultureIgnoreCase));

                        var metadata = new SF.Entity.Metadata()
                        {
                            Uri = $"{metainfo.Entity_Name}"
                        };
                        p.GetType().GetProperty("metadata").SetValue(p, metadata);

                        #endregion
                        paramList.Add((T)p);
                    }
                    catch (Exception e)
                    {
                        TestLog.Error(e.Message);
                    }
                    //OuterLoop:
                    //    continue;
                }
            }
            return paramList;
        }

        public static void CreateExcelReport(List<object> items, string sheetname, string filename = "Test.xlsx")
        {
            if (items.Count >= 1)
            {
                var classObject = Activator.CreateInstance(items.FirstOrDefault().GetType());
                var headerList = ColumnHeader.OrderHeaderList(classObject).OrderBy(x => x.Key).ToList();
                var valueList = ColumnHeader.OrderFieldist(classObject).OrderBy(x => x.Key).ToList();
                var filepath = $@"{Util.ResultPath}\{filename}";

                //headerList.Add(new KeyValuePair<int, string>(0, "Run On"));

                /*File Creation, If the file is not available in the specified location, then it is created*/
                if (!File.Exists(filepath))
                {
                    SLDocument d = new SLDocument();
                    d.SaveAs(filepath);
                }
                SLDocument doc = new SLDocument(filepath);


                int rowIndex = 1, columnIndex = 1;

                /* Check for the work sheet.
                 * If the work sheet is not available, then it is created.
                 * If the work sheet is available, then it is selected and remove the rows from 2 to last used rows
                 */
                if (doc.GetWorksheetNames().Any(x => x.ToLower().Equals(sheetname.ToLower())))
                {
                    doc.SelectWorksheet(sheetname);

                    var lastRowindex = doc.GetWorksheetStatistics().EndRowIndex;
                    var lastColumnIndex = doc.GetWorksheetStatistics().EndColumnIndex;

                    //Deleting the rows from 2 row to last used row
                    doc.DeleteRow(2, lastRowindex);

                }
                else
                {
                    doc.AddWorksheet(sheetname);
                    doc.SetCellValue(rowIndex, columnIndex++, "Run On");
                    foreach (var header in headerList)
                    {
                        doc.SetCellValue(rowIndex, columnIndex++, header.Value);
                    }
                }
                rowIndex = doc.GetWorksheetStatistics().EndRowIndex + 1;
                columnIndex = 1;

                foreach (var param in items)
                {
                    doc.SetCellValue(rowIndex, columnIndex++, $"\'{DateTime.Now:yyyy-MM-dd}\'");
                    foreach (var header in valueList)
                    {
                        var v = param.GetType().GetProperty(header.Value).GetValue(param);
                        doc.SetCellValue(rowIndex, columnIndex++, (v == null) ? "" : v.ToString());

                    }
                    rowIndex++;
                    columnIndex = 1;
                }
                columnIndex = doc.GetWorksheetStatistics().EndColumnIndex;
                doc.SetCellStyle(1, 1, rowIndex++, columnIndex++, new SLStyle()
                {
                    Alignment = new SLAlignment()
                    {
                        Horizontal = DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Center,
                        Vertical = DocumentFormat.OpenXml.Spreadsheet.VerticalAlignmentValues.Center
                    },
                    Font = new SLFont()
                    {
                        FontName = "Calibri",
                        FontSize = 8
                    }
                });
                doc.AutoFitColumn(1, columnIndex);
                doc.AutoFitRow(1, rowIndex);
                doc.Save();
            }
        }

        public static void CreateExcelReport<T>(CoreHRScenario hRScenario) where T : class
        {
            //lock (new object())
            //{
            var parameters = RunTimeData<T>.ReadOutputData(hRScenario).ToList();
            var scenario = $"{hRScenario}";
            var classObject = Activator.CreateInstance<T>();
            var headerList = ColumnHeader.OrderHeaderList(classObject).OrderBy(x => x.Key);
            var valueList = ColumnHeader.OrderFieldist(classObject).OrderBy(x => x.Key);
            var filepath = $@"{Util.ResultPath}\{_CoreHRReport}";
            if (!File.Exists(filepath))
            {
                SLDocument d = new SLDocument();
                d.SaveAs(filepath);
            }

            SLDocument doc = new SLDocument(filepath);


            int rowIndex = 1, columnIndex = 1;

            if (doc.GetWorksheetNames().Any(x => x.ToLower().Equals(scenario.ToLower())))
            {
                doc.SelectWorksheet(scenario);
                var lastRowindex = doc.GetWorksheetStatistics().EndRowIndex;
                var lastColumnIndex = doc.GetWorksheetStatistics().EndColumnIndex;
                //doc.ClearCellContent(2, 1, lastRowindex, lastColumnIndex);
            }
            else
            {
                doc.AddWorksheet(scenario);
                foreach (var header in headerList)
                {
                    doc.SetCellValue(rowIndex, columnIndex++, header.Value);
                }
            }
            rowIndex = doc.GetWorksheetStatistics().EndRowIndex + 1;
            columnIndex = 1;

            foreach (var param in parameters)
            {
                foreach (var header in valueList)
                {
                    var v = param.GetType().GetProperty(header.Value).GetValue(param);
                    doc.SetCellValue(rowIndex, columnIndex++, (v == null) ? "" : v.ToString());
                }
                rowIndex++;
                columnIndex = 1;
            }

            doc.AutoFitColumn(1, columnIndex);

            doc.Save(); //Thread.Sleep(2000);
            //}
        }

        public static void UpdateResultToSheet<T>(CoreHRScenario hrscenario, object o) where T : class
        {
            //Enum.TryParse(sheetName, out CoreHRScenario enumVal);
            //var parameters = RunTimeData<T>.ReadOutputData(enumVal).ToList();
            var scenario = $"{hrscenario}";
            var classObject = Activator.CreateInstance<T>();
            classObject = (T)o;
            var headerList = ColumnHeader.OrderHeaderList(classObject).OrderBy(x => x.Key);
            var valueList = ColumnHeader.OrderFieldist(classObject).OrderBy(x => x.Key);

            SLDocument doc = new SLDocument(_CoreHRReport);


            int rowIndex = 1, columnIndex = 1;

            if (doc.GetWorksheetNames().Any(x => x.ToLower().Equals(scenario.ToLower())))
            {
                doc.SelectWorksheet(scenario);
                var lastRowindex = doc.GetWorksheetStatistics().EndRowIndex;
                var lastColumnIndex = doc.GetWorksheetStatistics().EndColumnIndex;
                //doc.ClearCellContent(2, 1, lastRowindex, lastColumnIndex);
            }
            else
            {
                doc.AddWorksheet(scenario);
                foreach (var header in headerList)
                {
                    doc.SetCellValue(rowIndex, columnIndex++, header.Value);
                }
            }
            rowIndex = doc.GetWorksheetStatistics().EndRowIndex + 1;
            var keyColumn = classObject.GetType().GetProperty("rowKey").GetValue(classObject);
            //check if the data already availabel in the sheet.
            /*for (int i = 2; i <= rowIndex; i++)
            {
                Console.WriteLine(doc.GetCellValueAsString($"A{i}"));
                if (keyColumn.Equals(doc.GetCellValueAsString($"A{i}"))) { rowIndex = i; break; } 
                else { rowIndex = doc.GetWorksheetStatistics().EndRowIndex+1;  }
            }*/

            columnIndex = 1;
            foreach (var header in valueList)
            {
                var v = classObject.GetType().GetProperty(header.Value).GetValue(classObject);
                doc.SetCellValue(rowIndex, columnIndex++, (v == null) ? " null / blank " : v.ToString());
            }

            doc.AutoFitColumn(1, columnIndex);

            doc.Save(); Thread.Sleep(2000);

        }

        public static List<object> ReadInputData<T>(string sheetname = "Sheet1", string filename = "DataSheet") where T : class
        {
            var paramList = new List<object>();
            using (SLDocument doc = new SLDocument($@"{Util.DirectoryPath}\Data\excel_data\{filename}.xlsx"))
            {
                TestLog.Info($"Select the worksheet {sheetname}");
                doc.SelectWorksheet(sheetname.ToString().ToLower());
                int columnEndIndex = doc.GetWorksheetStatistics().EndColumnIndex;
                int rowEndIndex = doc.GetWorksheetStatistics().EndRowIndex;
                ParameterCount = rowEndIndex;
                Dictionary<string, int> columnIndexer = new Dictionary<string, int>();

                // Iterate over columns
                for (int columnIndex = 1; columnIndex <= columnEndIndex; columnIndex++)
                {
                    string columnName = doc.GetCellValueAsString(1, columnIndex);
                    if (!columnName.Trim().Equals(string.Empty))
                    {
                        columnIndexer.Add(columnName, columnIndex);
                    }
                }
                var classType = typeof(T);
                var o = Activator.CreateInstance(classType);
                var propList = o.GetType().GetProperties();
                var fullClassName = o.GetType().FullName;
                // Iterate over rows
                for (int row = 2; row <= rowEndIndex; row++)
                {
                    try
                    {
                        // Add condition to skip the empty rows if the key columns are blank or empty
                        var p = Activator.CreateInstance(classType);
                        foreach (var prop in propList)
                        {
                            var propName = prop.Name;
                            ColumnHeader columnName = (ColumnHeader)(prop.GetCustomAttributes(false).Length != 0 ? prop.GetCustomAttributes(false)[0] : new ColumnHeader());
                            var propDatatype = prop.PropertyType.Name;
                            var dict = columnIndexer.ToList().Find(x => x.Key.ToLower().Equals(propName.ToLower()) || x.Key.ToLower().Equals(columnName.ColumnName.ToLower()));
                            if (dict.Key != null)
                            {
                                int columnIndex = dict.Value;
                                switch (propDatatype.ToLower())
                                {
                                    case "int32": p.GetType().GetProperty(propName).SetValue(p, doc.GetCellValueAsDouble(row, columnIndex)); break;
                                    case "string": p.GetType().GetProperty(propName).SetValue(p, doc.GetCellValueAsString(row, columnIndex).Trim()); break;
                                    case "datetime": p.GetType().GetProperty(propName).SetValue(p, doc.GetCellValueAsDateTime(row, columnIndex)); break;
                                }
                            }
                        }

                        #region Automation Specific Logic

                        #endregion
                        paramList.Add((T)p);
                    }
                    catch (Exception e)
                    {
                        TestLog.Error(e.Message);
                    }
                    //OuterLoop:
                    continue;
                }
            }
            return paramList;
        }

        public static void CreateOnboardingReport(InputTestData data)
        {
            if (data.GUI != null && data.GUI.Equals(string.Empty))
            {
                var valueList = ColumnHeader.OrderFieldist(data).OrderBy(x => x.Key).ToList();
                var headerList = ColumnHeader.OrderHeaderList(data).OrderBy(x => x.Key).ToList();
                var sheetname = data.country;
                var filepath = $@"{Util.DirectoryPath}\Onboarding_Data.xlsx";

                //headerList.Add(new KeyValuePair<int, string>(0, "Run On"));

                /*File Creation, If the file is not available in the specified location, then it is created*/
                if (!File.Exists(filepath))
                {
                    SLDocument d = new SLDocument();
                    d.SaveAs(filepath);
                }
                SLDocument doc = new SLDocument(filepath);


                int rowIndex = 1, columnIndex = 1;

                /* Check for the work sheet.
                 * If the work sheet is not available, then it is created.
                 * If the work sheet is available, then it is selected and remove the rows from 2 to last used rows
                 */
                if (doc.GetWorksheetNames().Any(x => x.ToLower().Equals(sheetname.ToLower())))
                {
                    doc.SelectWorksheet(sheetname);
                    foreach (var header in headerList)
                    {
                        doc.SetCellValue(rowIndex, columnIndex++, header.Value);
                    }
                    //rowIndex = doc.GetWorksheetStatistics().EndRowIndex;
                    //columnIndex = doc.GetWorksheetStatistics().EndColumnIndex;

                }
                else
                {
                    doc.AddWorksheet(sheetname);
                    foreach (var header in headerList)
                    {
                        doc.SetCellValue(rowIndex, columnIndex++, header.Value);
                    }
                }
                rowIndex = doc.GetWorksheetStatistics().EndRowIndex + 1;
                columnIndex = 1;

                foreach (var header in valueList)
                {
                    var v = data.GetType().GetProperty(header.Value).GetValue(data);
                    doc.SetCellValue(rowIndex, columnIndex++, (v == null) ? "" : v.ToString());
                }
                columnIndex = doc.GetWorksheetStatistics().EndColumnIndex;
                doc.SetCellStyle(1, 1, rowIndex++, columnIndex++, new SLStyle()
                {
                    Alignment = new SLAlignment()
                    {
                        Horizontal = DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Center,
                        Vertical = DocumentFormat.OpenXml.Spreadsheet.VerticalAlignmentValues.Center
                    },
                    Font = new SLFont()
                    {
                        FontName = "Calibri",
                        FontSize = 8
                    }
                });
                doc.AutoFitColumn(1, columnIndex);
                doc.AutoFitRow(1, rowIndex);
                doc.Save();
            }
            else
            {
                TestLog.Info("Gui is blank");
            }
        }

        public static List<T> ReadFGInputData<T>(string sheetname = "Input") where T:class
        {
            var paramList = new List<T>();
            using (SLDocument doc = new SLDocument($@"{Util.DirectoryPath}\Data\excel_data\FGInputData.xlsx"))
            {
                TestLog.Info($"Select the worksheet {sheetname}");
                doc.SelectWorksheet(sheetname.ToLower());
                int columnEndIndex = doc.GetWorksheetStatistics().EndColumnIndex;
                int rowEndIndex = doc.GetWorksheetStatistics().EndRowIndex;
                ParameterCount = rowEndIndex;
                Dictionary<string, int> columnIndexer = new Dictionary<string, int>();

                // Iterate over columns
                for (int columnIndex = 1; columnIndex <= columnEndIndex; columnIndex++)
                {
                    string columnName = doc.GetCellValueAsString(1, columnIndex);
                    if (!columnName.Trim().Equals(string.Empty))
                    {
                        columnIndexer.Add(columnName, columnIndex);
                    }
                }
                var classType = typeof(T);
                var o = Activator.CreateInstance(classType);
                var propList = o.GetType().GetProperties();
                var fullClassName = o.GetType().FullName;
                // Iterate over rows
                for (int row = 2; row <= rowEndIndex; row++)
                {
                    try
                    {
                        var p = Activator.CreateInstance(classType);
                        foreach (var prop in propList)
                        {
                            var propName = prop.Name;
                            ColumnHeader columnName = null;
                            if (prop.GetCustomAttributes(false).Length > 0)
                            {
                                columnName = (ColumnHeader)prop.GetCustomAttributes(false).ToList().Find(x => x.ToString().Contains(nameof(ColumnHeader), StringComparison.InvariantCultureIgnoreCase));
                            }
                            if (columnName is null) columnName = new ColumnHeader();
                            var propDatatype = prop.PropertyType.Name;
                            var dict = columnIndexer.ToList().Find(x => x.Key.ToLower().Equals(propName.ToLower()) || x.Key.ToLower().Equals(columnName.ColumnName.ToLower()));
                            if (dict.Key != null)
                            {
                                int columnIndex = dict.Value;
                                #region read data based on datatype
                                switch (propDatatype.ToLower())
                                {
                                    case "boolean":
                                        bool cellvalue = false;
                                        var bvalue = doc.GetCellValueAsString(row, columnIndex).Trim().ToLower();
                                        if (bvalue.Equals("true") || bvalue.Equals("false")) { cellvalue = Convert.ToBoolean(bvalue); }
                                        if (bvalue.Equals("yes") || bvalue.Equals("no")) { cellvalue = bvalue.Equals("yes"); }
                                        if (bvalue.Length > 0) p.GetType().GetProperty(propName).SetValue(p, cellvalue);
                                        break;
                                    case "int32":
                                        p.GetType().GetProperty(propName).SetValue(p, doc.GetCellValueAsDouble(row, columnIndex));
                                        break;
                                    case "string":
                                        var cvalue = doc.GetCellValueAsString(row, columnIndex).Trim();
                                        p.GetType().GetProperty(propName).SetValue(p, (cvalue != null && !cvalue.Equals(string.Empty)) ? cvalue : null);
                                        break;
                                    case "datetime":
                                        p.GetType().GetProperty(propName).SetValue(p, doc.GetCellValueAsDateTime(row, columnIndex));
                                        break;
                                }
                                #endregion

                                
                            }
                        }
                        #region skip null rows
                        var chk = p.GetType().GetProperty("RequestType").GetValue(p);
                        if (chk == null) { continue; }
                        #endregion
                        paramList.Add((T)p);
                    }
                    catch (Exception e)
                    {
                        TestLog.Error(e.Message);
                    }                    
                }
            }
            return paramList;
        }
    }
}

/*
 var lt = Order.OrderedItems(parameter).OrderBy(x=>x.Key);

            SLDocument doc = new SLDocument(filepath);
            int rowIndex = 1, colIndex = 1;
            var classType = parameter.GetType().GetProperties();

            if (doc.GetWorksheetNames().Any(x => x.ToLower().Equals(sheetName.ToLower())))
            {
                doc.SelectWorksheet(sheetName);
                // This to select existing the work sheet.
            }
            else
            {
                // This code to set values to respective columns in excel
                doc.AddWorksheet(sheetName);
                foreach (var t in lt)
                {
                    doc.SetCellValue(rowIndex, colIndex++, t.Value);
                }
            }

            colIndex = 1;
            rowIndex = doc.GetWorksheetStatistics().EndRowIndex + 1;

            foreach (var t in lt)
            {
                var v = parameter.GetType().GetProperty(t.Value).GetValue(parameter);
                doc.SetCellValue(rowIndex, colIndex++, (v == null) ? "NULL/BLANK" : v.ToString());
            }

            doc.AutoFitColumn(1,colIndex);

            doc.Save();  Thread.Sleep(2000);
 */