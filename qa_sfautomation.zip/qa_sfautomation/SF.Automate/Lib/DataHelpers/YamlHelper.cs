﻿/// <summary>
/// This is a core file please do not make any changes unless necessary
/// Author : Samson Simon
/// Created Date : 26 Aug 2019
/// </summary>

namespace Pom
{
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using YamlDotNet.RepresentationModel;
    using YamlDotNet.Serialization;

    public class YamlHelper : ITestDataManagement
    {
        public YamlHelper()
        {
        }

        public static Dictionary<string, Dictionary<string, string>> SerializeYaml(string filename)
        {
            string file = $@"{Util.DirectoryPath}\Data\yaml_json\{filename}.yaml";
            string data = File.ReadAllText(file);
            var deserializer = new DeserializerBuilder().Build();
            var yamlObject = deserializer.Deserialize<Dictionary<string, Dictionary<string, string>>>(data.ToString());
            return yamlObject;
        }

        public string GetData(string key, string value, string filename)
        {
            var getdictionary = SerializeYaml(filename);
            string pairData = "";
            pairData = getdictionary[key][value];
            return pairData;
        }

        public string GetData(string key, string filename)
        {
            var getdictionary = SerializeYaml(filename);
            return string.Empty;
        }

        public Dictionary<string, string> GetDataDictionary(string Key, string filename)
        {
            var getdictionary = SerializeYaml(filename);
            var dataDictionary = getdictionary.Where(x => x.Key == Key).FirstOrDefault().Value;
            return dataDictionary;
        }

        public Dictionary<string, Dictionary<string, string>> GetDataDictionary(string filename)
        {
            return SerializeYaml(filename);
        }

        public bool IsKeyValuePresentInTestData(string key, string value1, string filename)
        {
            string file = $@"{Util.DirectoryPath.Replace(@"bin\Debug", "Data" + "\\" + filename + ".Yaml")}";
            var reader = new StringReader(File.ReadAllText(file));
            Dictionary<object, object> value = null;
            var deserializer = new DeserializerBuilder().Build();
            value = deserializer.Deserialize<Dictionary<object, object>>(reader);
            if (value.ContainsKey(key))
            {
                value = (Dictionary<object, object>)value[key];
                if (value.ContainsKey(value1))
                {
                    return true;
                }
            }
            return false;
        }

        public void WritetoTestData(string key, string value, string data, string filename)
        {
            string file = $@"{Util.DirectoryPath.Replace(@"bin\Debug", "Data" + "\\" + filename + ".Yaml")}";
            var reader = File.ReadAllText(file);
            var input = new StringReader(reader);
            var yaml = new YamlStream();
            yaml.Load(input);
            var rootMappingNode = (YamlMappingNode)yaml.Documents[0].RootNode;
            var props = new YamlMappingNode
            {
                { value, data }
            };
            rootMappingNode.Add(key, props);
            using (TextWriter writer = File.CreateText(file))
                yaml.Save(writer, false);
        }
    }
}