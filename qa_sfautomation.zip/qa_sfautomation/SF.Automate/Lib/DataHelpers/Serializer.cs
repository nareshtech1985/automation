﻿namespace Pom.DataHelpers
{
    using Newtonsoft.Json;
    using Pom;
    using System;
    using System.IO;

    public class Serializer<T> where T : class
    {
        public static T FromJson(string json) => JsonConvert.DeserializeObject<T>(json, Converter.Settings);

        public static string ToJson(T self) => JsonConvert.SerializeObject(self, Converter.Settings);

        public static T FetchData()
        {
            try
            {
                return FromJson(File.ReadAllText($@"{Util.DirectoryPath}\Data\json_data\{typeof(T).Name}.json"));
            }
            catch (Exception)
            {
                throw new FrameworkException($@"Input file {typeof(T).Name}.json is not found @ location {Util.DirectoryPath}\Data\");
            }
        }
    }
}