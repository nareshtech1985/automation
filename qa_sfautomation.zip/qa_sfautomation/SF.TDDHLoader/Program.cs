﻿namespace ExecuteQABatch
{
    using SF.Batch;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Diagnostics;
    using System.IO;
    using System.Linq;
    using System.Reflection;
    using System.Text;

    public class Program
    {
        private static readonly string[] allowedExtensions = new string[] { ".pgp", ".xml", ".txt" };
        private static readonly SfBatchConfig config = SfBatchConfig.FromJson(File.ReadAllText($@"{DirectoryPath}\SfBatchConfig.json"));
        public static object ConfigurationManger { get; private set; }
        public static string DirectoryPath => Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        private static BatchConfiguration batchMethod = new BatchConfiguration();
        private static List<string> FoFileMasks = new List<string>();
        private static List<string> GetFileNames()
        {
            var env = File.ReadAllText($@"{DirectoryPath}\env.txt");

            FoFileMasks = DataAccess.GetFOFileMask(env);

            var location = ConfigurationManager.AppSettings["filewatcherllocation"];
            List<string> filetype = new List<string>();
            var files = Directory.EnumerateFiles(location, "*.*").Where(f => allowedExtensions.ToList().Contains(Path.GetExtension(f))).ToList();

            foreach (var fname in files)
            {
                FileInfo f = new FileInfo(fname);

                #region Environment ITSDEV1

                if (env.ToLower().Equals("itsdev1"))
                {
                    File.AppendAllText(LogFile, $"\nFile Name :  {f.Name.ToLower()}");
                    batchMethod = config.BatchConfiguration.Find(x => x.Environment.Equals("itsdev1"));
                    var currentBatch = new BatchList();
                    if (f.Name.ToLower().Contains("_ce_"))
                    {
                        File.AppendAllText(LogFile, $"\nFile identified as Compound Employee file: {f.Name} ");
                        filetype.Add("ce");
                        currentBatch = batchMethod.BatchList.Find(x => x.Name.ToLower().Equals("ce"));
                    }
                    if (f.Name.ToLower().Contains("_employeetime_"))
                    {
                        File.AppendAllText(LogFile, $"\nFile identified as Employee TimeOff file: {f.Name} ");
                        filetype.Add("employeetimeoff");
                        currentBatch = batchMethod.BatchList.Find(x => x.Name.ToLower().Equals("employeetimeoff"));
                    }
                    if (f.Name.ToLower().Contains("_csce_"))
                    {
                        File.AppendAllText(LogFile, $"\nFile identified as Compound employee Country specific file: {f.Name} ");
                        filetype.Add("csce");
                        currentBatch = batchMethod.BatchList.Find(x => x.Name.ToLower().Equals("csce"));
                    }
                    if (f.Name.ToLower().Contains("_background_") || f.Name.ToLower().Contains("_talent_"))
                    {
                        File.AppendAllText(LogFile, $"\nFile identified as Talent file: {f.Name} ");
                        filetype.Add("talent");
                        currentBatch = batchMethod.BatchList.Find(x => x.Name.ToLower().Equals("talent"));
                    }
                    // Check if the file belongs to foundation set
                    if (!f.Name.ToLower().Contains("_ce_") && !f.Name.ToLower().Contains("_csce") && !f.Name.ToLower().Contains("_employeetime_"))
                    {
                        if (FoFileMasks.Any(x => f.Name.Contains(x)))
                        {
                            File.AppendAllText(LogFile, $"\nFile identified as Foundation Object file: {f.Name} ");
                            filetype.Add("fo");
                            currentBatch = batchMethod.BatchList.Find(x => x.Name.ToLower().Equals("fo"));
                        }
                    }
                    string copyfilename = "";
                    bool filecopied = false;
                    try
                    {
                        File.AppendAllText(LogFile, $"\nFile not copied  to : {copyfilename} ");
                        copyfilename = $@"{currentBatch.FileLocation}\{f.Name}";
                        if (File.Exists(copyfilename)) { File.Delete(copyfilename); }
                        File.AppendAllText(LogFile, $"\nFile Selected : {f.Name} ");
                        File.AppendAllText(LogFile, $"\nFile Copying to  : {copyfilename} ");
                        File.Copy(fname, copyfilename);
                        filecopied = true;
                    }
                    catch (Exception)
                    {
                        File.AppendAllText(LogFile, $"\nFile not copied  to : {copyfilename} ");
                        filecopied = false;
                    }
                    if (filecopied)
                    {
                        //Deleting the file from the server to remove the batch run
                        File.Delete(fname);
                    }
                }
                #endregion

                #region Environment UAT1

                if (env.ToLower().Equals("uat1"))
                {
                    batchMethod = config.BatchConfiguration.Find(x => x.Environment.Equals("uat1"));

                    //var content = File.ReadAllText(fname).ToLower();

                    if (f.Name.Contains("_ce_"))
                    {
                        filetype.Add("ce");
                    }
                    if (f.Name.Contains("csce"))
                    {
                        filetype.Add("csce");
                    }
                    if (f.Name.Contains("talent"))
                    {
                        filetype.Add("talent");
                    }
                    if (f.Name.Contains("fo"))
                    {
                        filetype.Add("fo");
                    }
                    if (f.Name.Contains("employeetimeoff"))
                    {
                        filetype.Add("employeetimeoff");
                    }
                    if (!f.Name.Contains("_ce_") && !f.Name.Contains("_csce_"))
                    {
                        if (FoFileMasks.Any(x => f.Name.Contains(x)))
                        {
                            filetype.Add("fo");
                        }
                    }
                    File.Delete(fname);
                }

                #endregion
            }

            if (filetype.Count == 0)
                Console.WriteLine("transfer type not specified!");

            return filetype;
        }


        public static List<string> CopyFileLoadFolder { get { return new List<string>(); } }

        private static string ErrorFile { get; set; }
        private static string LogFile { get; set; }
        private static void ExecuteBatch(List<string> filetype)
        {
            foreach (var runtype in filetype.Distinct())
            {
                switch (runtype.ToLower())
                {
                    case "employeetimeoff": RunEmployeeTimeOffDataLoad(); break;
                    case "talent": RunTalentDataLoad(); break;
                    case "ce": RunEmployeeDataLoad(); break;
                    case "csce": RunCountrySpecificDataLoad(); break;
                    case "fo": RunFoundationDataLoad(); break;
                    case "test": RunTest(); break;
                }
            }
        }

        private static void ExecuteBatch(string type, string fileLocation)
        {
            try
            {
                var f = new Process()
                {
                    StartInfo = new ProcessStartInfo
                    {
                        FileName = fileLocation,
                        UseShellExecute = false,
                        RedirectStandardOutput = true
                    }
                };
                File.AppendAllText(LogFile, $"Running the batch : {f.StartInfo.FileName}");
                f.Start();
                Console.WriteLine($"\nKey : {type}\nProcess Started --> {f.StartInfo.FileName}");
                if (!f.HasExited)
                {
                    var output = f.StandardOutput.ReadToEnd();
                    File.AppendAllText(LogFile, output, Encoding.Default);
                }
                f.WaitForExit();
                Console.WriteLine($@"\nProcess Completed, View log in '.\Log\{LogFile}'");
            }
            catch (Exception e)
            {
                File.AppendAllText(ErrorFile, $"Message : {e.Message} | Batch Name : {fileLocation} \nStackTrace : {e.StackTrace}", Encoding.Default);
                Console.WriteLine($"Message : {e.Message}\nStackTrace : {e.StackTrace}");
            }
        }

        private static void Main(string[] args)
        {
            var path = $@"{DirectoryPath}\Log";
            if (!Directory.Exists(path)) Directory.CreateDirectory(path);
            LogFile = $@"{DirectoryPath}\Log\Log_{DateTime.Now: yyyy_MM_dd}.txt";
            ErrorFile = $@"{DirectoryPath}\Log\Error_{DateTime.Now: yyyy_MM_dd}.txt";
            File.AppendAllText(LogFile, $"\n{DateTime.Now:t} Starting the job...");
            ExecuteBatch(GetFileNames());
            File.AppendAllText(LogFile, $"\n{DateTime.Now:t} Completed...");
        }
        private static void RunCountrySpecificDataLoad()
        {
            var s = batchMethod.BatchList.Find(x => x.Name.ToLower().Equals("csce"));
            foreach (var batchName in s.Batches)
            {
                ExecuteBatch("csce", batchName.BatchBatch);
            }
        }

        private static void RunEmployeeDataLoad()
        {
            var s = batchMethod.BatchList.Find(x => x.Name.ToLower().Equals("ce"));
            foreach (var batchName in s.Batches)
            {
                ExecuteBatch("ce", batchName.BatchBatch);
            }
        }

        private static void RunEmployeeTimeOffDataLoad()
        {
            var s = batchMethod.BatchList.Find(x => x.Name.ToLower().Equals("employeetimeoff"));
            foreach (var batchName in s.Batches)
            {
                ExecuteBatch("employeetimeoff", batchName.BatchBatch);
            }
        }

        private static void RunTalentDataLoad()
        {
            var s = batchMethod.BatchList.Find(x => x.Name.ToLower().Equals("talent"));
            foreach (var batchName in s.Batches)
            {
                ExecuteBatch("talent", batchName.BatchBatch);
            }
        }

        private static void RunFoundationDataLoad()
        {
            var s = batchMethod.BatchList.Find(x => x.Name.ToLower().Equals("fo"));
            foreach (var batchName in s.Batches)
            {
                ExecuteBatch("fo", batchName.BatchBatch);
            }
        }

        private static void RunTest()
        {
            var s = batchMethod.BatchList.Find(x => x.Name.ToLower().Equals("test"));
            foreach (var batchName in s.Batches)
            {
                ExecuteBatch("test", batchName.BatchBatch);
            }
        }
    }
}

/*
 
        private static List<string> tCopyFileLoadFolder
        {
            get
            {
                var location = ConfigurationManager.AppSettings["filewatcherllocation"];
                List<string> filetype = new List<string>();
                var files = Directory.EnumerateFiles(location, "*.*").Where(f => f.EndsWith(".pgp", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".xml", StringComparison.OrdinalIgnoreCase)).ToList();

                foreach (var file in files)
                {
                    //check name and move to folder
                    FileInfo f = new FileInfo(file);
                    File.AppendAllText(LogFile, $"\nFile : {f.Name} ");
                    bool filecopied = false;
                    BatchList currentBatch = new BatchList();
                    string copyfilename = "";

                    if (f.Name.ToLower().Contains("_ce_"))
                    {
                        filetype.Add("ce");
                        currentBatch = config.BatchList.Find(x => x.Name.ToLower().Equals("ce"));
                    }
                    if (f.Name.ToLower().Contains("_employeetime_"))
                    {
                        filetype.Add("employeetimeoff");
                        currentBatch = config.BatchList.Find(x => x.Name.ToLower().Equals("employeetimeoff"));
                    }
                    if (f.Name.ToLower().Contains("_csce_"))
                    {
                        filetype.Add("csce");
                        currentBatch = config.BatchList.Find(x => x.Name.ToLower().Equals("csce"));
                    }
                    if (f.Name.ToLower().Contains("_fo_"))
                    {
                        filetype.Add("fo");
                        currentBatch = config.BatchList.Find(x => x.Name.ToLower().Equals("fo"));
                    }
                    if (f.Name.ToLower().Contains("_background_") || f.Name.ToLower().Contains("_talent_"))
                    {
                        filetype.Add("talent");
                        currentBatch = config.BatchList.Find(x => x.Name.ToLower().Equals("talent"));
                    }

                    try
                    {
                        copyfilename = $@"{currentBatch.FileLocation}\{f.Name}";
                        if (File.Exists(copyfilename)) { File.Delete(copyfilename); }
                        File.AppendAllText(LogFile, $"\nFile Selected : {f.Name} ");
                        File.AppendAllText(LogFile, $"\nFile Copying to  : {copyfilename} ");
                        File.Copy(file, copyfilename);
                        filecopied = true;
                    }
                    catch (Exception)
                    {
                        File.AppendAllText(LogFile, $"\nFile not copied  to : {copyfilename} ");
                        filecopied = false;
                    }

                    if (filecopied)
                    {
                        //Deleting the file from the server to remove the batch run
                        File.Delete(file);
                    }
                }
                return filetype;
            }
        }
 */