# ---------------------------------------------------------------------------------------------------- #
# This Script has a precondition the target server required to be added to the trust zone of the this 
#  client system in order to connect to the remote system.
# 
# Script to invoke the remote system and perform the data load operation
# ---------------------------------------------------------------------------------------------------- #
#$Username = $args[0] #username from the commandline arguments to connect the remote server
#$Password = $args[1] #password from the commandline arguments to connect the remote server
$Username = 'EYUA\U.EC-TDDH-1'
$Password = 'uyas8fbrDvRhZq'
$pass = ConvertTo-SecureString -AsPlainText $Password -Force
$SecureString = $pass

# ---------------------------------------------------------------------------------------------------- #
# Creating the server credentials for login
# ---------------------------------------------------------------------------------------------------- #
$MySecureCreds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Username,$SecureString 
$mypssession = New-PSSession -ComputerName DEFRNVMUSYMSQ11.eyua.net -Credential $MySecureCreds
#Enter-PSSession -ComputerName DEFRNVMUSYMSQ11.eyua.net -Credential $MySecureCreds

# ---------------------------------------------------------------------------------------------------- #
# Load the file info to the staging tables
# ---------------------------------------------------------------------------------------------------- #
Invoke-Command -Session $mypssession -ScriptBlock { Set-Location H:\EC\TDDH_QA\EC }
#Invoke-Command -Session $mypssession -ScriptBlock { H:\EC\TDDH_QA\EC\CE_StageTruncation.bat }
#Invoke-Command -Session $mypssession -ScriptBlock { H:\EC\TDDH_QA\EC\CE_StgFullLoad.bat }
#Invoke-Command -Session $mypssession -ScriptBlock { H:\EC\TDDH_QA\EC\TimeOff_FullLoad.bat }
#Invoke-Command -Session $mypssession -ScriptBlock { H:\EC\TDDH_QA\EC\CE_FullLoad.bat }
#Invoke-Command -Session $mypssession -ScriptBlock { H:\EC\TDDH_QA\PostECProcess\Pkg_PostECProcess.bat }
#Invoke-Command -Session $mypssession -ScriptBlock { Exit }
