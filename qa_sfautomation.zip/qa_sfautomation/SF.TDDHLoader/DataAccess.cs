﻿using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;

namespace ExecuteQABatch
{
    internal class DataAccess
    {
        public static List<string> GetFOFileMask(string environment)
        {
            List<string> list = new List<string>();
            string connectionString = environment.ToLower().Equals("itsdev1") ? ConfigurationManager.ConnectionStrings["QA"].ToString() : ConfigurationManager.ConnectionStrings["UAT1"].ToString();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand cmd = new SqlCommand("select distinct filemask from dbo.fofilesconfiguration", connection);
                SqlDataReader dataReader = cmd.ExecuteReader();
                while (dataReader.Read())
                {
                    list.Add(dataReader.GetString(0));
                }
                dataReader.Close();
            }
            return list;
        }
    }
}
