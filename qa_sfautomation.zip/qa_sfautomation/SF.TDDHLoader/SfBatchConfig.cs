﻿namespace SF.Batch
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using System.Collections.Generic;
    using System.Globalization;

    public partial class SfBatchConfig
    {
        [JsonProperty("BatchConfiguration", NullValueHandling = NullValueHandling.Ignore)]
        public List<BatchConfiguration> BatchConfiguration { get; set; }
    }

    public partial class BatchConfiguration
    {
        [JsonProperty("Environment", NullValueHandling = NullValueHandling.Ignore)]
        public string Environment { get; set; }

        [JsonProperty("BatchList", NullValueHandling = NullValueHandling.Ignore)]
        public List<BatchList> BatchList { get; set; }
    }

    public partial class BatchList
    {
        [JsonProperty("Name", NullValueHandling = NullValueHandling.Ignore)]
        public string Name { get; set; }

        [JsonProperty("FileLocation", NullValueHandling = NullValueHandling.Ignore)]
        public string FileLocation { get; set; }

        [JsonProperty("Batches", NullValueHandling = NullValueHandling.Ignore)]
        public List<Batch> Batches { get; set; }
    }

    public partial class Batch
    {
        [JsonProperty("Batch", NullValueHandling = NullValueHandling.Ignore)]
        public string BatchBatch { get; set; }
    }

    public partial class SfBatchConfig
    {
        public static SfBatchConfig FromJson(string json) => JsonConvert.DeserializeObject<SfBatchConfig>(json, SF.Batch.Converter.Settings);
    }

    public static class Serialize
    {
        public static string ToJson(this SfBatchConfig self) => JsonConvert.SerializeObject(self, SF.Batch.Converter.Settings);
    }

    public static class Converter
    {
        public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
        {
            MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
            DateParseHandling = DateParseHandling.None,
            Converters =
            {
                new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
            },
        };
    }
}