﻿namespace SF.Entity.Person
{
    using Newtonsoft.Json;
    public partial class Address
    {
        [JsonProperty("__metadata", NullValueHandling = NullValueHandling.Ignore)]
        public Metadata Metadata { get; set; }

        [JsonProperty("addressType", NullValueHandling = NullValueHandling.Ignore)]
        public string AddressType { get; set; }

        [JsonProperty("personIdExternal", NullValueHandling = NullValueHandling.Ignore)]
        [JsonConverter(typeof(Common.ParseStringConverter))]
        public long? PersonIdExternal { get; set; }

        [JsonProperty("startDate", NullValueHandling = NullValueHandling.Ignore)]
        public string StartDate { get; set; }

        [JsonProperty("country", NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; }

        [JsonProperty("zipCode", NullValueHandling = NullValueHandling.Ignore)]
        public string ZipCode { get; set; }

        [JsonProperty("lastModifiedDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public string LastModifiedDateTime { get; set; }

        [JsonProperty("notes", NullValueHandling = NullValueHandling.Ignore)]
        public object Notes { get; set; }

        [JsonProperty("endDate", NullValueHandling = NullValueHandling.Ignore)]
        public string EndDate { get; set; }

        [JsonProperty("county", NullValueHandling = NullValueHandling.Ignore)]
        public object County { get; set; }

        [JsonProperty("createdDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public string CreatedDateTime { get; set; }

        [JsonProperty("province", NullValueHandling = NullValueHandling.Ignore)]
        public object Province { get; set; }

        [JsonProperty("address5", NullValueHandling = NullValueHandling.Ignore)]
        public object Address5 { get; set; }

        [JsonProperty("address4", NullValueHandling = NullValueHandling.Ignore)]
        public object Address4 { get; set; }

        [JsonProperty("attachmentId", NullValueHandling = NullValueHandling.Ignore)]
        public object AttachmentId { get; set; }

        [JsonProperty("state", NullValueHandling = NullValueHandling.Ignore)]
        public object State { get; set; }

        [JsonProperty("address8", NullValueHandling = NullValueHandling.Ignore)]
        public object Address8 { get; set; }

        [JsonProperty("address10", NullValueHandling = NullValueHandling.Ignore)]
        public object Address10 { get; set; }

        [JsonProperty("customLong1", NullValueHandling = NullValueHandling.Ignore)]
        public object CustomLong1 { get; set; }

        [JsonProperty("city", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        [JsonProperty("createdOn", NullValueHandling = NullValueHandling.Ignore)]
        public string CreatedOn { get; set; }

        [JsonProperty("empUsersSysId", NullValueHandling = NullValueHandling.Ignore)]
        public object EmpUsersSysId { get; set; }

        [JsonProperty("address3", NullValueHandling = NullValueHandling.Ignore)]
        public object Address3 { get; set; }

        [JsonProperty("address2", NullValueHandling = NullValueHandling.Ignore)]
        public string Address2 { get; set; }

        [JsonProperty("address1", NullValueHandling = NullValueHandling.Ignore)]
        public string Address1 { get; set; }

        [JsonProperty("lastModifiedBy", NullValueHandling = NullValueHandling.Ignore)]
        public string LastModifiedBy { get; set; }

        [JsonProperty("customString5", NullValueHandling = NullValueHandling.Ignore)]
        public object CustomString5 { get; set; }

        [JsonProperty("customString10", NullValueHandling = NullValueHandling.Ignore)]
        public object CustomString10 { get; set; }

        [JsonProperty("customString4", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomString4 { get; set; }

        [JsonProperty("customString11", NullValueHandling = NullValueHandling.Ignore)]
        public object CustomString11 { get; set; }

        [JsonProperty("customString3", NullValueHandling = NullValueHandling.Ignore)]
        public object CustomString3 { get; set; }

        [JsonProperty("customString2", NullValueHandling = NullValueHandling.Ignore)]
        public object CustomString2 { get; set; }

        [JsonProperty("customString9", NullValueHandling = NullValueHandling.Ignore)]
        public object CustomString9 { get; set; }

        [JsonProperty("customString8", NullValueHandling = NullValueHandling.Ignore)]
        public object CustomString8 { get; set; }

        [JsonProperty("customString7", NullValueHandling = NullValueHandling.Ignore)]
        public object CustomString7 { get; set; }

        [JsonProperty("customString6", NullValueHandling = NullValueHandling.Ignore)]
        public object CustomString6 { get; set; }

        [JsonProperty("lastModifiedOn", NullValueHandling = NullValueHandling.Ignore)]
        public string LastModifiedOn { get; set; }

        [JsonProperty("customString1", NullValueHandling = NullValueHandling.Ignore)]
        public object CustomString1 { get; set; }

        [JsonProperty("createdBy", NullValueHandling = NullValueHandling.Ignore)]
        public string CreatedBy { get; set; }
    }
}
