﻿namespace SF.Entity.Bank
{
    using Newtonsoft.Json;
    public class Bank
    {
        [JsonProperty("__metadata", NullValueHandling = NullValueHandling.Ignore)]
        public Metadata Metadata { get; set; }

        [JsonProperty("externalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalCode { get; set; }

        [JsonProperty("cust_BankID", NullValueHandling = NullValueHandling.Ignore)]
        public string CustBankId { get; set; }

        [JsonProperty("lastModifiedDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public string LastModifiedDateTime { get; set; }

        [JsonProperty("bankBranch", NullValueHandling = NullValueHandling.Ignore)]
        public object BankBranch { get; set; }

        [JsonProperty("city", NullValueHandling = NullValueHandling.Ignore)]
        public string City { get; set; }

        [JsonProperty("lastModifiedBy", NullValueHandling = NullValueHandling.Ignore)]
        public string LastModifiedBy { get; set; }

        [JsonProperty("postalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string PostalCode { get; set; }

        [JsonProperty("createdDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public string CreatedDateTime { get; set; }

        [JsonProperty("bankName", NullValueHandling = NullValueHandling.Ignore)]
        public string BankName { get; set; }

        [JsonProperty("mdfSystemRecordStatus", NullValueHandling = NullValueHandling.Ignore)]
        public string MdfSystemRecordStatus { get; set; }

        [JsonProperty("bankCountry", NullValueHandling = NullValueHandling.Ignore)]
        public string BankCountry { get; set; }

        [JsonProperty("effectiveStatus", NullValueHandling = NullValueHandling.Ignore)]
        public string EffectiveStatus { get; set; }

        [JsonProperty("routingNumber", NullValueHandling = NullValueHandling.Ignore)]
        public string RoutingNumber { get; set; }

        [JsonProperty("createdBy", NullValueHandling = NullValueHandling.Ignore)]
        public string CreatedBy { get; set; }

        [JsonProperty("street", NullValueHandling = NullValueHandling.Ignore)]
        public string Street { get; set; }

        [JsonProperty("businessIdentifierCode", NullValueHandling = NullValueHandling.Ignore)]
        public object BusinessIdentifierCode { get; set; }
    }
    public class PayTypeAssignment
    {
        [JsonProperty("externalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalCode { get; set; }

        [JsonProperty("CustomPayType_externalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string CustomPayTypeExternalCode { get; set; }

        [JsonProperty("country", NullValueHandling = NullValueHandling.Ignore)]
        public string Country { get; set; }

        [JsonProperty("lastModifiedDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public string LastModifiedDateTime { get; set; }

        [JsonProperty("lastModifiedBy", NullValueHandling = NullValueHandling.Ignore)]
        public string LastModifiedBy { get; set; }

        [JsonProperty("createdDateTime", NullValueHandling = NullValueHandling.Ignore)]
        public string CreatedDateTime { get; set; }

        [JsonProperty("mdfSystemRecordStatus", NullValueHandling = NullValueHandling.Ignore)]
        public string MdfSystemRecordStatus { get; set; }

        [JsonProperty("createdBy", NullValueHandling = NullValueHandling.Ignore)]
        public string CreatedBy { get; set; }
    }

    public class PayType
    {
        [JsonProperty("externalCode", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalCode { get; set; }

        [JsonProperty("externalName_defaultValue", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameDefaultValue { get; set; }

        [JsonProperty("externalName_es_MX", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameEsMx { get; set; }

        [JsonProperty("externalName_fr_CA", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameFrCa { get; set; }

        [JsonProperty("externalName_zh_TW", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameZhTw { get; set; }

        [JsonProperty("externalName_ja_JP", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameJaJp { get; set; }

        [JsonProperty("externalName_pt_BR", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNamePtBr { get; set; }

        [JsonProperty("externalName_iw_IL", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameIwIl { get; set; }

        [JsonProperty("externalName_zh_CN", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameZhCn { get; set; }

        [JsonProperty("standardPayType", NullValueHandling = NullValueHandling.Ignore)]
        public string StandardPayType { get; set; }

        [JsonProperty("externalName_localized", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameLocalized { get; set; }

        [JsonProperty("mdfSystemRecordStatus", NullValueHandling = NullValueHandling.Ignore)]
        public string MdfSystemRecordStatus { get; set; }

        [JsonProperty("externalName_fr_FR", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameFrFr { get; set; }

        [JsonProperty("externalName_de_DE", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameDeDe { get; set; }

        [JsonProperty("externalName_ko_KR", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameKoKr { get; set; }

        [JsonProperty("externalName_en_US", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameEnUs { get; set; }

        [JsonProperty("externalName_en_GB", NullValueHandling = NullValueHandling.Ignore)]
        public string ExternalNameEnGb { get; set; }
    }
}
