﻿namespace SF.Entity.Employment
{
    using System;
    public class Employment
    {
        public string personIdExternal { get; set; }
        public string userId { get; set; }
        public bool isContingentWorker { get; set; }
        public string assignmentIdExternal { get; set; }
        public bool hiringNotCompleted { get; set; }
        public bool isECRecord { get; set; }
        public string customString20 { get; set; }
        public bool customString23 { get; set; }
        public string createdOn { get; set; }
        public bool customString17 { get; set; }
        public string customString18 { get; set; }
        public bool customString19 { get; set; }
        public string assignmentClass { get; set; }
        public bool customString5 { get; set; }
        public bool customString2 { get; set; }
        public bool customString6 { get; set; }
        public DateTime serviceDate { get; set; }
        public DateTime endDate { get; set; }
        public DateTime bonusPayExpirationDate { get; set; }
        public DateTime createdDateTime { get; set; }
        public DateTime professionalServiceDate { get; set; }
        public DateTime salaryEndDate { get; set; }
        public DateTime seniorityDate { get; set; }
        public DateTime startDate { get; set; }
        public DateTime customDate22 { get; set; }
        public DateTime customDate21 { get; set; }
        public DateTime lastDateWorked { get; set; }
        public DateTime customDate7 { get; set; }
        public DateTime customDate8 { get; set; }
        public DateTime originalStartDate { get; set; }
        public DateTime payrollEndDate { get; set; }
        public DateTime benefitsEligibilityStartDate { get; set; }
        public DateTime customDate1 { get; set; }
        public DateTime customDate2 { get; set; }
        public DateTime customDate3 { get; set; }
        public DateTime customDate4 { get; set; }
        public DateTime customDate5 { get; set; }
        public DateTime customDate6 { get; set; }
        public DateTime benefitsEndDate { get; set; }

        public PersonInfo PersonInfo { get; set; }
    }
}
