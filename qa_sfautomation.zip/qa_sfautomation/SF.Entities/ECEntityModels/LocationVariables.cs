﻿namespace SF.Entity
{
    public class Locationvariables
    {
        public string country { get; set; }
        public string legalentityid { get; set; }
        public string externalCode { get; set; }
        public string description { get; set; }
        public string geozone { get; set; }
        public string geographicareaid { get; set; }
        public string geographicregionid { get; set; }
    }
}
