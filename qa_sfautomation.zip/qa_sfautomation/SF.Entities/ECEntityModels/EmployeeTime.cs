﻿namespace SF.Entity.EmployeeTimeOff
{
    using Newtonsoft.Json;
    using SF.Entity.Common;
    public class EmployeeTime
    {
        [JsonProperty("__metadata")]
        public Metadata Metadata { get; set; }

        [JsonProperty("endDate")]
        public string EndDate { get; set; }

        [JsonProperty("loaActualReturnDate")]
        public object LoaActualReturnDate { get; set; }

        [JsonProperty("timeType")]
        public string TimeType { get; set; }

        [JsonProperty("loaExpectedReturnDate")]
        public string LoaExpectedReturnDate { get; set; }

        [JsonProperty("startDate")]
        public string StartDate { get; set; }

        [JsonProperty("userId")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long UserId { get; set; }
    }
}
