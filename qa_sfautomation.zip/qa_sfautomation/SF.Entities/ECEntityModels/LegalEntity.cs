﻿namespace SF.Entity
{
    public class LegalEntity
    {
        public string externalCode { get; set; }
        public string description_defaultValue { get; set; }
    }
}
