﻿namespace SF.Entity.Common
{
    public class DateConvert
    {
        /// <summary>
        /// This will return the corresponding time in epoch seconds
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>

    }
}
