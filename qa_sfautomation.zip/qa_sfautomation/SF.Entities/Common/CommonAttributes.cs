﻿namespace SF.Entity
{
    using Newtonsoft.Json;
    using System;
    public partial class Metadata
    {
        [JsonProperty("uri")]
        public string Uri { get; set; }

        [JsonProperty("type", NullValueHandling = NullValueHandling.Ignore)]
        public string Type { get; set; }
    }
    public partial class Nav
    {
        [JsonProperty("__deferred")]
        public Deferred Deferred { get; set; }
    }

    public partial class Deferred
    {
        [JsonProperty("uri")]
        public Uri Uri { get; set; }
    }
}
