﻿namespace SF.EC
{
    public interface IECFunctions<T> where T : class
    {
        static void Create(T ecdata) { }
        static void Validate(T ecdata) { }
    }
}
