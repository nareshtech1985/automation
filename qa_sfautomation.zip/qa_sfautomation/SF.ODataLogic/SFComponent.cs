﻿namespace SF.ODataLogic
{
    using SF.Entity.Common;
    using System;
    using System.IO;
    using System.Reflection;

    public class SFComponent
    {
        public static string DirectoryPath => Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

        protected static string upsertMessage = "Upsert Call Success";
        public static string ToJsonDate(DateTime dateTime) => $"/Date({DateConvert.ToEpochTime(dateTime)})/";
    }
}
