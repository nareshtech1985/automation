﻿namespace SF.ODataLogic
{
    using RestSharp;
    using System;
    using System.IO;
    using System.Net;
    using System.Reflection;

    public class CpiApi : API
    {   
        public static string Apiauth { get; set; }

        public static void PostCall(string URI)
        {
            var serviceurl = "";
            if (URI.Equals(string.Empty))
            {
                serviceurl = "https://e2133-iflmap.hcisbt.eu1.hana.ondemand.com/cxf/cm_EmpData_EmpInfoMCPD_ITS";
            }
            else
            {
                serviceurl = $"https://e2133-iflmap.hcisbt.eu1.hana.ondemand.com/cxf{URI}";
            }

            string seednumber = $"QA{ new Random().Next(99999)}";
            Console.WriteLine($"Seed Number for CPI Api Call : {seednumber} ");
            var xmlbody = $"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:dis=\"http://camel.apache.org/cxf/jaxws/dispatch\"> <soapenv:Header/> <soapenv:Body> <dis:InvokeOneWay>{seednumber}</dis:InvokeOneWay> </soapenv:Body> </soapenv:Envelope>";

            var client = new RestClient(serviceurl);
            var request = new RestRequest(Method.POST);
            request.AddHeader("Authorization", Apiauth);
            request.AddHeader("X-Requested-With", "RestSharp");
            request.AddParameter("application/xml", xmlbody, ParameterType.RequestBody);
            request.RequestFormat = DataFormat.Xml;

            IRestResponse respone = client.Execute(request);
            if (respone.StatusCode == HttpStatusCode.OK || respone.StatusCode == HttpStatusCode.Accepted)
            {
                UpdateLog(URI, xmlbody, "API Call Success!","POST","CPI");
            }
            else
            {
                UpdateLog(URI, xmlbody, $"API Call Failed with message : {respone.Content}", "POST", "CPI");
            }

        }        
    }
}
