﻿namespace SF.ODataLogic
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using RestSharp;
    using System;
    using System.IO;
    using System.Net;

    public class SFApi : API
    {
        public static string Apiauth { get; set; }

        public static dynamic GET(string Uri)
        {

            var uri = $"https://api12preview.sapsf.eu/odata/v2/{Uri}";
            Console.WriteLine($"Calling the api via URI: {uri}");
            var client = new RestClient(uri)
            {
                Timeout = -1
            };
            var request = new RestRequest(Method.GET);
            request.AddHeader("Accept", "*/*");
            request.AddHeader("Accept-Encoding", "gzip, deflate, br");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("Authorization", Apiauth);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "JSESSIONID=3F7F64602310ED8642B0CC0C2C549D31.mo-e4dcb1b64");
            IRestResponse response = client.Execute(request);
            var jsonContent = JObject.Parse(response.Content);
            dynamic seriliazedString = JsonConvert.DeserializeObject(jsonContent["d"].ToString(), Type.GetType("null"));

            UpdateLog(uri, response.Content, "API Call Success!", "GET", "SF");

            return seriliazedString;
        }

        public static string UPSERT(string jsoncontent)
        {
            string response = "Failed";
            var uri = "https://api12preview.sapsf.eu/odata/v2/upsert?$format=json";
            var client = new RestClient(uri);
            var request = new RestRequest(Method.POST);
            request.AddHeader("Authorization", Apiauth);
            request.AddParameter("application/json; charset=utf-8", jsoncontent, ParameterType.RequestBody);
            request.RequestFormat = DataFormat.Json;
            try
            {
                IRestResponse respone = client.Execute(request);
                if (respone.StatusCode == HttpStatusCode.OK)
                {
                    dynamic seriliazedString = JsonConvert.DeserializeObject(JObject.Parse(respone.Content)["d"].ToString());
                    var status = seriliazedString[0].status.Value;
                    if (status == "ERROR")
                    {
                        UpdateLog(uri, respone.Content, "API Call Failed!", "POST", "SF");
                    }
                    else if (status == "OK")
                    {
                        UpdateLog(uri, request.Body!=null ? request.Body.ToString(): seriliazedString[0], "API Call Success!", "POST", "SF");
                        response = "Upsert Call Success";
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                UpdateLog(uri, e.Message, "API Call Failed!", "POST", "SF");
            }
            return response;
        }
    }

    public enum HTTPMethod
    {
        POST,
        GET
    }
}
