﻿namespace SF.ODataLogic
{
    using NUnit.Framework;

    [TestFixture]
    class APITest
    {

    }
}
