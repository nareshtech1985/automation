﻿namespace SF.ODataLogic
{
    using System;
    using System.IO;
    using System.Reflection;
    public class API
    {
        protected static string Root => Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

        protected static void UpdateLog(string URI, string body, string message,string http,string apitype)
        {
            using (StreamWriter e = new StreamWriter(new FileStream($@"{ Root }\API_CAllS\{apitype}_{http}_CALL_{ DateTime.Now:dd MM yyyy hh mm ss}.txt", FileMode.OpenOrCreate)))
            {
                e.WriteLine($"Request URI : {URI}");
                e.WriteLine($"Request Body\n{body}");
                e.WriteLine(message);
            }
            Console.WriteLine(message);
        }
    }
}