﻿namespace SF.ODataLogic.Generic
{
    interface ILogic
    {
        void ReadTestData(string sheetname);
    }
}
