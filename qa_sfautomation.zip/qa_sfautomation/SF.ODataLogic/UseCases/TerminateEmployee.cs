﻿namespace SF.ODataLogic
{
    using Newtonsoft.Json;
    using SF.Parameter;
    using SpreadsheetLight;
    using System;
    using System.Collections.Generic;

    public class TerminateEmployee : SFComponent
    {
        public static IList<TerminateParameter> parameters;
        public static void ReadTestData(string sheetName)
        {
            parameters = new List<TerminateParameter>();
            using (SLDocument doc = new SLDocument($@"{DirectoryPath}\Data\DataSheet.xlsx"))
            {
                doc.SelectWorksheet(sheetName);

                var prop = doc.GetWorksheetStatistics();
                for (int i = 2; i <= prop.EndRowIndex; i++)
                {
                    parameters.Add(new TerminateParameter()
                    {
                        personIdExternal = doc.GetCellValueAsString($"A{i}"),
                        userId = doc.GetCellValueAsString($"B{i}"),
                        startDate = doc.GetCellValueAsDateTime($"C{i}"),
                        eventReason = doc.GetCellValueAsString($"D{i}")
                    });
                }
            }
        }
        /// <summary>
        /// This will terminate the employee
        /// </summary>
        /// <param name="parameter"></param>
        public static void UPSERT(TerminateParameter parameter)
        {
            var terminate = new
            {
                __metadata = new Entity.Metadata()
                {
                    Uri = $@"EmpEmploymentTermination"
                },
                eventReason = GetEventReason(parameter),
                parameter.personIdExternal,
                endDate=ToJsonDate(parameter.startDate.AddDays(-1)),
                parameter.userId,
                payrollEndDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                lastDateWorked = ToJsonDate(parameter.startDate.AddDays(-1)),
                bonusPayExpirationDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                benefitsEndDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                salaryEndDate = ToJsonDate(parameter.startDate.AddDays(-1)) //to make effective on the given end date 
            };
            var body = JsonConvert.SerializeObject(terminate);
            SFApi.UPSERT(body);
        }


        public static TerminateParameter GetEmployeeStatus(TerminateParameter parameters)
        {
            string empJob = $@"EmpJob?$filter=userId eq '{parameters.userId}'&$select=startDate,eventReason,emplStatus,userId&$format=json&toDate={parameters.startDate.AddDays(365):yyyy-MM-dd}&$sort=startDate desc&$top=1";
            var response = SFApi.GET(empJob).results[0];

            return new TerminateParameter()
            {
                userId = response.userId,
                startDate = response.startDate,
                emplStatus = response.emplStatus,
                eventReason = response.eventReason
            };

        }

        public static string GetEventReason(TerminateParameter parameter)
        {
            var str = $"FOEventReason?$format=json&$filter=name eq '{parameter.eventReason}' and  eventNav/externalCode eq '26'&$expand=eventNav&$select=externalCode";
            string eventreason = "TAM";
            try
            {
                eventreason = SFApi.GET(str).results[0].externalCode;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine($"Event reason selected per data {parameter.eventReason} is '{eventreason}' ");
            return eventreason;
        }
    }
}
