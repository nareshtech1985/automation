﻿namespace SF.ODataLogic
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using SF.Entity.Common;
    using SF.Entity.EmployeeTimeOff;
    using SF.Parameter;
    using SpreadsheetLight;
    using System;
    using System.Collections.Generic;
    using System.Text.RegularExpressions;

    /// <summary>
    /// This class is to generate the Leave request for the given employee gui and within the date frame
    /// </summary>
    public class TimeOff : SFComponent
    {
        public static List<TimeOffParameters> parameters;


        public static void ReadTestData(string sheetName)
        {
            parameters = new List<TimeOffParameters>();
            using (SLDocument doc = new SLDocument($@"{DirectoryPath}\Data\DataSheet.xlsx"))
            {
                doc.SelectWorksheet(sheetName);

                var prop = doc.GetWorksheetStatistics();
                for (int i = 2; i <= prop.EndRowIndex; i++)
                {
                    parameters.Add(new TimeOffParameters()
                    {
                        personIdExternal = doc.GetCellValueAsString($"A{i}"),
                        startDate = doc.GetCellValueAsDateTime($"B{i}"),
                        endDate = doc.GetCellValueAsDateTime($"C{i}"),
                        LeaveType = doc.GetCellValueAsString($"D{i}")
                    });
                }
            }
        }

        public static string GeneratePostBodyForLeave(ref TimeOffParameters timeOff)
        {
            long userid = Convert.ToInt64(timeOff.personIdExternal);
            var timeProfile = GetProfile(userid);
            var timeType = GetTimeType(timeOff.LeaveType, timeProfile);
            var guid = $"{Guid.NewGuid():N}";
            timeOff.Guid = guid;
            var paidLeave = new EmployeeTime()
            {
                Metadata = new Entity.Metadata()
                {
                    Uri = $@"https://api12preview.sapsf.eu/odata/v2/EmployeeTime('{guid}')",
                    Type = "SFOData.EmployeeTime"
                },
                UserId = Convert.ToInt64(timeOff.personIdExternal),
                StartDate = $"/Date({DateConvert.ToEpochTime(timeOff.startDate)})/",
                EndDate = $"/Date({DateConvert.ToEpochTime(timeOff.endDate)})/",
                LoaActualReturnDate = null,
                TimeType = timeType,
                LoaExpectedReturnDate = $"/Date({DateConvert.ToEpochTime(timeOff.endDate.AddDays(1))})/"
            };
            
            return JsonConvert.SerializeObject(paidLeave);
        }

        public static string GeneratePostBodyForReturnFromLeave(ref TimeOffParameters timeOff)
        {
            long userid = Convert.ToInt64(timeOff.personIdExternal);
            GetActiveLeaveRequest(ref timeOff);
            var paidleave = new
            {
                __metadata = new Entity.Metadata()
                {
                    Uri = $@"https://api12preview.sapsf.eu/odata/v2/EmployeeTime('{timeOff.Guid}')",
                    Type = "SFOData.EmployeeTime"
                },
                loaActualReturnDate = $"/Date({DateConvert.ToEpochTime(timeOff.endDate.AddDays(1))})/",
            };
            return JsonConvert.SerializeObject(paidleave);
        }

        private static void GetActiveLeaveRequest(ref TimeOffParameters timeOff)
        {
            
            string uri = $@"EmployeeTime?$format=json&$expand=timeTypeNav&$filter=userId eq '{timeOff.personIdExternal}' and approvalStatus eq 'APPROVED' and startswith(timeTypeNav/externalName_defaultValue,'{timeOff.LeaveType}')";
            try
            {
                dynamic timeProfile = SFApi.GET(uri).results[0];
                timeOff.Guid = timeProfile.externalCode.Value;
                timeOff.startDate = timeProfile.startDate.Value;
                timeOff.endDate = timeProfile.endDate.Value;
                timeOff.LeaveTypeCode = timeProfile.timeType.Value;
                timeOff.LeaveDescription = timeProfile.timeTypeNav.externalName_defaultValue.Value;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            //Console.WriteLine($"Reading TimeProfile Value as : {timeProfile}");
            
        }

        public static void ValidateTimeOff(ref TimeOffParameters parameters)
        {
            dynamic response = GET(parameters).results[0];//taking first record only for now
            parameters.LeaveDescription =response.timeTypeNav.externalName_defaultValue.Value;

            var startDate = response.startDate.Value;
            var endDate = response.endDate.Value;
            var status = response.approvalStatus.Value;
            parameters.LeaveDescription = response.timeTypeNav.externalName_defaultValue.Value;
            /*
            Assert.Multiple(()=> {
                Assert.That(parameters.StartDate.Equals(new DateTime()));
            });
            */
        }

        private static string GetProfile(long userid)
        {
            string timeProfile = "";
            string empJob = $@"EmpJob?$filter=userId eq '{userid}'&$select=timeTypeProfileCode&$format=json&$top=1";
            try
            {
                timeProfile = SFApi.GET(empJob).results[0].timeTypeProfileCode.Value;
                //Console.WriteLine(timeProfile);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine($"Reading TimeProfile Value as : {timeProfile}");
            return timeProfile;
        }

        private static string GetTimeType(string leaveType, string timeProfile)
        {
            string timeType = "PDLVOTH";
            string empJob = $@"AvailableTimeType?$format=JSON&$expand=timeTypeNav&$filter=TimeTypeProfile_externalCode eq '{timeProfile}' and startswith(timeTypeNav/externalName_defaultValue,'{leaveType}')&$select=externalCode,timeTypeNav/externalName_defaultValue&";
            try
            {
                var response = SFApi.GET(empJob);
                List<string> selectlist = new List<string>();
                foreach (var robj in response.results)
                {
                    //Console.WriteLine($"Time Type {robj.externalCode} | Descritpion : {robj.timeTypeNav.externalName_defaultValue}");
                    selectlist.Add(robj.externalCode.Value);
                }

                int r = new Random().Next(selectlist.Count);
                timeType = selectlist[r];
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine($"Reading TimeProfile Value as : {timeType}");
            return timeType;
        }

        public static dynamic GET(TimeOffParameters obj)
        {
            string timeoff = $@"EmployeeTime?$filter=externalCode eq '{obj.Guid}'&$format=json&$expand=timeTypeNav";
            var response = SFApi.GET(timeoff);
            return response;
        }

        public static string UPSERT(string body)
        {
            return SFApi.UPSERT(body);
        }
    }


}
