﻿namespace SF.ODataLogic
{
    using Newtonsoft.Json;
    using SF.Parameter;
    using SpreadsheetLight;
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Logic used for class change logic
    /// 
    /// Current logic change the class of employee to ->32733 & type to  --> 61574
    /// 
    /// </summary>
    public class ClassChange : SFComponent
    {
        public static List<ClassChangeParameter> parameters;
        public static void ReadTestData(string sheetName)
        {
            parameters = new List<ClassChangeParameter>();
            using (SLDocument doc = new SLDocument($@"{DirectoryPath}\Data\DataSheet.xlsx"))
            {
                doc.SelectWorksheet(sheetName);

                var prop = doc.GetWorksheetStatistics();
                for (int i = 2; i <= prop.EndRowIndex; i++)
                {
                    parameters.Add(new ClassChangeParameter()
                    {
                        personIdExternal = doc.GetCellValueAsString($"A{i}"),
                        userId = doc.GetCellValueAsString($"B{i}"),
                        startDate = doc.GetCellValueAsDateTime($"C{i}")
                    });
                }
            }
        }

        /// <summary>
        /// For class change perform the soft termination with event reason as 'TAJ'
        /// </summary>
        private static void Step1_Termination(ClassChangeParameter parameter)
        {
            var terminate = new
            {
                Metadata = new Entity.Metadata()
                {
                    Uri = $@"EmpEmploymentTermination"
                },
                eventReason = "TAJ",
                parameter.personIdExternal,
                endDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                parameter.userId,
                payrollEndDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                lastDateWorked = ToJsonDate(parameter.startDate.AddDays(-1)),
                bonusPayExpirationDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                benefitsEndDate = ToJsonDate(parameter.startDate.AddDays(-1)),
                salaryEndDate = ToJsonDate(parameter.startDate.AddDays(-1)) //to make effective on the given end date 
            };
            var body = JsonConvert.SerializeObject(terminate);
            SFApi.UPSERT(body);
        }

        private static void Step2_RehireWithNewClass(ClassChangeParameter parameter)
        {
            var empjob = new
            {
                __metadata = new Entity.Metadata()
                {
                    Uri = $@"EmpJob"
                },
                parameter.userId,
                parameter.startDate,
                eventReason = "RAB",
                employeeClass = "32733",
                employmentType= "61574"
            };
            var body = JsonConvert.SerializeObject(empjob);
            SFApi.UPSERT(body);
        }

        /// <summary>
        /// Terminate and Create the Rehire record with class changes
        /// </summary>
        /// <param name="parameter"></param>
        public static void PerformClassChange(ClassChangeParameter parameter)
        {
            Step1_Termination(parameter);
            Step2_RehireWithNewClass(parameter);
        }

        public static ClassChangeParameter GetEmployeeJobData(ClassChangeParameter item)
        {
            var url = $"EmpJob?$filter=userId eq '{item.userId}'&$format=json&$format=json&$select=userId,startDate,eventReason,employeeClass,employmentType,emplStatus&asofDate={item.startDate:yyyy-MM-dd}";
            var response = SFApi.GET(url).results[0];
            return new ClassChangeParameter()
            {
                userId = response.userId,
                startDate = response.startDate,
                employeeClass = response.emplStatus,
                employmnetType = response.emplStatus,
                eventReason = response.eventReason
            };
        }
    }
}
