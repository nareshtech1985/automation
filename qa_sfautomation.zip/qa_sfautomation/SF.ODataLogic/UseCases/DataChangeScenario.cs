﻿namespace SF.ODataLogic.UseCases
{
    using Newtonsoft.Json;
    using NUnit.Framework;
    using SF.Entity;
    using SF.Entity.Common;
    using SF.Parameter;
    using SpreadsheetLight;
    using System;
    using System.Collections.Generic;

    public class DataChangeScenario : SFComponent
    {
        public static List<DataChangeParameter> parameters;
        public static void ReadTestData(string sheetName)
        {
            parameters = new List<DataChangeParameter>();
            using (SLDocument doc = new SLDocument($@"{DirectoryPath}\Data\DataSheet.xlsx"))
            {
                doc.SelectWorksheet(sheetName);

                var prop = doc.GetWorksheetStatistics();
                for (int i = 2; i <= prop.EndRowIndex; i++)
                {
                    parameters.Add(new DataChangeParameter()
                    {
                        personIdExternal = doc.GetCellValueAsString($"A{i}"),
                        userId = doc.GetCellValueAsString($"B{i}"),
                        startDate = doc.GetCellValueAsDateTime($"C{i}"),
                        departmentid = doc.GetCellValueAsString($"D{i}")
                    });
                }
            }
        }

        public static void PerformDepartmentChange(ref DataChangeParameter parameter)
        {
            var p = parameter;
            string department = p.departmentid.Equals("Choose Random", StringComparison.OrdinalIgnoreCase) ?  GetRandomDepartmentId(ref p).Departmentid : parameter.departmentid;

            var empjob = new
            {
                __metadata = new Metadata()
                {
                    Uri = $@"EmpJob"
                },
                p.userId,
                startDate = DateConvert.ToJsonDate(p.startDate),
                eventReason = "AAS",
                department,
            };

            var body = JsonConvert.SerializeObject(empjob,Formatting.Indented);
            SFApi.UPSERT(body);
            //Assert.That(upsertMessage.Equals(SFApi.UPSERT(body)),$"Data Creation failed for the user {parameter.personIdExternal})");
        }

        private static DeptDataStore GetRandomDepartmentId(ref DataChangeParameter parameter)
        {
            var empjob = $"EmpJob?$format=json&$filter=userId eq '{parameter.userId}'&$select=userId,businessUnit,customString21,company,division,customString3,department&asofDate={parameter.startDate:yyyy-MM-dd}";
            var response = SFApi.GET(empjob).results[0];

            var empjobinfo = new
            {
                response.userId,
                speciality = response.division,
                managementregionid = response.businessUnit,
                managementcountryid = response.customString21,
                legalentityid = response.company,
                subservicelineid = response.customString3,
                currentdepartmentid = response.department
            };

            parameter.departmentid = empjobinfo.currentdepartmentid;
            string speciality = empjobinfo.speciality.Value;

            var deptlist = $"FODepartment?$format=json&$filter=cust_managerialcountry eq '{empjobinfo.managementcountryid}' and cust_tomanagementregion/externalCode eq '{empjobinfo.managementregionid}' and cust_toeylegalentity/externalCode eq '{empjobinfo.legalentityid}' and startswith(cust_speciality,'{speciality.Substring(0,3)}') and cust_toSSL/externalCode eq '{empjobinfo.subservicelineid}' and externalCode ne '{empjobinfo.currentdepartmentid}'&$expand=cust_tomanagementregion,cust_toeylegalentity,cust_toSSL&$select=cust_toeylegalentity/externalCode,cust_toeylegalentity/description_defaultValue,externalCode,description_defaultValue,cust_managerialcountry ,startDate,cust_tomanagementregion/externalCode,cust_tomanagementregion/description_defaultValue,cust_speciality,cust_tomanagementregion/externalCode,cust_tomanagementregionProp,cust_toeylegalentityProp,status,cust_toSSL/externalCode,cust_toSSL/cust_description_defaultValue";

            List<DeptDataStore> deptid = new List<DeptDataStore>();
            dynamic departmentlist = SFApi.GET(deptlist);

            if (departmentlist != null)
            {
                foreach(dynamic dp in departmentlist.results)
                {
                    deptid.Add(new DeptDataStore() { 
                    
                        Departmentid = dp.externalCode,
                        DepartmentDescription = dp.description_defaultValue,
                        LegalEntityId = dp.cust_toeylegalentityProp,
                        LegalEntityDescription = dp.cust_toeylegalentity.description_defaultValue,
                        ManagementRegionId = dp.cust_tomanagementregionProp,
                        ManagementRegionDescription = dp.cust_tomanagementregion.description_defaultValue,
                        ManagerialCountry = dp.cust_managerialcountry,
                        Speciality = dp.cust_speciality,
                        Startdate = dp.startDate,
                        Status = dp.status,
                        SubServiceLine = dp.cust_toSSL.externalCode,
                        SubServiceLineDescription = dp.cust_toSSL.cust_description_defaultValue
                    });
                }

                Console.WriteLine($"Total dept applicable for this user is {deptid.Count}");
                Console.WriteLine($"Choosing a random entry ... ");

                DeptDataStore selectedDeptid = deptid[new Random().Next(deptid.Count)];
                Console.WriteLine($"Applying the following department id '{selectedDeptid.Departmentid}' to the user ");
                return selectedDeptid;
            }
            else
            {
                throw new Exception("No Entries Retrived for this user from the API Call , need manual review ");
            }
        }

        public static void ValidateDataChange(ref DataChangeParameter parameter)
        {
            var empjob = $"EmpJob?$format=json&$filter=userId eq '{parameter.userId}'&$select=userId,startDate,eventReason,businessUnit,customString21,company,division,customString3,department&asofDate={parameter.startDate:yyyy-MM-dd}";
            var response = SFApi.GET(empjob).results[0];

            var empjobinfo = new
            {
                response.userId,
                response.startDate,
                response.eventReason,
                speciality = response.division,
                managementregionid = response.businessUnit,
                managementcountryid = response.customString21,
                legalentityid = response.company,
                subservicelineid = response.customString3,
                currentdepartmentid = response.department
            };

            var dptid = parameter.departmentid;
            var effdt = parameter.startDate;

            try
            {
                Assert.Multiple(() =>
                {
                    Assert.That(!dptid.Equals(empjobinfo.currentdepartmentid), "Department is not changed");
                    //Assert.That(effdt.Equals(empjobinfo.startDate), "Effective Date mismatch");
                    //Assert.That("AAS".Equals(empjobinfo.eventReason), "Event reason not matching");
                });
            }
            catch (Exception)
            {
                Console.WriteLine("Exception f");
            }

            parameter.departmentid = empjobinfo.currentdepartmentid;
        }
    }
}
