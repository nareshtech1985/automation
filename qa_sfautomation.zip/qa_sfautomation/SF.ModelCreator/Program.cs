﻿/// <summary>
/// This program is an experimental script to reduce the FO scripts and to make a generic class and work flow.
/// This is still under development and planning
/// </summary>
namespace SF.ModelCreator
{
    using RestSharp;
    using SF.Model;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Reflection;
    using System.Text.RegularExpressions;
    using System.Xml.Serialization;

    internal class Program
    {
        private static List<string> fonames = new List<string> { "cust_activity_type", "Bank", "cust_BELGIUM_ACTUAL_WEEKLY_HOURS", "cust_Brazilcnpj", "cust_Careerlevel", "cust_codeblock", "FOCorporateAddressDEFLT", "FOCostCenter", "CurrencyExchangeRate", "FODepartment", "cust_establishmentid", "FOEventReason", "FOFrequency", "cust_Geographic_area", "FOLocationGroup", "FOGeozone", "FOJobCode", "cust_jobfamily", "cust_jobfamilygroup", "FOJobFunction", "cust_jobroletype", "FOCompany", "FOLocation", "cust_Region", "FOBusinessUnit", "cust_Management_Unit", "cust_Managerial_Country", "NameFormatGO", "cust_operation_unit", "FOPayComponent", "FOPayComponentGroup", "FOPayGrade", "FOPayGroup", "FOPayRange", "cust_proficiency_level", "cust_rank", "cust_RewardsDiversifier", "cust_ServiceLine", "cust_service_type", "FODivision", "cust_sub_management_unit", "cust_subServiceLine", "WorkSchedule" };

        private static List<string> skipList = new List<string> { "effectiveStartDate", "externalCode", "effectiveStatus", "effectiveStatus", "externalName", "mdfSystemStatus", "description", "name", "startDate", "endDate", "" };

        private static List<string> ignorelist = new List<string> { "createdBy", "createdDateTime", "createdOn", "lastModifiedBy", "lastModifiedDateTime", "lastModifiedOn", "mdfSystemEffectiveEndDate", "mdfSystemRecordStatus" };

        private static List<string> inputIgnoreList = new List<string> { "cust_Description_de_DE", "description_de_DE", "cust_Description_en_GB", "description_en_GB", "cust_Description_en_US", "description_en_US", "cust_Description_es_MX", "description_es_MX", "cust_Description_fr_CA", "description_fr_CA", "cust_Description_fr_FR", "description_fr_FR", "cust_Description_iw_IL", "description_iw_IL", "cust_Description_ja_JP", "description_ja_JP", "cust_Description_ko_KR", "description_ko_KR", "cust_Description_pt_BR", "description_pt_BR", "cust_Description_zh_CN", "description_zh_CN", "cust_Description_zh_TW", "description_zh_TW", "externalName_de_DE", "externalName_en_GB", "externalName_en_US", "externalName_es_MX", "externalName_fr_CA", "externalName_fr_FR", "externalName_iw_IL", "externalName_ja_JP", "externalName_ko_KR", "externalName_pt_BR", "externalName_zh_CN", "externalName_zh_TW", "name_de_DE", "name_en_GB", "name_en_US", "name_es_MX", "name_fr_CA", "name_fr_FR", "name_iw_IL", "name_ja_JP", "name_ko_KR", "name_pt_BR", "name_zh_CN", "name_zh_TW" };

        private static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            List<EntityModel> entities = new List<EntityModel>();
            var fomapdatas = TestData<FOMapping>.Data.ToList();

            //fonames.ForEach(n => entities.AddRange(GETAsync($"https://api12preview.sapsf.eu/odata/v2/{n}/$metadata").ToArray()));
            var directorypath = $@"{DirectoryPath}\FOData";
            if (!Directory.Exists(directorypath)) Directory.CreateDirectory(directorypath);
            //using (SLDocument doc = new SLDocument())
            //{
            //    entities.Select(x => x.ObjectName).Distinct().ToList().ForEach(n =>
            //    {

            //        var fomapdata = fomapdatas.Find(r => r.SfEntityName.Equals(n));
            //        var filename = $@"{directorypath}\{fomapdata.FOObjectClassName}.cs";
            //        doc.AddWorksheet(fomapdata.EnumValues);
            //        int rowcounter = 1, columncounter = 1;
            //        StreamWriter wr = new StreamWriter(File.Create(filename), System.Text.Encoding.UTF8)
            //        {
            //            AutoFlush = true
            //        };
            //        wr.WriteLine($"namespace SF.FOEntities\n{{\n\tusing Parameter;\n\tpublic class {fomapdata.FOObjectClassName} : FO_ObjectBase, IFoundationObject\n\t{{\n");
            //        entities.FindAll(e => e.ObjectName.Equals(n)).ForEach(e1 =>
            //        {
            //            var dictValue = _cleanedNames.First(x => x.Key.ToLower().Equals(e1.FieldName.ToLower()));
            //            if (!skipList.Any(y => y.Trim().ToLower().Equals(e1.FieldName.Trim().ToLower())))
            //            { wr.WriteLine($"\t[ColumnHeader(2,\"{dictValue.Value}\")]\tpublic string {e1.FieldName} {{ get; set; }}"); }

            //            if (!inputIgnoreList.Any(y1 => y1.Trim().ToLower().Equals(e1.FieldName.Trim().ToLower())))
            //            {
            //                doc.SetCellValue(rowcounter, columncounter, dictValue.Value);
            //                if (e1.IsKey)
            //                {
            //                    doc.SetCellStyle(rowcounter, columncounter, new SLStyle() { Font = new SLFont() { Bold = true, FontColor = Color.Red }, Alignment = new SLAlignment() { Horizontal = DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Center, Vertical = DocumentFormat.OpenXml.Spreadsheet.VerticalAlignmentValues.Center } });
            //                }
            //                else
            //                {
            //                    doc.SetCellStyle(rowcounter, columncounter, new SLStyle() { Font = new SLFont() { Bold = true, Italic = true, FontColor = Color.DarkViolet }, Alignment = new SLAlignment() { Horizontal = DocumentFormat.OpenXml.Spreadsheet.HorizontalAlignmentValues.Center, Vertical = DocumentFormat.OpenXml.Spreadsheet.VerticalAlignmentValues.Center } });
            //                }
            //                columncounter++;
            //            }
            //        });
            //        wr.WriteLine($@"}}}}");
            //        wr.Close();
            //        doc.AutoFitColumn(1, columncounter);
            //    });
            //    if (doc.GetWorksheetNames().Any(x => x.ToLower().Equals("sheet1"))) { doc.DeleteWorksheet("Sheet1"); }
            //    doc.SaveAs("Foundation.xlsx");
            //}

            /*
            using (SLDocument doc = new SLDocument())
            {
                int rowcounter = 1, columncounter = 1;
                entities.Select(x => x.ObjectName).Distinct().ToList().ForEach(n =>
                {
                    //var fomapdata = fomapdatas.Find(r => r.SfEntityName.Equals(n));
                    //doc.AddWorksheet(fomapdata.EnumValues);

                    entities.FindAll(e => e.ObjectName.Equals(n)).ForEach(e1 =>
                    {
                        columncounter = 1;
                        doc.SetCellValue(rowcounter, columncounter++, e1.ObjectName);
                        doc.SetCellValue(rowcounter, columncounter++, e1.FieldName);
                        doc.SetCellValue(rowcounter++, columncounter++, e1.IsKey);
                    });
                    doc.AutoFitColumn(1, columncounter);
                });
                //if (doc.GetWorksheetNames().Any(x => x.ToLower().Equals("sheet1"))) { doc.DeleteWorksheet("Sheet1"); }
                doc.SaveAs("ColumnMapper.xlsx");
            }*/

            var filename = "testcase.cs";
            int TCCounter = 47;
            using (StreamWriter wr = new StreamWriter(File.Create(filename), System.Text.Encoding.UTF8))
            {
                wr.AutoFlush = true;
                wr.WriteLine($@"public class Test {{");
                fomapdatas.Select(x => x.EC_Entity_Name).Distinct().ToList().ForEach(n =>
                {
                    var fomapdata = fomapdatas.Find(r => r.EC_Entity_Name.Equals(n));
                    //var dictValue = _cleanedNames.First(x => x.Key.ToLower().Equals(e1.FieldName.ToLower()));
                    wr.WriteLine("[Test,Category(\"Step 03 FO TDDH Validation\")]");
                    wr.WriteLine($"public void TC{TCCounter++:000}_Validate_{fomapdata.TDDH_Table_Name}()");
                    wr.WriteLine("{");
                    wr.WriteLine("    dataaccess = new FODataAccess(Driver);");
                    wr.WriteLine($"    var fo_test_datas = ExcelWorkBook.ReadFoundationData<{fomapdata.FO_Object_ClassName}>(FOType.{fomapdata.Enum_Values.ToLower()});");
                    wr.WriteLine($"    foreach ({fomapdata.FO_Object_ClassName} fo_data in fo_test_datas) {{ dataaccess.Validate_FO_{fomapdata.Enum_Values}(fo_data); }}");
                    wr.WriteLine("}");
                });
                wr.WriteLine($"}}");
            }
            //GETAsync($"https://api12preview.sapsf.eu/odata/v2/NameFormatGO/$metadata");
            //GETAsync($"https://api12preview.sapsf.eu/odata/v2/FOCompany/$metadata");
        }
        private static string DirectoryPath => Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        public static List<EntityModel> GETAsync(string uri)
        {
            List<EntityModel> _entities = new List<EntityModel>();
            Console.WriteLine($"Calling the api via URI: {uri}");
            var client = new RestClient();
            var request = new RestRequest(uri, Method.Get);
            var foname = Regex.Match(uri, @"v2\/([a-zA-Z_]+)\/").Groups[1].Value;
            #region api header
            request.AddHeader("Accept", "*/*");
            request.AddHeader("Accept-Encoding", "gzip, deflate, br");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("Authorization", "Basic MTI1NDQ4MkBFWUlUU0RFVjE6cWEyMDIyKkphbg==");
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Cookie", "JSESSIONID=3F7F64602310ED8642B0CC0C2C549D31.mo-e4dcb1b64");
            #endregion

            try
            {
                DateTime start = DateTime.Now;
                RestResponse response = client.ExecuteAsync(request, Method.Get).Result;
                TimeSpan span = DateTime.Now - start;
                if (response.StatusCode != HttpStatusCode.OK)
                {
                    Console.WriteLine($"Error in calling api, please correct it {response.Content}");
                }
                else
                {
                    //var jsonContent = JObject.Parse(response.Content);
                    //dynamic seriliazedString = JsonConvert.DeserializeObject(jsonContent["d"].ToString(), Type.GetType("null"));
                    //Console.WriteLine($"Content: {response.Content}");

                    var stream = response.Content;

                    XmlSerializer serializer = new XmlSerializer(typeof(Edmx));
                    StringReader reader = new StringReader(stream);
                    Edmx metadata = (Edmx)serializer.Deserialize(reader);

                    //adding keys
                    metadata.DataServices.Schema[1].EntityType.Key.ToList().ForEach(k => { _entities.Add(new EntityModel() { ObjectName = foname, FieldName = k.Name, IsKey = true }); });

                    //adding other fields
                    metadata.DataServices.Schema[1].EntityType.Property.ToList().ForEach(v =>
                    {
                        if (!ignorelist.Any(x => x.Equals(v.Name)) && !_entities.Any(y => y.FieldName.Equals(v.Name)))
                        {
                            _entities.Add(new EntityModel() { ObjectName = foname, FieldName = v.Name, IsKey = false });
                        }
                    });
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Data for {foname} not captured, Exception is call : {e.Message}");

            }
            return _entities;
        }

        #region cleaneddata
        private static Dictionary<string, string> _cleanedNames = new Dictionary<string, string>()
        {
            {"cust_activity_type","Activity Type"},{"address1","Address 1"},{"addressAddress1","Address 1"},{"address2","Address 2"},{"addressAddress2","Address 2"},{"address3","Address 3"},{"addressAddress3","Address 3"},{"address4","Address 4"},{"addressAddress4","Address 4"},{"address5","Address 5"},{"addressAddress5","Address 5"},{"address6","Address 6"},{"addressAddress6","Address 6"},{"address8","Address 8"},{"addressAddress8","Address 8"},{"addressCustomString1","Address Custom String 1"},{"addressCustomString2","Address Custom String 2"},{"addressCustomString3","Address Custom String 3"},{"addressCustomString4","Address Custom String 4"},{"addressId","Address ID"},{"adjustmentPercentage","Adjustment Percentage"},{"annualizationFactor","Annualization Factor"},{"averageHoursPerDay","Average Hours Per Day"},{"averageHoursPerMonth","Average Hours Per Month"},{"averageHoursPerWeek","Average Hours Per Week"},{"averageHoursPerYear","Average Hours Per Year"},{"averageWorkingDaysPerWeek","Average Working Days Per Week"},{"bankBranch","Bank Branch"},{"bankCountry","Bank Country"},{"cust_BankID","Bank ID"},{"bankName","Bank Name"},{"basePayComponentGroup","Base Pay Component Group"},{"businessIdentifierCode","Business Identifier Code"},{"cust_bussinessunit","Business Unit"},{"canOverride","Can Override"},{"cust_careerlevel","Career Level Code"},{"cust_CareerLevelProp","Career Level Prop"},{"addressCity","City"},{"city","City"},{"addressZipCode","Code"},{"cust_codeblock","Code Block"},{"cust_comp","Comp"},{"cust_comp_desc","Comp Description"},{"companyFlx","companyFlx"},{"costCenter","Cost Center"},{"addressCountry","Country"},{"country","Country"},{"cust_countryProp","Country"},{"addressCounty","County"},{"county","County"},{"crossMidnightAllowed","Cross Midnight Allowed"},{"currency","Currency"},{"currencyExchangeRateType","Currency Exchange Rate Type"},{"customLong1","Custom Long 1"},{"addressCustomLong1","Custom Long1"},{"customString1","Custom String 1"},{"customString2","Custom String 2"},{"customString3","Custom String 3"},{"customString4","Custom String 4"},{"customString7","Custom String 7"},{"dataDelimiter","Datadelimiter"},{"decimalPoint","Decimalpoint"},{"cust_description","Description"},{"cust_Description","Description"},{"description","Description"},{"cust_Description_de_DE","Description de_DE"},{"description_de_DE","Description de_DE"},{"description_defaultValue","Description Default"},{"cust_Description_defaultValue","Description Default"},{"cust_Description_en_GB","Description en_GB"},{"description_en_GB","Description en_GB"},{"cust_Description_en_US","Description en_US"},{"description_en_US","Description en_US"},{"cust_Description_es_MX","Description es_MX"},{"description_es_MX","Description es_MX"},{"cust_Description_fr_CA","Description fr_CA"},{"description_fr_CA","Description fr_CA"},{"cust_Description_fr_FR","Description fr_FR"},{"description_fr_FR","Description fr_FR"},{"cust_Description_iw_IL","Description iw_IL"},{"description_iw_IL","Description iw_IL"},{"cust_Description_ja_JP","Description ja_JP"},{"description_ja_JP","Description ja_JP"},{"cust_Description_ko_KR","Description ko_KR"},{"description_ko_KR","Description ko_KR"},{"description_localized","Description Local"},{"cust_Description_localized","Description Local"},{"cust_Description_pt_BR","Description pt_BR"},{"description_pt_BR","Description pt_BR"},{"cust_Description_zh_CN","Description zh_CN"},{"description_zh_CN","Description zh_CN"},{"cust_Description_zh_TW","Description zh_TW"},{"description_zh_TW","Description zh_TW"},{"displayOnSelfService","Display On SelfService"},{"cust_eco_location","Eco Location"},{"cust_eco_location_desc","Eco Location Description"},{"effectiveStatus","Effective Status"},{"effectiveEndDate","Effective End Date"},{"effectiveStartDate","Effective Start Date"},{"emplStatus","Empl Status"},{"endDate","End Date"},{"entityUUID","Entityuuid"},{"cust_establishmentid","Establishmentid"},{"event","Event"},{"exchangeRate","Exchangerate"},{"cust_Experiencelevel","Experiencelevel"},{"externalCode","External Code"},{"externalName","External Name"},{"externalName_de_DE","External Name de_DE"},{"externalName_defaultValue","External Name Default"},{"externalName_en_GB","External Name en_GB"},{"externalName_en_US","External Name es_MX"},{"externalName_es_MX","External Name es_MX"},{"externalName_fr_CA","External Name fr_CA"},{"externalName_fr_FR","External Name fr_FR"},{"externalName_iw_IL","External Name iw_IL"},{"externalName_ja_JP","External Name ja_JP"},{"externalName_ko_KR","External Name ko_KR"},{"externalName_localized","External Name local"},{"externalName_pt_BR","External Name pt_BR"},{"externalName_zh_CN","External Name zh_CN"},{"externalName_zh_TW","External Name zh_TW"},{"cust_toeylegalentityProp","EY Legal Entity"},{"flexibleRequestingAllowed","Flexible RequestingAllowed llowed"},{"frequencyCode","Frequency Code"},{"cust_FTEHRSGFIS","FTSHRSGFIS"},{"cust_gcohremplegent","Gcohremplegent"},{"cust_gdentitycode","Gdentitycode"},{"custGeographicAreaFlx","GeographicAreaFlx"},{"geozoneFlx","Geozone Flx"},{"grade","Grade"},{"headOfUnit","Head OfUnit"},{"individualWorkSchedule","Individual WorkSchedule"},{"isEndDatedPayment","Is EndDate Payment"},{"isFulltimeEmployee","Is FulltimeEmployee"},{"isEarning","IsEarning"},{"isRegular","Isregular"},{"cust_JobFamily","JobFamily"},{"cust_JobFamilyGrp","JobFamily"},{"cust_jobrole","Jobrole"},{"cust_JobRoleTypeProp","JobRoleType"},{"lag","Lag"},{"locationGroup","Locationgroup"},{"cust_tomanagementregionProp","Management Region"},{"cust_managementarea","Managementarea"},{"cust_managementunit","Managementunit"},{"cust_managerialcountry","Managerialcountry"},{"maxFractionDigits","Max FractionDigits"},{"maximumPay","Maximumpay"},{"mdfSystemStatus","Status"},{"cust_merc_comp_code_desc","Merc Comp Code Description"},{"cust_merc_comp_code","Merc Comp Code"},{"midPoint","Midpoint"},{"minimumPay","Minimumpay"},{"modelCategory","Modelcategory"},{"name","Name"},{"name_defaultValue","Name Default"},{"name_de_DE","Name_De_De"},{"name_en_GB","Name_En_Gb"},{"name_en_US","Name_En_Us"},{"name_es_MX","Name_Es_Mx"},{"name_fr_CA","Name_Fr_Ca"},{"name_fr_FR","Name_Fr_Fr"},{"name_iw_IL","Name_Iw_Il"},{"name_ja_JP","Name_Ja_Jp"},{"name_ko_KR","Name_Ko_Kr"},{"name_localized","Name_Localized"},{"name_pt_BR","Name_Pt_Br"},{"name_zh_CN","Name_Zh_Cn"},{"name_zh_TW","Name_Zh_Tw"},{"number","Number"},{"cust_operatingunit","Operatingunit"},{"cust_overtimeeligibility","Overtimeeligibility"},{"cust_parentDepartment1","Parent Department 1"},{"cust_parentDepartment2","Parent Department 2"},{"payComponentFlx","Pay ComponentFlx"},{"payComponentType","Pay ComponentType"},{"payComponentValue","Pay ComponentValue"},{"payFrequency","Pay frequency"},{"paygradeLevel","Pay Grade level"},{"payGradeFlx","Pay GradeFlx"},{"paymentFrequency","Payment Frequency"},{"payrollEvent","Payroll Event"},{"payrollVendorId","Payroll Vendor Id"},{"cust_pcaobtrlegent","Pcaobtrlegent"},{"periodModel","Period Model"},{"postalCode","Postal Code"},{"cust_prof_centre","Prof Centre"},{"cust_prof_centre_desc","Prof Centre Description"},{"addressProvince","Province"},{"province","Province"},{"cust_ranksProp","Rank"},{"rate","Rate"},{"recordId","Record Id"},{"recurring","Recurring"},{"regularTemporary","Regular Temporary"},{"cust_RewardsDiversifier","Rewardsdiversifier"},{"custRewardsDiversifierFlx","RewardsDiversifier"},{"cust_RoleType","Roletype"},{"routingNumber","Routing Number"},{"sample","Sample"},{"searchString","Search String"},{"selfServiceDescription","Self Service Description"},{"cust_servicetype","Servicetype"},{"custServiceTypeFlx","ServiceType"},{"shiftClassification","Shift Classification"},{"showOnCompUI","Show On Comp"},{"sortOrder","Sort Order"},{"sourceCurrency","Source Currency"},{"cust_speciality","Speciality"},{"cust_toSSLProp","SSL"},{"standardHours","Standard Hours"},{"startDate","Start Date"},{"startingDate","Starting Date"},{"addressState","State"},{"state","State"},{"status","Status"},{"street","Street"},{"cust_STDHRSGFIS","STSHRSGFIS"},{"cust_submanagementunit","Submanagementunit"},{"target","Target"},{"targetCurrency","Target Currency"},{"taxTreatment","Tax Treatment"},{"timeRecordingVariant","Time Recording Variant"},{"timezone","Timezone"},{"toDisplayNameFormatProp","To Display Name Format Prop"},{"toNameFormatProp","To Name Format Prop"},{"cust_toNameFormatGOProp","toNameFormat"},{"cust_transfergroup","Transfergroup"},{"unitOfMeasure","Unit Of Measure"},{"useForComparatioCalc","Use For Comparatio Calc"},{"useForRangePenetration","Use For Range Penetration"},{"usedForCompPlanning","Used For Comp Planning"},{"userId","User Id"},{"cust_WBS","WBS"},{"weeksInPayPeriod","Weeks In Pay Period"},{"zipCode","Zip Code"},
        };
        #endregion
    }

    internal class EntityModel
    {
        internal string ObjectName { get; set; }
        internal string FieldName { get; set; }
        internal bool IsKey { get; set; }
    }
}
