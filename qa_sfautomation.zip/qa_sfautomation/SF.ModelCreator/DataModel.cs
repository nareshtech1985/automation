﻿namespace SF.ModelCreator
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Converters;
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Reflection;

    public static class Converter
    {
        public static readonly JsonSerializerSettings Settings = new JsonSerializerSettings
        {
            MetadataPropertyHandling = MetadataPropertyHandling.Ignore,
            DateParseHandling = DateParseHandling.None,
            Converters =
            {
                new IsoDateTimeConverter { DateTimeStyles = DateTimeStyles.AssumeUniversal }
            },
            Formatting = Formatting.Indented,
            NullValueHandling = NullValueHandling.Ignore
        };
    }
    public class TestData<T>
    {
        private static string DirectoryPath => Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        [JsonProperty("Data", NullValueHandling = NullValueHandling.Ignore)]
        public static IEnumerable<T> Data { get; set; } = Instance.GetType().GetProperty("Data").GetValue(Instance, null) as IEnumerable<T>;
        public static TestData<T> FromJson(string json) => JsonConvert.DeserializeObject<TestData<T>>(json, Converter.Settings);
        public static string ToJson(T self) => JsonConvert.SerializeObject(self, Converter.Settings);
        public static TestData<T> Instance
        {
            get
            {
                if (Data != null) { Console.WriteLine("Reloading data.."); }
                try
                {
                    var filename = $"{typeof(T).Name}.json";
                    List<string> files = Directory.EnumerateFiles(DirectoryPath).ToList();
                    string xs = files.Find(x => x.Contains(filename));
                    if (xs == null)
                    {
                        //foreach (var dir in Directory.EnumerateDirectories(DirectoryPath))
                        //{
                        //    files = Directory.EnumerateFiles(dir).ToList();
                        //    xs = files.Find(x => x.Contains(filename));
                        //    if (!xs.Equals(string.Empty)) break;
                        //}
                    }

                    return FromJson(File.ReadAllText(xs));
                }
                catch (Exception e)
                {
                    //throw new FrameworkException($@"Error of {typeof(T).Name}.json | Exception : {e.Message}");
                    Console.WriteLine(e.Message);
                    return null;
                }
            }
        }

        public static T Random => Data.ToList()[new Random().Next(Data.Count())];

    }
}
