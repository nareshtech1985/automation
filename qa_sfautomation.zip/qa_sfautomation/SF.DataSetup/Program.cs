﻿namespace SF.DataSetup
{
    using SF.Parameter;
    using System;

    public class Program
    {
        private static void Main(string[] args)
        {

        }
    }

    public class Leave
    {
        [ColumnHeader(1, "GUI")]
        public string GUI { get; set; }
        [ColumnHeader(2, "User ID")]
        public string UserId { get; set; }
        [ColumnHeader(3, "Start Date")]
        public DateTime StartDate { get; set; }
        [ColumnHeader(4, "End Date")]
        public DateTime EndDate { get; set; }
        [ColumnHeader(5, "Leave Type")]
        public string LeaveType { get; set; }
    }
}
