﻿namespace SF.DataSetup
{
    using Newtonsoft.Json;
    using Newtonsoft.Json.Linq;
    using RestSharp;
    using System;
    using System.IO;
    using System.Net;
    using System.Reflection;

    internal class API
    {
        public string DirectoryPath => Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);

        protected void CreateLogFile(string URI, string body, string message, string http, string apitype)
        {
            if (!Directory.Exists($@"{DirectoryPath}\api_call_log)")) Directory.CreateDirectory($@"{DirectoryPath}\api_call_log");
            string _apilogfile = $@"{DirectoryPath}\api_call_log\{apitype}_{http}_call_{ DateTime.Now:dd MM yyyy HH mm ss}.txt";
            using (StreamWriter e = new StreamWriter(new FileStream(_apilogfile, FileMode.OpenOrCreate)))
            {
                e.WriteLine($"Request URI : {URI}\n");
                e.WriteLine($"{body}");
                e.WriteLine($"{message}");
            }
            Console.WriteLine(message);
        }

        public dynamic Get(string Uri)
        {
            var baseurl = "https://api12preview.sapsf.eu/odata/v2/";
            dynamic seriliazedString = "";
            var uri = Uri.StartsWith("http") ? Uri : $"{baseurl}{Uri}";
            var entity = Uri.Replace(baseurl, string.Empty);
            entity = entity.Substring(0, entity.IndexOf('?'));
            Console.WriteLine($"Calling the api via URI: {uri}");
            var client = new RestClient();
            var request = new RestRequest(uri, Method.Get);
            request.AddHeader("Accept", "*/*");
            request.AddHeader("Accept-Encoding", "gzip, deflate, br");
            request.AddHeader("Connection", "keep-alive");
            request.AddHeader("Authorization", "Basic MTI1NDQ4MkBFWUlUU0RFVjE6cWEyMDIyKkFwcmls");
            request.AddHeader("Content-Type", "application/json");
            try
            {
                DateTime start = DateTime.Now;
                Console.WriteLine($"API Invoke @ {start:H:m:ss}");
                RestResponse response = client.ExecuteAsync(request, Method.Get).Result;
                TimeSpan span = DateTime.Now - start;
                if (response.StatusCode == HttpStatusCode.Unauthorized)
                {
                    CreateLogFile(uri, response.Content, "API Call Fail!", "ERROR_GET", "SF");
                }
                else
                {
                    var jsonContent = JObject.Parse(response.Content);
                    seriliazedString = JsonConvert.DeserializeObject(jsonContent["d"].ToString(), Type.GetType("null"));

                    if (seriliazedString.Value == "\"results\": []")
                    {
                        CreateLogFile(uri, response.Content, "API Call Fail!", "ERROR_GET", "SF");
                    }
                    else
                    {
                        CreateLogFile(uri, response.Content, "API Call Success!", "GET", "SF");
                    }
                }
            }
            catch (Exception e)
            {
                CreateLogFile(uri, e.Message, "API Call Fail!", "ERROR_GET", "SF");
                seriliazedString = "\"results\": []";
            }
            return seriliazedString;
        }
    }
}
