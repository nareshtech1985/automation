﻿using System;
using System.Collections.Generic;

namespace SF.DataSetup
{

    public class Output<T> where T : class
    {
        public List<T> results { get; set; }
    }

    public class Result
    {
        public __Metadata __metadata { get; set; }
        public string seqNumber { get; set; }
        public string userId { get; set; }
        public DateTime startDate { get; set; }
        public object customString131 { get; set; }
        public string customString130 { get; set; }
        public bool effectiveLatestChange { get; set; }
        public object customString133 { get; set; }
        public object customString132 { get; set; }
        public DateTime createdDateTime { get; set; }
        public object customString43 { get; set; }
        public object customString44 { get; set; }
        public string customString45 { get; set; }
        public object attachmentFileSize { get; set; }
        public string customString46 { get; set; }
        public object customString47 { get; set; }
        public object customString48 { get; set; }
        public object customString49 { get; set; }
        public object customString51 { get; set; }
        public object customString52 { get; set; }
        public object customString135 { get; set; }
        public object customString134 { get; set; }
        public object occupationCri { get; set; }
        public object customString137 { get; set; }
        public object customString138 { get; set; }
        public DateTime departmentEntryDate { get; set; }
        public string costCenter { get; set; }
        public object customString122 { get; set; }
        public object customString121 { get; set; }
        public string customString33 { get; set; }
        public object customString34 { get; set; }
        public object customString35 { get; set; }
        public object customString36 { get; set; }
        public object customString41 { get; set; }
        public object customString124 { get; set; }
        public object customString123 { get; set; }
        public object customString126 { get; set; }
        public bool calcMethodIndicator { get; set; }
        public object customString125 { get; set; }
        public string customString128 { get; set; }
        public object customString127 { get; set; }
        public object customString129 { get; set; }
        public object customString28 { get; set; }
        public object customString29 { get; set; }
        public bool isFulltimeEmployee { get; set; }
        public object customString151 { get; set; }
        public string emplStatus { get; set; }
        public object customString153 { get; set; }
        public object customString152 { get; set; }
        public object customString155 { get; set; }
        public object customString154 { get; set; }
        public string countryOfCompany { get; set; }
        public object customString20 { get; set; }
        public string customString21 { get; set; }
        public string customString22 { get; set; }
        public string customString23 { get; set; }
        public string customString24 { get; set; }
        public object customString26 { get; set; }
        public string localJobTitle { get; set; }
        public object customString27 { get; set; }
        public object customString30 { get; set; }
        public object entryIntoGroup { get; set; }
        public string payGrade { get; set; }
        public object customString157 { get; set; }
        public object customString156 { get; set; }
        public object travelDistance { get; set; }
        public string customString17 { get; set; }
        public string customString18 { get; set; }
        public object customString19 { get; set; }
        public object customString142 { get; set; }
        public object customString141 { get; set; }
        public object customString144 { get; set; }
        public object customString143 { get; set; }
        public string customString10 { get; set; }
        public string customString11 { get; set; }
        public string customString12 { get; set; }
        public string managerId { get; set; }
        public object customString13 { get; set; }
        public string customString14 { get; set; }
        public object wtdHoursLimit { get; set; }
        public string customString15 { get; set; }
        public string customString16 { get; set; }
        public DateTime lastModifiedOn { get; set; }
        public object customString146 { get; set; }
        public object customString145 { get; set; }
        public object customString148 { get; set; }
        public object customString147 { get; set; }
        public object customString149 { get; set; }
        public string businessUnit { get; set; }
        public DateTime lastModifiedDateTime { get; set; }
        public object harmfulAgentExposure { get; set; }
        public object sickPaySupplement { get; set; }
        public string customDouble20 { get; set; }
        public DateTime locationEntryDate { get; set; }
        public object initialEntryDate { get; set; }
        public string holidayCalendarCode { get; set; }
        public string eventReason { get; set; }
        public bool isCompetitionClauseActive { get; set; }
        public object noticePeriod { get; set; }
        public object continuedSicknessPayMeasure { get; set; }
        public string shiftCode { get; set; }
        public object customLong2 { get; set; }
        public object customLong1 { get; set; }
        public string regularTemp { get; set; }
        public bool isSideLineJobAllowed { get; set; }
        public string company { get; set; }
        public string eeo1JobCategory { get; set; }
        public string employeeClass { get; set; }
        public object contractEndDate { get; set; }
        public bool pensionProtection { get; set; }
        public object attachmentFileType { get; set; }
        public string createdBy { get; set; }
        public object contractId { get; set; }
        public string location { get; set; }
        public string workscheduleCode { get; set; }
        public DateTime endDate { get; set; }
        public object contractType { get; set; }
        public object attachmentStatus { get; set; }
        public string jobCode { get; set; }
        public string division { get; set; }
        public string timeTypeProfileCode { get; set; }
        public object eeoClass { get; set; }
        public object continuedSicknessPayPeriod { get; set; }
        public object attachmentMimeType { get; set; }
        public object attachmentId { get; set; }
        public string flsaStatus { get; set; }
        public object corporation { get; set; }
        public DateTime companyEntryDate { get; set; }
        public DateTime? customDate24 { get; set; }
        public object customDate23 { get; set; }
        public object customDate25 { get; set; }
        public object occupationGtm { get; set; }
        public object customDate22 { get; set; }
        public object payScaleType { get; set; }
        public object customDate21 { get; set; }
        public string customDouble2 { get; set; }
        public DateTime createdOn { get; set; }
        public string customDouble3 { get; set; }
        public object customDouble4 { get; set; }
        public object customDouble5 { get; set; }
        public bool healthRisk { get; set; }
        public string customDouble1 { get; set; }
        public string fte { get; set; }
        public DateTime? customDate13 { get; set; }
        public DateTime? customDate12 { get; set; }
        public DateTime? customDate15 { get; set; }
        public DateTime? customDate14 { get; set; }
        public string _event { get; set; }
        public DateTime? customDate11 { get; set; }
        public DateTime? customDate10 { get; set; }
        public bool teachersPension { get; set; }
        public object workerCategory { get; set; }
        public object contractDate { get; set; }
        public object attachmentFileName { get; set; }
        public string jobTitle { get; set; }
        public object customString86 { get; set; }
        public object customString88 { get; set; }
        public object customString89 { get; set; }
        public string customString90 { get; set; }
        public object customString91 { get; set; }
        public object customString92 { get; set; }
        public string standardHours { get; set; }
        public object customString75 { get; set; }
        public object customString76 { get; set; }
        public object customString77 { get; set; }
        public object customString78 { get; set; }
        public object customString79 { get; set; }
        public DateTime jobEntryDate { get; set; }
        public object customString80 { get; set; }
        public object customString81 { get; set; }
        public string customString82 { get; set; }
        public object customString83 { get; set; }
        public object customString84 { get; set; }
        public object customString85 { get; set; }
        public object payScaleArea { get; set; }
        public DateTime? probationPeriodEndDate { get; set; }
        public string timezone { get; set; }
        public string workingDaysPerWeek { get; set; }
        public object customString64 { get; set; }
        public object customString65 { get; set; }
        public object customString66 { get; set; }
        public object customString67 { get; set; }
        public object customString68 { get; set; }
        public object customString69 { get; set; }
        public object customDate7 { get; set; }
        public DateTime? customDate9 { get; set; }
        public object customString70 { get; set; }
        public object attachment { get; set; }
        public object customString71 { get; set; }
        public object customString72 { get; set; }
        public object customString73 { get; set; }
        public object customString74 { get; set; }
        public object customString113 { get; set; }
        public string customString112 { get; set; }
        public object customDate3 { get; set; }
        public string department { get; set; }
        public object customDate5 { get; set; }
        public object customDate6 { get; set; }
        public bool workingTimeDirective { get; set; }
        public string employmentType { get; set; }
        public string lastModifiedBy { get; set; }
        public string customString5 { get; set; }
        public object customString53 { get; set; }
        public string customString4 { get; set; }
        public object customString54 { get; set; }
        public string customString3 { get; set; }
        public object customString55 { get; set; }
        public string customString2 { get; set; }
        public string customString56 { get; set; }
        public string customString57 { get; set; }
        public object customString9 { get; set; }
        public object tupeOrgNumber { get; set; }
        public object customString58 { get; set; }
        public object customString8 { get; set; }
        public object customString59 { get; set; }
        public string customString7 { get; set; }
        public string customString6 { get; set; }
        public object customString60 { get; set; }
        public object customString61 { get; set; }
        public object customString62 { get; set; }
        public object customString63 { get; set; }
        public Customstring64nav customString64Nav { get; set; }
        public Customstring35nav customString35Nav { get; set; }
        public Customstring70nav customString70Nav { get; set; }
        public Customstring58nav customString58Nav { get; set; }
        public Holidaycalendarcodenav holidayCalendarCodeNav { get; set; }
        public Customstring29nav customString29Nav { get; set; }
        public Customstring143nav customString143Nav { get; set; }
        public Companynav companyNav { get; set; }
        public Customstring154nav customString154Nav { get; set; }
        public Customstring75nav customString75Nav { get; set; }
        public Customstring81nav customString81Nav { get; set; }
        public Customstring47nav customString47Nav { get; set; }
        public Payscaleareanav payScaleAreaNav { get; set; }
        public Customstring12nav customString12Nav { get; set; }
        public Businessunitnav businessUnitNav { get; set; }
        public Customstring18nav customString18Nav { get; set; }
        public Contracttypenav contractTypeNav { get; set; }
        public Customstring7nav customString7Nav { get; set; }
        public Costcenternav costCenterNav { get; set; }
        public Customstring46nav customString46Nav { get; set; }
        public Customstring69nav customString69Nav { get; set; }
        public Customstring88nav customString88Nav { get; set; }
        public Employmenttypenav employmentTypeNav { get; set; }
        public Usernav userNav { get; set; }
        public Customstring13nav customString13Nav { get; set; }
        public Customstring2nav customString2Nav { get; set; }
        public Customstring63nav customString63Nav { get; set; }
        public Timetypeprofilecodenav timeTypeProfileCodeNav { get; set; }
        public Customstring52nav customString52Nav { get; set; }
        public Divisionnav divisionNav { get; set; }
        public Customstring24nav customString24Nav { get; set; }
        public Customstring142nav customString142Nav { get; set; }
        public Customstring153nav customString153Nav { get; set; }
        public Customstring16nav customString16Nav { get; set; }
        public Workschedulecodenav workscheduleCodeNav { get; set; }
        public Sickpaysupplementnav sickPaySupplementNav { get; set; }
        public Customstring45nav customString45Nav { get; set; }
        public Customstring22nav customString22Nav { get; set; }
        public Employmentnav employmentNav { get; set; }
        public Customstring80nav customString80Nav { get; set; }
        public Customstring74nav customString74Nav { get; set; }
        public Customstring51nav customString51Nav { get; set; }
        public Workercategorynav workerCategoryNav { get; set; }
        public Customstring147nav customString147Nav { get; set; }
        public Countryofcompanynav countryOfCompanyNav { get; set; }
        public Customstring112nav customString112Nav { get; set; }
        public Customstring8nav customString8Nav { get; set; }
        public Customstring33nav customString33Nav { get; set; }
        public Eventnav eventNav { get; set; }
        public Customstring68nav customString68Nav { get; set; }
        public Customstring85nav customString85Nav { get; set; }
        public Customstring89nav customString89Nav { get; set; }
        public Occupationcrinav occupationCriNav { get; set; }
        public Customstring3nav customString3Nav { get; set; }
        public Customstring62nav customString62Nav { get; set; }
        public Occupationgtmnav occupationGtmNav { get; set; }
        public Customstring113nav customString113Nav { get; set; }
        public Customstring79nav customString79Nav { get; set; }
        public Customstring34nav customString34Nav { get; set; }
        public Customstring11nav customString11Nav { get; set; }
        public Jobcodenav jobCodeNav { get; set; }
        public Customstring152nav customString152Nav { get; set; }
        public Customstring90nav customString90Nav { get; set; }
        public Emplstatusnav emplStatusNav { get; set; }
        public Customstring67nav customString67Nav { get; set; }
        public Customstring17nav customString17Nav { get; set; }
        public Customstring73nav customString73Nav { get; set; }
        public Customstring28nav customString28Nav { get; set; }
        public Customstring146nav customString146Nav { get; set; }
        public Noticeperiodnav noticePeriodNav { get; set; }
        public Customstring157nav customString157Nav { get; set; }
        public Customstring78nav customString78Nav { get; set; }
        public Customstring55nav customString55Nav { get; set; }
        public Customstring9nav customString9Nav { get; set; }
        public Customstring84nav customString84Nav { get; set; }
        public Customstring4nav customString4Nav { get; set; }
        public Customstring44nav customString44Nav { get; set; }
        public Customstring61nav customString61Nav { get; set; }
        public Customstring26nav customString26Nav { get; set; }
        public Departmentnav departmentNav { get; set; }
        public Customstring66nav customString66Nav { get; set; }
        public Customstring91nav customString91Nav { get; set; }
        public Customstring43nav customString43Nav { get; set; }
        public Continuedsicknesspaymeasurenav continuedSicknessPayMeasureNav { get; set; }
        public Customstring151nav customString151Nav { get; set; }
        public Payscaletypenav payScaleTypeNav { get; set; }
        public Customstring27nav customString27Nav { get; set; }
        public Customstring72nav customString72Nav { get; set; }
        public Customstring122nav customString122Nav { get; set; }
        public Customstring145nav customString145Nav { get; set; }
        public Harmfulagentexposurenav harmfulAgentExposureNav { get; set; }
        public Flsastatusnav flsaStatusNav { get; set; }
        public Shiftcodenav shiftCodeNav { get; set; }
        public Customstring156nav customString156Nav { get; set; }
        public Customstring21nav customString21Nav { get; set; }
        public Customstring77nav customString77Nav { get; set; }
        public Customstring49nav customString49Nav { get; set; }
        public Customstring10nav customString10Nav { get; set; }
        public Customstring83nav customString83Nav { get; set; }
        public Eeoclassnav eeoClassNav { get; set; }
        public Customstring60nav customString60Nav { get; set; }
        public Customstring5nav customString5Nav { get; set; }
        public Customstring48nav customString48Nav { get; set; }
        public Customstring65nav customString65Nav { get; set; }
        public Customstring86nav customString86Nav { get; set; }
        public Customstring92nav customString92Nav { get; set; }
        public Customstring19nav customString19Nav { get; set; }
        public Customstring36nav customString36Nav { get; set; }
        public Customstring71nav customString71Nav { get; set; }
        public Manageremploymentnav managerEmploymentNav { get; set; }
        public Customstring54nav customString54Nav { get; set; }
        public Customstring144nav customString144Nav { get; set; }
        public Managerusernav managerUserNav { get; set; }
        public Customstring149nav customString149Nav { get; set; }
        public Locationnav locationNav { get; set; }
        public Customstring20nav customString20Nav { get; set; }
        public Regulartempnav regularTempNav { get; set; }
        public Customstring76nav customString76Nav { get; set; }
        public Eventreasonnav eventReasonNav { get; set; }
        public Customstring53nav customString53Nav { get; set; }
        public Customstring82nav customString82Nav { get; set; }
        public Employeeclassnav employeeClassNav { get; set; }
        public Customstring59nav customString59Nav { get; set; }
        public Customstring6nav customString6Nav { get; set; }
        public Wfrequestnav wfRequestNav { get; set; }
        public Eeo1jobcategorynav eeo1JobCategoryNav { get; set; }
        public Paygradenav payGradeNav { get; set; }
    }

    public class __Metadata
    {
        public string uri { get; set; }
        public string type { get; set; }
    }

    public class Customstring64nav
    {
        public __Deferred __deferred { get; set; }
    }

    public class __Deferred
    {
        public string uri { get; set; }
    }

    public class Customstring35nav
    {
        public __Deferred1 __deferred { get; set; }
    }

    public class __Deferred1
    {
        public string uri { get; set; }
    }

    public class Customstring70nav
    {
        public __Deferred2 __deferred { get; set; }
    }

    public class __Deferred2
    {
        public string uri { get; set; }
    }

    public class Customstring58nav
    {
        public __Deferred3 __deferred { get; set; }
    }

    public class __Deferred3
    {
        public string uri { get; set; }
    }

    public class Holidaycalendarcodenav
    {
        public __Deferred4 __deferred { get; set; }
    }

    public class __Deferred4
    {
        public string uri { get; set; }
    }

    public class Customstring29nav
    {
        public __Deferred5 __deferred { get; set; }
    }

    public class __Deferred5
    {
        public string uri { get; set; }
    }

    public class Customstring143nav
    {
        public __Deferred6 __deferred { get; set; }
    }

    public class __Deferred6
    {
        public string uri { get; set; }
    }

    public class Companynav
    {
        public __Deferred7 __deferred { get; set; }
    }

    public class __Deferred7
    {
        public string uri { get; set; }
    }

    public class Customstring154nav
    {
        public __Deferred8 __deferred { get; set; }
    }

    public class __Deferred8
    {
        public string uri { get; set; }
    }

    public class Customstring75nav
    {
        public __Deferred9 __deferred { get; set; }
    }

    public class __Deferred9
    {
        public string uri { get; set; }
    }

    public class Customstring81nav
    {
        public __Deferred10 __deferred { get; set; }
    }

    public class __Deferred10
    {
        public string uri { get; set; }
    }

    public class Customstring47nav
    {
        public __Deferred11 __deferred { get; set; }
    }

    public class __Deferred11
    {
        public string uri { get; set; }
    }

    public class Payscaleareanav
    {
        public __Deferred12 __deferred { get; set; }
    }

    public class __Deferred12
    {
        public string uri { get; set; }
    }

    public class Customstring12nav
    {
        public __Deferred13 __deferred { get; set; }
    }

    public class __Deferred13
    {
        public string uri { get; set; }
    }

    public class Businessunitnav
    {
        public __Deferred14 __deferred { get; set; }
    }

    public class __Deferred14
    {
        public string uri { get; set; }
    }

    public class Customstring18nav
    {
        public __Deferred15 __deferred { get; set; }
    }

    public class __Deferred15
    {
        public string uri { get; set; }
    }

    public class Contracttypenav
    {
        public __Deferred16 __deferred { get; set; }
    }

    public class __Deferred16
    {
        public string uri { get; set; }
    }

    public class Customstring7nav
    {
        public __Deferred17 __deferred { get; set; }
    }

    public class __Deferred17
    {
        public string uri { get; set; }
    }

    public class Costcenternav
    {
        public __Deferred18 __deferred { get; set; }
    }

    public class __Deferred18
    {
        public string uri { get; set; }
    }

    public class Customstring46nav
    {
        public __Deferred19 __deferred { get; set; }
    }

    public class __Deferred19
    {
        public string uri { get; set; }
    }

    public class Customstring69nav
    {
        public __Deferred20 __deferred { get; set; }
    }

    public class __Deferred20
    {
        public string uri { get; set; }
    }

    public class Customstring88nav
    {
        public __Deferred21 __deferred { get; set; }
    }

    public class __Deferred21
    {
        public string uri { get; set; }
    }

    public class Employmenttypenav
    {
        public __Deferred22 __deferred { get; set; }
    }

    public class __Deferred22
    {
        public string uri { get; set; }
    }

    public class Usernav
    {
        public __Metadata1 __metadata { get; set; }
        public string userId { get; set; }
        public object salaryBudgetFinalSalaryPercentage { get; set; }
        public object dateOfCurrentPosition { get; set; }
        public object matrix1Label { get; set; }
        public object salary { get; set; }
        public string objective { get; set; }
        public object ssn { get; set; }
        public string state { get; set; }
        public object issueComments { get; set; }
        public string timeZone { get; set; }
        public string defaultLocale { get; set; }
        public object nationality { get; set; }
        public object salaryBudgetLumpsumPercentage { get; set; }
        public object sysCostOfSource { get; set; }
        public object ethnicity { get; set; }
        public object payGrade { get; set; }
        public object nickname { get; set; }
        public string email { get; set; }
        public object salaryBudgetExtra2Percentage { get; set; }
        public object stockBudgetOther1Amount { get; set; }
        public object talentPool { get; set; }
        public object raiseProrating { get; set; }
        public object sysStartingSalary { get; set; }
        public object finalJobCode { get; set; }
        public object lumpsum2Target { get; set; }
        public object stockBudgetOptionAmount { get; set; }
        public string country { get; set; }
        public DateTime lastModifiedDateTime { get; set; }
        public object stockBudgetStockAmount { get; set; }
        public DateTime sciLastModified { get; set; }
        public object criticalTalentComments { get; set; }
        public string homePhone { get; set; }
        public object veteranSeparated { get; set; }
        public object stockBudgetOther2Amount { get; set; }
        public string firstName { get; set; }
        public object stockBudgetUnitAmount { get; set; }
        public object salutation { get; set; }
        public object impactOfLoss { get; set; }
        public object benchStrength { get; set; }
        public object sysSource { get; set; }
        public object futureLeader { get; set; }
        public string title { get; set; }
        public object meritEffectiveDate { get; set; }
        public object veteranProtected { get; set; }
        public object lumpsumTarget { get; set; }
        public object employeeClass { get; set; }
        public DateTime hireDate { get; set; }
        public object matrix2Label { get; set; }
        public object salaryLocal { get; set; }
        public object citizenship { get; set; }
        public object reasonForLeaving { get; set; }
        public object riskOfLoss { get; set; }
        public string location { get; set; }
        public object reloComments { get; set; }
        public string username { get; set; }
        public object serviceDate { get; set; }
        public object reviewFreq { get; set; }
        public object salaryBudgetTotalRaisePercentage { get; set; }
        public string jobCode { get; set; }
        public DateTime lastModifiedWithTZ { get; set; }
        public string division { get; set; }
        public string custom02 { get; set; }
        public object meritTarget { get; set; }
        public string custom01 { get; set; }
        public string custom04 { get; set; }
        public string custom03 { get; set; }
        public string custom06 { get; set; }
        public string custom05 { get; set; }
        public string custom08 { get; set; }
        public object reloWilling { get; set; }
        public string custom07 { get; set; }
        public object stockBudgetOther3Amount { get; set; }
        public string custom09 { get; set; }
        public object onboardingId { get; set; }
        public object fax { get; set; }
        public object bonusBudgetAmount { get; set; }
        public object salaryBudgetPromotionPercentage { get; set; }
        public object dateOfPosition { get; set; }
        public object finalJobFamily { get; set; }
        public int teamMembersSize { get; set; }
        public object compensationEligible { get; set; }
        public object lastReviewDate { get; set; }
        public object compensationStockEligible { get; set; }
        public string businessPhone { get; set; }
        public string status { get; set; }
        public string lastName { get; set; }
        public string gender { get; set; }
        public string city { get; set; }
        public string competency { get; set; }
        public object businessSegment { get; set; }
        public object custom20 { get; set; }
        public object custom22 { get; set; }
        public object custom21 { get; set; }
        public object compensationSalaryRateUnits { get; set; }
        public object newToPosition { get; set; }
        public string assignmentUUID { get; set; }
        public DateTime dateOfBirth { get; set; }
        public object localCurrencyCode { get; set; }
        public object jobLevel { get; set; }
        public string custom11 { get; set; }
        public string defaultFullName { get; set; }
        public string custom10 { get; set; }
        public object compensationReadOnly { get; set; }
        public object custom13 { get; set; }
        public string custom12 { get; set; }
        public string custom15 { get; set; }
        public object custom14 { get; set; }
        public string custom17 { get; set; }
        public string custom16 { get; set; }
        public object veteranDisabled { get; set; }
        public object custom19 { get; set; }
        public DateTime custom18 { get; set; }
        public string totalTeamSize { get; set; }
        public object married { get; set; }
        public string EYUReportGroup { get; set; }
        public object cellPhone { get; set; }
        public object veteranMedal { get; set; }
        public object compensationSalaryRateType { get; set; }
        public string zipCode { get; set; }
        public object jobTitle { get; set; }
        public object minority { get; set; }
        public object suffix { get; set; }
        public object matrixManaged { get; set; }
        public object bonusTarget { get; set; }
        public string addressLine1 { get; set; }
        public object jobFamily { get; set; }
        public object jobRole { get; set; }
        public string addressLine2 { get; set; }
        public string addressLine3 { get; set; }
        public string mi { get; set; }
        public string potential { get; set; }
        public object origHireDate { get; set; }
        public object level { get; set; }
        public object salaryBudgetMeritPercentage { get; set; }
        public object salaryProrating { get; set; }
        public DateTime lastModified { get; set; }
        public object promotionAmount { get; set; }
        public object impactOfLossComments { get; set; }
        public string empId { get; set; }
        public object compensationSalaryEligible { get; set; }
        public string department { get; set; }
        public bool isPrimaryAssignment { get; set; }
        public object reloLocation { get; set; }
        public object companyExitDate { get; set; }
        public object seatingChart { get; set; }
        public object finalJobRole { get; set; }
        public string performance { get; set; }
        public object compensationBonusEligible { get; set; }
        public object keyPosition { get; set; }
        public object salaryBudgetExtraPercentage { get; set; }
        public Delegatorofautodelegateconfignav delegatorOfAutoDelegateConfigNav { get; set; }
        public Secondmanager secondManager { get; set; }
        public Ethnicitynav ethnicityNav { get; set; }
        public Incumbentofpositionnav incumbentOfPositionNav { get; set; }
        public Subjectuseridofachievementnav subjectUserIdOfAchievementNav { get; set; }
        public Userssysidofemployeedatareplicationnotificationnav usersSysIdOfEmployeeDataReplicationNotificationNav { get; set; }
        public Proxy proxy { get; set; }
        public Participantuserid1ofonboardingmeetingeventnav participantUserId1OfOnboardingMeetingEventNav { get; set; }
        public Targetidoftimemanagementalertnav targetIdOfTimeManagementAlertNav { get; set; }
        public Matrixreports matrixReports { get; set; }
        public Useridofworkschedulenav userIdOfWorkScheduleNav { get; set; }
        public Useridofemployeetimegroupnav userIdOfEmployeeTimeGroupNav { get; set; }
        public Processoridofonboardingcandidateinfonav processorIdOfOnboardingCandidateInfoNav { get; set; }
        public Benchstrengthnav benchStrengthNav { get; set; }
        public Manager manager { get; set; }
        public Useridofonboardingcandidateinfonav userIdOfOnboardingCandidateInfoNav { get; set; }
        public Usersysidofworkordernav userSysIdOfWorkOrderNav { get; set; }
        public Impactoflossnav impactOfLossNav { get; set; }
        public Concurrentuserofonboardingcandidateinfonav concurrentUserOfOnboardingCandidateInfoNav { get; set; }
        public Useridofaccrualcalculationbasenav userIdOfAccrualCalculationBaseNav { get; set; }
        public Useridofhrischangelogdatareplicationnav userIdOfHRISChangeLogDataReplicationNav { get; set; }
        public Nominationnav nominationNav { get; set; }
        public Externalcodeofcust_Certificationslicencesheadernav externalCodeOfcust_CERTIFICATIONSLICENCESHEADERNav { get; set; }
        public Reasonforleavingnav reasonForLeavingNav { get; set; }
        public Custommanager customManager { get; set; }
        public Workorderowneridofworkordernav workOrderOwnerIdOfWorkOrderNav { get; set; }
        public Costcentermanageroffocostcenternav costCenterManagerOfFOCostCenterNav { get; set; }
        public Syssourcenav sysSourceNav { get; set; }
        public Secondreports secondReports { get; set; }
        public Usersysidofonetimedeductionnav userSysIdOfOneTimeDeductionNav { get; set; }
        public Usersysidofrecurringdeductionnav userSysIdOfRecurringDeductionNav { get; set; }
        public Workerofpaymentinformationv3nav workerOfPaymentInformationV3Nav { get; set; }
        public Empinfo empInfo { get; set; }
        public Userssysidofsecondaryassignmentsitemnav usersSysIdOfSecondaryAssignmentsItemNav { get; set; }
        public Useridofemployeepayrollrunresultsnav userIdOfEmployeePayrollRunResultsNav { get; set; }
        public Useridoftimeaccountnav userIdOfTimeAccountNav { get; set; }
        public Useridofbudgetgroupnav userIdOfBudgetGroupNav { get; set; }
        public Externalcodeofskillprofilenav externalCodeOfSkillProfileNav { get; set; }
        public Keypositionnav keyPositionNav { get; set; }
        public Hrmanageridofonboardingcandidateinfonav hrManagerIdOfOnboardingCandidateInfoNav { get; set; }
        public Userssysidofemployeedatareplicationelementnav usersSysIdOfEmployeeDataReplicationElementNav { get; set; }
        public Headofunitoffodivisionnav headOfUnitOfFODivisionNav { get; set; }
        public Assigneeuseridofdomaineventalertnav assigneeUserIdOfDomainEventAlertNav { get; set; }
        public Relowillingnav reloWillingNav { get; set; }
        public Customreports customReports { get; set; }
        public Delegateeofautodelegatedetailnav delegateeOfAutoDelegateDetailNav { get; set; }
        public Hr hr { get; set; }
        public Headofunitoffobusinessunitnav headOfUnitOfFOBusinessUnitNav { get; set; }
        public Useridoftimeaccountsnapshotnav userIdOfTimeAccountSnapshotNav { get; set; }
        public Useridoftemporarytimeinformationnav userIdOfTemporaryTimeInformationNav { get; set; }
        public Useridofpayrolldatamaintenancetasknav userIdOfPayrollDataMaintenanceTaskNav { get; set; }
        public Directreports directReports { get; set; }
        public Participantuserid2ofonboardingmeetingeventnav participantUserId2OfOnboardingMeetingEventNav { get; set; }
        public Participantuserid3ofonboardingmeetingeventnav participantUserId3OfOnboardingMeetingEventNav { get; set; }
        public Initiatedbyofpayrolldatamaintenancetasknav initiatedByOfPayrollDataMaintenanceTaskNav { get; set; }
        public Personkeynav personKeyNav { get; set; }
        public Userssysidofemployeedatareplicationconfirmationnav usersSysIdOfEmployeeDataReplicationConfirmationNav { get; set; }
        public Eyureportgroupnav EYUReportGroupNav { get; set; }
        public Competencyratingnav competencyRatingNav { get; set; }
        public Userpermissionsnav userPermissionsNav { get; set; }
        public Auditusersysidofonetimedeductionnav auditUserSysIdOfOneTimeDeductionNav { get; set; }
        public Subjectuseridofactivitynav subjectUserIdOfActivityNav { get; set; }
        public Useridofdatareplicationproxynav userIdOfDataReplicationProxyNav { get; set; }
        public Employmentidentityofdrtmpurgefreezenav employmentIdentityOfDRTMPurgeFreezeNav { get; set; }
        public Externalcodeofcust_Educationnav externalCodeOfcust_educationNav { get; set; }
        public Matrixmanager matrixManager { get; set; }
        public Salutationnav salutationNav { get; set; }
        public Useridofemployeetimenav userIdOfEmployeeTimeNav { get; set; }
        public Manageridofonboardingcandidateinfonav managerIdOfOnboardingCandidateInfoNav { get; set; }
        public Headofunitoffodepartmentnav headOfUnitOfFODepartmentNav { get; set; }
        public Participantuserid4ofonboardingmeetingeventnav participantUserId4OfOnboardingMeetingEventNav { get; set; }
        public Hrreports hrReports { get; set; }
        public Riskoflossnav riskOfLossNav { get; set; }
        public Participantuserid5ofonboardingmeetingeventnav participantUserId5OfOnboardingMeetingEventNav { get; set; }
        public Owneroftalentpoolnav ownerOfTalentPoolNav { get; set; }
        public Userssysidofhiredatechangenav usersSysIdOfHireDateChangeNav { get; set; }
    }

    public class __Metadata1
    {
        public string uri { get; set; }
        public string type { get; set; }
    }

    public class Delegatorofautodelegateconfignav
    {
        public __Deferred23 __deferred { get; set; }
    }

    public class __Deferred23
    {
        public string uri { get; set; }
    }

    public class Secondmanager
    {
        public __Deferred24 __deferred { get; set; }
    }

    public class __Deferred24
    {
        public string uri { get; set; }
    }

    public class Ethnicitynav
    {
        public __Deferred25 __deferred { get; set; }
    }

    public class __Deferred25
    {
        public string uri { get; set; }
    }

    public class Incumbentofpositionnav
    {
        public __Deferred26 __deferred { get; set; }
    }

    public class __Deferred26
    {
        public string uri { get; set; }
    }

    public class Subjectuseridofachievementnav
    {
        public __Deferred27 __deferred { get; set; }
    }

    public class __Deferred27
    {
        public string uri { get; set; }
    }

    public class Userssysidofemployeedatareplicationnotificationnav
    {
        public __Deferred28 __deferred { get; set; }
    }

    public class __Deferred28
    {
        public string uri { get; set; }
    }

    public class Proxy
    {
        public __Deferred29 __deferred { get; set; }
    }

    public class __Deferred29
    {
        public string uri { get; set; }
    }

    public class Participantuserid1ofonboardingmeetingeventnav
    {
        public __Deferred30 __deferred { get; set; }
    }

    public class __Deferred30
    {
        public string uri { get; set; }
    }

    public class Targetidoftimemanagementalertnav
    {
        public __Deferred31 __deferred { get; set; }
    }

    public class __Deferred31
    {
        public string uri { get; set; }
    }

    public class Matrixreports
    {
        public __Deferred32 __deferred { get; set; }
    }

    public class __Deferred32
    {
        public string uri { get; set; }
    }

    public class Useridofworkschedulenav
    {
        public __Deferred33 __deferred { get; set; }
    }

    public class __Deferred33
    {
        public string uri { get; set; }
    }

    public class Useridofemployeetimegroupnav
    {
        public __Deferred34 __deferred { get; set; }
    }

    public class __Deferred34
    {
        public string uri { get; set; }
    }

    public class Processoridofonboardingcandidateinfonav
    {
        public __Deferred35 __deferred { get; set; }
    }

    public class __Deferred35
    {
        public string uri { get; set; }
    }

    public class Benchstrengthnav
    {
        public __Deferred36 __deferred { get; set; }
    }

    public class __Deferred36
    {
        public string uri { get; set; }
    }

    public class Manager
    {
        public __Deferred37 __deferred { get; set; }
    }

    public class __Deferred37
    {
        public string uri { get; set; }
    }

    public class Useridofonboardingcandidateinfonav
    {
        public __Deferred38 __deferred { get; set; }
    }

    public class __Deferred38
    {
        public string uri { get; set; }
    }

    public class Usersysidofworkordernav
    {
        public __Deferred39 __deferred { get; set; }
    }

    public class __Deferred39
    {
        public string uri { get; set; }
    }

    public class Impactoflossnav
    {
        public __Deferred40 __deferred { get; set; }
    }

    public class __Deferred40
    {
        public string uri { get; set; }
    }

    public class Concurrentuserofonboardingcandidateinfonav
    {
        public __Deferred41 __deferred { get; set; }
    }

    public class __Deferred41
    {
        public string uri { get; set; }
    }

    public class Useridofaccrualcalculationbasenav
    {
        public __Deferred42 __deferred { get; set; }
    }

    public class __Deferred42
    {
        public string uri { get; set; }
    }

    public class Useridofhrischangelogdatareplicationnav
    {
        public __Deferred43 __deferred { get; set; }
    }

    public class __Deferred43
    {
        public string uri { get; set; }
    }

    public class Nominationnav
    {
        public __Deferred44 __deferred { get; set; }
    }

    public class __Deferred44
    {
        public string uri { get; set; }
    }

    public class Externalcodeofcust_Certificationslicencesheadernav
    {
        public __Deferred45 __deferred { get; set; }
    }

    public class __Deferred45
    {
        public string uri { get; set; }
    }

    public class Reasonforleavingnav
    {
        public __Deferred46 __deferred { get; set; }
    }

    public class __Deferred46
    {
        public string uri { get; set; }
    }

    public class Custommanager
    {
        public __Deferred47 __deferred { get; set; }
    }

    public class __Deferred47
    {
        public string uri { get; set; }
    }

    public class Workorderowneridofworkordernav
    {
        public __Deferred48 __deferred { get; set; }
    }

    public class __Deferred48
    {
        public string uri { get; set; }
    }

    public class Costcentermanageroffocostcenternav
    {
        public __Deferred49 __deferred { get; set; }
    }

    public class __Deferred49
    {
        public string uri { get; set; }
    }

    public class Syssourcenav
    {
        public __Deferred50 __deferred { get; set; }
    }

    public class __Deferred50
    {
        public string uri { get; set; }
    }

    public class Secondreports
    {
        public __Deferred51 __deferred { get; set; }
    }

    public class __Deferred51
    {
        public string uri { get; set; }
    }

    public class Usersysidofonetimedeductionnav
    {
        public __Deferred52 __deferred { get; set; }
    }

    public class __Deferred52
    {
        public string uri { get; set; }
    }

    public class Usersysidofrecurringdeductionnav
    {
        public __Deferred53 __deferred { get; set; }
    }

    public class __Deferred53
    {
        public string uri { get; set; }
    }

    public class Workerofpaymentinformationv3nav
    {
        public __Deferred54 __deferred { get; set; }
    }

    public class __Deferred54
    {
        public string uri { get; set; }
    }

    public class Empinfo
    {
        public __Deferred55 __deferred { get; set; }
    }

    public class __Deferred55
    {
        public string uri { get; set; }
    }

    public class Userssysidofsecondaryassignmentsitemnav
    {
        public __Deferred56 __deferred { get; set; }
    }

    public class __Deferred56
    {
        public string uri { get; set; }
    }

    public class Useridofemployeepayrollrunresultsnav
    {
        public __Deferred57 __deferred { get; set; }
    }

    public class __Deferred57
    {
        public string uri { get; set; }
    }

    public class Useridoftimeaccountnav
    {
        public __Deferred58 __deferred { get; set; }
    }

    public class __Deferred58
    {
        public string uri { get; set; }
    }

    public class Useridofbudgetgroupnav
    {
        public __Deferred59 __deferred { get; set; }
    }

    public class __Deferred59
    {
        public string uri { get; set; }
    }

    public class Externalcodeofskillprofilenav
    {
        public __Deferred60 __deferred { get; set; }
    }

    public class __Deferred60
    {
        public string uri { get; set; }
    }

    public class Keypositionnav
    {
        public __Deferred61 __deferred { get; set; }
    }

    public class __Deferred61
    {
        public string uri { get; set; }
    }

    public class Hrmanageridofonboardingcandidateinfonav
    {
        public __Deferred62 __deferred { get; set; }
    }

    public class __Deferred62
    {
        public string uri { get; set; }
    }

    public class Userssysidofemployeedatareplicationelementnav
    {
        public __Deferred63 __deferred { get; set; }
    }

    public class __Deferred63
    {
        public string uri { get; set; }
    }

    public class Headofunitoffodivisionnav
    {
        public __Deferred64 __deferred { get; set; }
    }

    public class __Deferred64
    {
        public string uri { get; set; }
    }

    public class Assigneeuseridofdomaineventalertnav
    {
        public __Deferred65 __deferred { get; set; }
    }

    public class __Deferred65
    {
        public string uri { get; set; }
    }

    public class Relowillingnav
    {
        public __Deferred66 __deferred { get; set; }
    }

    public class __Deferred66
    {
        public string uri { get; set; }
    }

    public class Customreports
    {
        public __Deferred67 __deferred { get; set; }
    }

    public class __Deferred67
    {
        public string uri { get; set; }
    }

    public class Delegateeofautodelegatedetailnav
    {
        public __Deferred68 __deferred { get; set; }
    }

    public class __Deferred68
    {
        public string uri { get; set; }
    }

    public class Hr
    {
        public __Deferred69 __deferred { get; set; }
    }

    public class __Deferred69
    {
        public string uri { get; set; }
    }

    public class Headofunitoffobusinessunitnav
    {
        public __Deferred70 __deferred { get; set; }
    }

    public class __Deferred70
    {
        public string uri { get; set; }
    }

    public class Useridoftimeaccountsnapshotnav
    {
        public __Deferred71 __deferred { get; set; }
    }

    public class __Deferred71
    {
        public string uri { get; set; }
    }

    public class Useridoftemporarytimeinformationnav
    {
        public __Deferred72 __deferred { get; set; }
    }

    public class __Deferred72
    {
        public string uri { get; set; }
    }

    public class Useridofpayrolldatamaintenancetasknav
    {
        public __Deferred73 __deferred { get; set; }
    }

    public class __Deferred73
    {
        public string uri { get; set; }
    }

    public class Directreports
    {
        public __Deferred74 __deferred { get; set; }
    }

    public class __Deferred74
    {
        public string uri { get; set; }
    }

    public class Participantuserid2ofonboardingmeetingeventnav
    {
        public __Deferred75 __deferred { get; set; }
    }

    public class __Deferred75
    {
        public string uri { get; set; }
    }

    public class Participantuserid3ofonboardingmeetingeventnav
    {
        public __Deferred76 __deferred { get; set; }
    }

    public class __Deferred76
    {
        public string uri { get; set; }
    }

    public class Initiatedbyofpayrolldatamaintenancetasknav
    {
        public __Deferred77 __deferred { get; set; }
    }

    public class __Deferred77
    {
        public string uri { get; set; }
    }

    public class Personkeynav
    {
        public __Metadata2 __metadata { get; set; }
        public string personIdExternal { get; set; }
        public string personId { get; set; }
        public string perPersonUuid { get; set; }
        public Useraccountnav userAccountNav { get; set; }
    }

    public class __Metadata2
    {
        public string uri { get; set; }
        public string type { get; set; }
    }

    public class Useraccountnav
    {
        public __Deferred78 __deferred { get; set; }
    }

    public class __Deferred78
    {
        public string uri { get; set; }
    }

    public class Userssysidofemployeedatareplicationconfirmationnav
    {
        public __Deferred79 __deferred { get; set; }
    }

    public class __Deferred79
    {
        public string uri { get; set; }
    }

    public class Eyureportgroupnav
    {
        public __Deferred80 __deferred { get; set; }
    }

    public class __Deferred80
    {
        public string uri { get; set; }
    }

    public class Competencyratingnav
    {
        public __Deferred81 __deferred { get; set; }
    }

    public class __Deferred81
    {
        public string uri { get; set; }
    }

    public class Userpermissionsnav
    {
        public __Deferred82 __deferred { get; set; }
    }

    public class __Deferred82
    {
        public string uri { get; set; }
    }

    public class Auditusersysidofonetimedeductionnav
    {
        public __Deferred83 __deferred { get; set; }
    }

    public class __Deferred83
    {
        public string uri { get; set; }
    }

    public class Subjectuseridofactivitynav
    {
        public __Deferred84 __deferred { get; set; }
    }

    public class __Deferred84
    {
        public string uri { get; set; }
    }

    public class Useridofdatareplicationproxynav
    {
        public __Deferred85 __deferred { get; set; }
    }

    public class __Deferred85
    {
        public string uri { get; set; }
    }

    public class Employmentidentityofdrtmpurgefreezenav
    {
        public __Deferred86 __deferred { get; set; }
    }

    public class __Deferred86
    {
        public string uri { get; set; }
    }

    public class Externalcodeofcust_Educationnav
    {
        public __Deferred87 __deferred { get; set; }
    }

    public class __Deferred87
    {
        public string uri { get; set; }
    }

    public class Matrixmanager
    {
        public __Deferred88 __deferred { get; set; }
    }

    public class __Deferred88
    {
        public string uri { get; set; }
    }

    public class Salutationnav
    {
        public __Deferred89 __deferred { get; set; }
    }

    public class __Deferred89
    {
        public string uri { get; set; }
    }

    public class Useridofemployeetimenav
    {
        public __Deferred90 __deferred { get; set; }
    }

    public class __Deferred90
    {
        public string uri { get; set; }
    }

    public class Manageridofonboardingcandidateinfonav
    {
        public __Deferred91 __deferred { get; set; }
    }

    public class __Deferred91
    {
        public string uri { get; set; }
    }

    public class Headofunitoffodepartmentnav
    {
        public __Deferred92 __deferred { get; set; }
    }

    public class __Deferred92
    {
        public string uri { get; set; }
    }

    public class Participantuserid4ofonboardingmeetingeventnav
    {
        public __Deferred93 __deferred { get; set; }
    }

    public class __Deferred93
    {
        public string uri { get; set; }
    }

    public class Hrreports
    {
        public __Deferred94 __deferred { get; set; }
    }

    public class __Deferred94
    {
        public string uri { get; set; }
    }

    public class Riskoflossnav
    {
        public __Deferred95 __deferred { get; set; }
    }

    public class __Deferred95
    {
        public string uri { get; set; }
    }

    public class Participantuserid5ofonboardingmeetingeventnav
    {
        public __Deferred96 __deferred { get; set; }
    }

    public class __Deferred96
    {
        public string uri { get; set; }
    }

    public class Owneroftalentpoolnav
    {
        public __Deferred97 __deferred { get; set; }
    }

    public class __Deferred97
    {
        public string uri { get; set; }
    }

    public class Userssysidofhiredatechangenav
    {
        public __Deferred98 __deferred { get; set; }
    }

    public class __Deferred98
    {
        public string uri { get; set; }
    }

    public class Customstring13nav
    {
        public __Deferred99 __deferred { get; set; }
    }

    public class __Deferred99
    {
        public string uri { get; set; }
    }

    public class Customstring2nav
    {
        public __Deferred100 __deferred { get; set; }
    }

    public class __Deferred100
    {
        public string uri { get; set; }
    }

    public class Customstring63nav
    {
        public __Deferred101 __deferred { get; set; }
    }

    public class __Deferred101
    {
        public string uri { get; set; }
    }

    public class Timetypeprofilecodenav
    {
        public __Deferred102 __deferred { get; set; }
    }

    public class __Deferred102
    {
        public string uri { get; set; }
    }

    public class Customstring52nav
    {
        public __Deferred103 __deferred { get; set; }
    }

    public class __Deferred103
    {
        public string uri { get; set; }
    }

    public class Divisionnav
    {
        public __Deferred104 __deferred { get; set; }
    }

    public class __Deferred104
    {
        public string uri { get; set; }
    }

    public class Customstring24nav
    {
        public __Deferred105 __deferred { get; set; }
    }

    public class __Deferred105
    {
        public string uri { get; set; }
    }

    public class Customstring142nav
    {
        public __Deferred106 __deferred { get; set; }
    }

    public class __Deferred106
    {
        public string uri { get; set; }
    }

    public class Customstring153nav
    {
        public __Deferred107 __deferred { get; set; }
    }

    public class __Deferred107
    {
        public string uri { get; set; }
    }

    public class Customstring16nav
    {
        public __Deferred108 __deferred { get; set; }
    }

    public class __Deferred108
    {
        public string uri { get; set; }
    }

    public class Workschedulecodenav
    {
        public __Deferred109 __deferred { get; set; }
    }

    public class __Deferred109
    {
        public string uri { get; set; }
    }

    public class Sickpaysupplementnav
    {
        public __Deferred110 __deferred { get; set; }
    }

    public class __Deferred110
    {
        public string uri { get; set; }
    }

    public class Customstring45nav
    {
        public __Deferred111 __deferred { get; set; }
    }

    public class __Deferred111
    {
        public string uri { get; set; }
    }

    public class Customstring22nav
    {
        public __Deferred112 __deferred { get; set; }
    }

    public class __Deferred112
    {
        public string uri { get; set; }
    }

    public class Employmentnav
    {
        public __Deferred113 __deferred { get; set; }
    }

    public class __Deferred113
    {
        public string uri { get; set; }
    }

    public class Customstring80nav
    {
        public __Deferred114 __deferred { get; set; }
    }

    public class __Deferred114
    {
        public string uri { get; set; }
    }

    public class Customstring74nav
    {
        public __Deferred115 __deferred { get; set; }
    }

    public class __Deferred115
    {
        public string uri { get; set; }
    }

    public class Customstring51nav
    {
        public __Deferred116 __deferred { get; set; }
    }

    public class __Deferred116
    {
        public string uri { get; set; }
    }

    public class Workercategorynav
    {
        public __Deferred117 __deferred { get; set; }
    }

    public class __Deferred117
    {
        public string uri { get; set; }
    }

    public class Customstring147nav
    {
        public __Deferred118 __deferred { get; set; }
    }

    public class __Deferred118
    {
        public string uri { get; set; }
    }

    public class Countryofcompanynav
    {
        public __Deferred119 __deferred { get; set; }
    }

    public class __Deferred119
    {
        public string uri { get; set; }
    }

    public class Customstring112nav
    {
        public __Deferred120 __deferred { get; set; }
    }

    public class __Deferred120
    {
        public string uri { get; set; }
    }

    public class Customstring8nav
    {
        public __Deferred121 __deferred { get; set; }
    }

    public class __Deferred121
    {
        public string uri { get; set; }
    }

    public class Customstring33nav
    {
        public __Deferred122 __deferred { get; set; }
    }

    public class __Deferred122
    {
        public string uri { get; set; }
    }

    public class Eventnav
    {
        public __Deferred123 __deferred { get; set; }
    }

    public class __Deferred123
    {
        public string uri { get; set; }
    }

    public class Customstring68nav
    {
        public __Deferred124 __deferred { get; set; }
    }

    public class __Deferred124
    {
        public string uri { get; set; }
    }

    public class Customstring85nav
    {
        public __Deferred125 __deferred { get; set; }
    }

    public class __Deferred125
    {
        public string uri { get; set; }
    }

    public class Customstring89nav
    {
        public __Deferred126 __deferred { get; set; }
    }

    public class __Deferred126
    {
        public string uri { get; set; }
    }

    public class Occupationcrinav
    {
        public __Deferred127 __deferred { get; set; }
    }

    public class __Deferred127
    {
        public string uri { get; set; }
    }

    public class Customstring3nav
    {
        public __Deferred128 __deferred { get; set; }
    }

    public class __Deferred128
    {
        public string uri { get; set; }
    }

    public class Customstring62nav
    {
        public __Deferred129 __deferred { get; set; }
    }

    public class __Deferred129
    {
        public string uri { get; set; }
    }

    public class Occupationgtmnav
    {
        public __Deferred130 __deferred { get; set; }
    }

    public class __Deferred130
    {
        public string uri { get; set; }
    }

    public class Customstring113nav
    {
        public __Deferred131 __deferred { get; set; }
    }

    public class __Deferred131
    {
        public string uri { get; set; }
    }

    public class Customstring79nav
    {
        public __Deferred132 __deferred { get; set; }
    }

    public class __Deferred132
    {
        public string uri { get; set; }
    }

    public class Customstring34nav
    {
        public __Deferred133 __deferred { get; set; }
    }

    public class __Deferred133
    {
        public string uri { get; set; }
    }

    public class Customstring11nav
    {
        public __Deferred134 __deferred { get; set; }
    }

    public class __Deferred134
    {
        public string uri { get; set; }
    }

    public class Jobcodenav
    {
        public __Deferred135 __deferred { get; set; }
    }

    public class __Deferred135
    {
        public string uri { get; set; }
    }

    public class Customstring152nav
    {
        public __Deferred136 __deferred { get; set; }
    }

    public class __Deferred136
    {
        public string uri { get; set; }
    }

    public class Customstring90nav
    {
        public __Deferred137 __deferred { get; set; }
    }

    public class __Deferred137
    {
        public string uri { get; set; }
    }

    public class Emplstatusnav
    {
        public __Deferred138 __deferred { get; set; }
    }

    public class __Deferred138
    {
        public string uri { get; set; }
    }

    public class Customstring67nav
    {
        public __Deferred139 __deferred { get; set; }
    }

    public class __Deferred139
    {
        public string uri { get; set; }
    }

    public class Customstring17nav
    {
        public __Deferred140 __deferred { get; set; }
    }

    public class __Deferred140
    {
        public string uri { get; set; }
    }

    public class Customstring73nav
    {
        public __Deferred141 __deferred { get; set; }
    }

    public class __Deferred141
    {
        public string uri { get; set; }
    }

    public class Customstring28nav
    {
        public __Deferred142 __deferred { get; set; }
    }

    public class __Deferred142
    {
        public string uri { get; set; }
    }

    public class Customstring146nav
    {
        public __Deferred143 __deferred { get; set; }
    }

    public class __Deferred143
    {
        public string uri { get; set; }
    }

    public class Noticeperiodnav
    {
        public __Deferred144 __deferred { get; set; }
    }

    public class __Deferred144
    {
        public string uri { get; set; }
    }

    public class Customstring157nav
    {
        public __Deferred145 __deferred { get; set; }
    }

    public class __Deferred145
    {
        public string uri { get; set; }
    }

    public class Customstring78nav
    {
        public __Deferred146 __deferred { get; set; }
    }

    public class __Deferred146
    {
        public string uri { get; set; }
    }

    public class Customstring55nav
    {
        public __Deferred147 __deferred { get; set; }
    }

    public class __Deferred147
    {
        public string uri { get; set; }
    }

    public class Customstring9nav
    {
        public __Deferred148 __deferred { get; set; }
    }

    public class __Deferred148
    {
        public string uri { get; set; }
    }

    public class Customstring84nav
    {
        public __Deferred149 __deferred { get; set; }
    }

    public class __Deferred149
    {
        public string uri { get; set; }
    }

    public class Customstring4nav
    {
        public __Deferred150 __deferred { get; set; }
    }

    public class __Deferred150
    {
        public string uri { get; set; }
    }

    public class Customstring44nav
    {
        public __Deferred151 __deferred { get; set; }
    }

    public class __Deferred151
    {
        public string uri { get; set; }
    }

    public class Customstring61nav
    {
        public __Deferred152 __deferred { get; set; }
    }

    public class __Deferred152
    {
        public string uri { get; set; }
    }

    public class Customstring26nav
    {
        public __Deferred153 __deferred { get; set; }
    }

    public class __Deferred153
    {
        public string uri { get; set; }
    }

    public class Departmentnav
    {
        public __Deferred154 __deferred { get; set; }
    }

    public class __Deferred154
    {
        public string uri { get; set; }
    }

    public class Customstring66nav
    {
        public __Deferred155 __deferred { get; set; }
    }

    public class __Deferred155
    {
        public string uri { get; set; }
    }

    public class Customstring91nav
    {
        public __Deferred156 __deferred { get; set; }
    }

    public class __Deferred156
    {
        public string uri { get; set; }
    }

    public class Customstring43nav
    {
        public __Deferred157 __deferred { get; set; }
    }

    public class __Deferred157
    {
        public string uri { get; set; }
    }

    public class Continuedsicknesspaymeasurenav
    {
        public __Deferred158 __deferred { get; set; }
    }

    public class __Deferred158
    {
        public string uri { get; set; }
    }

    public class Customstring151nav
    {
        public __Deferred159 __deferred { get; set; }
    }

    public class __Deferred159
    {
        public string uri { get; set; }
    }

    public class Payscaletypenav
    {
        public __Deferred160 __deferred { get; set; }
    }

    public class __Deferred160
    {
        public string uri { get; set; }
    }

    public class Customstring27nav
    {
        public __Deferred161 __deferred { get; set; }
    }

    public class __Deferred161
    {
        public string uri { get; set; }
    }

    public class Customstring72nav
    {
        public __Deferred162 __deferred { get; set; }
    }

    public class __Deferred162
    {
        public string uri { get; set; }
    }

    public class Customstring122nav
    {
        public __Deferred163 __deferred { get; set; }
    }

    public class __Deferred163
    {
        public string uri { get; set; }
    }

    public class Customstring145nav
    {
        public __Deferred164 __deferred { get; set; }
    }

    public class __Deferred164
    {
        public string uri { get; set; }
    }

    public class Harmfulagentexposurenav
    {
        public __Deferred165 __deferred { get; set; }
    }

    public class __Deferred165
    {
        public string uri { get; set; }
    }

    public class Flsastatusnav
    {
        public __Deferred166 __deferred { get; set; }
    }

    public class __Deferred166
    {
        public string uri { get; set; }
    }

    public class Shiftcodenav
    {
        public __Deferred167 __deferred { get; set; }
    }

    public class __Deferred167
    {
        public string uri { get; set; }
    }

    public class Customstring156nav
    {
        public __Deferred168 __deferred { get; set; }
    }

    public class __Deferred168
    {
        public string uri { get; set; }
    }

    public class Customstring21nav
    {
        public __Deferred169 __deferred { get; set; }
    }

    public class __Deferred169
    {
        public string uri { get; set; }
    }

    public class Customstring77nav
    {
        public __Deferred170 __deferred { get; set; }
    }

    public class __Deferred170
    {
        public string uri { get; set; }
    }

    public class Customstring49nav
    {
        public __Deferred171 __deferred { get; set; }
    }

    public class __Deferred171
    {
        public string uri { get; set; }
    }

    public class Customstring10nav
    {
        public __Deferred172 __deferred { get; set; }
    }

    public class __Deferred172
    {
        public string uri { get; set; }
    }

    public class Customstring83nav
    {
        public __Deferred173 __deferred { get; set; }
    }

    public class __Deferred173
    {
        public string uri { get; set; }
    }

    public class Eeoclassnav
    {
        public __Deferred174 __deferred { get; set; }
    }

    public class __Deferred174
    {
        public string uri { get; set; }
    }

    public class Customstring60nav
    {
        public __Deferred175 __deferred { get; set; }
    }

    public class __Deferred175
    {
        public string uri { get; set; }
    }

    public class Customstring5nav
    {
        public __Deferred176 __deferred { get; set; }
    }

    public class __Deferred176
    {
        public string uri { get; set; }
    }

    public class Customstring48nav
    {
        public __Deferred177 __deferred { get; set; }
    }

    public class __Deferred177
    {
        public string uri { get; set; }
    }

    public class Customstring65nav
    {
        public __Deferred178 __deferred { get; set; }
    }

    public class __Deferred178
    {
        public string uri { get; set; }
    }

    public class Customstring86nav
    {
        public __Deferred179 __deferred { get; set; }
    }

    public class __Deferred179
    {
        public string uri { get; set; }
    }

    public class Customstring92nav
    {
        public __Deferred180 __deferred { get; set; }
    }

    public class __Deferred180
    {
        public string uri { get; set; }
    }

    public class Customstring19nav
    {
        public __Deferred181 __deferred { get; set; }
    }

    public class __Deferred181
    {
        public string uri { get; set; }
    }

    public class Customstring36nav
    {
        public __Deferred182 __deferred { get; set; }
    }

    public class __Deferred182
    {
        public string uri { get; set; }
    }

    public class Customstring71nav
    {
        public __Deferred183 __deferred { get; set; }
    }

    public class __Deferred183
    {
        public string uri { get; set; }
    }

    public class Manageremploymentnav
    {
        public __Deferred184 __deferred { get; set; }
    }

    public class __Deferred184
    {
        public string uri { get; set; }
    }

    public class Customstring54nav
    {
        public __Deferred185 __deferred { get; set; }
    }

    public class __Deferred185
    {
        public string uri { get; set; }
    }

    public class Customstring144nav
    {
        public __Deferred186 __deferred { get; set; }
    }

    public class __Deferred186
    {
        public string uri { get; set; }
    }

    public class Managerusernav
    {
        public __Deferred187 __deferred { get; set; }
    }

    public class __Deferred187
    {
        public string uri { get; set; }
    }

    public class Customstring149nav
    {
        public __Deferred188 __deferred { get; set; }
    }

    public class __Deferred188
    {
        public string uri { get; set; }
    }

    public class Locationnav
    {
        public __Deferred189 __deferred { get; set; }
    }

    public class __Deferred189
    {
        public string uri { get; set; }
    }

    public class Customstring20nav
    {
        public __Deferred190 __deferred { get; set; }
    }

    public class __Deferred190
    {
        public string uri { get; set; }
    }

    public class Regulartempnav
    {
        public __Deferred191 __deferred { get; set; }
    }

    public class __Deferred191
    {
        public string uri { get; set; }
    }

    public class Customstring76nav
    {
        public __Deferred192 __deferred { get; set; }
    }

    public class __Deferred192
    {
        public string uri { get; set; }
    }

    public class Eventreasonnav
    {
        public __Deferred193 __deferred { get; set; }
    }

    public class __Deferred193
    {
        public string uri { get; set; }
    }

    public class Customstring53nav
    {
        public __Deferred194 __deferred { get; set; }
    }

    public class __Deferred194
    {
        public string uri { get; set; }
    }

    public class Customstring82nav
    {
        public __Deferred195 __deferred { get; set; }
    }

    public class __Deferred195
    {
        public string uri { get; set; }
    }

    public class Employeeclassnav
    {
        public __Deferred196 __deferred { get; set; }
    }

    public class __Deferred196
    {
        public string uri { get; set; }
    }

    public class Customstring59nav
    {
        public __Deferred197 __deferred { get; set; }
    }

    public class __Deferred197
    {
        public string uri { get; set; }
    }

    public class Customstring6nav
    {
        public __Deferred198 __deferred { get; set; }
    }

    public class __Deferred198
    {
        public string uri { get; set; }
    }

    public class Wfrequestnav
    {
        public __Deferred199 __deferred { get; set; }
    }

    public class __Deferred199
    {
        public string uri { get; set; }
    }

    public class Eeo1jobcategorynav
    {
        public __Deferred200 __deferred { get; set; }
    }

    public class __Deferred200
    {
        public string uri { get; set; }
    }

    public class Paygradenav
    {
        public __Deferred201 __deferred { get; set; }
    }

    public class __Deferred201
    {
        public string uri { get; set; }
    }

}
