[Read Me!](../Readme.md)

# Workflow Overview
![workflow_img](/SF.StaticPage/img01.png)
- Step 01 : Core HR Scenarios Data Creation via SF API
- Step 02 : Core HR Scenarios Data Verification via SF API
- Step 03 : (CPI - Cloud Platform Integration Portal) iFlow deployment via Selenium Automation
- Step 04 : Generate Zone A extracts from SFTP Server via Selenium Automation
- Step 05 : Task Scheduler will verify the Zone A extract availabilty in QA batch server
- Step 06 : Once Zone A extract is available, auto-execute batch job to load the data to TDDH server
- Step 07 : Once the TDDH data doad completes, the TDDH tables are validated based on the input sheet data and report is generated
- Step 08 : Send email report to stakeholders with execution status & logs, captured output data as attachment

# In Scope Scenarios
| Sl.No | Scenario Name                                              | Automated Status |
| ----- | ---------------------------------------------------------- | ---------------: |
| 1     | Active EMP – Address change                                |        Automated |
| 2     | Active EMP – Bank account change                           |        Automated |
| 3     | Active EMP – Class Change                                  |        Automated |
| 4     | Active EMP – Department Change                             |        Automated |
| 5     | Active EMP – FTE change                                    |        Automated |
| 6.a   | Active EMP – Rank Change Promotion                         |        Automated |
| 6.b   | Active EMP – Rank Change Demotion                          |        Automated |
| 7     | Active EMP – Std. Hrs Change                               |        Automated |
| 8     | Active EMP – Work location change                          |        Automated |
| 9     | Active EMP – Domestic transfer                             |        Automated |
| 10    | Active EMP to PAID LEAVE of Absence                        |        Automated |
| 11    | Active EMP to Return from PAID LEAVE of Absence            |        Automated |
| 12    | Active EMP to Return from UNPAID LEAVE of Absence          |        Automated |
| 13    | Active EMP to UNPAID LEAVE of Absence                      |        Automated |
| 14    | Change Counselor Information                               |        Automated |
| 15    | Create Concurrent Assignment                               |        Automated |
| 16    | EMP Return from Global Assignment                          |        Automated |
| 17    | EMP Termination in Future, Current                         |        Automated |
| 18    | Employees Long Term Disability                             |        Automated |
| 19    | Legal Entity Change (Including transfer to a different LE) |        Automated |
| 20    | MC Change                                                  |        Automated |
| 21    | No show                                                    |        Automated |
| 22    | Send an EMP to Global Assignment                           |        Automated |
| 23    | Start date change                                          |        Automated |