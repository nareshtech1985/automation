# Tools, Language Details

### Version 1 
| Item                    | Description  |
| ----------------------- | ------------ |
| Visual Studio           | 2019 or 2022 |
| Microsoft .Net Framwork | 4.6.1        |
| C#                      | 7.0          |
| Selenium                | 3.141        |

