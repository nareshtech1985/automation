[Read Me!](../Readme.md)

# Workflow Overview
![workflow_img](/SF.StaticPage/img02.png)
- Step 01 : Foundation Data Creation via SF API
- Step 02 : Foundation Data Verification via SF API
- Step 03
	-	A: (CPI - Cloud Platform Integration Portal) iFlow deployment via Selenium Automation
	-	B: (SF IC - SuccessFactors Integration Center) Integration Center Package/Job Invoke by Selenium Automation
- Step 04 : Generate Zone A extracts from SFTP Server via Selenium Automation
- Step 05 : Task Scheduler will verify the Zone A extract availabilty in QA batch server
- Step 06 : Once Zone A extract is available, auto-execute batch job to load the data to TDDH server
- Step 07 : Once the TDDH data doad completes, the TDDH tables are validated based on the input sheet data and report is generated
- Step 08 : Send email report to stakeholders with execution status & logs, captured output data as attachment

# In Scope Scenarios - Automated
| SL NO | FO Object               | Automation Status |
| ----- | ----------------------- | ----------------- |
| 1     | FO_GeographicArea       | Automated         |
| 2     | FO_GeographicRegion     | Automated         |
| 3     | FO_ManagerialCountry    | Automated         |
| 4     | FO_ManagementArea       | Automated         |
| 5     | FO_ManagementRegion     | Automated         |
| 6     | FO_ManagementUnit       | Automated         |
| 7     | FO_SubManagementUnit    | Automated         |
| 8     | FO_OperatingUnit        | Automated         |
| 9     | FO_CostCenter           | Automated         |
| 10    | FO_CodeBlock            | Automated         |
| 11    | FO_Establishment        | Automated         |
| 12    | FO_CorporateAddress     | Automated         |
| 13    | FO_GeoZone              | Automated         |
| 14    | FO_Location             | Automated         |
| 15    | FO_LegalEntity          | Automated         |
| 16    | FO_Speciality           | Automated         |
| 17    | FO_ServiceLine          | Automated         |
| 18    | FO_SubServiceLine       | Automated         |
| 19    | FO_Department           | Automated         |
| 20    | FO_JobFamilyGroup       | Automated         |
| 21    | FO_JobFamily            | Automated         |
| 22    | FO_CareerLevel          | Automated         |
| 23    | FO_JobRoleType          | Automated         |
| 24    | FO_JobFunction          | Automated         |
| 25    | FO_RewardsDiversifier   | Automated         |
| 26    | FO_Rank                 | Automated         |
| 27    | FO_ServiceType          | Automated         |
| 28    | FO_PayGrade             | Automated         |
| 29    | FO_ActivityType         | Automated         |
| 30    | FO_JobClassification    | Automated         |
| 31    | FO_Frequency            | Automated         |
| 32    | FO_PayRanges            | Automated         |
| 33    | FO_PayGroup             | Automated         |
| 34    | FO_PayComponentGroup    | Automated         |
| 35    | FO_PayComponent         | Automated         |
| 36    | FO_Bank                 | Automated         |
| 37    | FO_BelgiumWeeklyHours   | Automated         |
| 38    | FO_BrazilCNPJ           | Automated         |
| 39    | FO_CurrencyExchangeRate | Automated         |
| 40    | FO_EventReason          | Automated         |
| 41    | FO_NameFormat           | Automated         |
| 42    | FO_ProficiencyLevel     | Automated         |
| 43    | FO_WorkSchedule         | Automated         |
| 44    | FO_BusinessUnit_Finance | Automated         |

# In Scope Scenarios - Non-Executable 
| FO Object           | Reason for non-execution                                                                        	|
| ------------------- | --------------------------------------------------------------------------------------------    	|
| FO_JobFamilyGroup   | Read-only entity as per SF EC API configuration. RBP is responsible for any updation  				|
| FO_JobFamily        | Read-only entity as per SF EC API configuration. RBP is responsible for any updation  				|
| FO_JobRoleType      | Read-only entity as per SF EC API configuration. RBP is responsible for any updation  				|
| FO_NameFormat       | Read-only entity as per SF EC API configuration. RBP is responsible for any updation  				|
| FO_CorporateAddress | Data cannot be directly created, instead this is covered by 'FO_Location'                       	|	