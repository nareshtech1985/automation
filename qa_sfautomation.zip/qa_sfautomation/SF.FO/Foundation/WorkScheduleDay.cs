﻿namespace SF.FOEntities
{
    using SF.Entity;
    public class WorkScheduleDay
    {
        public Metadata __metadata { get; set; } = new Metadata() { Uri = "WorkScheduleDay" };
        public string WorkSchedule_externalCode { get; set; }
        public string day { get; set; }
        public string hoursAndMinutes { get; set; }
        public string mdfSystemRecordStatus { get; set; }
        public string workingHours { get; set; }
    }
}
