﻿namespace SF.FOEntities
{
    public class JobClassificationCSFO : FO_ObjectBase, IFoundationObject
    {
    }
}