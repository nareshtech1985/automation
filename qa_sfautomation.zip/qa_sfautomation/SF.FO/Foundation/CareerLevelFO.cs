﻿namespace SF.FOEntities
{
    using Parameter;

    public class CareerLevelFO : FO_ObjectBase, IFoundationObject
    {

        [ColumnHeader(990, "Career Level Description")]
        public string cust_Description { get; set; }
    }
}