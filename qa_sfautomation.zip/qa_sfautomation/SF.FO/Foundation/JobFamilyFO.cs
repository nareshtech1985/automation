﻿namespace SF.FOEntities
{
    using Parameter;

    public class JobFamilyFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Job Family Description")] public string cust_description { get; set; }
    }
}