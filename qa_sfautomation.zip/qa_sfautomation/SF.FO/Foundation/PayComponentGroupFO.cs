﻿namespace SF.FOEntities
{
    using Parameter;

    public class PayComponentGroupFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Currency")] public string currency { get; set; }
        [ColumnHeader(990, "Pay Component ID")] public string payComponentFlx { get; set; }
        [ColumnHeader(990, "Show On Comp UI")] public bool showOnCompUI { get; set; }
        [ColumnHeader(990, "Sort Order")] public string sortOrder { get; set; }
        [ColumnHeader(990, "Status")] public string status { get; set; }
        [ColumnHeader(990, "Use For Comparatio Calc")] public bool useForComparatioCalc { get; set; }
        [ColumnHeader(990, "Use For Range Penetration")] public bool useForRangePenetration { get; set; }

    }
}