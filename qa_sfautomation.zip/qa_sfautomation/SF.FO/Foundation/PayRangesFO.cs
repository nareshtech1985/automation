﻿namespace SF.FOEntities
{
    using Parameter;

    public class PayRangesFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Currency")] public string currency { get; set; }
        [ColumnHeader(990, "Rewards Diversifier ID")] public string custRewardsDiversifierFlx { get; set; }
        [ColumnHeader(990, "Service Type ID")] public string custServiceTypeFlx { get; set; }
        [ColumnHeader(990, "Differential Percent")] public string customLong1 { get; set; }
        [ColumnHeader(990, "Frequency")] public string frequencyCode { get; set; }
        [ColumnHeader(990, "Geozone ID")] public string geozoneFlx { get; set; }
        [ColumnHeader(990, "Maximumpay")] public string maximumPay { get; set; }
        [ColumnHeader(990, "Midpoint")] public string midPoint { get; set; }
        [ColumnHeader(990, "Minimumpay")] public string minimumPay { get; set; }
        [ColumnHeader(990, "Pay Grade ID")] public string payGradeFlx { get; set; }
        [ColumnHeader(990, "Status")] public string status { get; set; }
    }
}