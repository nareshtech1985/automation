﻿namespace SF.FOEntities
{
    using Parameter;

    public class GeographicRegionFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "GeographicAreaFlx")] public string custGeographicAreaFlx { get; set; }
        [ColumnHeader(990, "Status")] public string status { get; set; }
    }
}