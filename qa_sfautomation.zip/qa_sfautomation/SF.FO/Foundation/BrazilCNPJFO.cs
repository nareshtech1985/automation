﻿namespace SF.FOEntities
{
    using Parameter;

    public class BrazilCNPJFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Custom Description")] public string cust_description { get; set; }
    }
}