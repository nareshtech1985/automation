﻿namespace SF.FOEntities
{
    using Newtonsoft.Json;
    using Parameter;

    public class EventReasonFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Empl Status")]
        public string emplStatus { get; set; }
        [ColumnHeader(990, "Event")]
        [JsonProperty(propertyName: "event")]
        public string event_ { get; set; }
        [ColumnHeader(990, "Payroll Event")]
        public string payrollEvent { get; set; }
        [ColumnHeader(990, "Status")]
        public string status { get; set; }
    }
}