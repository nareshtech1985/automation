﻿namespace SF.FOEntities
{
    using Parameter;

    public class RewardsDiversifierFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Rewards Diversifier Description")]
        public string cust_Description { get; set; }
    }
}