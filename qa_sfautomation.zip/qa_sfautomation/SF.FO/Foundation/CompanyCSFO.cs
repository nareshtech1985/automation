﻿namespace SF.FOEntities
{
    public class CompanyCSFO : FO_ObjectBase, IFoundationObject
    {
    }
}