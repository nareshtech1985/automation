﻿namespace SF.FOEntities
{
    using Parameter;

    public class ServiceLineFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Description de_DE")] public string cust_description_de_DE { get; set; }
        [ColumnHeader(990, "Description Default")] public string cust_description_defaultValue { get; set; }
        [ColumnHeader(990, "Description en_GB")] public string cust_description_en_GB { get; set; }
        [ColumnHeader(990, "Description en_US")] public string cust_description_en_US { get; set; }
        [ColumnHeader(990, "Description es_MX")] public string cust_description_es_MX { get; set; }
        [ColumnHeader(990, "Description fr_CA")] public string cust_description_fr_CA { get; set; }
        [ColumnHeader(990, "Description fr_FR")] public string cust_description_fr_FR { get; set; }
        [ColumnHeader(990, "Description iw_IL")] public string cust_description_iw_IL { get; set; }
        [ColumnHeader(990, "Description ja_JP")] public string cust_description_ja_JP { get; set; }
        [ColumnHeader(990, "Description ko_KR")] public string cust_description_ko_KR { get; set; }
        [ColumnHeader(990, "Description Local")] public string cust_description_localized { get; set; }
        [ColumnHeader(990, "Description pt_BR")] public string cust_description_pt_BR { get; set; }
        [ColumnHeader(990, "Description zh_CN")] public string cust_description_zh_CN { get; set; }
        [ColumnHeader(990, "Description zh_TW")] public string cust_description_zh_TW { get; set; }
        [ColumnHeader(990, "External Name de_DE")] public string externalName_de_DE { get; set; }
        [ColumnHeader(990, "External Name Default")] public string externalName_defaultValue { get; set; }
        [ColumnHeader(990, "External Name en_GB")] public string externalName_en_GB { get; set; }
        [ColumnHeader(990, "External Name en_US")] public string externalName_en_US { get; set; }
        [ColumnHeader(990, "External Name es_MX")] public string externalName_es_MX { get; set; }
        [ColumnHeader(990, "External Name fr_CA")] public string externalName_fr_CA { get; set; }
        [ColumnHeader(990, "External Name fr_FR")] public string externalName_fr_FR { get; set; }
        [ColumnHeader(990, "External Name iw_IL")] public string externalName_iw_IL { get; set; }
        [ColumnHeader(990, "External Name ja_JP")] public string externalName_ja_JP { get; set; }
        [ColumnHeader(990, "External Name ko_KR")] public string externalName_ko_KR { get; set; }
        [ColumnHeader(990, "External Name local")] public string externalName_localized { get; set; }
        [ColumnHeader(990, "External Name pt_BR")] public string externalName_pt_BR { get; set; }
        [ColumnHeader(990, "External Name zh_CN")] public string externalName_zh_CN { get; set; }
        [ColumnHeader(990, "External Name zh_TW")] public string externalName_zh_TW { get; set; }
    }
}