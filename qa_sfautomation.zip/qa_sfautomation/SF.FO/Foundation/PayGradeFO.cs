﻿namespace SF.FOEntities
{
    using Parameter;

    public class PayGradeFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Pay Grade level")] public string paygradeLevel { get; set; }
        [ColumnHeader(990, "Status")] public string status { get; set; }
    }
}