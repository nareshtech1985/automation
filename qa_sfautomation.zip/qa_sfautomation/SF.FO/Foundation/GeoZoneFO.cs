﻿namespace SF.FOEntities
{
    using Parameter;

    public class GeoZoneFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Adjustment Percentage")] public string adjustmentPercentage { get; set; }
        [ColumnHeader(990, "Status")] public string status { get; set; }
    }
}