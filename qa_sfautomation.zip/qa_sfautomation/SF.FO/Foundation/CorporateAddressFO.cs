﻿namespace SF.FOEntities
{
    using Parameter;

    public class CorporateAddressFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Address ID")] public string addressId { get; set; }
        [ColumnHeader(990, "Address 1")] public string address1 { get; set; }
        [ColumnHeader(990, "Address 2")] public string address2 { get; set; }
        [ColumnHeader(990, "Address 3")] public string address3 { get; set; }
        [ColumnHeader(990, "Address 4")] public string address4 { get; set; }
        [ColumnHeader(990, "Address 5")] public string address5 { get; set; }
        [ColumnHeader(990, "Address 6")] public string address6 { get; set; }
        [ColumnHeader(990, "Address 8")] public string address8 { get; set; }
        [ColumnHeader(990, "City")] public string city { get; set; }
        [ColumnHeader(990, "Country")] public string country { get; set; }
        [ColumnHeader(990, "County")] public string county { get; set; }
        [ColumnHeader(990, "Custom Long 1")] public string customLong1 { get; set; }
        [ColumnHeader(990, "Custom String 1")] public string customString1 { get; set; }
        [ColumnHeader(990, "Custom String 2")] public string customString2 { get; set; }
        [ColumnHeader(990, "Custom String 3")] public string customString3 { get; set; }
        [ColumnHeader(990, "Custom String 4")] public string customString4 { get; set; }
        [ColumnHeader(990, "Province")] public string province { get; set; }
        [ColumnHeader(990, "State")] public string state { get; set; }
        [ColumnHeader(990, "Zip Code")] public string zipCode { get; set; }
    }
}