﻿namespace SF.FOEntities
{
    using Newtonsoft.Json;
    using Parameter;
    using System;

    public class WorkScheduleFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Average Hours Per Day")] public string averageHoursPerDay { get; set; }
        [ColumnHeader(990, "Average Hours Per Month")] public string averageHoursPerMonth { get; set; }
        [ColumnHeader(990, "Average Hours Per Week")] public string averageHoursPerWeek { get; set; }
        [ColumnHeader(990, "Average Hours Per Year")] public string averageHoursPerYear { get; set; }
        [ColumnHeader(990, "Average Working Days Per Week")] public string averageWorkingDaysPerWeek { get; set; }
        [ColumnHeader(990, "Country")] public string country { get; set; }
        [ColumnHeader(990, "Cross Midnight Allowed")] public bool crossMidnightAllowed { get; set; }
        [ColumnHeader(990, "Entityuuid")] public string entityUUID { get; set; }
        [ColumnHeader(990, "External Name de_DE")] public string externalName_de_DE { get; set; }
        [ColumnHeader(990, "External Name Default")] public string externalName_defaultValue { get; set; }
        [ColumnHeader(990, "External Name en_GB")] public string externalName_en_GB { get; set; }
        [ColumnHeader(990, "External Name en_US")] public string externalName_en_US { get; set; }
        [ColumnHeader(990, "External Name es_MX")] public string externalName_es_MX { get; set; }
        [ColumnHeader(990, "External Name fr_CA")] public string externalName_fr_CA { get; set; }
        [ColumnHeader(990, "External Name fr_FR")] public string externalName_fr_FR { get; set; }
        [ColumnHeader(990, "External Name iw_IL")] public string externalName_iw_IL { get; set; }
        [ColumnHeader(990, "External Name ja_JP")] public string externalName_ja_JP { get; set; }
        [ColumnHeader(990, "External Name ko_KR")] public string externalName_ko_KR { get; set; }
        [ColumnHeader(990, "External Name local")] public string externalName_localized { get; set; }
        [ColumnHeader(990, "External Name pt_BR")] public string externalName_pt_BR { get; set; }
        [ColumnHeader(990, "External Name zh_CN")] public string externalName_zh_CN { get; set; }
        [ColumnHeader(990, "External Name zh_TW")] public string externalName_zh_TW { get; set; }
        [ColumnHeader(990, "Flexible RequestingAllowed llowed")] public bool flexibleRequestingAllowed { get; set; }
        [ColumnHeader(990, "Individual WorkSchedule")] public bool individualWorkSchedule { get; set; }
        [ColumnHeader(990, "Record Id")] public string recordId { get; set; }
        [ColumnHeader(990, "Search String")] public string searchString { get; set; }
        [ColumnHeader(990, "Shift Classification")] public string shiftClassification { get; set; }
        [ColumnHeader(990, "User Id")] public string userId { get; set; }
        public string startingDate { get => _startingDate.Equals(DateTime.MinValue) ? null : ToJsonDate(_startingDate); set => startingDate = value; }
        public string periodModel { get => _periodModel == null ? null : _periodModel.ToUpper(); set => _periodModel = value; }
        public string timeRecordingVariant { get => _timeRecordingVariant == null ? null : _timeRecordingVariant.ToUpper(); set => _timeRecordingVariant = value; }
        public string modelCategory { get => _modelCategory == null ? null : _modelCategory.ToUpper(); set => _modelCategory = value; }

        /* Custom Ignored Properties */
        [ColumnHeader(990, "Modelcategory")] [JsonIgnore()] public string _modelCategory { get; set; }
        [ColumnHeader(990, "Starting Date")] [JsonIgnore()] public DateTime _startingDate { get; set; }
        [ColumnHeader(990, "Period Model")] [JsonIgnore()] public string _periodModel { get; set; }
        [ColumnHeader(990, "Time Recording Variant")] [JsonIgnore()] public string _timeRecordingVariant { get; set; } = "DURATION";

        /* array items*/
        public WorkScheduleDay[] workScheduleDays
        {
            get

            {
                var days = new WorkScheduleDay[7];
                for (int i = 0; i < 7; i++)
                {
                    days[i] = new WorkScheduleDay()
                    {
                        WorkSchedule_externalCode = externalCode,
                        day = $"{(i + 1)}",
                        hoursAndMinutes = (i < Convert.ToInt32(averageWorkingDaysPerWeek)) ? $"{Convert.ToInt32(averageHoursPerDay):00}:00" : "00:00",
                        workingHours = (i < Convert.ToInt32(averageWorkingDaysPerWeek)) ? $"{averageHoursPerDay:0}" : "0",
                    };
                }
                return days;
            }
        }
    }
}