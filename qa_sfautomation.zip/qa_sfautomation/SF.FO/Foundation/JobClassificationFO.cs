﻿namespace SF.FOEntities
{
    using Parameter;

    public class JobClassificationFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Experiencelevel")] public string cust_Experiencelevel { get; set; }
        [ColumnHeader(990, "Job Family")] public string cust_JobFamily { get; set; }
        [ColumnHeader(990, "Job Family Group")] public string cust_JobFamilyGrp { get; set; }
        [ColumnHeader(990, "Rewards diversifier")] public string cust_RewardsDiversifier { get; set; }
        [ColumnHeader(990, "Role type")] public string cust_RoleType { get; set; }
        [ColumnHeader(990, "Activity Type")] public string cust_activity_type { get; set; }
        [ColumnHeader(990, "Career Level Code")] public string cust_careerlevel { get; set; }
        [ColumnHeader(990, "Country")] public string cust_countryProp { get; set; }
        [ColumnHeader(990, "Jobrole")] public string cust_jobrole { get; set; }
        [ColumnHeader(990, "Overtimeeligibility")] public string cust_overtimeeligibility { get; set; }
        [ColumnHeader(990, "Rank")] public string cust_ranksProp { get; set; }
        [ColumnHeader(990, "Servicetype")] public string cust_servicetype { get; set; }
        [ColumnHeader(990, "Description de_DE")] public string description_de_DE { get; set; }
        [ColumnHeader(990, "Description Default")] public string description_defaultValue { get; set; }
        [ColumnHeader(990, "Description en_GB")] public string description_en_GB { get; set; }
        [ColumnHeader(990, "Description en_US")] public string description_en_US { get; set; }
        [ColumnHeader(990, "Description es_MX")] public string description_es_MX { get; set; }
        [ColumnHeader(990, "Description fr_CA")] public string description_fr_CA { get; set; }
        [ColumnHeader(990, "Description fr_FR")] public string description_fr_FR { get; set; }
        [ColumnHeader(990, "Description iw_IL")] public string description_iw_IL { get; set; }
        [ColumnHeader(990, "Description ja_JP")] public string description_ja_JP { get; set; }
        [ColumnHeader(990, "Description ko_KR")] public string description_ko_KR { get; set; }
        [ColumnHeader(990, "Description Local")] public string description_localized { get; set; }
        [ColumnHeader(990, "Description pt_BR")] public string description_pt_BR { get; set; }
        [ColumnHeader(990, "Description zh_CN")] public string description_zh_CN { get; set; }
        [ColumnHeader(990, "Description zh_TW")] public string description_zh_TW { get; set; }
        [ColumnHeader(990, "Entityuuid")] public string entityUUID { get; set; }
        [ColumnHeader(990, "Grade")] public string grade { get; set; }
        [ColumnHeader(990, "Is FulltimeEmployee")] public bool isFulltimeEmployee { get; set; }
        [ColumnHeader(990, "Isregular")] public string isRegular { get; set; } //to be removed
        [ColumnHeader(990, "Name_De_De")] public string name_de_DE { get; set; }
        [ColumnHeader(990, "Name Default")] public string name_defaultValue { get; set; }
        [ColumnHeader(990, "Name_En_Gb")] public string name_en_GB { get; set; }
        [ColumnHeader(990, "Name_En_Us")] public string name_en_US { get; set; }
        [ColumnHeader(990, "Name_Es_Mx")] public string name_es_MX { get; set; }
        [ColumnHeader(990, "Name_Fr_Ca")] public string name_fr_CA { get; set; }
        [ColumnHeader(990, "Name_Fr_Fr")] public string name_fr_FR { get; set; }
        [ColumnHeader(990, "Name_Iw_Il")] public string name_iw_IL { get; set; }
        [ColumnHeader(990, "Name_Ja_Jp")] public string name_ja_JP { get; set; }
        [ColumnHeader(990, "Name_Ko_Kr")] public string name_ko_KR { get; set; }
        [ColumnHeader(990, "Name_Localized")] public string name_localized { get; set; }
        [ColumnHeader(990, "Name_Pt_Br")] public string name_pt_BR { get; set; }
        [ColumnHeader(990, "Name_Zh_Cn")] public string name_zh_CN { get; set; }
        [ColumnHeader(990, "Name_Zh_Tw")] public string name_zh_TW { get; set; }
        [ColumnHeader(990, "Regular Temporary")] public string regularTemporary { get; set; }
        [ColumnHeader(990, "Standard Hours")] public string standardHours { get; set; }
        [ColumnHeader(990, "Status")] public string status { get; set; }
    }
}