﻿namespace SF.FOEntities
{
    using Parameter;

    public class JobRoleTypeFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Job Role Type Description")] public string cust_description { get; set; }
    }
}