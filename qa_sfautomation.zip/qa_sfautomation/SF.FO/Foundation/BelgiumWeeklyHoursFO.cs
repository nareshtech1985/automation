﻿namespace SF.FOEntities
{
    using Parameter;

    public class BelgiumWeeklyHoursFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "FTSHRSGFIS")] public string cust_FTEHRSGFIS { get; set; }
        [ColumnHeader(990, "STSHRSGFIS")] public string cust_STDHRSGFIS { get; set; }
    }
}