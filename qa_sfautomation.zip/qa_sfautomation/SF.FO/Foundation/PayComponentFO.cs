﻿namespace SF.FOEntities
{
    using Parameter;

    public class PayComponentFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Base Pay Component Group")] public string basePayComponentGroup { get; set; }
        [ColumnHeader(990, "Can Override")] public bool canOverride { get; set; } = true;
        [ColumnHeader(990, "Currency")] public string currency { get; set; }
        [ColumnHeader(990, "Is FTE Prorated")] public string customString2 { get; set; }
        [ColumnHeader(990, "Display On SelfService")] public bool displayOnSelfService { get; set; }
        [ColumnHeader(990, "Frequency Code")] public string frequencyCode { get; set; }
        [ColumnHeader(990, "IsEarning")] public bool isEarning { get; set; }
        [ColumnHeader(990, "Is EndDate Payment")] public bool isEndDatedPayment { get; set; }
        [ColumnHeader(990, "Max FractionDigits")] public string maxFractionDigits { get; set; }
        [ColumnHeader(990, "Number")] public string number { get; set; }
        [ColumnHeader(990, "Pay ComponentType")] public string payComponentType { get; set; }
        [ColumnHeader(990, "Pay ComponentValue")] public string payComponentValue { get; set; }
        [ColumnHeader(990, "Rate")] public string rate { get; set; }
        [ColumnHeader(990, "Recurring")] public bool recurring { get; set; }
        [ColumnHeader(990, "Self Service Description")] public string selfServiceDescription { get; set; }
        [ColumnHeader(990, "Status")] public string status { get; set; }
        [ColumnHeader(990, "Target")] public bool target { get; set; }
        [ColumnHeader(990, "Tax Treatment")] public string taxTreatment { get; set; }
        [ColumnHeader(990, "Unit Of Measure")] public string unitOfMeasure { get; set; }
        [ColumnHeader(990, "Used For Comp Planning")] public string usedForCompPlanning { get; set; }
    }
}