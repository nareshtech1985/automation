﻿namespace SF.FOEntities
{
    using Parameter;

    public class LocationFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Address 1")] public string addressAddress1 { get; set; }
        [ColumnHeader(990, "Address 2")] public string addressAddress2 { get; set; }
        [ColumnHeader(990, "Address 3")] public string addressAddress3 { get; set; }
        [ColumnHeader(990, "Address 4")] public string addressAddress4 { get; set; }
        [ColumnHeader(990, "Address 5")] public string addressAddress5 { get; set; }
        [ColumnHeader(990, "Address 6")] public string addressAddress6 { get; set; }
        [ColumnHeader(990, "Address 8")] public string addressAddress8 { get; set; }
        [ColumnHeader(990, "City")] public string addressCity { get; set; }
        [ColumnHeader(990, "Country")] public string addressCountry { get; set; }
        [ColumnHeader(990, "County")] public string addressCounty { get; set; }
        [ColumnHeader(990, "Custom Long1")] public string addressCustomLong1 { get; set; }
        [ColumnHeader(990, "Address Custom String 1")] public string addressCustomString1 { get; set; }
        [ColumnHeader(990, "Address Custom String 2")] public string addressCustomString2 { get; set; }
        [ColumnHeader(990, "Address Custom String 3")] public string addressCustomString3 { get; set; }
        [ColumnHeader(990, "Address Custom String 4")] public string addressCustomString4 { get; set; }
        [ColumnHeader(990, "Province")] public string addressProvince { get; set; }
        [ColumnHeader(990, "State")] public string addressState { get; set; }
        [ColumnHeader(990, "Zip Code")] public string addressZipCode { get; set; }
        [ColumnHeader(990, "Legal Entity")] public string companyFlx { get; set; }
        [ColumnHeader(990, "GV Personnel Subarea")] public string customString2 { get; set; }
        [ColumnHeader(990, "US Affirmative Action Establishment ID")] public string customString3 { get; set; }
        [ColumnHeader(990, "Geographic Area")] public string customString7 { get; set; }
        [ColumnHeader(990, "Geozone")] public string geozoneFlx { get; set; }
        [ColumnHeader(990, "Geographic Region")] public string locationGroup { get; set; }
        [ColumnHeader(990, "Standard Hours")] public string standardHours { get; set; }
        [ColumnHeader(990, "Status")] public string status { get; set; }
        [ColumnHeader(990, "Timezone")] public string timezone { get; set; }
    }
}