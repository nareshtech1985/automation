﻿namespace SF.FOEntities
{
    using Parameter;

    public class FrequencyFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Annualization Factor")] public string annualizationFactor { get; set; }
    }
}