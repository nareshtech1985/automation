﻿namespace SF.FOEntities
{
    using Parameter;

    public class CodeBlockFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(11, "Business Unit")] public string cust_bussinessunit { get; set; }
        [ColumnHeader(12, "Management Unit")] public string cust_managementunit { get; set; }
        [ColumnHeader(13, "Operating Unit")] public string cust_operatingunit { get; set; }
        [ColumnHeader(14, "Sub Management Unit")] public string cust_submanagementunit { get; set; }
        [ColumnHeader(15, "Managerial Country")] public string cust_managerialcountry { get; set; }

    }
}