﻿namespace SF.FOEntities
{
    using Parameter;

    public class EstablishmentFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Establishment Description")] public string cust_description { get; set; }
    }
}