﻿namespace SF.FOEntities
{
    using Parameter;

    public class NameElementGO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "NameFormat External Code")] public string NameFormatGO_externalCode { get; set; }
    }
}