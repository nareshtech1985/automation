﻿namespace SF.FOEntities
{
    using Parameter;

    public class JobFamilyGroupFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(990, "Job Family Group Description")] public string cust_description { get; set; }
    }
}