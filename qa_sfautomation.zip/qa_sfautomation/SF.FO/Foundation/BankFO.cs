﻿namespace SF.FOEntities
{
    using Parameter;

    public class BankFO : FO_ObjectBase, IFoundationObject
    {
        [ColumnHeader(11, "Bank Branch")] public string bankBranch { get; set; }
        [ColumnHeader(12, "Country")] public string bankCountry { get; set; }
        [ColumnHeader(13, "Bank Name")] public string bankName { get; set; }
        [ColumnHeader(14, "Business Identifier Code")] public string businessIdentifierCode { get; set; }
        [ColumnHeader(15, "City")] public string city { get; set; }
        [ColumnHeader(16, "Bank ID")] public string cust_BankID { get; set; }
        [ColumnHeader(17, "Postal Code")] public string postalCode { get; set; }
        [ColumnHeader(18, "Routing Number")] public string routingNumber { get; set; }
        [ColumnHeader(19, "Street")] public string street { get; set; }
    }
}