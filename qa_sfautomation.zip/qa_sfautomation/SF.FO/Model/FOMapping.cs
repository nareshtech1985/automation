﻿namespace SF.Model
{
    using Newtonsoft.Json;

    public class FOMapping
    {
        [JsonProperty("FO Group")]
        public string FO_Group { get; set; }
        [JsonProperty("Execution_Order")]
        public int Execution_Order { get; set; }
        [JsonProperty("TDDH Table Name")]
        public string TDDH_Table_Name { get; set; }
        [JsonProperty("Enum Values")]
        public string Enum_Values { get; set; }
        [JsonProperty("FO Object Class Name")]
        public string FO_Object_ClassName { get; set; }
        public bool IsCPI { get; set; }
        public bool IsSFIC { get; set; }
        public string PackageName { get; set; }
        [JsonProperty("EC Entity Name")]
        public string EC_Entity_Name { get; set; }
    }
}
