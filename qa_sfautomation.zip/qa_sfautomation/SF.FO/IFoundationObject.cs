﻿namespace SF.FOEntities
{
    public interface IFoundationObject
    {
    }
}