﻿namespace SF.FOEntities
{
    using Newtonsoft.Json;
    using Parameter;
    using SF.Entity;
    using System;
    using System.Collections.Generic;
    using System.Text.RegularExpressions;


    public class FO_ObjectBase
    {
        protected List<object> fo_data = new List<object>();
        protected static string ToEpochTime(DateTime date)
        {
            TimeSpan t = date.AddDays(1) - new DateTime(1970, 1, 1);
            DateTimeOffset timeOffset = date.AddDays(1);
            int secondsSinceEpoch = (int)t.TotalSeconds;
            //Console.WriteLine($"Date: {date:d} | EPOCH Time : {secondsSinceEpoch} | EPOCH 2 : {timeOffset.ToUnixTimeMilliseconds()}");
            return timeOffset.ToUnixTimeMilliseconds().ToString();
        }

        public static DateTime ToDateTime(string epochtime) => DateTimeOffset.FromUnixTimeMilliseconds(Convert.ToInt64(Regex.Match(epochtime, @"[\d]+").Value)).DateTime;

        public static string ToJsonDate(DateTime d) => $"/Date({ToEpochTime(d)})/";

        [JsonIgnore]
        [ColumnHeader(1, "SL No")]
        public int rowKey { get; set; }

        [JsonIgnore]
        [ColumnHeader(3, "START DATE")]
        public DateTime _startDate { get; set; }
        public string startDate { get => _startDate.Equals(DateTime.MinValue) ? null : ToJsonDate(_startDate); set => startDate = value; }

        [ColumnHeader(994, "End Date")]
        public string endDate { get; set; }

        [ColumnHeader(2, "External Code")]
        public string externalCode { get; set; } = null;

        [ColumnHeader(5, "Effective Status")]
        public string effectiveStatus { get; set; }

        [JsonIgnore]
        [ColumnHeader(4, "Effective Start Date")]
        public DateTime _effectiveStartDate { get; set; }

        public string effectiveStartDate { get => _effectiveStartDate.Equals(DateTime.MinValue) ? null : ToJsonDate(_effectiveStartDate); set => startDate = value; }

        [ColumnHeader(7, "External Name")]
        public string externalName { get; set; }

        [ColumnHeader(6, "MDF Status")]
        public string mdfSystemStatus { get; set; }

        [ColumnHeader(9, "Description")]
        public string description { get; set; }

        [ColumnHeader(8, "Name")]
        public string name { get; set; }

        [JsonProperty("__metadata")]
        public Metadata metadata { get; set; }

        #region Test Data Status Related Fields

        [ColumnHeader(995, "API CALL STATUS")]
        [JsonIgnore]
        public string api_c_status { get; set; } = "No Run";

        [ColumnHeader(996, "API VALIDATION STATUS")]
        [JsonIgnore]
        public string api_v_status { get; set; } = "No Run";

        [ColumnHeader(997, "TDDH DB STATUS")]
        [JsonIgnore]
        public string db_v_status { get; set; } = "No Run";

        #endregion Test Data Status Related Fields
    }
}