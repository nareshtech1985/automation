﻿namespace SF.FOEntities
{
    public interface IFOFunction<T> where T : class
    {
        static void Generate_ZoneA_Extract() { }
        static void Create(T fo_object) { }
        static void Validate(T fo_object) { }
    }
}
