# Overview
SF API Automation is an end-to-end automation for the major components of the successfactor integrations. In this solution the main scope is further classified to Core HR Scenarios & Foundation Objects. The data is created in the EC (Successfactors) via OData API and then the data flow to the downstream is validated in TDDH db.

### Current Downstream In-Scope
| Sl No | Downstream | Automation Status |
| ----- | ---------- | ----------------- |
| 01    | TDDH       | Comepleted      |


## Workflows
| Sl No | Workflow Documentation                        | Description                       | Automation Status |
| ----- | --------------------------------------------- | --------------------------------- | ----------------- |
| 1     | [Core HR Scenario](SF.Doc\CoreHR_Workflow.md) | Scenarios related to Core HR      | Completed         |
| 2     | [Foundation Objects](SF.Doc\FO_Workflow.md)   | Scenarios for the Foundation Data | Completed         |

# Tools & Languages
- Visual Studio 2019
- C#

# Test Data Input
- Excel Workbook

# Test Data Output
- Excel Workbook

# Reference
- [Odata.org](https://www.odata.org/)
- [SAP API Hub](https://api.sap.com/)

# Key Contacts
| Sl No | Contact Name                 | Email                               | Role            |
| ----- | ---------------------------- | ----------------------------------- | --------------- |
| 01    | Shantanu L Gokhale           | shantanu.gokhale@ey.com             | Project Manager |
| 02    | K Aravind                    | k.aravind@ey.com                    | QA Lead         |
| 03    | Samson Chittillappilly Simon | samson.chittillappilly.simon@ey.com | QA Team Member  |
| 04    | Ramanatha Kamath             | ramanatha.kamath@ey.com             | QA Team Member  |

