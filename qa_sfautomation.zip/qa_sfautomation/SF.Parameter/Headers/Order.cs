﻿namespace SF.Parameter
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class Order : Attribute
    {
        int _index;
        public int Index { get => _index; }
        public Order(int index)
        {
            _index = index;
        }

        public static Dictionary<int, string> OrderedItems<T>(T t)
        {
            Dictionary<int, string> excelColumns = new Dictionary<int, string>();
            var props = t.GetType().GetProperties();
            foreach(var p in props)
            {
                try
                {
                    Order o = (Order)p.GetCustomAttributes(true).GetValue(0);
                    if (o != null)
                    {
                        excelColumns.Add(o.Index, p.Name);
                    }
                }catch(Exception e) { Console.WriteLine($"{e.Message}"); }
            }
            return excelColumns; 
        }
    }
}
