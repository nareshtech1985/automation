﻿namespace SF.Parameter
{
    using System;
    using System.Collections.Generic;

    public class ColumnHeader : Attribute
    {
        private string _columnName = "";
        private int _index = -1;

        public ColumnHeader()
        {

        }

        public ColumnHeader(int index, string columnName)
        {
            _index = index;
            _columnName = columnName;
        }

        public string ColumnName { get => _columnName; }

        public static Dictionary<int, string> OrderHeaderList<T>(T t)
        {
            Dictionary<int, string> excelColumns = new Dictionary<int, string>();
            var props = t.GetType().GetProperties();
            foreach (var p in props)
            {
                try
                {
                    ColumnHeader o = (ColumnHeader)p.GetCustomAttributes(true).GetValue(0);
                    if (o != null)
                    {
                        excelColumns.Add(o._index, o.ColumnName);
                    }
                }
                catch (Exception e) { Console.WriteLine($"{e.Message}"); }
            }
            return excelColumns;
        }

        public static Dictionary<int, string> OrderFieldist<T>(T t)
        {
            Dictionary<int, string> excelColumns = new Dictionary<int, string>();
            var props = t.GetType().GetProperties();
            foreach (var p in props)
            {
                try
                {
                    ColumnHeader o = (ColumnHeader)p.GetCustomAttributes(true).GetValue(0);
                    if (o != null)
                    {
                        excelColumns.Add(o._index, p.Name);
                    }
                }
                catch (Exception e) { Console.WriteLine($"{e.Message}"); }
            }
            return excelColumns;
        }
    }
}