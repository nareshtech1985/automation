﻿using System;

namespace SF.Parameter
{
    public class TerminateParameter : BaseParameter
    {
        public string eventReason { get; set; }
        public string emplStatus { get; set; }

        public string TerminationReason { get; set; }

        public DateTime TerminationDate { get; set; }
    }
}
