﻿namespace SF.Parameter
{
    public class BankChangeParameter : BaseParameter
    {
        [ColumnHeader(4, "Payment Type")]
        public string paymentType { get; set; }
        [ColumnHeader(5, "Payment Method")]
        public string paymentMethod { get; set; }
        [ColumnHeader(6, "Country")]
        public string country { get; set; }
        [ColumnHeader(7, "Bank Name")]
        public string bankName { get; set; }
        [ColumnHeader(8, "Account Number")]
        public string bankAccountNumber { get; set; }
        [ColumnHeader(9, "Bank Conuntry Code")]
        public string bankCountryCode { get; set; }
        [ColumnHeader(10, "Rounting Number")]
        public string routingNumber { get; set; }
        public string externalCode { get; set; }

        public string Bankinfo { get => $"{userId} - {bankName} - {bankAccountNumber} {startDate:yyyy-MM-dd}"; }
    }
}