﻿namespace SF.Parameter
{
    public class ClassChangeParameter : BaseParameter
    {
        public string employeeClass { get; set; }
        public string eventReason { get; set; }
        public string employmentType { get; set; }
        public string emplStatus { get; set; }

        public string OutputString => $"User ID : {userId} \nGUI : {personIdExternal} \nEmployee Class : {employeeClass} \nEmployee Type : {employmentType}";
    }
}
