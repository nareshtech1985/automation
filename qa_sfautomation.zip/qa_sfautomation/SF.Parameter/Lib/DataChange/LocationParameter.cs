﻿namespace SF.Parameter
{
    public class LocationParameter : DataChangeParameter
    {
    }
}