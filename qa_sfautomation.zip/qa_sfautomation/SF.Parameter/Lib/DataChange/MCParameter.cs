﻿namespace SF.Parameter
{
    public class MCParameter : DataChangeParameter
    {
    }
}
