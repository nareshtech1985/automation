﻿namespace SF.Parameter
{
    public class FTEParameter : DataChangeParameter
    {

    }
}
