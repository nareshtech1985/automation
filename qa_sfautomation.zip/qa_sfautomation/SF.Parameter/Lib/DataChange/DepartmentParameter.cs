﻿namespace SF.Parameter
{
    public class DepartmentParameter : DataChangeParameter
    {
    }
}
