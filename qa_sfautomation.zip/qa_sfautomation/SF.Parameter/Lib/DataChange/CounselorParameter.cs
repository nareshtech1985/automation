﻿namespace SF.Parameter
{
    public class CounselorParameter : DataChangeParameter
    {

    }
}
