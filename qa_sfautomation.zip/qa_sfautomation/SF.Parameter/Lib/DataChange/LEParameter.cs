﻿namespace SF.Parameter
{
    public class LEParameter : DataChangeParameter
    {
    }
}
