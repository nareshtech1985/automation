﻿namespace SF.Parameter
{
    public class RankParameter : DataChangeParameter
    {
        public string eygrade { get; set; }
        public string rankId { get; set; }
        public string activityTypeCode { get; set; }
        public string regularTemp { get; set; }
    }
}
