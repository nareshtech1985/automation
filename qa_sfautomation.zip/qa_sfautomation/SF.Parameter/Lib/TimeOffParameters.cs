﻿namespace SF.Parameter
{
    public class TimeOffParameters : BaseParameter
    {       
        public string LeaveType { get; set; }
        public string Guid { get; set; }
        public string LeaveDescription { get; set; }
        public string LeaveTypeCode { get; set; }
        public string RequestType { get; set; }
    }
}
