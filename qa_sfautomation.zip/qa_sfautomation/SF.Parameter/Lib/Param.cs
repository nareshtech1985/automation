﻿namespace SF.Parameter.Lib
{
    public class Param
    {
        public string DummaryValue { get; set; }
    }
}
