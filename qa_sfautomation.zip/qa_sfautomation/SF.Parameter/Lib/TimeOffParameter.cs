﻿namespace SF.Parameter
{
    public class TimeOffParameter : BaseParameter
    {
        [ColumnHeader(5,"External Code")]
        public string Guid { get; set; }
        [ColumnHeader(6, "Leave Description")]
        public string LeaveDescription { get; set; }
        public string LeaveType { get; set; }
        [ColumnHeader(7, "Leave Type Code")]
        public string LeaveTypeCode { get; set; }
    }
}