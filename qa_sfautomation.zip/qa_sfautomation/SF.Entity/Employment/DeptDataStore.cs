﻿namespace SF.Entity
{
    using System;
    public class DeptDataStore
    {
        public string Departmentid { get; set; }
        public DateTime Startdate { get; set; }
        public string Speciality { get; set; }
        public string ManagementRegionId { get; set; }
        public string ManagementRegionDescription { get; set; }
        public string LegalEntityId { get; set; }
        public string LegalEntityDescription { get; set; }
        public string DepartmentDescription { get; set; }
        public string ManagerialCountry { get; set; }
        public string Status { get; set; }
        public string SubServiceLine { get; set; }
        public string SubServiceLineDescription { get; set; }
        public string ServiceLine { get; set; }
        public string CodeBlock { get; set; }
    }
}
