﻿using Newtonsoft.Json;
using SF.Entity.Common;

namespace SF.Entity.Employment
{
    class EmpJob
    {
        [JsonProperty("__metadata")]
        public Metadata Metadata { get; set; }

        [JsonProperty("seqNumber")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long SeqNumber { get; set; }

        [JsonProperty("userId")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long UserId { get; set; }

        [JsonProperty("startDate")]
        public string StartDate { get; set; }

        [JsonProperty("customString131")]
        public object CustomString131 { get; set; }

        [JsonProperty("customString130")]
        public object CustomString130 { get; set; }

        [JsonProperty("customString133")]
        public object CustomString133 { get; set; }

        [JsonProperty("customString132")]
        public object CustomString132 { get; set; }

        [JsonProperty("customString42")]
        public object CustomString42 { get; set; }

        [JsonProperty("createdDateTime")]
        public string CreatedDateTime { get; set; }

        [JsonProperty("customString43")]
        public object CustomString43 { get; set; }

        [JsonProperty("customString44")]
        public object CustomString44 { get; set; }

        [JsonProperty("customString45")]
        public object CustomString45 { get; set; }

        [JsonProperty("attachmentFileSize")]
        public object AttachmentFileSize { get; set; }

        [JsonProperty("customString46")]
        public object CustomString46 { get; set; }

        [JsonProperty("customString47")]
        public object CustomString47 { get; set; }

        [JsonProperty("customString48")]
        public object CustomString48 { get; set; }

        [JsonProperty("customString49")]
        public object CustomString49 { get; set; }

        [JsonProperty("customString50")]
        public object CustomString50 { get; set; }

        [JsonProperty("customString51")]
        public object CustomString51 { get; set; }

        [JsonProperty("customString52")]
        public object CustomString52 { get; set; }

        [JsonProperty("customString135")]
        public object CustomString135 { get; set; }

        [JsonProperty("customString134")]
        public object CustomString134 { get; set; }

        [JsonProperty("occupationCri")]
        public object OccupationCri { get; set; }

        [JsonProperty("customString137")]
        public object CustomString137 { get; set; }

        [JsonProperty("customString138")]
        public object CustomString138 { get; set; }

        [JsonProperty("departmentEntryDate")]
        public string DepartmentEntryDate { get; set; }

        [JsonProperty("costCenter")]
        public object CostCenter { get; set; }

        [JsonProperty("customString122")]
        public object CustomString122 { get; set; }

        [JsonProperty("customString121")]
        public object CustomString121 { get; set; }

        [JsonProperty("customString32")]
        public object CustomString32 { get; set; }

        [JsonProperty("customString33")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long CustomString33 { get; set; }

        [JsonProperty("customString34")]
        public object CustomString34 { get; set; }

        [JsonProperty("customString35")]
        public object CustomString35 { get; set; }

        [JsonProperty("customString36")]
        public object CustomString36 { get; set; }

        [JsonProperty("customString40")]
        public object CustomString40 { get; set; }

        [JsonProperty("customString41")]
        public object CustomString41 { get; set; }

        [JsonProperty("customString124")]
        public object CustomString124 { get; set; }

        [JsonProperty("customString123")]
        public object CustomString123 { get; set; }

        [JsonProperty("customString126")]
        public object CustomString126 { get; set; }

        [JsonProperty("calcMethodIndicator")]
        public bool CalcMethodIndicator { get; set; }

        [JsonProperty("customString125")]
        public object CustomString125 { get; set; }

        [JsonProperty("customString128")]
        public object CustomString128 { get; set; }

        [JsonProperty("customString127")]
        public object CustomString127 { get; set; }

        [JsonProperty("customString129")]
        public object CustomString129 { get; set; }

        [JsonProperty("customString28")]
        public object CustomString28 { get; set; }

        [JsonProperty("customString29")]
        public object CustomString29 { get; set; }

        [JsonProperty("isFulltimeEmployee")]
        public bool IsFulltimeEmployee { get; set; }

        [JsonProperty("customString151")]
        public object CustomString151 { get; set; }

        [JsonProperty("emplStatus")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long EmplStatus { get; set; }

        [JsonProperty("customString153")]
        public object CustomString153 { get; set; }

        [JsonProperty("customString152")]
        public object CustomString152 { get; set; }

        [JsonProperty("customString155")]
        public object CustomString155 { get; set; }

        [JsonProperty("customString154")]
        public object CustomString154 { get; set; }

        [JsonProperty("countryOfCompany")]
        public string CountryOfCompany { get; set; }

        [JsonProperty("customString20")]
        public object CustomString20 { get; set; }

        [JsonProperty("customString21")]
        public string CustomString21 { get; set; }

        [JsonProperty("customString22")]
        public string CustomString22 { get; set; }

        [JsonProperty("customString23")]
        public object CustomString23 { get; set; }

        [JsonProperty("customString24")]
        public object CustomString24 { get; set; }

        [JsonProperty("customString26")]
        public object CustomString26 { get; set; }

        [JsonProperty("localJobTitle")]
        public string LocalJobTitle { get; set; }

        [JsonProperty("customString27")]
        public object CustomString27 { get; set; }

        [JsonProperty("customString30")]
        public object CustomString30 { get; set; }

        [JsonProperty("payGrade")]
        public string PayGrade { get; set; }

        [JsonProperty("travelDistance")]
        public object TravelDistance { get; set; }

        [JsonProperty("customString17")]
        public object CustomString17 { get; set; }

        [JsonProperty("customString18")]
        public string CustomString18 { get; set; }

        [JsonProperty("customString19")]
        public object CustomString19 { get; set; }

        [JsonProperty("customString142")]
        public object CustomString142 { get; set; }

        [JsonProperty("customString141")]
        public object CustomString141 { get; set; }

        [JsonProperty("customString144")]
        public object CustomString144 { get; set; }

        [JsonProperty("customString143")]
        public object CustomString143 { get; set; }

        [JsonProperty("customString10")]
        public object CustomString10 { get; set; }

        [JsonProperty("customString11")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long CustomString11 { get; set; }

        [JsonProperty("customString12")]
        public string CustomString12 { get; set; }

        [JsonProperty("managerId")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long ManagerId { get; set; }

        [JsonProperty("customString13")]
        public object CustomString13 { get; set; }

        [JsonProperty("customString14")]
        public string CustomString14 { get; set; }

        [JsonProperty("wtdHoursLimit")]
        public object WtdHoursLimit { get; set; }

        [JsonProperty("customString15")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long CustomString15 { get; set; }

        [JsonProperty("customString16")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long CustomString16 { get; set; }

        [JsonProperty("lastModifiedOn")]
        public string LastModifiedOn { get; set; }

        [JsonProperty("customString146")]
        public object CustomString146 { get; set; }

        [JsonProperty("customString145")]
        public object CustomString145 { get; set; }

        [JsonProperty("customString148")]
        public object CustomString148 { get; set; }

        [JsonProperty("customString147")]
        public object CustomString147 { get; set; }

        [JsonProperty("customString149")]
        public object CustomString149 { get; set; }

        [JsonProperty("businessUnit")]
        public string BusinessUnit { get; set; }

        [JsonProperty("lastModifiedDateTime")]
        public string LastModifiedDateTime { get; set; }

        [JsonProperty("harmfulAgentExposure")]
        public object HarmfulAgentExposure { get; set; }

        [JsonProperty("sickPaySupplement")]
        public object SickPaySupplement { get; set; }

        [JsonProperty("customDouble20")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long CustomDouble20 { get; set; }

        [JsonProperty("locationEntryDate")]
        public string LocationEntryDate { get; set; }

        [JsonProperty("holidayCalendarCode")]
        public string HolidayCalendarCode { get; set; }

        [JsonProperty("eventReason")]
        public string EventReason { get; set; }

        [JsonProperty("isCompetitionClauseActive")]
        public bool IsCompetitionClauseActive { get; set; }

        [JsonProperty("noticePeriod")]
        public object NoticePeriod { get; set; }

        [JsonProperty("continuedSicknessPayMeasure")]
        public object ContinuedSicknessPayMeasure { get; set; }

        [JsonProperty("shiftCode")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long ShiftCode { get; set; }

        [JsonProperty("regularTemp")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long RegularTemp { get; set; }

        [JsonProperty("isSideLineJobAllowed")]
        public bool IsSideLineJobAllowed { get; set; }

        [JsonProperty("company")]
        public string Company { get; set; }

        [JsonProperty("eeo1JobCategory")]
        public object Eeo1JobCategory { get; set; }

        [JsonProperty("employeeClass")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long EmployeeClass { get; set; }

        [JsonProperty("contractEndDate")]
        public object ContractEndDate { get; set; }

        [JsonProperty("pensionProtection")]
        public bool PensionProtection { get; set; }

        [JsonProperty("attachmentFileType")]
        public object AttachmentFileType { get; set; }

        [JsonProperty("createdBy")]
        public string CreatedBy { get; set; }

        [JsonProperty("contractId")]
        public object ContractId { get; set; }

        [JsonProperty("location")]
        public string Location { get; set; }

        [JsonProperty("workscheduleCode")]
        public string WorkscheduleCode { get; set; }

        [JsonProperty("endDate")]
        public string EndDate { get; set; }

        [JsonProperty("contractType")]
        public object ContractType { get; set; }

        [JsonProperty("attachmentStatus")]
        public object AttachmentStatus { get; set; }

        [JsonProperty("jobCode")]
        public string JobCode { get; set; }

        [JsonProperty("division")]
        public string Division { get; set; }

        [JsonProperty("timeTypeProfileCode")]
        public string TimeTypeProfileCode { get; set; }

        [JsonProperty("eeoClass")]
        public object EeoClass { get; set; }

        [JsonProperty("continuedSicknessPayPeriod")]
        public object ContinuedSicknessPayPeriod { get; set; }

        [JsonProperty("attachmentMimeType")]
        public object AttachmentMimeType { get; set; }

        [JsonProperty("attachmentId")]
        public object AttachmentId { get; set; }

        [JsonProperty("flsaStatus")]
        public object FlsaStatus { get; set; }

        [JsonProperty("companyEntryDate")]
        public string CompanyEntryDate { get; set; }

        [JsonProperty("customDate24")]
        public object CustomDate24 { get; set; }

        [JsonProperty("customDate23")]
        public object CustomDate23 { get; set; }

        [JsonProperty("customDate25")]
        public object CustomDate25 { get; set; }

        [JsonProperty("occupationGtm")]
        public object OccupationGtm { get; set; }

        [JsonProperty("customDate22")]
        public object CustomDate22 { get; set; }

        [JsonProperty("payScaleType")]
        public object PayScaleType { get; set; }

        [JsonProperty("customDate21")]
        public object CustomDate21 { get; set; }

        [JsonProperty("customDouble2")]
        public object CustomDouble2 { get; set; }

        [JsonProperty("createdOn")]
        public string CreatedOn { get; set; }

        [JsonProperty("customDouble3")]
        public object CustomDouble3 { get; set; }

        [JsonProperty("customDouble4")]
        public object CustomDouble4 { get; set; }

        [JsonProperty("customDouble5")]
        public object CustomDouble5 { get; set; }

        [JsonProperty("healthRisk")]
        public bool HealthRisk { get; set; }

        [JsonProperty("customDouble1")]
        public object CustomDouble1 { get; set; }

        [JsonProperty("fte")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long Fte { get; set; }

        [JsonProperty("customDate13")]
        public object CustomDate13 { get; set; }

        [JsonProperty("customDate12")]
        public object CustomDate12 { get; set; }

        [JsonProperty("customDate15")]
        public object CustomDate15 { get; set; }

        [JsonProperty("customDate14")]
        public object CustomDate14 { get; set; }

        [JsonProperty("event")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long Event { get; set; }

        [JsonProperty("customDate11")]
        public object CustomDate11 { get; set; }

        [JsonProperty("customDate10")]
        public object CustomDate10 { get; set; }

        [JsonProperty("teachersPension")]
        public bool TeachersPension { get; set; }

        [JsonProperty("workerCategory")]
        public object WorkerCategory { get; set; }

        [JsonProperty("contractDate")]
        public object ContractDate { get; set; }

        [JsonProperty("attachmentFileName")]
        public object AttachmentFileName { get; set; }

        [JsonProperty("jobTitle")]
        public string JobTitle { get; set; }

        [JsonProperty("customString86")]
        public object CustomString86 { get; set; }

        [JsonProperty("customString88")]
        public object CustomString88 { get; set; }

        [JsonProperty("customString89")]
        public object CustomString89 { get; set; }

        [JsonProperty("customString90")]
        public object CustomString90 { get; set; }

        [JsonProperty("customString91")]
        public object CustomString91 { get; set; }

        [JsonProperty("standardHours")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long StandardHours { get; set; }

        [JsonProperty("customString75")]
        public object CustomString75 { get; set; }

        [JsonProperty("customString76")]
        public object CustomString76 { get; set; }

        [JsonProperty("customString77")]
        public object CustomString77 { get; set; }

        [JsonProperty("customString78")]
        public object CustomString78 { get; set; }

        [JsonProperty("customString79")]
        public object CustomString79 { get; set; }

        [JsonProperty("jobEntryDate")]
        public string JobEntryDate { get; set; }

        [JsonProperty("customString80")]
        public object CustomString80 { get; set; }

        [JsonProperty("customString81")]
        public object CustomString81 { get; set; }

        [JsonProperty("customString82")]
        public object CustomString82 { get; set; }

        [JsonProperty("customString83")]
        public object CustomString83 { get; set; }

        [JsonProperty("customString84")]
        public object CustomString84 { get; set; }

        [JsonProperty("customString85")]
        public object CustomString85 { get; set; }

        [JsonProperty("payScaleArea")]
        public object PayScaleArea { get; set; }

        [JsonProperty("probationPeriodEndDate")]
        public object ProbationPeriodEndDate { get; set; }

        [JsonProperty("timezone")]
        public string Timezone { get; set; }

        [JsonProperty("workingDaysPerWeek")]
        public object WorkingDaysPerWeek { get; set; }

        [JsonProperty("customString64")]
        public object CustomString64 { get; set; }

        [JsonProperty("customString65")]
        public object CustomString65 { get; set; }

        [JsonProperty("customString66")]
        public object CustomString66 { get; set; }

        [JsonProperty("customString67")]
        public object CustomString67 { get; set; }

        [JsonProperty("customString68")]
        public object CustomString68 { get; set; }

        [JsonProperty("customString69")]
        public object CustomString69 { get; set; }

        [JsonProperty("customDate7")]
        public object CustomDate7 { get; set; }

        [JsonProperty("customDate9")]
        public object CustomDate9 { get; set; }

        [JsonProperty("customString70")]
        public object CustomString70 { get; set; }

        [JsonProperty("attachment")]
        public object Attachment { get; set; }

        [JsonProperty("customString71")]
        public object CustomString71 { get; set; }

        [JsonProperty("customString72")]
        public object CustomString72 { get; set; }

        [JsonProperty("customString73")]
        public object CustomString73 { get; set; }

        [JsonProperty("customString74")]
        public object CustomString74 { get; set; }

        [JsonProperty("customString112")]
        public object CustomString112 { get; set; }

        [JsonProperty("customDate3")]
        public object CustomDate3 { get; set; }

        [JsonProperty("department")]
        public string Department { get; set; }

        [JsonProperty("customDate5")]
        public object CustomDate5 { get; set; }

        [JsonProperty("customDate6")]
        public object CustomDate6 { get; set; }

        [JsonProperty("workingTimeDirective")]
        public bool WorkingTimeDirective { get; set; }

        [JsonProperty("employmentType")]
        [JsonConverter(typeof(ParseStringConverter))]
        public long EmploymentType { get; set; }

        [JsonProperty("lastModifiedBy")]
        public string LastModifiedBy { get; set; }

        [JsonProperty("customString5")]
        public string CustomString5 { get; set; }

        [JsonProperty("customString53")]
        public object CustomString53 { get; set; }

        [JsonProperty("customString4")]
        public string CustomString4 { get; set; }

        [JsonProperty("customString54")]
        public object CustomString54 { get; set; }

        [JsonProperty("customString3")]
        public string CustomString3 { get; set; }

        [JsonProperty("customString55")]
        public object CustomString55 { get; set; }

        [JsonProperty("customString2")]
        public string CustomString2 { get; set; }

        [JsonProperty("customString56")]
        public object CustomString56 { get; set; }

        [JsonProperty("customString57")]
        public object CustomString57 { get; set; }

        [JsonProperty("customString9")]
        public object CustomString9 { get; set; }

        [JsonProperty("tupeOrgNumber")]
        public object TupeOrgNumber { get; set; }

        [JsonProperty("customString58")]
        public object CustomString58 { get; set; }

        [JsonProperty("customString8")]
        public object CustomString8 { get; set; }

        [JsonProperty("customString59")]
        public object CustomString59 { get; set; }

        [JsonProperty("customString7")]
        public string CustomString7 { get; set; }

        [JsonProperty("customString6")]
        public string CustomString6 { get; set; }

        [JsonProperty("customString60")]
        public object CustomString60 { get; set; }

        [JsonProperty("customString61")]
        public object CustomString61 { get; set; }

        [JsonProperty("customString62")]
        public object CustomString62 { get; set; }

        [JsonProperty("customString63")]
        public object CustomString63 { get; set; }

        [JsonProperty("customString64Nav")]
        public Nav CustomString64Nav { get; set; }

        [JsonProperty("customString35Nav")]
        public Nav CustomString35Nav { get; set; }

        [JsonProperty("customString70Nav")]
        public Nav CustomString70Nav { get; set; }

        [JsonProperty("customString58Nav")]
        public Nav CustomString58Nav { get; set; }

        [JsonProperty("holidayCalendarCodeNav")]
        public Nav HolidayCalendarCodeNav { get; set; }

        [JsonProperty("customString29Nav")]
        public Nav CustomString29Nav { get; set; }

        [JsonProperty("customString143Nav")]
        public Nav CustomString143Nav { get; set; }

        [JsonProperty("companyNav")]
        public Nav CompanyNav { get; set; }

        [JsonProperty("customString154Nav")]
        public Nav CustomString154Nav { get; set; }

        [JsonProperty("customString75Nav")]
        public Nav CustomString75Nav { get; set; }

        [JsonProperty("customString81Nav")]
        public Nav CustomString81Nav { get; set; }

        [JsonProperty("customString47Nav")]
        public Nav CustomString47Nav { get; set; }

        [JsonProperty("payScaleAreaNav")]
        public Nav PayScaleAreaNav { get; set; }

        [JsonProperty("customString12Nav")]
        public Nav CustomString12Nav { get; set; }

        [JsonProperty("businessUnitNav")]
        public Nav BusinessUnitNav { get; set; }

        [JsonProperty("customString18Nav")]
        public Nav CustomString18Nav { get; set; }

        [JsonProperty("contractTypeNav")]
        public Nav ContractTypeNav { get; set; }

        [JsonProperty("customString7Nav")]
        public Nav CustomString7Nav { get; set; }

        [JsonProperty("costCenterNav")]
        public Nav CostCenterNav { get; set; }

        [JsonProperty("customString46Nav")]
        public Nav CustomString46Nav { get; set; }

        [JsonProperty("customString69Nav")]
        public Nav CustomString69Nav { get; set; }

        [JsonProperty("customString88Nav")]
        public Nav CustomString88Nav { get; set; }

        [JsonProperty("employmentTypeNav")]
        public Nav EmploymentTypeNav { get; set; }

        [JsonProperty("userNav")]
        public Nav UserNav { get; set; }

        [JsonProperty("customString13Nav")]
        public Nav CustomString13Nav { get; set; }

        [JsonProperty("customString2Nav")]
        public Nav CustomString2Nav { get; set; }

        [JsonProperty("customString63Nav")]
        public Nav CustomString63Nav { get; set; }

        [JsonProperty("timeTypeProfileCodeNav")]
        public Nav TimeTypeProfileCodeNav { get; set; }

        [JsonProperty("customString52Nav")]
        public Nav CustomString52Nav { get; set; }

        [JsonProperty("divisionNav")]
        public Nav DivisionNav { get; set; }

        [JsonProperty("customString24Nav")]
        public Nav CustomString24Nav { get; set; }

        [JsonProperty("customString142Nav")]
        public Nav CustomString142Nav { get; set; }

        [JsonProperty("customString153Nav")]
        public Nav CustomString153Nav { get; set; }

        [JsonProperty("customString16Nav")]
        public Nav CustomString16Nav { get; set; }

        [JsonProperty("workscheduleCodeNav")]
        public Nav WorkscheduleCodeNav { get; set; }

        [JsonProperty("sickPaySupplementNav")]
        public Nav SickPaySupplementNav { get; set; }

        [JsonProperty("customString45Nav")]
        public Nav CustomString45Nav { get; set; }

        [JsonProperty("customString22Nav")]
        public Nav CustomString22Nav { get; set; }

        [JsonProperty("employmentNav")]
        public Nav EmploymentNav { get; set; }

        [JsonProperty("customString80Nav")]
        public Nav CustomString80Nav { get; set; }

        [JsonProperty("customString74Nav")]
        public Nav CustomString74Nav { get; set; }

        [JsonProperty("customString51Nav")]
        public Nav CustomString51Nav { get; set; }

        [JsonProperty("workerCategoryNav")]
        public Nav WorkerCategoryNav { get; set; }

        [JsonProperty("customString147Nav")]
        public Nav CustomString147Nav { get; set; }

        [JsonProperty("countryOfCompanyNav")]
        public Nav CountryOfCompanyNav { get; set; }

        [JsonProperty("customString40Nav")]
        public Nav CustomString40Nav { get; set; }

        [JsonProperty("customString112Nav")]
        public Nav CustomString112Nav { get; set; }

        [JsonProperty("customString8Nav")]
        public Nav CustomString8Nav { get; set; }

        [JsonProperty("customString33Nav")]
        public Nav CustomString33Nav { get; set; }

        [JsonProperty("eventNav")]
        public Nav EventNav { get; set; }

        [JsonProperty("customString68Nav")]
        public Nav CustomString68Nav { get; set; }

        [JsonProperty("customString85Nav")]
        public Nav CustomString85Nav { get; set; }

        [JsonProperty("customString89Nav")]
        public Nav CustomString89Nav { get; set; }

        [JsonProperty("occupationCriNav")]
        public Nav OccupationCriNav { get; set; }

        [JsonProperty("customString3Nav")]
        public Nav CustomString3Nav { get; set; }

        [JsonProperty("customString62Nav")]
        public Nav CustomString62Nav { get; set; }

        [JsonProperty("occupationGtmNav")]
        public Nav OccupationGtmNav { get; set; }

        [JsonProperty("customString79Nav")]
        public Nav CustomString79Nav { get; set; }

        [JsonProperty("customString34Nav")]
        public Nav CustomString34Nav { get; set; }

        [JsonProperty("customString11Nav")]
        public Nav CustomString11Nav { get; set; }

        [JsonProperty("jobCodeNav")]
        public Nav JobCodeNav { get; set; }

        [JsonProperty("customString152Nav")]
        public Nav CustomString152Nav { get; set; }

        [JsonProperty("customString90Nav")]
        public Nav CustomString90Nav { get; set; }

        [JsonProperty("emplStatusNav")]
        public Nav EmplStatusNav { get; set; }

        [JsonProperty("customString67Nav")]
        public Nav CustomString67Nav { get; set; }

        [JsonProperty("customString17Nav")]
        public Nav CustomString17Nav { get; set; }

        [JsonProperty("customString73Nav")]
        public Nav CustomString73Nav { get; set; }

        [JsonProperty("customString28Nav")]
        public Nav CustomString28Nav { get; set; }

        [JsonProperty("customString146Nav")]
        public Nav CustomString146Nav { get; set; }

        [JsonProperty("noticePeriodNav")]
        public Nav NoticePeriodNav { get; set; }

        [JsonProperty("customString78Nav")]
        public Nav CustomString78Nav { get; set; }

        [JsonProperty("customString55Nav")]
        public Nav CustomString55Nav { get; set; }

        [JsonProperty("customString9Nav")]
        public Nav CustomString9Nav { get; set; }

        [JsonProperty("customString84Nav")]
        public Nav CustomString84Nav { get; set; }

        [JsonProperty("customString4Nav")]
        public Nav CustomString4Nav { get; set; }

        [JsonProperty("customString44Nav")]
        public Nav CustomString44Nav { get; set; }

        [JsonProperty("customString61Nav")]
        public Nav CustomString61Nav { get; set; }

        [JsonProperty("customString50Nav")]
        public Nav CustomString50Nav { get; set; }

        [JsonProperty("customString26Nav")]
        public Nav CustomString26Nav { get; set; }

        [JsonProperty("departmentNav")]
        public Nav DepartmentNav { get; set; }

        [JsonProperty("customString66Nav")]
        public Nav CustomString66Nav { get; set; }

        [JsonProperty("customString91Nav")]
        public Nav CustomString91Nav { get; set; }

        [JsonProperty("customString43Nav")]
        public Nav CustomString43Nav { get; set; }

        [JsonProperty("continuedSicknessPayMeasureNav")]
        public Nav ContinuedSicknessPayMeasureNav { get; set; }

        [JsonProperty("customString151Nav")]
        public Nav CustomString151Nav { get; set; }

        [JsonProperty("payScaleTypeNav")]
        public Nav PayScaleTypeNav { get; set; }

        [JsonProperty("customString27Nav")]
        public Nav CustomString27Nav { get; set; }

        [JsonProperty("customString72Nav")]
        public Nav CustomString72Nav { get; set; }

        [JsonProperty("customString122Nav")]
        public Nav CustomString122Nav { get; set; }

        [JsonProperty("customString145Nav")]
        public Nav CustomString145Nav { get; set; }

        [JsonProperty("harmfulAgentExposureNav")]
        public Nav HarmfulAgentExposureNav { get; set; }

        [JsonProperty("flsaStatusNav")]
        public Nav FlsaStatusNav { get; set; }

        [JsonProperty("shiftCodeNav")]
        public Nav ShiftCodeNav { get; set; }

        [JsonProperty("customString21Nav")]
        public Nav CustomString21Nav { get; set; }

        [JsonProperty("customString77Nav")]
        public Nav CustomString77Nav { get; set; }

        [JsonProperty("customString49Nav")]
        public Nav CustomString49Nav { get; set; }

        [JsonProperty("customString10Nav")]
        public Nav CustomString10Nav { get; set; }

        [JsonProperty("customString83Nav")]
        public Nav CustomString83Nav { get; set; }

        [JsonProperty("eeoClassNav")]
        public Nav EeoClassNav { get; set; }

        [JsonProperty("customString60Nav")]
        public Nav CustomString60Nav { get; set; }

        [JsonProperty("customString5Nav")]
        public Nav CustomString5Nav { get; set; }

        [JsonProperty("customString48Nav")]
        public Nav CustomString48Nav { get; set; }

        [JsonProperty("customString65Nav")]
        public Nav CustomString65Nav { get; set; }

        [JsonProperty("customString86Nav")]
        public Nav CustomString86Nav { get; set; }

        [JsonProperty("customString19Nav")]
        public Nav CustomString19Nav { get; set; }

        [JsonProperty("customString36Nav")]
        public Nav CustomString36Nav { get; set; }

        [JsonProperty("customString71Nav")]
        public Nav CustomString71Nav { get; set; }

        [JsonProperty("managerEmploymentNav")]
        public Nav ManagerEmploymentNav { get; set; }

        [JsonProperty("customString54Nav")]
        public Nav CustomString54Nav { get; set; }

        [JsonProperty("customString144Nav")]
        public Nav CustomString144Nav { get; set; }

        [JsonProperty("managerUserNav")]
        public Nav ManagerUserNav { get; set; }

        [JsonProperty("customString149Nav")]
        public Nav CustomString149Nav { get; set; }

        [JsonProperty("locationNav")]
        public Nav LocationNav { get; set; }

        [JsonProperty("customString20Nav")]
        public Nav CustomString20Nav { get; set; }

        [JsonProperty("regularTempNav")]
        public Nav RegularTempNav { get; set; }

        [JsonProperty("customString76Nav")]
        public Nav CustomString76Nav { get; set; }

        [JsonProperty("eventReasonNav")]
        public Nav EventReasonNav { get; set; }

        [JsonProperty("customString53Nav")]
        public Nav CustomString53Nav { get; set; }

        [JsonProperty("customString82Nav")]
        public Nav CustomString82Nav { get; set; }

        [JsonProperty("employeeClassNav")]
        public Nav EmployeeClassNav { get; set; }

        [JsonProperty("customString42Nav")]
        public Nav CustomString42Nav { get; set; }

        [JsonProperty("customString59Nav")]
        public Nav CustomString59Nav { get; set; }

        [JsonProperty("customString6Nav")]
        public Nav CustomString6Nav { get; set; }

        [JsonProperty("wfRequestNav")]
        public Nav WfRequestNav { get; set; }

        [JsonProperty("eeo1JobCategoryNav")]
        public Nav Eeo1JobCategoryNav { get; set; }

        [JsonProperty("payGradeNav")]
        public Nav PayGradeNav { get; set; }
    }
}