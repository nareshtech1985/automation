Write-Host "Starting cleanup activity"
Stop-Process -name "chromedriver" -Force -ErrorAction SilentlyContinue
Stop-Process -name "msedgedriver" -Force -ErrorAction SilentlyContinue
Stop-Process -name "msedge" -Force -ErrorAction SilentlyContinue
#Stop-Process -name "chrome" -Force -ErrorAction SilentlyContinue 
Write-Host "Clean up completed"